--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: career; Type: TABLE; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE TABLE career (
    id bigint NOT NULL,
    sector_id bigint NOT NULL,
    title character varying(100000) NOT NULL,
    count bigint,
    education_subjects_total bigint,
    education_institutes_total bigint,
    previous_titles_total bigint,
    next_titles_total bigint,
    visible boolean NOT NULL
);


ALTER TABLE career OWNER TO geektalent;

--
-- Name: career_company; Type: TABLE; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE TABLE career_company (
    id bigint NOT NULL,
    career_id bigint NOT NULL,
    company_name character varying(100000) NOT NULL,
    total_count bigint,
    title_count bigint,
    company_count bigint,
    count bigint,
    relevance_score double precision,
    visible boolean NOT NULL
);


ALTER TABLE career_company OWNER TO geektalent;

--
-- Name: career_company_id_seq; Type: SEQUENCE; Schema: public; Owner: geektalent
--

CREATE SEQUENCE career_company_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE career_company_id_seq OWNER TO geektalent;

--
-- Name: career_company_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geektalent
--

ALTER SEQUENCE career_company_id_seq OWNED BY career_company.id;


--
-- Name: career_id_seq; Type: SEQUENCE; Schema: public; Owner: geektalent
--

CREATE SEQUENCE career_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE career_id_seq OWNER TO geektalent;

--
-- Name: career_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geektalent
--

ALTER SEQUENCE career_id_seq OWNED BY career.id;


--
-- Name: career_institute; Type: TABLE; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE TABLE career_institute (
    id bigint NOT NULL,
    career_id bigint NOT NULL,
    institute_name character varying(100000) NOT NULL,
    count bigint,
    visible boolean NOT NULL
);


ALTER TABLE career_institute OWNER TO geektalent;

--
-- Name: career_institute_id_seq; Type: SEQUENCE; Schema: public; Owner: geektalent
--

CREATE SEQUENCE career_institute_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE career_institute_id_seq OWNER TO geektalent;

--
-- Name: career_institute_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geektalent
--

ALTER SEQUENCE career_institute_id_seq OWNED BY career_institute.id;


--
-- Name: career_skill; Type: TABLE; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE TABLE career_skill (
    id bigint NOT NULL,
    career_id bigint NOT NULL,
    skill_name character varying(100000) NOT NULL,
    total_count bigint,
    title_count bigint,
    skill_count bigint,
    count bigint,
    relevance_score double precision,
    visible boolean NOT NULL
);


ALTER TABLE career_skill OWNER TO geektalent;

--
-- Name: career_skill_id_seq; Type: SEQUENCE; Schema: public; Owner: geektalent
--

CREATE SEQUENCE career_skill_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE career_skill_id_seq OWNER TO geektalent;

--
-- Name: career_skill_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geektalent
--

ALTER SEQUENCE career_skill_id_seq OWNED BY career_skill.id;


--
-- Name: career_subject; Type: TABLE; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE TABLE career_subject (
    id bigint NOT NULL,
    career_id bigint NOT NULL,
    subject_name character varying(100000) NOT NULL,
    count bigint,
    visible boolean NOT NULL
);


ALTER TABLE career_subject OWNER TO geektalent;

--
-- Name: career_subject_id_seq; Type: SEQUENCE; Schema: public; Owner: geektalent
--

CREATE SEQUENCE career_subject_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE career_subject_id_seq OWNER TO geektalent;

--
-- Name: career_subject_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geektalent
--

ALTER SEQUENCE career_subject_id_seq OWNED BY career_subject.id;


--
-- Name: entity_description; Type: TABLE; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE TABLE entity_description (
    id bigint NOT NULL,
    entity_type character varying(20),
    linkedin_sector character varying(100000),
    entity_name character varying(100000),
    match_count integer,
    short_description character varying(100000),
    description character varying(100000),
    description_url character varying(100000),
    description_source character varying(100000),
    edited boolean NOT NULL
);


ALTER TABLE entity_description OWNER TO geektalent;

--
-- Name: entity_description_id_seq; Type: SEQUENCE; Schema: public; Owner: geektalent
--

CREATE SEQUENCE entity_description_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE entity_description_id_seq OWNER TO geektalent;

--
-- Name: entity_description_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geektalent
--

ALTER SEQUENCE entity_description_id_seq OWNED BY entity_description.id;


--
-- Name: next_title; Type: TABLE; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE TABLE next_title (
    id bigint NOT NULL,
    career_id bigint NOT NULL,
    next_title character varying(100000) NOT NULL,
    count bigint,
    visible boolean NOT NULL
);


ALTER TABLE next_title OWNER TO geektalent;

--
-- Name: next_title_id_seq; Type: SEQUENCE; Schema: public; Owner: geektalent
--

CREATE SEQUENCE next_title_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE next_title_id_seq OWNER TO geektalent;

--
-- Name: next_title_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geektalent
--

ALTER SEQUENCE next_title_id_seq OWNED BY next_title.id;


--
-- Name: previous_title; Type: TABLE; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE TABLE previous_title (
    id bigint NOT NULL,
    career_id bigint NOT NULL,
    previous_title character varying(100000) NOT NULL,
    count bigint,
    visible boolean NOT NULL
);


ALTER TABLE previous_title OWNER TO geektalent;

--
-- Name: previous_title_id_seq; Type: SEQUENCE; Schema: public; Owner: geektalent
--

CREATE SEQUENCE previous_title_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE previous_title_id_seq OWNER TO geektalent;

--
-- Name: previous_title_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geektalent
--

ALTER SEQUENCE previous_title_id_seq OWNED BY previous_title.id;


--
-- Name: salary_bin; Type: TABLE; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE TABLE salary_bin (
    id bigint NOT NULL,
    career_id bigint NOT NULL,
    lower_bound double precision,
    upper_bound double precision,
    count integer
);


ALTER TABLE salary_bin OWNER TO geektalent;

--
-- Name: salary_bin_id_seq; Type: SEQUENCE; Schema: public; Owner: geektalent
--

CREATE SEQUENCE salary_bin_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE salary_bin_id_seq OWNER TO geektalent;

--
-- Name: salary_bin_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geektalent
--

ALTER SEQUENCE salary_bin_id_seq OWNED BY salary_bin.id;


--
-- Name: salary_history_point; Type: TABLE; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE TABLE salary_history_point (
    id bigint NOT NULL,
    career_id bigint NOT NULL,
    date date,
    salary double precision
);


ALTER TABLE salary_history_point OWNER TO geektalent;

--
-- Name: salary_history_point_id_seq; Type: SEQUENCE; Schema: public; Owner: geektalent
--

CREATE SEQUENCE salary_history_point_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE salary_history_point_id_seq OWNER TO geektalent;

--
-- Name: salary_history_point_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geektalent
--

ALTER SEQUENCE salary_history_point_id_seq OWNED BY salary_history_point.id;


--
-- Name: sector; Type: TABLE; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE TABLE sector (
    id bigint NOT NULL,
    name character varying(100000) NOT NULL,
    count bigint,
    total_count bigint,
    education_subjects_total bigint,
    education_institutes_total bigint,
    visible boolean NOT NULL
);


ALTER TABLE sector OWNER TO geektalent;

--
-- Name: sector_company; Type: TABLE; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE TABLE sector_company (
    id bigint NOT NULL,
    sector_id bigint NOT NULL,
    company_name character varying(100000) NOT NULL,
    total_count bigint,
    sector_count bigint,
    company_count bigint,
    count bigint,
    relevance_score double precision,
    visible boolean NOT NULL
);


ALTER TABLE sector_company OWNER TO geektalent;

--
-- Name: sector_company_id_seq; Type: SEQUENCE; Schema: public; Owner: geektalent
--

CREATE SEQUENCE sector_company_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sector_company_id_seq OWNER TO geektalent;

--
-- Name: sector_company_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geektalent
--

ALTER SEQUENCE sector_company_id_seq OWNED BY sector_company.id;


--
-- Name: sector_id_seq; Type: SEQUENCE; Schema: public; Owner: geektalent
--

CREATE SEQUENCE sector_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sector_id_seq OWNER TO geektalent;

--
-- Name: sector_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geektalent
--

ALTER SEQUENCE sector_id_seq OWNED BY sector.id;


--
-- Name: sector_institute; Type: TABLE; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE TABLE sector_institute (
    id bigint NOT NULL,
    sector_id bigint NOT NULL,
    institute_name character varying(100000) NOT NULL,
    count bigint,
    visible boolean NOT NULL
);


ALTER TABLE sector_institute OWNER TO geektalent;

--
-- Name: sector_institute_id_seq; Type: SEQUENCE; Schema: public; Owner: geektalent
--

CREATE SEQUENCE sector_institute_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sector_institute_id_seq OWNER TO geektalent;

--
-- Name: sector_institute_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geektalent
--

ALTER SEQUENCE sector_institute_id_seq OWNED BY sector_institute.id;


--
-- Name: sector_skill; Type: TABLE; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE TABLE sector_skill (
    id bigint NOT NULL,
    sector_id bigint NOT NULL,
    skill_name character varying(100000) NOT NULL,
    total_count bigint,
    sector_count bigint,
    skill_count bigint,
    count bigint,
    relevance_score double precision,
    visible boolean NOT NULL
);


ALTER TABLE sector_skill OWNER TO geektalent;

--
-- Name: sector_skill_id_seq; Type: SEQUENCE; Schema: public; Owner: geektalent
--

CREATE SEQUENCE sector_skill_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sector_skill_id_seq OWNER TO geektalent;

--
-- Name: sector_skill_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geektalent
--

ALTER SEQUENCE sector_skill_id_seq OWNED BY sector_skill.id;


--
-- Name: sector_subject; Type: TABLE; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE TABLE sector_subject (
    id bigint NOT NULL,
    sector_id bigint NOT NULL,
    subject_name character varying(100000) NOT NULL,
    count bigint,
    visible boolean NOT NULL
);


ALTER TABLE sector_subject OWNER TO geektalent;

--
-- Name: sector_subject_id_seq; Type: SEQUENCE; Schema: public; Owner: geektalent
--

CREATE SEQUENCE sector_subject_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE sector_subject_id_seq OWNER TO geektalent;

--
-- Name: sector_subject_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: geektalent
--

ALTER SEQUENCE sector_subject_id_seq OWNED BY sector_subject.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY career ALTER COLUMN id SET DEFAULT nextval('career_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY career_company ALTER COLUMN id SET DEFAULT nextval('career_company_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY career_institute ALTER COLUMN id SET DEFAULT nextval('career_institute_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY career_skill ALTER COLUMN id SET DEFAULT nextval('career_skill_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY career_subject ALTER COLUMN id SET DEFAULT nextval('career_subject_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY entity_description ALTER COLUMN id SET DEFAULT nextval('entity_description_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY next_title ALTER COLUMN id SET DEFAULT nextval('next_title_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY previous_title ALTER COLUMN id SET DEFAULT nextval('previous_title_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY salary_bin ALTER COLUMN id SET DEFAULT nextval('salary_bin_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY salary_history_point ALTER COLUMN id SET DEFAULT nextval('salary_history_point_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY sector ALTER COLUMN id SET DEFAULT nextval('sector_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY sector_company ALTER COLUMN id SET DEFAULT nextval('sector_company_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY sector_institute ALTER COLUMN id SET DEFAULT nextval('sector_institute_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY sector_skill ALTER COLUMN id SET DEFAULT nextval('sector_skill_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY sector_subject ALTER COLUMN id SET DEFAULT nextval('sector_subject_id_seq'::regclass);


--
-- Data for Name: career; Type: TABLE DATA; Schema: public; Owner: geektalent
--

COPY career (id, sector_id, title, count, education_subjects_total, education_institutes_total, previous_titles_total, next_titles_total, visible) FROM stdin;
1	1	Project Manager	6009	1062	1670	1713	1258	t
2	1	Management Consultant	5290	942	1409	1688	1476	t
3	1	IT Manager	60404	14266	18508	5159	5369	t
4	1	IT Consultant	32697	8088	10932	3531	2950	t
5	1	Business Analyst	1896	415	548	604	470	t
6	1	IT Service Manager	3322	475	697	943	784	t
7	1	Network Engineer	4987	699	1034	549	539	t
8	1	Software Developer	33573	12407	14838	2837	3037	t
9	1	Data Analyst	11543	3079	4735	1561	1643	t
10	1	Test Analyst	11546	2833	3424	932	847	t
11	1	Web Developer	3401	910	1047	596	639	t
12	1	Web Designer	677	49	16	187	225	t
13	1	Database Administrator	2242	463	510	263	254	t
14	1	Digital Marketer	2223	169	219	360	272	t
15	1	Animator	1010	196	314	164	172	t
16	1	Cyber Security Analyst	1422	176	215	86	43	t
17	1	IT Trainer	111	0	0	42	46	t
18	1	Data Scientist	199	49	54	70	28	t
19	1	Game Developer	302	51	24	58	70	t
20	1	Game Designer	215	32	28	35	24	t
53	5	Sales Director	456	5	0	403	294	t
54	6	Mechanical/Design Engineer	384	82	40	98	94	t
41	5	Service Advisor	630	12	12	88	98	t
42	5	Sales Executive	1748	52	14	876	1122	t
43	6	Vehicle Technician	1536	20	0	23	60	t
44	5	Sales Manager	1857	97	43	1099	1076	t
45	5	Business Manager	618	20	7	608	469	t
46	5	Parts Manager	808	19	15	41	31	t
47	6	Project Engineer	1151	184	235	497	473	t
48	6	Quality Engineer	344	20	14	101	86	t
49	6	Manufacturing Engineer	373	12	10	92	101	t
50	5	General Manager	596	10	0	897	684	t
51	5	Parts Advisor	265	0	0	27	46	t
52	5	Driving Instructor	438	0	0	10	14	t
55	5	Workshop Controller	203	0	0	10	15	t
56	5	Fleet Manager	181	5	0	41	29	t
57	6	Buyer	281	10	14	382	349	t
58	6	Maintenance Engineer	94	7	0	51	51	t
78	8	Nurse	36796	3480	4890	243	348	t
79	8	Healthcare Assistant	18717	1175	1587	325	407	t
80	8	Care Worker	7355	406	562	208	201	t
81	8	Doctor	26592	4449	5985	606	507	t
82	8	General Practitioner (GP)	4918	495	544	33	29	t
83	8	Surgeon	2824	396	410	33	16	t
84	8	Dentist	5410	738	595	47	45	t
85	8	Physiotherapist	3301	613	706	78	71	t
86	8	Occupational Therapist	1141	243	227	24	26	t
87	8	Speech and Language Therapist	542	120	134	24	13	t
88	8	Care Manager	3263	170	201	102	89	t
89	8	Paramedic	1855	67	146	28	25	t
90	8	Healthcare Administrator	9524	290	329	252	250	t
91	8	Health Service Manager	3557	167	350	209	208	t
92	8	Biomedical Scientist	1124	177	198	34	36	t
93	8	Radiographer	1997	287	312	23	28	t
94	8	Optician	1613	334	418	18	11	t
95	8	Pharmacist	1522	296	387	97	100	t
96	8	Midwife	1325	163	171	23	20	t
100	9	Portfolio Manager	6656	1472	2303	956	724	t
102	9	Risk Manager	2693	379	665	788	558	t
104	9	Tax Manager	3097	582	997	260	249	t
105	9	Data Analyst	13821	4194	6236	1973	2032	t
106	9	Risk Analyst	1586	409	471	473	480	t
107	9	Mortgage Advisor	2375	181	247	179	151	t
108	9	Investment Banker	2911	923	1308	427	407	t
110	9	Bank Manager	1876	143	135	281	304	t
111	9	Business Analyst	2300	442	619	1953	1601	t
109	9	Audit Manager	5582	1875	2682	918	1332	t
97	9	Accountant	17806	3495	4149	1707	2092	t
98	9	Relationship Manager	9558	1531	2477	1654	1323	t
99	9	Financial Analyst	10390	2713	3974	2731	2348	t
101	9	Financial Advisor	7695	1194	1967	587	528	t
112	9	Tax Assistant	1440	491	694	242	215	t
113	9	Quantitative Analyst	144	35	36	72	55	t
114	9	Banker	2840	192	254	174	191	t
115	9	Trader	1240	163	182	221	240	t
116	9	Personal Banker	1454	105	119	160	221	t
117	9	Personal Assistant	2198	69	37	689	706	t
118	9	Client Manager	1454	202	198	599	479	t
119	9	Change Analyst	1234	157	134	644	489	t
120	9	Actuary	567	198	270	82	92	t
121	9	Financial Administrator	844	21	0	80	109	t
122	9	Payroll Manager	457	30	9	85	78	t
124	9	Customer Advisor	2100	215	228	489	867	t
125	10	Biotechnology Professional	235	32	51	0	0	t
126	10	Application Specialist	23	14	16	553	445	t
127	10	Microbiologist	23	9	12	361	497	t
128	10	Scientist	126	65	78	3239	3248	t
129	10	Research Scientist	91	52	57	2601	3162	t
130	10	Laboratory Technician	29	20	23	1561	2621	t
131	10	Biomedical Scientist	281	33	48	829	965	t
132	10	Nanotechnology Professional	33	2	4	0	0	t
133	11	Mechanical Engineer	1481	559	749	3874	4477	t
134	11	Service Engineer	492	109	216	2470	3071	t
135	12	Electrical/Electronic Manufacturing Professional	583	50	101	0	0	t
\.


--
-- Data for Name: career_company; Type: TABLE DATA; Schema: public; Owner: geektalent
--

COPY career_company (id, career_id, company_name, total_count, title_count, company_count, count, relevance_score, visible) FROM stdin;
1	1	Hewlett-Packard	7984381	6009	4116	164	0.026797055591831126	t
2	1	IBM	7984381	6009	6116	144	0.0232155302854777611	t
3	1	Fujitsu	7984381	6009	2597	98	0.0159956482331677814	t
4	1	Capgemini	7984381	6009	2652	74	0.0119917374772138974	t
5	1	CSC	7984381	6009	1549	61	0.00996493529326262367	t
6	1	Tata Consultancy Services	7984381	6009	2038	55	0.00890439031410518098	t
7	1	Cognizant Technology Solutions	7984381	6009	1567	50	0.00813071301435339122	t
8	1	Lloyds Banking Group	7984381	6009	10811	54	0.00763825017159552432	t
9	1	CGI	7984381	6009	1157	45	0.00734939004453257286	t
10	1	Atos	7984381	6009	1319	45	0.00732908515025088199	t
11	1	BT	7984381	6009	7515	44	0.00638594323344441467	t
12	1	Capita	7984381	6009	3831	41	0.00634806443019668952	t
13	1	Computacenter	7984381	6009	1301	39	0.00633208696986391553	t
14	1	Royal Bank of Scotland	7984381	6009	10073	38	0.00506607216620785002	t
15	1	Microsoft	7984381	6009	2269	32	0.00504496229987793678	t
16	1	Wipro Technologies	7984381	6009	990	31	0.00503872831366181887	t
17	1	EDS	7984381	6009	356	25	0.00411893886708671227	t
18	1	Accenture	7984381	6009	4368	23	0.00328299462656369547	t
19	1	Dell	7984381	6009	723	20	0.00324022760802593346	t
20	1	Infosys	7984381	6009	843	20	0.00322518694559505159	t
21	1	Wipro	7984381	6009	497	19	0.00310201180897882794	t
22	1	HCL Technologies	7984381	6009	652	18	0.00291604190671367189	t
23	1	Barclays	7984381	6009	8766	24	0.00289829672843047465	t
24	1	Oracle	7984381	6009	1388	18	0.00282379251047092973	t
25	1	Logica	7984381	6009	465	17	0.00277293789237652993	t
26	1	BAE Systems Applied Intelligence	7984381	6009	510	17	0.00276729764396494923	t
27	1	Unisys	7984381	6009	270	15	0.00246429420890951351	t
28	1	Tech Mahindra	7984381	6009	618	15	0.002420676287859956	t
29	1	IBM Global Services	7984381	6009	314	14	0.00229223691939292335	t
30	1	NCR Corporation	7984381	6009	395	14	0.00228208447225207792	t
31	1	The Health and Social Care Information Centre	7984381	6009	313	13	0.00212581987828791433	t
32	1	TCS	7984381	6009	747	13	0.00207142281582955827	t
33	1	Thomson Reuters	7984381	6009	2085	14	0.00207026180968382465	t
34	1	Hewlett-Packard Enterprise Services	7984381	6009	91	12	0.00198710272382644597	t
35	1	Allstate Northern Ireland	7984381	6009	250	12	0.00196717384610552767	t
36	1	Nationwide Building Society	7984381	6009	3053	14	0.00194893379940804423	t
37	1	Google	7984381	6009	1790	13	0.00194069439153447647	t
38	1	Infosys Technologies Ltd	7984381	6009	185	11	0.00180877849163032199	t
39	1	Rackspace	7984381	6009	368	11	0.00178584148142322706	t
40	1	Cisco	7984381	6009	779	11	0.0017343272125974567	t
41	1	Xerox	7984381	6009	942	11	0.00171389697946217534	t
42	1	DIGITAL BANANAS TECHNOLOGY LIMITED	7984381	6009	54	10	0.00165865550149210152	t
43	1	Getronics	7984381	6009	188	10	0.00164186009511095013	t
44	1	Capita IT Enterprise Services	7984381	6009	208	10	0.00163935331803913634	t
45	1	T-Systems	7984381	6009	276	10	0.00163083027599496993	t
46	1	Steria	7984381	6009	374	10	0.00161854706834308306	t
47	2	IBM	7984381	5290	6116	118	0.0215545234849215395	t
48	2	Capgemini	7984381	5290	2652	85	0.0157463370854824362	t
49	2	Hewlett-Packard	7984381	5290	4116	43	0.00761808527464769101	t
50	2	Oracle	7984381	5290	1388	41	0.0075816563674930542	t
51	2	Tata Consultancy Services	7984381	5290	2038	40	0.00731103220960230022	t
52	2	Infosys	7984381	5290	843	38	0.00708247615412964208	t
53	2	Wipro Technologies	7984381	5290	990	29	0.00536160180347011652	t
54	2	Accenture	7984381	5290	4368	31	0.00531656779711743663	t
55	2	Fujitsu	7984381	5290	2597	27	0.0047818779270013068	t
56	2	TCS	7984381	5290	747	25	0.00463541142283217366	t
57	2	Microsoft	7984381	5290	2269	26	0.00463382412204925171	t
58	2	Cognizant Technology Solutions	7984381	5290	1567	25	0.00453264282425371381	t
59	2	Deloitte	7984381	5290	6014	25	0.00397531116830443336	t
60	2	CGI	7984381	5290	1157	21	0.00382738214600918938	t
61	2	CSC	7984381	5290	1549	21	0.00377825374278631604	t
62	2	Logica	7984381	5290	465	18	0.00334662508385435422	t
63	2	Sogeti	7984381	5290	115	15	0.00282300599643874658	t
64	2	SAP	7984381	5290	599	15	0.00276234745776560717	t
65	2	HCL Technologies	7984381	5290	652	14	0.00256654385274234127	t
66	2	PA Consulting Group	7984381	5290	647	13	0.00237800924615511229	t
67	2	Computacenter	7984381	5290	1301	13	0.00229604502241082887	t
68	2	Cognizant	7984381	5290	308	12	0.00223133404435471973	t
69	2	IBM Global Services	7984381	5290	314	11	0.00204142083461582909	t
70	2	Steria	7984381	5290	374	11	0.00203390118106130773	t
71	2	BAE Systems Applied Intelligence	7984381	5290	510	11	0.00201685663300439242	t
72	2	Deloitte Digital	7984381	5290	117	10	0.0018769491194030694	t
73	2	Arrow ECS United Kingdom	7984381	5290	139	10	0.001874191913099745	t
74	2	HCL AXON	7984381	5290	209	10	0.00186541898395280333	t
75	3	BAE Systems	7984381	60404	5012	389	0.00585655170351291436	t
76	3	IBM	7984381	60404	6116	396	0.00583399748509379375	t
77	3	Tata Consultancy Services	7984381	60404	2038	289	0.00456372886252589226	t
78	3	Hewlett-Packard	7984381	60404	4116	231	0.00333396594106708704	t
79	3	Fujitsu	7984381	60404	2597	207	0.00312530914793235229	t
80	3	Lloyds Banking Group	7984381	60404	10811	269	0.00312295490629013262	t
81	3	Royal Bank of Scotland	7984381	60404	10073	251	0.00291582486006838762	t
82	3	Capita	7984381	60404	3831	182	0.00255254440943500967	t
83	3	Computacenter	7984381	60404	1301	152	0.00237138669821036242	t
84	3	Oracle	7984381	60404	1388	141	0.00217691202592444578	t
85	3	BT	7984381	60404	7515	186	0.00215435192834656552	t
86	3	National Grid	7984381	60404	2201	132	0.00192417948251410748	t
87	3	Jaguar Land Rover	7984381	60404	5067	153	0.00191280169532236305	t
88	3	Thales	7984381	60404	1290	122	0.0018723330617451447	t
89	3	Virgin Media	7984381	60404	2558	119	0.00166226822262311325	t
90	3	Barclays	7984381	60404	8766	163	0.00161280459105333021	t
91	3	CSC	7984381	60404	1549	102	0.00150601956898624781	t
92	3	Transport for London	7984381	60404	4169	120	0.00147564261588177103	t
93	3	Sky	7984381	60404	4506	122	0.00146647625524507549	t
94	3	Selex ES	7984381	60404	618	89	0.00140665295050448587	t
95	3	Lockheed Martin	7984381	60404	635	89	0.0014045075631566933	t
96	3	Vodafone	7984381	60404	4493	118	0.00140139126846605851	t
97	3	Rolls-Royce	7984381	60404	3618	106	0.00131163888593810582	t
98	3	HSBC	7984381	60404	9221	148	0.00130516301554669091	t
99	3	British Gas	7984381	60404	2638	98	0.00130186300236796596	t
100	3	QinetiQ	7984381	60404	1181	83	0.001235514403860124	t
101	3	Barclays Corporate Banking	7984381	60404	823	79	0.00121396816031572288	t
102	3	Handelsbanken	7984381	60404	418	72	0.00114830909896384008	t
103	3	Microsoft	7984381	60404	2269	86	0.00114825379642924364	t
104	3	Credit Suisse	7984381	60404	2990	91	0.00114067110441143371	t
105	3	Infosys	7984381	60404	843	71	0.00107799302099307378	t
106	3	Capgemini	7984381	60404	2652	83	0.00104987529864818303	t
107	3	Network Rail	7984381	60404	5155	101	0.00103426365846674998	t
108	3	Cisco Systems	7984381	60404	573	66	0.00102865984866650222	t
109	3	British Airways	7984381	60404	5257	101	0.00102139133437999415	t
110	3	Cisco	7984381	60404	779	67	0.00101934419625743515	t
111	3	Atos	7984381	60404	1319	71	0.0010179221752548795	t
112	3	ABB	7984381	60404	685	64	0.000981162743470321381	t
113	3	Barclays Bank	7984381	60404	2843	80	0.000975727057971604206	t
114	3	EDF Energy	7984381	60404	2269	75	0.000964758459393795379	t
115	3	Royal Air Force	7984381	60404	3136	81	0.000955432070312068867	t
116	3	Babcock International Group	7984381	60404	2359	75	0.000953400526376069549	t
117	3	Citi	7984381	60404	3422	83	0.000952701871718751136	t
118	3	HP CDS	7984381	60404	147	57	0.000932288183133522428	t
119	3	NATS	7984381	60404	688	60	0.000914058568599264605	t
120	3	Siemens	7984381	60404	1643	67	0.000910308039287267205	t
121	3	Serco	7984381	60404	2333	70	0.000873274735645885626	t
122	3	Rackspace	7984381	60404	368	54	0.00085435396478436836	t
123	3	MBDA	7984381	60404	392	53	0.000834643788370358292	t
124	3	John Lewis	7984381	60404	3006	72	0.000821705425076346566	t
125	4	IBM	7984381	32697	6116	422	0.0121903081152273003	t
126	4	Accenture	7984381	32697	4368	389	0.0113967187947798757	t
127	4	Hewlett-Packard	7984381	32697	4116	303	0.00878738415317535659	t
128	4	Fujitsu	7984381	32697	2597	282	0.00833351116323204251	t
129	4	Capgemini	7984381	32697	2652	282	0.00832659438937633986	t
130	4	Tata Consultancy Services	7984381	32697	2038	167	0.00487220614671030668	t
131	4	Atos	7984381	32697	1319	152	0.00450198316787207495	t
132	4	CSC	7984381	32697	1549	147	0.0043195104515157956	t
133	4	Royal Bank of Scotland	7984381	32697	10073	173	0.00404598599697901865	t
134	4	Lloyds Banking Group	7984381	32697	10811	171	0.00389175625751317714	t
135	4	Capita	7984381	32697	3831	141	0.00384826958544212889	t
136	4	BT	7984381	32697	7515	154	0.00378419636342093146	t
137	4	CGI	7984381	32697	1157	126	0.00372390647729292472	t
138	4	Oracle	7984381	32697	1388	124	0.00363343681682418542	t
139	4	Wipro Technologies	7984381	32697	990	122	0.00362206989735974197	t
140	4	Vodafone	7984381	32697	4493	119	0.00308940546710169059	t
141	4	Microsoft	7984381	32697	2269	98	0.00272419294203600417	t
142	4	GSK	7984381	32697	3270	92	0.00241405002703785768	t
143	4	BP	7984381	32697	5408	99	0.00236014339929981791	t
144	4	Thomson Reuters	7984381	32697	2085	76	0.00207172138154871959	t
145	4	HSBC	7984381	32697	9221	101	0.00194204154208752269	t
146	4	Tech Mahindra	7984381	32697	618	64	0.00188769534256021869	t
147	4	Jaguar Land Rover	7984381	32697	5067	80	0.00181954489959463466	t
148	4	Computacenter	7984381	32697	1301	64	0.00180180158722487074	t
149	4	SAP	7984381	32697	599	57	0.00167511753756677674	t
150	4	Transport for London	7984381	32697	4169	70	0.00162538090135557812	t
151	4	HCL AXON	7984381	32697	209	50	0.00150919651621815739	t
152	4	Environment Agency	7984381	32697	1807	56	0.00149249042665324525	t
153	4	Sky	7984381	32697	4506	66	0.00146016152099923959	t
154	4	Centrica	7984381	32697	963	49	0.0013836642294953259	t
155	4	Visa Europe	7984381	32697	643	47	0.00136248806710825062	t
156	4	HCL Technologies	7984381	32697	652	47	0.00136135623138640871	t
157	4	Xerox	7984381	32697	942	48	0.00135559557437556081	t
158	4	Cognizant Technology Solutions	7984381	32697	1567	50	0.0013384150817446548	t
159	4	Steria	7984381	32697	374	44	0.00130418856382667433	t
160	4	TCS	7984381	32697	747	45	0.00128798986626994967	t
161	4	Citi	7984381	32697	3422	55	0.00125867918920752244	t
162	4	Nationwide Building Society	7984381	32697	3053	53	0.00124366524352825434	t
163	4	Aviva	7984381	32697	3140	53	0.00123272416488378104	t
164	4	Wipro	7984381	32697	497	41	0.00119659132688264324	t
165	4	Shell	7984381	32697	2616	48	0.00114507413011293675	t
166	4	Logica	7984381	32697	465	38	0.00110848681625922547	t
167	4	Dell	7984381	32697	723	38	0.00107604085889975308	t
168	4	Bank of England	7984381	32697	1043	39	0.00106650741614943171	t
169	4	Ericsson	7984381	32697	1077	39	0.0010622315923113617	t
170	4	Barclays	7984381	32697	8766	70	0.00104726436654358109	t
171	4	Experian	7984381	32697	954	38	0.00104699040870580664	t
172	4	Standard Life	7984381	32697	924	37	0.00102005358930788389	t
173	4	Direct Line Group	7984381	32697	1252	38	0.00100951407036036942	t
174	4	GlaxoSmithKline	7984381	32697	2234	42	0.00100885663770452095	t
175	5	Hewlett-Packard	7984381	1896	4116	26	0.0132007083948237746	t
176	5	Lloyds Banking Group	7984381	1896	10811	27	0.0128895485759831629	t
177	5	Tata Consultancy Services	7984381	1896	2038	23	0.0118783740289582149	t
178	5	IBM	7984381	1896	6116	21	0.0103124026770541125	t
179	5	HSBC	7984381	1896	9221	17	0.00781322032293651179	t
180	5	Capgemini	7984381	1896	2358	15	0.00761787478492369826	t
181	5	Capita	7984381	1896	3831	15	0.00743334578173734765	t
182	5	Royal Bank of Scotland	7984381	1896	10073	15	0.00665138377366592589	t
183	5	Thomson Reuters	7984381	1896	2085	13	0.00659697179205816567	t
184	5	Credit Suisse	7984381	1896	2990	12	0.00595604714096240918	t
185	5	Sky	7984381	1896	4506	11	0.00523857990945466364	t
186	6	Fujitsu	7984381	3322	2597	71	0.0210561677162535536	t
187	6	IBM	7984381	3322	6116	64	0.0185072073501618486	t
188	6	Atos	7984381	3322	1319	45	0.0133864286533148993	t
189	6	Capgemini	7984381	3322	2652	44	0.0129182594350545233	t
190	6	Computacenter	7984381	3322	1301	43	0.0127863864401399473	t
191	6	Hewlett-Packard	7984381	3322	4116	42	0.012132527578437519	t
192	6	Capita	7984381	3322	3715	40	0.0115804739843167574	t
193	6	CSC	7984381	3322	1549	29	0.00853922999876055404	t
194	6	CGI	7984381	3322	1157	21	0.00617915607581882159	t
195	6	SCC	7984381	3322	542	17	0.00505161841299992583	t
196	6	Kelway	7984381	3322	307	15	0.00447876557406716534	t
197	6	BT	7984381	3322	7289	17	0.00420624187838215119	t
198	6	Vodafone	7984381	3322	4493	15	0.00395427377416943289	t
199	6	Plan-Net plc	7984381	3322	42	12	0.00360852285831230347	t
200	6	Daisy Group	7984381	3322	227	12	0.00358534297704591991	t
201	6	SiteMinder	7984381	3322	67	11	0.00330424166543803353	t
202	6	Rackspace	7984381	3322	368	11	0.00326652737213435022	t
203	7	BT	7984381	4987	7515	77	0.0145079933874688767	t
204	7	Vodafone	7984381	4987	4493	37	0.00686085175669856086	t
205	7	Hewlett-Packard	7984381	4987	4116	33	0.00610551173907668537	t
206	7	National Grid	7984381	4987	2201	28	0.00534227150984187618	t
207	7	Fujitsu	7984381	4987	2597	27	0.005091997002637072	t
208	7	Openreach	7984381	4987	1460	22	0.00423125563484462279	t
209	7	IBM	7984381	4987	5856	24	0.00408162996180302939	t
210	7	Rackspace	7984381	4987	368	16	0.00316422806271849039	t
211	7	Royal Mail	7984381	4987	6205	18	0.00283401223458491867	t
212	7	Cisco	7984381	4987	779	14	0.00271142703518608081	t
213	7	Virgin Media	7984381	4987	2558	15	0.00268912445195018234	t
214	7	Transport for London	7984381	4987	4169	16	0.0026878760991483246	t
215	7	O2 (Telefónica UK)	7984381	4987	1437	14	0.00262896463265275583	t
216	7	NHS England	7984381	4987	3222	15	0.00260591011261564155	t
217	7	Cisco Systems	7984381	4987	573	13	0.00253659685370325513	t
218	7	RM Education	7984381	4987	212	12	0.00238119170625183561	t
219	7	Network Rail	7984381	4987	5155	15	0.00236366113982397355	t
220	7	AT&T	7984381	4987	411	12	0.00235625246901151374	t
221	7	Wolseley	7984381	4987	618	12	0.00233031064936957107	t
222	7	Capita	7984381	4987	3831	14	0.00232894184896767888	t
223	7	Pfizer	7984381	4987	1170	11	0.0020604857853331578	t
224	7	Dimension Data	7984381	4987	337	10	0.00196423299957737595	t
225	8	Accenture	7984381	33573	4368	375	0.0106674768210039857	t
226	8	IBM	7984381	33573	6116	299	0.00817434234924808122	t
930	79	Care UK	7984381	18717	1632	183	0.00959530214644549809	t
227	8	Tata Consultancy Services	7984381	33573	2038	268	0.0077599861860352037	t
228	8	Google	7984381	33573	1790	210	0.00605630441925169346	t
229	8	Sky	7984381	33573	4506	184	0.00493700197476904228	t
230	8	Capgemini	7984381	33573	2652	169	0.00472151162436313179	t
231	8	Wipro Technologies	7984381	33573	990	141	0.00409302181339848102	t
232	8	Infosys	7984381	33573	843	132	0.00384230598160401797	t
233	8	Goldman Sachs	7984381	33573	3155	125	0.00334213663350328921	t
234	8	Cognizant Technology Solutions	7984381	33573	1567	109	0.00306327895068763973	t
235	8	Hewlett-Packard	7984381	33573	4116	116	0.00295206389609621415	t
236	8	BT	7984381	33573	7515	130	0.00294332276041140263	t
237	8	Microsoft	7984381	33573	2269	105	0.00285533958479576664	t
238	8	TCS	7984381	33573	747	88	0.00253826924567373755	t
239	8	Facebook	7984381	33573	431	85	0.00248827879434023467	t
240	8	BAE Systems	7984381	33573	5012	101	0.00239069674926910888	t
241	8	Thomson Reuters	7984381	33573	2085	88	0.00236998446254226176	t
242	8	ARM	7984381	33573	564	81	0.00235190448196241934	t
243	8	HCL Technologies	7984381	33573	652	81	0.00234083642447694123	t
244	8	J.P. Morgan	7984381	33573	3396	90	0.00226491878706928072	t
245	8	BBC	7984381	33573	4898	95	0.00222556523549440185	t
246	8	Citi	7984381	33573	3422	86	0.00214200222640676275	t
247	8	Royal Bank of Scotland	7984381	33573	10073	110	0.00202336218920402778	t
248	8	Imagination Technologies	7984381	33573	280	67	0.00196886153733740604	t
249	8	Tech Mahindra	7984381	33573	618	66	0.00189643852153045843	t
250	8	HSBC	7984381	33573	9221	102	0.00189122820386617698	t
251	8	CGI	7984381	33573	1157	68	0.00188846989581644472	t
252	8	Ericsson	7984381	33573	1077	67	0.00186862015306551803	t
253	8	Cisco	7984381	33573	779	64	0.001816365780882713	t
254	8	Capita	7984381	33573	3831	76	0.0017914447818526899	t
255	8	British Airways	7984381	33573	5257	80	0.00173173839400481751	t
256	8	Bloomberg LP	7984381	33573	1200	62	0.0017035919613006005	t
257	8	Thales	7984381	33573	1290	58	0.00157262590428500779	t
258	8	Credit Suisse	7984381	33573	2990	62	0.00147845761017553257	t
259	8	Oracle	7984381	33573	1388	54	0.00144065366022528034	t
260	8	CSC	7984381	33573	1549	54	0.00142040414596207587	t
261	8	JPMorgan Chase	7984381	33573	1367	51	0.00135356006163932208	t
262	8	OpenBet	7984381	33573	135	44	0.00129913157409012507	t
263	8	Wipro	7984381	33573	497	45	0.00128351322353531462	t
264	8	Liberty Information Technology	7984381	33573	80	43	0.00127613749682627857	t
265	8	Barclays	7984381	33573	8766	79	0.00126048798857910358	t
266	8	Fujitsu	7984381	33573	2597	52	0.00122877041679593122	t
267	8	Aviva	7984381	33573	3140	53	0.0011903870843675802	t
268	8	Cisco Systems	7984381	33573	573	42	0.00118421960703922707	t
269	8	Mastek Ltd	7984381	33573	175	38	0.00111463095971583146	t
270	8	UBS Investment Bank	7984381	33573	1384	43	0.00111212900863237444	t
271	8	Lloyds Banking Group	7984381	33573	10811	82	0.00109301626499906288	t
272	8	Bank of America Merrill Lynch	7984381	33573	1631	43	0.00108106298364472539	t
273	8	Kainos	7984381	33573	132	36	0.00106021598869351311	t
274	8	Rolls-Royce	7984381	33573	3618	50	0.00104053256890374013	t
275	9	Goldman Sachs	7984381	11543	3155	383	0.0328326019601583446	t
276	9	Accenture	7984381	11543	4368	249	0.0210548861191192441	t
277	9	J.P. Morgan	7984381	11543	3396	191	0.016144835059474439	t
278	9	Deutsche Bank	7984381	11543	4194	181	0.0151771650591498823	t
279	9	HSBC	7984381	11543	9221	165	0.0131585210279935687	t
280	9	Lloyds Banking Group	7984381	11543	10811	148	0.0114842076335559783	t
281	9	Morgan Stanley	7984381	11543	2749	126	0.0105867144786587104	t
282	9	Royal Bank of Scotland	7984381	11543	10073	130	0.0100151276058311253	t
283	9	Barclays	7984381	11543	8766	124	0.00965851109236019051	t
284	9	BlackRock	7984381	11543	1208	111	0.0094786254612885517	t
285	9	Credit Suisse	7984381	11543	2990	112	0.00934187460983575135	t
286	9	Deloitte	7984381	11543	6014	114	0.00913610286707734233	t
287	9	KPMG	7984381	11543	5288	111	0.00896688798462089674	t
288	9	Citi	7984381	11543	3422	98	0.00807307840325702589	t
289	9	Barclays Investment Bank	7984381	11543	1912	83	0.00696110118447100957	t
290	9	Moody's Investors Service	7984381	11543	275	66	0.00569153701483894083	t
291	9	Bank of America Merrill Lynch	7984381	11543	1631	55	0.00456712137199602811	t
292	9	UBS Investment Bank	7984381	11543	1384	45	0.00373052138714149431	t
293	9	Bank of England	7984381	11543	1043	44	0.00368653358568299654	t
294	9	Nomura	7984381	11543	712	39	0.00329425945757154826	t
295	9	JPMorgan Chase	7984381	11543	1367	38	0.00312534750739712269	t
296	9	BNP Paribas	7984381	11543	2012	36	0.00287093179871101547	t
297	9	Towers Watson	7984381	11543	838	33	0.00275790769800631072	t
298	9	UBS	7984381	11543	1389	31	0.00251528201941989904	t
299	9	The Market Mogul	7984381	11543	63	29	0.00250808066527103421	t
300	9	PA Consulting Group	7984381	11543	647	28	0.00234807395059744278	t
301	9	Nationwide Building Society	7984381	11543	3053	30	0.00221981538445192817	t
302	9	Bank of America	7984381	11543	1301	26	0.00209252940924221486	t
303	9	Barclays Wealth and Investment Management	7984381	11543	858	25	0.00206133504470040925	t
304	9	American Express	7984381	11543	1795	26	0.00203056903829274861	t
305	9	Rothschild	7984381	11543	359	23	0.00195040651084464394	t
306	9	BP	7984381	11543	5408	30	0.00192443750269890635	t
307	9	SC Johnson	7984381	11543	161	22	0.0018884828125323536	t
308	9	Lehman Brothers	7984381	11543	248	22	0.00187757076339752863	t
309	9	EY	7984381	11543	4443	28	0.00187195741593312393	t
310	9	IMS Health	7984381	11543	334	22	0.00186678414011482796	t
311	9	The Blackstone Group	7984381	11543	154	21	0.00180260277646429796	t
312	9	Macquarie Group	7984381	11543	380	21	0.00177425653388417785	t
313	9	Citigroup	7984381	11543	566	21	0.00175092732538903472	t
314	9	UK National Audit Office	7984381	11543	222	20	0.00170731580148691031	t
315	9	IHS	7984381	11543	382	20	0.00168724766514700216	t
316	9	JPMorgan Chase & Co.	7984381	11543	493	20	0.00167332539556119104	t
317	9	Finalta	7984381	11543	30	19	0.00164463954806187349	t
318	9	Merrill Lynch	7984381	11543	731	20	0.00164347404275557774	t
319	9	Aimia Inc	7984381	11543	207	19	0.00162243917223585019	t
320	9	Barclays Wealth	7984381	11543	377	18	0.00151435876034177125	t
321	9	J.P. Morgan Asset Management	7984381	11543	249	17	0.00144365525238077086	t
322	9	Bloomberg LP	7984381	11543	1200	18	0.00141113328404336908	t
323	9	RWE npower	7984381	11543	1263	18	0.00140323145535953026	t
324	9	Care Quality Commission	7984381	11543	598	17	0.00139988162998934645	t
325	10	Lloyds Banking Group	7984381	11546	10811	105	0.00775124887030179295	t
326	10	Sky	7984381	11546	4506	92	0.00741449757044411288	t
327	10	IBM	7984381	11546	6116	89	0.00695235535060152992	t
328	10	Cognizant Technology Solutions	7984381	11546	1567	82	0.00691576921541580108	t
329	10	Hewlett-Packard	7984381	11546	4116	65	0.00512155497373318128	t
330	10	Tata Consultancy Services	7984381	11546	2038	59	0.00486177694864206936	t
331	10	Capgemini	7984381	11546	2652	58	0.00469802993914717696	t
332	10	Accenture	7984381	11546	4368	60	0.00465627011054071775	t
333	10	Royal Bank of Scotland	7984381	11546	10073	66	0.00446112839880045183	t
334	10	Capita	7984381	11546	3831	47	0.0035960622234088766	t
335	10	CSC	7984381	11546	1549	43	0.00353534209640451015	t
336	10	BT	7984381	11546	7515	50	0.00339419973225468232	t
337	10	CGI	7984381	11546	1157	40	0.00332430252699931778	t
338	10	BAE Systems	7984381	11546	5012	45	0.00327446322168710099	t
339	10	HSBC	7984381	11546	9221	49	0.00309348764070303036	t
340	10	Fujitsu	7984381	11546	2597	39	0.00305695372466661995	t
341	10	Jaguar Land Rover	7984381	11546	5067	41	0.0029206227679733519	t
342	10	Sogeti	7984381	11546	115	32	0.00276111225558774067	t
343	10	Siemens	7984381	11546	1643	33	0.00265619698874052955	t
344	10	Barclays	7984381	11546	8766	42	0.00254340787370377483	t
345	10	Wipro Technologies	7984381	11546	990	30	0.00247789357905769426	t
346	10	Vodafone	7984381	11546	4493	35	0.00247220419030589863	t
347	10	Lockheed Martin	7984381	11546	635	27	0.00226221325137768549	t
348	10	Infosys	7984381	11546	843	27	0.00223612466431925535	t
349	10	Ford Motor Company	7984381	11546	1988	26	0.00200577650228577322	t
350	10	SQS Group	7984381	11546	72	23	0.00198588600344331082	t
351	10	Nationwide Building Society	7984381	11546	3053	27	0.00195893342682343331	t
352	10	Aviva	7984381	11546	3140	27	0.00194802137358264776	t
353	10	Atos	7984381	11546	1319	24	0.00191621541430484431	t
354	10	Thomson Reuters	7984381	11546	2085	25	0.00190687468273899817	t
355	10	Centrica	7984381	11546	963	23	0.0018741315271497464	t
356	10	Sony Computer Entertainment Europe	7984381	11546	503	22	0.00184509193352386377	t
357	10	Tech Mahindra	7984381	11546	618	22	0.00183066795510213542	t
358	10	TCS	7984381	11546	747	22	0.00181448801408993577	t
359	10	Thales	7984381	11546	1290	22	0.00174638175075951443	t
360	10	SEGA Europe Limited	7984381	11546	93	20	0.00172304553761921616	t
361	10	Cubic	7984381	11546	127	19	0.00163204554972956129	t
362	10	Mastek Ltd	7984381	11546	175	19	0.00162602510656223139	t
363	10	Visa Europe	7984381	11546	643	19	0.00156732578568076313	t
364	10	Barclaycard	7984381	11546	1435	20	0.001554723980732613	t
365	10	Credit Suisse	7984381	11546	2990	22	0.00153315772191657475	t
366	10	Cognizant	7984381	11546	308	18	0.00152260795463995849	t
367	10	Ericsson	7984381	11546	1077	19	0.0015128909453761539	t
368	10	EE	7984381	11546	1826	20	0.00150568245409873685	t
369	10	Pole To Win Europe Ltd.	7984381	11546	81	17	0.00146434412647266092	t
370	10	Mindtree	7984381	11546	85	17	0.00146384242287538329	t
371	10	Sopra Steria	7984381	11546	288	17	0.00143838096531354997	t
372	10	Rockstar Games	7984381	11546	144	16	0.00136970678750274427	t
373	10	Sainsbury's Bank	7984381	11546	369	16	0.0013414859601558846	t
374	10	Logica	7984381	11546	465	16	0.00132944507382122459	t
375	11	Gamesys	7984381	3401	245	13	0.00379333606313520845	t
1284	98	Biffa	7984381	9558	368	14	0.00142035187780152183	t
376	11	GIMO Global Interactive Marketing Online Ltd	7984381	3401	56	10	0.00293454796983297394	t
377	13	Capgemini	7984381	2242	2652	29	0.0126062709119015535	t
378	13	IBM	7984381	2242	6116	27	0.0112799908025788993	t
379	13	Fujitsu	7984381	2242	2597	23	0.0099362276369540925	t
380	13	BT	7984381	2242	7289	21	0.00845610405284354105	t
381	13	Tata Consultancy Services	7984381	2242	2038	19	0.00822163655164510031	t
382	13	Royal Bank of Scotland	7984381	2242	10073	19	0.00721501414128617249	t
383	13	Hewlett-Packard	7984381	2242	4116	17	0.00706899411012051372	t
384	13	CSC	7984381	2242	1549	16	0.00694443149691942752	t
385	13	Lloyds Banking Group	7984381	2242	10811	18	0.00667640211100527757	t
386	13	Wipro Technologies	7984381	2242	990	15	0.00656830724090555571	t
387	13	CGI	7984381	2242	1157	12	0.00520891870127690101	t
388	13	Oracle	7984381	2242	1388	12	0.00517997908997722308	t
389	13	Deutsche Bank	7984381	2242	4194	12	0.004828444244492823	t
390	14	SEO	7984381	2223	207	56	0.0251722658958567873	t
391	14	ReachLocal	7984381	2223	43	12	0.00539422699973241514	t
392	14	SDK	7984381	2223	22	9	0.0040469543636943257	t
393	15	The Mill	7984381	1010	148	9	0.00889347989777131663	t
394	16	BT	7984381	1422	7289	20	0.0131541329925477825	t
395	16	Rackspace	7984381	1422	368	18	0.0126143844561960837	t
396	16	Softcat Ltd	7984381	1422	278	17	0.0119222983239733304	t
397	16	PwC	7984381	1422	6805	17	0.0111046816983586937	t
398	16	BAE Systems Applied Intelligence	7984381	1422	510	14	0.00978315597662964172	t
399	16	Fujitsu	7984381	1422	2597	13	0.00881836394675665665	t
400	16	KPMG	7984381	1422	5288	11	0.00707455060185464401	t
401	16	CGI	7984381	1422	1157	10	0.0068886677458857206	t
402	19	VMC	7984381	302	50	12	0.0397303398658042442	t
403	19	Rockstar Games	7984381	302	144	10	0.0330957993803909084	t
404	19	HCL Technologies	7984381	302	652	10	0.0330321727554539549	t
405	20	King	7984381	215	176	9	0.0418395487174967814	t
480	42	Sytner Group	7984381	1748	397	28	0.0159720812867001072	t
492	42	Inchcape	7984381	1748	245	11	0.00626359254224962986	t
481	42	Enterprise Rent-A-Car	7984381	1748	949	27	0.0153307235186290313	t
482	42	Evans Halshaw	7984381	1748	214	25	0.01427838309806591	t
499	43	Garage	7984381	1536	86	12	0.00780323012190515999	t
477	41	Enterprise Rent-A-Car	7984381	630	949	82	0.130050134587550659	t
478	41	Lookers PLC	7984381	630	277	10	0.0158395729462512472	t
479	41	Sytner Group	7984381	630	397	10	0.0158245424173682689	t
496	43	Kwik-Fit	7984381	1536	264	25	0.0162461024657927951	t
497	43	Jaguar Land Rover	7984381	1536	5067	21	0.0130397695288302605	t
498	43	Ford Motor Company	7984381	1536	1988	18	0.0114719708128806202	t
500	44	Euro Car Parts Ltd.	7984381	1857	525	25	0.0133999372140017683	t
501	44	Mercedes-Benz UK Ltd	7984381	1857	696	14	0.00745360482839598892	t
505	44	Benfield Motor Group	7984381	1857	91	9	0.00483625421575110959	t
513	46	Marshall Motor Group	7984381	808	173	13	0.016069067758890599	t
483	42	Mercedes-Benz UK Ltd	7984381	1748	696	25	0.0142180020182893496	t
484	42	Arnold Clark	7984381	1748	352	24	0.0136888879171888061	t
485	42	Bristol Street Motors	7984381	1748	142	18	0.0102819491157603599	t
486	42	Lookers PLC	7984381	1748	277	16	0.00912062209892004587	t
487	42	Audi UK	7984381	1748	250	15	0.00855179678975068712	t
488	42	Euro Car Parts Ltd.	7984381	1748	525	14	0.00794513935175867117	t
489	42	Ford Motor Company	7984381	1748	1988	14	0.00776186648928334395	t
490	42	Mercedes-Benz Retail Group	7984381	1748	111	11	0.00628037898351531225	t
491	42	JCT600 Ltd	7984381	1748	120	11	0.00627925153596761709	t
493	42	BMW	7984381	1748	380	11	0.00624668082903420338	t
494	42	Marshall Motor Group	7984381	1748	173	10	0.00570040447081874603	t
495	42	Ford Retail Group	7984381	1748	96	9	0.00513784275913658269	t
502	44	Sytner Group	7984381	1857	397	13	0.00695243341740236186	t
503	44	Andrew Page Ltd	7984381	1857	138	10	0.00536899458914309562	t
504	44	Vauxhall Motors Ltd	7984381	1857	373	10	0.0053395552789700226	t
506	45	Jaguar Land Rover	7984381	618	5067	22	0.0349667979662867251	t
507	45	Ford Motor Company	7984381	618	1988	11	0.0175517251596593732	t
508	45	Euro Car Parts Ltd.	7984381	618	525	10	0.0161167238506291499	t
509	45	Northgate Vehicle Hire	7984381	618	101	9	0.0145515834079598186	t
510	45	Inchcape	7984381	618	245	9	0.0145335468004102204	t
511	46	Lookers PLC	7984381	808	277	14	0.017293790029666526	t
512	46	Sytner Group	7984381	808	397	14	0.017278759165666159	t
514	46	Inchcape	7984381	808	245	10	0.0123468021817616583	t
515	46	Volkswagen Group UK Ltd	7984381	808	268	10	0.0123439212661615883	t
516	47	Jaguar Land Rover	7984381	1151	5067	176	0.152297853310710662	t
517	47	Ford Motor Company	7984381	1151	1988	56	0.0484113376096440631	t
518	47	Ricardo	7984381	1151	277	19	0.0164750671366354767	t
519	47	Bentley Motors Ltd	7984381	1151	709	17	0.0146830837148454116	t
520	47	Delphi Diesel Systems	7984381	1151	302	12	0.0103893906193386135	t
521	47	McLaren Automotive Ltd	7984381	1151	340	12	0.0103846306412345123	t
522	47	MIRA Ltd	7984381	1151	92	10	0.00867782577499151206	t
523	47	Nissan Motor Manufacturing Ltd.	7984381	1151	367	10	0.00864337856502762555	t
524	47	Cummins Inc.	7984381	1151	605	10	0.00861356607058615283	t
525	47	Jaguar Cars	7984381	1151	150	9	0.00780162555200300447	t
526	48	Jaguar Land Rover	7984381	344	5067	39	0.112742336422678932	t
527	49	Jaguar Land Rover	7984381	373	5067	103	0.275517667323682491	t
528	49	Ford Motor Company	7984381	373	1988	26	0.0694593525970479408	t
529	50	Sytner Group	7984381	596	397	11	0.0184080278435831135	t
530	50	Evans Halshaw	7984381	596	214	10	0.0167529716996479526	t
531	50	Pendragon PLC	7984381	596	198	9	0.0150769981587638505	t
532	50	Lookers PLC	7984381	596	277	9	0.0150671031027221364	t
533	52	RED Driving School	7984381	438	85	12	0.0273881169221225178	t
534	52	AA Driving School	7984381	438	45	10	0.0228266664294782713	t
535	54	Jaguar Land Rover	7984381	384	5067	27	0.069681237237751964	t
536	54	Ford Motor Company	7984381	384	1988	12	0.0310025049170233914	t
537	54	Triumph Motorcycles	7984381	384	149	9	0.0234199649232708883	t
538	57	Jaguar Land Rover	7984381	281	5067	50	0.177307569167385659	t
539	57	Ford Motor Company	7984381	281	1988	13	0.04601597855453015	t
540	57	Bentley Motors Ltd	7984381	281	709	10	0.035499639608454904	t
541	58	Jaguar Land Rover	7984381	94	5067	14	0.148303302180842755	t
1294	98	BDO LLP	7984381	9558	1229	21	0.00204563565044354589	t
878	78	National Health Service (NHS)	7984381	36796	98520	13493	0.355998997077608181	t
879	78	Bupa	7984381	36796	2413	168	0.00428323791875189104	t
880	78	NHS Direct	7984381	36796	818	120	0.00317339862491056385	t
881	78	BMI Healthcare	7984381	36796	967	120	0.00315465079144920408	t
882	78	Barchester Healthcare	7984381	36796	840	99	0.00259727396826166116	t
883	78	NHS Professionals	7984381	36796	814	90	0.00235482117936075758	t
884	78	Nottingham University Hospital	7984381	36796	636	85	0.00224070446282380624	t
885	78	Care UK	7984381	36796	1632	89	0.00222459414046533629	t
886	78	Spire Healthcare	7984381	36796	611	76	0.00199812584953725642	t
887	78	GP Surgery	7984381	36796	271	74	0.00198630075778431087	t
888	78	Salford Royal Foundation Trust	7984381	36796	400	68	0.00180625326341740688	t
889	78	Kings College Hospital	7984381	36796	482	65	0.00171402758948513748	t
890	78	HCA International Ltd	7984381	36796	406	63	0.00166898485992146139	t
891	78	Brighton & Sussex University Hospitals NHS Trust	7984381	36796	328	58	0.001542285704819839	t
892	78	The Ipswich Hospital NHS Trust	7984381	36796	264	57	0.00152303577406481534	t
893	78	South London and Maudsley NHS Foundation Trust	7984381	36796	738	56	0.00143609232383186207	t
894	78	Southend University Hospital	7984381	36796	386	54	0.00142577712470667753	t
895	78	Four Seasons Health Care	7984381	36796	352	52	0.00137544977094583945	t
896	78	Ramsay Health Care	7984381	36796	316	50	0.00132537406595629494	t
897	78	Priory Group	7984381	36796	669	51	0.00130826074925941959	t
898	78	UHSM - University Hospital of South Manchester NHS FT	7984381	36796	274	49	0.00130335599871704349	t
899	78	Private	7984381	36796	3527	63	0.00127628695231808242	t
900	78	Oxford Health NHS Foundation Trust	7984381	36796	296	48	0.00127328517079640271	t
901	78	Pennine Care NHS Foundation Trust	7984381	36796	303	48	0.00127240440009687575	t
902	78	Nuffield Health	7984381	36796	1190	52	0.00127000893577389716	t
903	78	South Essex Partnership University NHS Foundation Trust	7984381	36796	422	48	0.0012574312982049174	t
904	78	Central London Community Healthcare NHS Trust	7984381	36796	277	46	0.00122107045125086403	t
905	78	Four Seasons Healthcare	7984381	36796	341	46	0.0012130176905694747	t
906	78	Berkshire Healthcare NHS Foundation Trust	7984381	36796	228	42	0.00111802508040190034	t
907	78	Central Manchester & Manchester Children's Foundation Trust	7984381	36796	328	42	0.00110544264183722952	t
908	78	HCA	7984381	36796	373	41	0.0010724778530467145	t
909	78	Partnerships in Care	7984381	36796	323	39	0.00102416368945622369	t
910	78	NELFT	7984381	36796	141	38	0.0010197610362075117	t
911	78	Lancashire Care NHS Foundation Trust	7984381	36796	397	39	0.00101485268491836736	t
912	78	Sandwell and West Birmingham NHS Trust	7984381	36796	224	38	0.00100931761219883484	t
913	78	Hertfordshire Community NHS Trust	7984381	36796	145	37	0.00099195504722851156	t
914	78	NHS Blood and Transplant	7984381	36796	434	38	0.000982894491213025983	t
915	78	Nottinghamshire Healthcare	7984381	36796	297	37	0.000972829740610211863	t
916	78	GP Practice	7984381	36796	100	36	0.000970314453146200583	t
917	78	Cambridgeshire Community Services NHS Trust	7984381	36796	133	36	0.00096616224841985913	t
918	78	CNWL	7984381	36796	219	36	0.000955341351254242123	t
919	78	The London Clinic	7984381	36796	272	36	0.00094867265881496657	t
920	78	North East London NHS Foundation Trust	7984381	36796	308	36	0.000944142980931685083	t
921	78	University College London Hospitals	7984381	36796	369	36	0.000936467693407235782	t
922	78	West Herts NHS Trust	7984381	36796	186	34	0.000904888173107757363	t
923	78	Papworth Hospital NHS Foundation Trust	7984381	36796	188	34	0.000904636524336464008	t
924	78	Solent NHS Trust	7984381	36796	280	34	0.000893060680856966717	t
925	78	West London Mental Health NHS Trust	7984381	36796	303	34	0.000890166719987092476	t
926	78	Heatherwood & Wexham Park Hospitals' NHS Foundation Trust	7984381	36796	200	33	0.000875823940272290333	t
927	78	Alder Hey Children's Hospital	7984381	36796	222	33	0.00087305580378806277	t
928	79	National Health Service (NHS)	7984381	18717	98520	3319	0.165374005586467698	t
929	79	Bupa	7984381	18717	2413	311	0.0163520280853941442	t
931	79	Barchester Healthcare	7984381	18717	840	175	0.00926630565153818871	t
932	79	Four Seasons Healthcare	7984381	18717	341	116	0.00616932816477514141	t
933	79	Four Seasons Health Care	7984381	18717	352	87	0.00461491301287018409	t
934	79	HC-One	7984381	18717	326	70	0.00370777764874111139	t
935	79	Care Home	7984381	18717	204	63	0.00334822305371197497	t
936	79	Private	7984381	18717	3527	70	0.00330592790966097953	t
937	79	NHS Professionals	7984381	18717	814	56	0.00289677404787163674	t
938	79	Allied Healthcare	7984381	18717	323	46	0.00242288456175827893	t
939	79	Anchor Trust	7984381	18717	458	45	0.00235238391775030066	t
940	79	Nurse Plus UK Ltd	7984381	18717	126	43	0.00228695699490967692	t
941	79	Nursing Home	7984381	18717	167	43	0.00228180990359374896	t
942	79	Priory Group	7984381	18717	669	42	0.00216523651536758635	t
943	79	Bluebird Care	7984381	18717	306	39	0.00205014839140786349	t
944	79	Bupa Home Healthcare	7984381	18717	213	37	0.00195471769235975711	t
945	79	Newcross Healthcare Solutions	7984381	18717	126	34	0.00180498085612695825	t
946	79	McDonald's Corporation	7984381	18717	2108	37	0.00171682164251381851	t
947	79	St Andrew's Healthcare	7984381	18717	455	32	0.0016565727781685689	t
948	79	HCA	7984381	18717	373	30	0.00155976115218204301	t
949	79	BMI Healthcare	7984381	18717	967	31	0.00153874400181657021	t
950	79	FSHC	7984381	18717	120	29	0.0015379695674565051	t
951	79	McDonald's	7984381	18717	1455	31	0.00147748106127576929	t
952	79	NHS Direct	7984381	18717	818	27	0.0013432376676547641	t
953	79	Advanced ChemDry	7984381	18717	4703	35	0.00128394261524097161	t
954	79	Southern Cross Healthcare	7984381	18717	98	24	0.0012729668997873895	t
955	79	Carewatch Care Services Ltd	7984381	18717	243	23	0.00120121086765357537	t
956	79	Royal Bournemouth Hospital	7984381	18717	283	23	0.00119618931515023106	t
957	79	Marie Curie Cancer Care	7984381	18717	365	23	0.00118589513251837514	t
958	79	Prestige Nursing + Care	7984381	18717	66	22	0.00116987833317168323	t
959	79	Four Seasons	7984381	18717	105	22	0.00116498231948092236	t
960	79	Methodist Homes MHA	7984381	18717	103	21	0.00111168049279689865	t
961	79	Caring Homes Group	7984381	18717	127	21	0.0011086675612948921	t
962	79	The Doctors Laboratory	7984381	18717	141	21	0.00110691001791872142	t
963	79	Sevacare	7984381	18717	113	20	0.00105687220036187156	t
964	79	Housing 21	7984381	18717	191	20	0.00104708017298035003	t
965	79	Orchard Care Homes	7984381	18717	89	19	0.00100633222755468731	t
966	79	Caremark Ltd	7984381	18717	152	19	0.000998423282361919889	t
967	79	Spire Healthcare	7984381	18717	611	20	0.000994353871695234344	t
968	79	South London and Maudsley NHS Foundation Trust	7984381	18717	738	20	0.000978410442497116076	t
969	79	Sunrise Senior Living	7984381	18717	332	19	0.00097582629609687028	t
970	79	Home Care Assistance	7984381	18717	50	18	0.000957675336936256952	t
971	79	Runwood Homes Senior Living	7984381	18717	61	18	0.000956294409997837332	t
972	79	London Care	7984381	18717	96	18	0.000951900551557410953	t
973	79	Lloydspharmacy	7984381	18717	543	19	0.000949337606641728789	t
974	79	Surrey County Council	7984381	18717	1467	21	0.000940445552432856227	t
975	79	Ramsay Health Care	7984381	18717	316	18	0.000924282012789017036	t
976	79	Somerset Care	7984381	18717	104	17	0.000897343336747551167	t
977	79	Carewatch	7984381	18717	113	17	0.000896213487434298632	t
978	80	National Health Service (NHS)	7984381	7355	92942	1004	0.124980430464169845	t
979	80	Care UK	7984381	7355	1632	77	0.0102741338567515286	t
980	80	Rethink Mental Illness	7984381	7355	149	51	0.0069217731833766151	t
981	80	Bluebird Care	7984381	7355	306	44	0.00594948062833636909	t
982	80	NHS Professionals	7984381	7355	814	40	0.00534144858437394284	t
983	80	Voyage Care Ltd	7984381	7355	229	32	0.00432608586059156797	t
984	80	Allied Healthcare	7984381	7355	323	30	0.00404212743902434418	t
985	80	Social Services	7984381	7355	401	28	0.00376017477749851893	t
986	80	Priory Group	7984381	7355	669	24	0.00318222913415707603	t
987	80	Caremark Ltd	7984381	7355	152	23	0.0031109529648327746	t
988	80	Mencap	7984381	7355	669	23	0.00304614184349507331	t
989	80	Carewatch Care Services Ltd	7984381	7355	243	21	0.00282737062327331279	t
990	80	Private	7984381	7355	3527	22	0.00255177566543819418	t
991	80	Turning Point	7984381	7355	318	17	0.00227361946043124494	t
992	80	Local Authority	7984381	7355	992	17	0.00218912681868731673	t
993	80	MiHomecare	7984381	7355	110	16	0.00216360705030742761	t
994	80	Camden and Islington NHS Foundation Trust	7984381	7355	279	16	0.00214242120987015189	t
995	80	Carewatch	7984381	7355	113	15	0.00202714367963766247	t
996	80	NHS Direct	7984381	7355	818	15	0.00193876487781352385	t
997	80	London Care	7984381	7355	96	14	0.00189318750901964583	t
998	80	Cygnet Health Care	7984381	7355	170	14	0.001883910868828176	t
999	80	Creative Support	7984381	7355	228	14	0.00187663998867810514	t
1000	80	Medacs Healthcare	7984381	7355	232	14	0.00187613854866775539	t
1001	80	Mears Group PLC	7984381	7355	556	14	0.00183552190782942785	t
1002	80	Sevacare	7984381	7355	113	13	0.0017549690983136568	t
1003	80	Richmond Fellowship	7984381	7355	207	13	0.00174318525807043824	t
1004	80	Rethink	7984381	7355	53	12	0.0016264034078068998	t
1005	80	Lifeways Group	7984381	7355	89	12	0.0016218904477137521	t
1006	80	Care Management Group Ltd	7984381	7355	100	12	0.00162051148768529042	t
1007	80	Dimensions	7984381	7355	282	12	0.00159769596721437814	t
1008	80	The Cambian Group	7984381	7355	292	12	0.00159644236718850378	t
1009	80	GE Healthcare	7984381	7355	814	11	0.00139491715517586225	t
1010	80	Barchester Healthcare	7984381	7355	840	11	0.00139165779510858913	t
1011	80	Fife Council	7984381	7355	1119	11	0.0013566823543866961	t
1012	80	Hesley Group	7984381	7355	56	10	0.00135385274647513171	t
1013	80	CareTech	7984381	7355	98	10	0.00134858762636645962	t
1014	80	Private Healthcare Systems	7984381	7355	169	10	0.0013396870661827522	t
1015	80	Barnet Enfield and Haringey Mental Health NHS Trust	7984381	7355	209	10	0.00133467266607925497	t
1016	81	National Health Service (NHS)	7984381	26592	98520	8764	0.318293791552265615	t
1017	81	Imperial College London	7984381	26592	7127	137	0.00427354070409218141	t
1018	81	Litfield House	7984381	26592	293	88	0.00328350502034806865	t
1019	81	Quintiles	7984381	26592	780	74	0.00269407370707010121	t
1020	81	GSK	7984381	26592	3270	82	0.00268302038711322553	t
1021	81	Nottingham University Hospital	7984381	26592	636	69	0.00252351439624632105	t
1022	81	Kings College Hospital	7984381	26592	482	66	0.00242967363161777482	t
1023	81	King's College London	7984381	26592	5864	78	0.00220612661598950689	t
1024	81	Moorfields Eye Hospital, London	7984381	26592	385	58	0.00214001528404991412	t
1025	81	University College London	7984381	26592	7053	80	0.00213217517080899546	t
1026	81	GlaxoSmithKline	7984381	26592	2234	63	0.00209631910255038715	t
1027	81	Care UK	7984381	26592	1632	60	0.00205877538223904998	t
1028	81	University of Oxford	7984381	26592	7286	77	0.00198970280762964533	t
1029	81	University Hospital Birmingham	7984381	26592	414	47	0.00172133051915525207	t
1030	81	Amgen	7984381	26592	307	46	0.00169704550713693737	t
1031	81	Southend University Hospital	7984381	26592	386	43	0.00157392525294162825	t
1032	81	AstraZeneca	7984381	26592	2122	48	0.00154442899556675429	t
1033	81	Central Manchester & Manchester Children's Foundation Trust	7984381	26592	328	40	0.00146802083595939416	t
1034	81	The Institute of Cancer Research	7984381	26592	399	38	0.00138363684399775465	t
1035	81	basildon and thurrock hospital	7984381	26592	172	37	0.00137443139742154962	t
1036	81	Nuffield Health	7984381	26592	1190	40	0.00135969929086690697	t
1037	81	University College London Hospitals	7984381	26592	369	37	0.00134967577748741976	t
1038	81	Addenbrookes Hospital	7984381	26592	195	36	0.00133381018950761636	t
1039	81	Public Health England	7984381	26592	927	37	0.00127955579818160993	t
1040	81	Salford Royal Foundation Trust	7984381	26592	400	35	0.00127031830733981667	t
1041	81	NHS Connecting for Health	7984381	26592	586	35	0.00124694498090454665	t
1042	81	Bupa	7984381	26592	2413	41	0.00124374434427360222	t
1043	81	NHS Direct	7984381	26592	818	35	0.00121779115438313493	t
1044	81	Colchester Hospital University NHS Foundation Trust	7984381	26592	218	33	0.00121772706585195826	t
1045	81	Sheffield Teaching Hospitals NHS Foundation Trust	7984381	26592	236	33	0.00121546513103564196	t
1046	81	University Hospital of Wales	7984381	26592	112	32	0.00119331639078829282	t
1047	81	Royal Bournemouth Hospital	7984381	26592	283	32	0.00117182801003328668	t
1048	81	Hull & East Yorkshire Hospitals NHS Trust	7984381	26592	198	31	0.00114477841101725186	t
1049	81	Gilead Sciences	7984381	26592	251	31	0.00113811826961365348	t
1050	81	Croydon Health Services NHS Trust	7984381	26592	259	31	0.00113711296525084607	t
1051	81	Central Manchester University Hospitals NHS Foundation Trust	7984381	26592	263	31	0.00113661031306944247	t
1052	81	UHSM - University Hospital of South Manchester NHS FT	7984381	26592	274	31	0.00113522801957058241	t
1053	81	Wrightington, Wigan & Leigh NHS Foundation Trust	7984381	26592	264	29	0.0010610227342823669	t
1054	81	PPD	7984381	26592	360	29	0.00104895908192867903	t
1055	81	Covance	7984381	26592	420	29	0.00104141929920762441	t
1056	81	Great Ormond Street Hospital for Children NHS Trust	7984381	26592	210	28	0.00103007758086045382	t
1057	81	NHS Professionals	7984381	26592	814	30	0.0010296390172102269	t
1058	81	Royal Free Hampstead NHS Trust	7984381	26592	255	28	0.00102442274381966264	t
1059	81	Novartis	7984381	26592	619	29	0.00101641235318279265	t
1060	81	BMI Healthcare	7984381	26592	967	30	0.00101041257127153705	t
1061	81	South Essex Partnership University NHS Foundation Trust	7984381	26592	422	28	0.00100343701524606009	t
1062	81	Allergan	7984381	26592	211	27	0.000992220959944240454	t
1063	81	Doncaster and Bassetlaw NHS Trust	7984381	26592	217	27	0.000991466981672134949	t
1064	81	Sandwell and West Birmingham NHS Trust	7984381	26592	224	27	0.000990587340354678707	t
1065	81	University Hospitals of Leicester	7984381	26592	160	26	0.000960898817386274945	t
1066	82	National Health Service (NHS)	7984381	4918	82724	1177	0.229105318816495623	t
1067	82	Litfield House	7984381	4918	293	37	0.00749130112979631748	t
1068	82	GP	7984381	4918	128	21	0.00425661904318971451	t
1069	82	NHS Connecting for Health	7984381	4918	586	16	0.00318192164395526096	t
1295	98	Citi	7984381	9558	3422	23	0.00198014480727346214	t
1070	82	Bradford and Airedale NHS (National Health Service)	7984381	4918	109	13	0.0026313200708879339	t
1071	82	NHS Professionals	7984381	4918	814	12	0.00233950825013288892	t
1072	82	Locum	7984381	4918	218	11	0.00221073998255930538	t
1073	82	The Surgery	7984381	4918	91	10	0.00202319582994182814	t
1074	83	National Health Service (NHS)	7984381	2824	96204	871	0.296483601270025765	t
1075	83	University Hospital Birmingham	7984381	2824	414	15	0.00526162448461420587	t
1076	83	Kings College Hospital	7984381	2824	482	15	0.00525310484364691164	t
1077	83	Wrightington, Wigan & Leigh NHS Foundation Trust	7984381	2824	264	13	0.00457195193515142276	t
1078	83	Nottingham University Hospital	7984381	2824	636	12	0.00417111154994384298	t
1079	83	BMI Healthcare	7984381	2824	967	11	0.00377540800708419007	t
1080	83	University Hospital of Wales	7984381	2824	112	10	0.00352829702580118205	t
1081	83	Ramsay Health Care	7984381	2824	316	10	0.00350273810289929719	t
1082	84	National Health Service (NHS)	7984381	5410	85568	267	0.0386623229955494266	t
1083	84	IDH Group	7984381	5410	319	78	0.014387540520790186	t
1084	84	Oasis Dental Care	7984381	5410	219	65	0.0119954866962909742	t
1085	84	IDH	7984381	5410	71	28	0.00517021157327480357	t
1086	84	Bupa	7984381	5410	2413	17	0.00284203967224510006	t
1087	84	Integrated Dental Holdings	7984381	5410	97	14	0.00257739802582463524	t
1088	84	Denticare	7984381	5410	23	13	0.0024017041916956838	t
1089	84	mydentist (UK)	7984381	5410	70	13	0.00239581370782251252	t
1090	84	The Village Dental Practice	7984381	5410	18	10	0.00184742619993695338	t
1091	84	Rodericks Limited	7984381	5410	41	10	0.00184454362272242281	t
1092	84	Genix Healthcare	7984381	5410	42	10	0.00184441829327831289	t
1093	84	Oasis	7984381	5410	125	10	0.00183401594941718098	t
1094	85	National Health Service (NHS)	7984381	3301	96367	943	0.273714732191071453	t
1095	85	NHS Professionals	7984381	3301	814	13	0.00383783818831506199	t
1096	85	BMI Healthcare	7984381	3301	967	13	0.00381866785046604913	t
1097	85	Shuropody	7984381	3301	46	10	0.00302487436710874866	t
1098	85	Spire Healthcare	7984381	3301	611	10	0.00295408194302579233	t
1099	85	Nuffield Health	7984381	3301	1190	10	0.00288153537038148867	t
1100	86	National Health Service (NHS)	7984381	1141	91198	447	0.380393922309306354	t
1101	87	National Health Service (NHS)	7984381	542	83387	176	0.314300817621855189	t
1102	88	Bupa	7984381	3263	2413	50	0.0150272482880246458	t
1103	88	Sunrise Senior Living	7984381	3263	332	38	0.0116088878487371362	t
1104	88	National Health Service (NHS)	7984381	3263	74307	64	0.0103115214568421393	t
1105	88	Care UK	7984381	3263	1632	31	0.00929986123714172247	t
1106	88	HC-One	7984381	3263	326	30	0.00915690572188177301	t
1107	88	Bluebird Care	7984381	3263	306	20	0.00609349425992812988	t
1108	88	Four Seasons Health Care	7984381	3263	352	17	0.00516795544342129893	t
1109	88	Priory Group	7984381	3263	669	16	0.00482164495959679518	t
1110	88	Voyage Care Ltd	7984381	3263	229	15	0.00457018334281071928	t
1111	88	The Cambian Group	7984381	3263	292	10	0.00302933102359901653	t
1112	88	Anchor Trust	7984381	3263	458	10	0.00300853193254435472	t
1113	89	National Health Service (NHS)	7984381	1855	76801	219	0.108465594141118643	t
1114	89	East of England Ambulance Trust	7984381	1855	328	86	0.0463308697656278912	t
1115	89	Scottish Ambulance Service	7984381	1855	246	85	0.0458019333716192523	t
1116	89	London Ambulance Service	7984381	1855	382	73	0.0393143901791207159	t
1117	89	West Midlands Ambulance Service NHS Trust	7984381	1855	252	62	0.0333993786034963575	t
1118	89	East Midlands Ambulance Service	7984381	1855	223	44	0.0236972525702878363	t
1119	89	North West Ambulance Service NHS Trust	7984381	1855	222	39	0.0210013336860147282	t
1120	89	Yorkshire Ambulance Service NHS Trust	7984381	1855	282	38	0.0204546084366988845	t
1121	89	South Central Ambulance Service NHS Trust	7984381	1855	147	33	0.0177754762187015865	t
1122	89	The London Ambulance Service NHS Trust	7984381	1855	149	33	0.0177752256714437396	t
1123	89	South Western Ambulance Service NHS Foundation Trust	7984381	1855	172	32	0.0172331355463980831	t
1124	89	NWAS	7984381	1855	75	30	0.0161668694252428968	t
1125	89	Welsh Ambulance Services NHS Trust	7984381	1855	162	29	0.015616761787946104	t
1126	89	South East Coast Ambulance Service	7984381	1855	211	26	0.0139929968853876076	t
1127	89	South Central Ambulance Service NHS Foundation Trust	7984381	1855	91	20	0.0107727767313760478	t
1128	89	ERS Medical	7984381	1855	85	19	0.010234319541569184	t
1129	89	North East Ambulance Service	7984381	1855	140	19	0.0102274294919783657	t
1130	89	Medical Services Ltd	7984381	1855	75	17	0.0091571546146976112	t
1285	98	Bupa	7984381	9558	2413	29	0.00273516674980353114	t
1131	89	East of England Ambulance Service	7984381	1855	44	14	0.00754341160245303524	t
1132	89	SECAMB	7984381	1855	59	14	0.00754153249801917547	t
1133	89	LAS	7984381	1855	40	11	0.00592628620222751187	t
1134	89	Royal Air Force	7984381	1855	3136	11	0.00553843904707887816	t
1135	89	UK Specialist Ambulance Service	7984381	1855	22	10	0.00538933229596773745	t
1136	89	EMAS	7984381	1855	39	10	0.00538720264427602989	t
1137	89	Ambulance Service	7984381	1855	23	9	0.0048499981907584068	t
1138	90	National Health Service (NHS)	7984381	9524	98520	3298	0.334342797541073489	t
1139	90	BMI Healthcare	7984381	9524	967	47	0.00481953873183633974	t
1140	90	Spire Healthcare	7984381	9524	611	33	0.00339245291275603201	t
1141	90	GP Surgery	7984381	9524	271	31	0.00322484031778781221	t
1142	90	University College London Hospitals	7984381	9524	369	28	0.00289718181376627136	t
1143	90	Northampton General Hospital	7984381	9524	272	26	0.00269909845298996198	t
1144	90	University Hospital Birmingham	7984381	9524	414	23	0.00236592260865749193	t
1145	90	Nottingham University Hospital	7984381	9524	636	23	0.00233808511890689187	t
1146	90	Care UK	7984381	9524	1632	24	0.00231831589146309393	t
1147	90	NHS Direct	7984381	9524	818	22	0.00221014009893534405	t
1148	90	Royal Devon and Exeter NHS Trust	7984381	9524	244	19	0.00196674642875345734	t
1149	90	UHSM - University Hospital of South Manchester NHS FT	7984381	9524	274	18	0.00185786131167421198	t
1150	90	Central Manchester & Manchester Children's Foundation Trust	7984381	9524	328	18	0.00185109003038352545	t
1151	90	Nuffield Health	7984381	9524	1190	18	0.0017430003179284934	t
1152	90	Brighton & Sussex University Hospitals NHS Trust	7984381	9524	328	16	0.00164084344210357587	t
1153	90	London Bridge Hospital	7984381	9524	132	15	0.0015602973911668335	t
1154	90	Spire Healthcare Group plc	7984381	9524	279	15	0.00154186445876440927	t
1155	90	HCA	7984381	9524	373	15	0.00153007741355469583	t
1156	90	Southend University Hospital	7984381	9524	386	15	0.00152844729028101195	t
1157	90	Salford Royal Foundation Trust	7984381	9524	400	15	0.00152669177290935256	t
1158	90	NHS Connecting for Health	7984381	9524	586	15	0.00150336847068587693	t
1159	90	Priory Group	7984381	9524	669	15	0.00149296076055389589	t
1160	90	Bupa	7984381	9524	2413	17	0.0014845200419642678	t
1161	90	Doctors Surgery	7984381	9524	92	14	0.00146018986094588574	t
1162	90	Norfolk & Norwich University NHS Trust	7984381	9524	162	14	0.00145141227408758836	t
1163	90	Wrightington, Wigan & Leigh NHS Foundation Trust	7984381	9524	264	14	0.00143862207609406949	t
1164	90	The Queen Elizabeth Hospital King's Lynn NHS Foundation Trust	7984381	9524	150	13	0.0013477937091233216	t
1165	90	Private	7984381	9524	3527	17	0.00134483101681936545	t
1166	90	Blackpool Fylde and Wyre Hospitals NHS Foundation Trust	7984381	9524	191	13	0.00134265255110631895	t
1167	90	Royal Surrey County Hospital	7984381	9524	192	13	0.00134252715700834322	t
1168	90	The London Clinic	7984381	9524	272	13	0.00133249562917028917	t
1169	90	IDH Group	7984381	9524	319	13	0.00132660210656543255	t
1170	90	Bristol Royal Infirmary	7984381	9524	183	12	0.00123853240975014948	t
1171	90	Colchester Hospital University NHS Foundation Trust	7984381	9524	218	12	0.00123414361632100079	t
1172	90	North East London NHS Foundation Trust	7984381	9524	308	12	0.00122285814750319006	t
1173	90	Moorfields Eye Hospital, London	7984381	9524	385	12	0.00121320280195906321	t
1174	90	St Helens & Knowsley Teaching Hospitals NHS Trust	7984381	9524	152	11	0.00113729633264742056	t
1175	90	NHS Greater Glasgow & Clyde	7984381	9524	177	11	0.00113416148019802876	t
1176	90	Hull & East Yorkshire Hospitals NHS Trust	7984381	9524	198	11	0.00113152820414053946	t
1177	90	Taunton & Somerset NHS Foundation Trust	7984381	9524	210	11	0.00113002347496483154	t
1178	90	Kingston Hospital NHS Trust	7984381	9524	279	11	0.00112137128220450989	t
1179	90	Surrey & Sussex Healthcare NHS Trust	7984381	9524	98	10	0.00103894431979813218	t
1180	90	GP Practice	7984381	9524	100	10	0.00103869353160218093	t
1181	90	James Paget Hospital	7984381	9524	114	10	0.00103693801423052133	t
1182	90	Coventry & Warwickshire Partnership Trust	7984381	9524	131	10	0.00103480631456493496	t
1183	90	Royal Bolton Hospitals NHS Foundation Trust	7984381	9524	157	10	0.00103154606801756743	t
1184	90	Rotherham NHS Foundation trust	7984381	9524	195	10	0.00102678109229449176	t
1185	90	Sandwell and West Birmingham NHS Trust	7984381	9524	224	10	0.00102314466345319725	t
1186	90	Salisbury NHS Foundation Trust	7984381	9524	225	10	0.00102301926935522152	t
1187	90	Croydon Health Services NHS Trust	7984381	9524	259	10	0.00101875587002404856	t
1188	91	National Health Service (NHS)	7984381	3557	97704	648	0.170014840726440269	t
1189	91	Care UK	7984381	3557	1632	17	0.00457694834890331331	t
1190	91	Nottingham University Hospital	7984381	3557	636	15	0.00413922531458876895	t
1191	91	Priory Group	7984381	3557	669	14	0.00385382931427537094	t
1192	91	Barchester Healthcare	7984381	3557	840	14	0.00383240295529288988	t
1193	91	GP Surgery	7984381	3557	271	13	0.00362243776262541903	t
1194	91	BMI Healthcare	7984381	3557	967	12	0.00325396763362555954	t
1195	91	The Cambian Group	7984381	3557	292	11	0.00305728427752032916	t
1196	91	Nuffield Health	7984381	3557	1190	11	0.00294476456777607214	t
1197	92	National Health Service (NHS)	7984381	1124	94125	526	0.456247117518817413	t
1198	92	Public Health England	7984381	1124	927	14	0.0123411516639452632	t
1199	92	The Doctors Laboratory	7984381	1124	141	13	0.0115498027427033915	t
1200	93	National Health Service (NHS)	7984381	1997	96042	813	0.395180771371027695	t
1201	93	InHealth	7984381	1997	154	31	0.0155078759969262021	t
1202	93	Alliance Medical Ltd	7984381	1997	105	18	0.00900262128082351953	t
1203	93	Nottingham University Hospital	7984381	1997	636	16	0.00793434699542895118	t
1204	93	BMI Healthcare	7984381	1997	967	16	0.00789288068661694701	t
1205	93	Spire Healthcare	7984381	1997	611	13	0.00643484968422248452	t
1206	94	Specsavers	7984381	1613	1610	247	0.152960069371322921	t
1207	94	Boots Opticians	7984381	1613	596	111	0.0687551151795971621	t
1208	94	Vision Express	7984381	1613	452	83	0.0514106880175260184	t
1209	94	Locum Optometrist	7984381	1613	50	32	0.0198365548144578165	t
1210	94	Optical Express	7984381	1613	159	19	0.0117617554660351554	t
1211	94	Locum	7984381	1613	218	16	0.00989410032980413655	t
1212	94	Boots UK	7984381	1613	4583	12	0.00686694522829204516	t
1213	95	National Health Service (NHS)	7984381	1522	97335	499	0.31572759037826853	t
1214	95	Boots UK	7984381	1522	4583	30	0.0191405596618820714	t
1215	95	Day Lewis Plc	7984381	1522	168	19	0.0124649092523365906	t
1216	95	BMI Healthcare	7984381	1522	967	15	0.00973619783099590255	t
1217	95	Pharmacy	7984381	1522	248	11	0.00719764384573168877	t
1218	95	Moorfields Eye Hospital, London	7984381	1522	385	10	0.00652332658269809667	t
1219	95	Interface Clinical Services	7984381	1522	13	9	0.00591277093689963375	t
1220	96	National Health Service (NHS)	7984381	1325	92524	734	0.54246416116882723	t
1274	98	Deloitte	7984381	9558	6014	50	0.00448336633176004036	t
1258	98	Royal Bank of Scotland	7984381	9558	10717	388	0.0392990654230166436	t
1259	98	HSBC	7984381	9558	11527	460	0.046739480869669392	t
1260	98	NatWest	7984381	9558	2331	227	0.0234859081320492012	t
1261	98	Lloyds	7984381	9558	12328	270	0.026736579090934836	t
1262	98	Barclays	7984381	9558	16137	465	0.0466851605786729115	t
1263	98	Lex Autolease	7984381	9558	225	11	0.00112403393113402403	t
1264	98	British American Tobacco	7984381	9558	901	12	0.00114401695255016232	t
1265	98	Handelsbanken	7984381	9558	418	90	0.0093750664173865763	t
1266	98	The Prince's Trust	7984381	9558	489	12	0.00119567954117438639	t
1267	98	Allied Irish Bank (GB)	7984381	9558	114	13	0.00134745232143532894	t
1268	98	The Co-operative Banking Group	7984381	9558	304	12	0.00121887754820225393	t
1269	98	BT	7984381	9558	7515	68	0.0061806452630141142	t
1270	98	Standard Life	7984381	9558	924	13	0.00124588266904304386	t
1271	98	AXA PPP healthcare	7984381	9558	485	14	0.00140568070578930295	t
1272	98	Lombard	7984381	9558	188	49	0.00510916566814670174	t
1273	98	Bloomberg LP	7984381	9558	1200	14	0.00131602354349240943	t
1275	98	Insight	7984381	9558	349	40	0.00414622899492019751	t
1276	98	Global Payments	7984381	9558	93	10	0.0010358362295926969	t
1277	98	Quintessentially Lifestyle	7984381	9558	82	38	0.00397020977573529256	t
1348	100	Brewin Dolphin	7984381	6656	405	62	0.00927190913274870791	t
1349	100	Towers Watson	7984381	6656	838	59	0.0087665358067607474	t
1350	100	Standard Life Investments	7984381	6656	342	55	0.00822724598548675405	t
1308	99	Santander	7984381	10390	4198	31	0.00246106416032700146	t
1309	99	HSBC	7984381	10390	10888	96	0.00788625344018154331	t
1310	99	Royal Bank of Scotland	7984381	10390	10717	95	0.00781132636116860062	t
1311	99	Barclays	7984381	10390	15788	164	0.0138250379273941616	t
1312	99	BNY Mellon	7984381	10390	1074	46	0.00429841484276222065	t
1313	99	Handelsbanken	7984381	10390	418	38	0.00360970791675190895	t
1314	99	Deutsche Bank	7984381	10390	4194	61	0.00535271974548687766	t
1315	99	American Express	7984381	10390	1795	37	0.00334064969312142203	t
1316	99	J.P. Morgan	7984381	10390	3396	57	0.00506730790907748783	t
1317	99	State Street	7984381	10390	660	34	0.00319387205553486658	t
1318	99	Aviva	7984381	10390	3140	37	0.00317197631488460186	t
1319	99	BNP Paribas	7984381	10390	2012	44	0.00398803880804999428	t
1320	99	Morgan Stanley	7984381	10390	2749	57	0.00514844670143378702	t
1321	99	Lloyds	7984381	10390	12438	120	0.0100047946435678596	t
1322	99	Citi	7984381	10390	3422	50	0.00438944471912174235	t
1323	99	Barclaycard	7984381	10390	1435	29	0.00261482208312739444	t
1324	99	Legal & General	7984381	10390	1221	26	0.00235254393895636916	t
1325	99	Bloomberg LP	7984381	10390	1200	23	0.00206606210556623156	t
1326	99	KPMG	7984381	10390	5288	26	0.00184251075732875017	t
1327	99	Langham Hall UK LLP	7984381	10390	39	19	0.00182617327012335917	t
1328	99	PwC	7984381	10390	6805	26	0.0016522672519122027	t
1329	99	Aberdeen Asset Management	7984381	10390	470	20	0.00186849434293438776	t
1330	99	Lloyds TSB	7984381	10390	1410	25	0.00223247008212539358	t
1331	99	Nationwide Building Society	7984381	10390	3053	31	0.00260465599533158104	t
1332	99	BNP Paribas Securities Services	7984381	10390	168	20	0.00190636747321507147	t
1333	99	Standard Life	7984381	10390	924	27	0.00248616182913275439	t
1334	99	Northern Trust	7984381	10390	309	16	0.00150319779133031069	t
1335	99	JPMorgan Chase	7984381	10390	1367	27	0.00243060621087334101	t
1336	99	Bank of America Merrill Lynch	7984381	10390	2362	45	0.00404051790587008075	t
1337	99	Apex Fund Services (UK) Ltd	7984381	10390	21	14	0.00134657161663172243	t
1338	99	Schroders	7984381	10390	615	17	0.00156119482866148981	t
1339	99	Moody's Investors Service	7984381	10390	275	17	0.00160383345215629942	t
1366	100	Baillie Gifford	7984381	6656	215	25	0.00373219330183658	t
1371	100	Henderson Global Investors	7984381	6656	320	21	0.00311756872033958988	t
1416	101	Skipton Financial Services	7984381	7695	67	24	0.0031135176721900199	t
1398	101	Old Mutual Wealth	7984381	7695	207	10	0.00127484818604026791	t
1399	101	Lloyds	7984381	7695	12501	133	0.0157334320184573176	t
1400	101	Nationwide Building Society	7984381	7695	3053	91	0.0114545287939360387	t
1401	101	HSBC	7984381	7695	11527	132	0.015725457984156449	t
1402	101	Positive Solutions	7984381	7695	177	68	0.00882324225981153711	t
1403	101	Cheetham Jackson	7984381	7695	21	10	0.00129816614038872789	t
1404	101	Wesleyan	7984381	7695	351	106	0.0137444641776993202	t
1405	101	Coutts	7984381	7695	681	49	0.00628854038140560199	t
1406	101	Towry	7984381	7695	243	42	0.0054328912340781332	t
1407	101	St. James's Place Wealth Management	7984381	7695	1115	197	0.025485954248536568	t
1408	101	EY	7984381	7695	4443	42	0.00490635678104839063	t
1409	101	True Potential LLP	7984381	7695	125	37	0.00479728493857441152	t
1410	101	Legal & General	7984381	7695	1221	36	0.00452980463813745272	t
1411	101	Santander	7984381	7695	4198	96	0.0119613848791393917	t
1412	101	Halifax	7984381	7695	875	32	0.00405286152277787529	t
1413	101	Your Move	7984381	7695	353	30	0.00385814247083793955	t
1414	101	Bellpenny	7984381	7695	85	29	0.00376166050228968771	t
1415	101	Saunderson House	7984381	7695	55	26	0.00337518181887230904	t
1417	101	Brewin Dolphin	7984381	7695	405	24	0.0030711441852557214	t
1418	101	Charles Stanley & Co. Limited	7984381	7695	117	11	0.00141621094844200722	t
1419	101	Chase de Vere	7984381	7695	90	23	0.0029805543879675646	t
1420	101	Aviva	7984381	7695	3140	25	0.00285834984532197956	t
1421	101	UBS Wealth Management	7984381	7695	250	10	0.00126945747616401088	t
1447	101	Fairstone Financial Management Ltd	7984381	7695	29	11	0.00142724309888643997	t
1448	102	Lloyds	7984381	2693	12438	139	0.0500743967981700094	t
1450	102	HSBC	7984381	2693	11527	108	0.0386733235067233741	t
1451	102	Barclays	7984381	2693	16137	83	0.0288092921302877877	t
1452	102	Nationwide Building Society	7984381	2693	3053	32	0.0115041673781557056	t
1453	102	Huntswood	7984381	2693	296	27	0.00999229117179636396	t
1454	102	Aviva	7984381	2693	3140	26	0.00926451719281387587	t
1455	102	J.P. Morgan	7984381	2693	3396	24	0.00848952703164576779	t
1456	102	Deutsche Bank	7984381	2693	4194	21	0.00727517306237631875	t
1457	102	Credit Suisse	7984381	2693	2990	20	0.00705455997467397105	t
1458	102	Citi	7984381	2693	3422	19	0.00662897771253132938	t
1459	102	Santander	7984381	2693	4117	31	0.0109994038701412642	t
1460	102	UBS	7984381	2693	2773	13	0.00448153859833134299	t
1461	102	PwC	7984381	2693	6805	16	0.00509075741323244263	t
1462	102	Barclaycard	7984381	2693	1435	13	0.00464917231190170588	t
1464	102	Standard Chartered Bank	7984381	2693	1092	12	0.00432068730537717334	t
1465	102	BNP Paribas	7984381	2693	2012	12	0.00420542346644986898	t
1466	102	Goldman Sachs	7984381	2693	3155	12	0.0040622206752608369	t
1468	102	Tesco Bank	7984381	2693	719	10	0.00362450252973653799	t
1469	102	BNY Mellon	7984381	2693	1074	10	0.00358002572232437146	t
1449	102	Royal Bank of Scotland	7984381	2693	10717	86	0.0306027216033855007	t
1422	101	Charles Derby Financial Services	7984381	7695	43	21	0.00272628679669688432	t
1423	101	2plan Wealth Management Ltd	7984381	7695	57	21	0.00272453168185345183	t
1424	101	Tilney Bestinvest	7984381	7695	106	10	0.00128751008598217359	t
1425	101	Lighthouse Financial Advice	7984381	7695	64	20	0.0025935742431663477	t
1426	101	NFU Mutual	7984381	7695	858	19	0.00236395427720914684	t
1427	101	Lloyds TSB	7984381	7695	1420	21	0.00255365871531070465	t
1428	101	Accenture	7984381	7695	4368	21	0.00218408167542220952	t
1429	101	Royal Bank of Scotland	7984381	7695	10478	33	0.00297905798679454605	t
1430	101	RBC Wealth Management	7984381	7695	65	10	0.00129265006516651152	t
1431	101	Wren Sterling (formerly Towergate Financial)	7984381	7695	32	15	0.00194718652791011195	t
1432	101	Goldman Sachs	7984381	7695	3155	18	0.00194591019627487431	t
1433	101	Succession Group Ltd	7984381	7695	37	14	0.00181647981991492715	t
1434	101	LEBC Group	7984381	7695	50	14	0.00181485007041745422	t
1435	101	Foster Denovo	7984381	7695	67	14	0.00181271885953614327	t
1436	101	Close Brothers Asset Management	7984381	7695	123	14	0.0018056984001624133	t
1437	101	AWD Chase de Vere	7984381	7695	44	13	0.00168552238122782324	t
1438	101	Ashcourt Rowan	7984381	7695	59	13	0.00168364190103843141	t
1439	101	AFH Wealth Management	7984381	7695	80	13	0.00168100922877328267	t
1440	101	Mortgage Advice Bureau	7984381	7695	102	13	0.00167825119116217459	t
1441	101	Clayton Holmes Naisbitt Financial Consultancy LLP	7984381	7695	14	10	0.00129904369781044414	t
1442	101	True Potential Wealth Management LLP	7984381	7695	45	23	0.00298619582853574053	t
1541	105	J.P. Morgan	7984381	13821	3396	302	0.0214626282464930734	t
1542	105	Accenture	7984381	13821	4368	248	0.0174268066487568395	t
1543	105	Deutsche Bank	7984381	13821	4194	215	0.0150568258127903604	t
1544	105	HSBC	7984381	13821	11527	225	0.0148616064377599805	t
1545	105	Morgan Stanley	7984381	13821	2749	179	0.0126288694170831137	t
1546	105	Citi	7984381	13821	3422	178	0.0124719545672086016	t
1547	105	Credit Suisse	7984381	13821	2990	170	0.0119463210099019241	t
1548	105	IMS Health	7984381	13821	334	20	0.00140767832075986516	t
1549	105	Royal Bank of Scotland	7984381	13821	10478	150	0.00955728127915330197	t
1550	105	Barclays	7984381	13821	15928	328	0.0217747995206834036	t
1551	105	BlackRock	7984381	13821	1208	119	0.00847345831059282198	t
1552	105	KPMG	7984381	13821	5288	119	0.00796157457845856655	t
1553	105	European Bank for Reconstruction and Development (EBRD)	7984381	13821	801	25	0.00171148333936319268	t
1554	105	Deloitte	7984381	13821	6014	113	0.00743561462647342099	t
1555	105	Bank of America Merrill Lynch	7984381	13821	2362	127	0.00890850852118358315	t
1556	105	Towers Watson	7984381	13821	838	81	0.00576567233557978304	t
1557	105	Moody's Investors Service	7984381	13821	275	72	0.00518399513443681612	t
1558	105	Aimia Inc	7984381	13821	207	19	0.0013511328301273641	t
1559	105	Bank of England	7984381	13821	1043	63	0.00443532841185495345	t
1521	104	EY	7984381	3097	4443	267	0.0856892395917821514	t
1522	104	PwC	7984381	3097	6805	171	0.0543835293466611164	t
1523	104	KPMG	7984381	3097	5288	144	0.0458521017961559807	t
1524	104	Deloitte	7984381	3097	6014	108	0.0341324760306766714	t
1525	104	Ernst & Young	7984381	3097	1872	105	0.0336823849007280782	t
1526	104	BDO LLP	7984381	3097	1229	74	0.0237493774984930475	t
1527	104	Grant Thornton UK LLP	7984381	3097	1583	33	0.0104612686973683811	t
1528	104	HM Revenue & Customs	7984381	3097	1980	28	0.00879643524993464244	t
1529	104	Smith & Williamson	7984381	3097	411	24	0.00770094649833349704	t
1530	104	Mazars	7984381	3097	520	19	0.00607219747039917674	t
1531	104	BP	7984381	3097	5408	19	0.00545976468389515121	t
1532	104	Wilkins Kennedy LLP	7984381	3097	95	14	0.00451035497028669588	t
1533	104	Ernst & Young LLP	7984381	3097	115	14	0.0045078491078214579	t
1534	104	Haines Watts	7984381	3097	182	14	0.00449945446856291238	t
1535	104	PricewaterhouseCoopers	7984381	3097	918	14	0.00440723872984217536	t
1536	104	RSM UK	7984381	3097	366	13	0.0041533821183829733	t
1537	104	Crowe Clark Whitehill LLP	7984381	3097	180	12	0.00385366822380992608	t
1538	104	Menzies LLP	7984381	3097	112	10	0.00321615132519222297	t
1539	104	Rawlinson & Hunter	7984381	3097	38	9	0.00290240460081384608	t
1540	105	Goldman Sachs	7984381	13821	3155	474	0.033959274258858009	t
1560	105	Nomura	7984381	13821	1229	87	0.00615149156972327141	t
1561	105	BNP Paribas	7984381	13821	2012	49	0.00329904825570268446	t
1562	105	JPMorgan Chase	7984381	13821	1367	42	0.00287261716670636404	t
1563	105	UBS	7984381	13821	2773	109	0.00755231948745393577	t
1564	105	Mercer	7984381	13821	619	37	0.00260406688553679313	t
1565	105	Lloyds	7984381	13821	12438	181	0.0115582292677876529	t
1628	107	London & Country Mortgages	7984381	2375	76	16	0.00672932519785917997	t
1614	107	Nationwide Building Society	7984381	2375	3053	132	0.0552129992596373728	t
1616	107	Barclays	7984381	2375	10994	63	0.0251568605422588833	t
1617	107	Halifax	7984381	2375	875	42	0.0175798507951905533	t
1618	107	Royal Bank of Scotland	7984381	2375	10717	54	0.0214009623777861313	t
1619	107	NatWest	7984381	2375	2331	46	0.0190821521623300676	t
1620	107	Sequence UK Ltd incorporating Barnard Marcus - Brown & Merry - Fox & Sons - William H Brown	7984381	2375	252	34	0.0142884780434497562	t
1622	107	Santander	7984381	2375	4117	53	0.0218066442788547379	t
1623	107	Countrywide Plc	7984381	2375	554	21	0.00877533006905255319	t
1624	107	John Charcol	7984381	2375	41	18	0.0075760658872495272	t
1625	107	Connells	7984381	2375	260	18	0.00754862917522500579	t
1627	107	Mortgage Advice Bureau	7984381	2375	102	17	0.00714724578468646943	t
1629	107	Lloyds	7984381	2375	12265	95	0.0384753206148930466	t
1630	107	HSBC	7984381	2375	9017	18	0.00645153653961435918	t
1631	107	Sequence / WIlliam H Brown	7984381	2375	133	11	0.00461629456898033242	t
1633	107	TSB Bank	7984381	2375	794	10	0.00411230539237748913	t
1634	108	J.P. Morgan	7984381	2911	3396	163	0.0555894403793067426	t
1635	108	Goldman Sachs	7984381	2911	3155	141	0.0480593385697226858	t
1636	108	Citi	7984381	2911	3422	132	0.0449330374155193293	t
1637	108	Morgan Stanley	7984381	2911	2749	104	0.0353951618605609294	t
1638	108	Credit Suisse	7984381	2911	2990	97	0.0329594179560660852	t
1591	106	BNP Paribas	7984381	1586	2012	30	0.0186672267530856653	t
1593	106	HSBC	7984381	1586	10336	31	0.0182551264982601241	t
1594	106	Barclays	7984381	1586	15788	83	0.0503655569435562112	t
1595	106	Royal Bank of Scotland	7984381	1586	10717	27	0.0156848296805265144	t
1596	106	Credit Suisse	7984381	1586	2990	20	0.0122382903388598852	t
1597	106	American Express	7984381	1586	1795	18	0.0111267026941114112	t
1598	106	Morgan Stanley	7984381	1586	2749	18	0.011007195679337764	t
1599	106	Nationwide Building Society	7984381	1586	3053	17	0.0103384714860846536	t
1600	106	J.P. Morgan	7984381	1586	3396	17	0.0102955040793054498	t
1601	106	Bank of America Merrill Lynch	7984381	1586	2362	22	0.0135782441135164928	t
1602	106	Deutsche Bank	7984381	1586	4194	15	0.00893425450537051712	t
1603	106	Moody's Investors Service	7984381	1586	275	14	0.008794543020072456	t
1605	106	Lloyds	7984381	1586	12265	51	0.0306263276784982455	t
1606	106	Barclaycard	7984381	1586	1435	12	0.00738794592061544752	t
1607	106	Euler Hermes	7984381	1586	146	11	0.00691877589354097759	t
1608	106	Sumitomo Mitsui Banking Corporation	7984381	1586	217	11	0.00690988176560708954	t
1609	106	Santander	7984381	1586	4117	34	0.0209261038237256863	t
1610	106	BlueBay Asset Management	7984381	1586	172	10	0.00628487659557830283	t
1612	106	UBS	7984381	1586	2773	20	0.0122654738002916253	t
1613	107	Countrywide Mortgage Services	7984381	2375	190	146	0.0614681718117633946	t
1655	108	Fidelity Worldwide Investment	7984381	2911	589	17	0.00576825155774104027	t
1706	110	TSB Bank	7984381	1876	794	37	0.0196279821123585101	t
1708	110	Lloyds	7984381	1876	12501	153	0.0800096203588848143	t
1709	110	Santander	7984381	1876	4198	71	0.0373294762496527779	t
1669	109	Deloitte	7984381	5582	6014	201	0.0352800433045905998	t
1710	110	Halifax	7984381	1876	875	31	0.0164187890348996939	t
1679	109	Lloyds	7984381	5582	12172	37	0.00510754299481014969	t
1685	109	UHY Hacker Young	7984381	5582	117	14	0.00249515241563425015	t
1666	109	KPMG	7984381	5582	5288	469	0.083416088882147521	t
1667	109	EY	7984381	5582	4443	258	0.0456954778037147111	t
1668	109	BDO LLP	7984381	5582	1229	221	0.0394652094463531361	t
1670	109	Grant Thornton UK LLP	7984381	5582	1583	195	0.0347597544957086307	t
1671	109	Mazars	7984381	5582	520	106	0.0189377219505921235	t
1672	109	PwC	7984381	5582	6805	90	0.0152816479548212054	t
1673	109	Ernst & Young	7984381	5582	1872	74	0.013031549971229562	t
1674	109	Royal Bank of Scotland	7984381	5582	10073	72	0.0116451558607032924	t
1675	109	Baker Tilly	7984381	5582	625	58	0.0103194776980236533	t
1676	109	RSM UK	7984381	5582	366	47	0.00837994022067890462	t
1677	109	MHA MacIntyre Hudson	7984381	5582	113	39	0.00697746852403740257	t
1678	109	Moore Stephens	7984381	5582	284	36	0.00641821895351816531	t
1680	109	Haines Watts	7984381	5582	182	24	0.00427973173808169922	t
1681	109	HSBC	7984381	5582	11527	29	0.00375420149934303608	t
1682	109	Crowe Clark Whitehill LLP	7984381	5582	180	18	0.00320434685521666773	t
1683	109	Santander	7984381	5582	3832	31	0.00507717754406767155	t
1684	109	HW Fisher & Company	7984381	5582	73	14	0.0025006670300517838	t
1686	109	PRGX	7984381	5582	52	12	0.00214475382272911802	t
1687	109	RSM Tenon	7984381	5582	112	12	0.00213723389397793605	t
1688	109	PricewaterhouseCoopers	7984381	5582	918	12	0.00203621618442039517	t
1689	109	Buzzacott	7984381	5582	64	11	0.00196397724578609156	t
1690	109	Wilkins Kennedy LLP	7984381	5582	95	11	0.00196009194926464797	t
1696	110	HSBC	7984381	1876	11527	249	0.131316371383592728	t
1697	110	Barclays	7984381	1876	15105	171	0.0892805446314460099	t
1699	110	Royal Bank of Scotland	7984381	1876	10717	114	0.0594393108364889566	t
1700	110	Nationwide Building Society	7984381	1876	3053	80	0.0422714837623534359	t
1701	110	Handelsbanken	7984381	1876	418	61	0.0324712686680351456	t
1702	110	NatWest	7984381	1876	2331	99	0.0524922435353158343	t
1704	110	Lloyds TSB	7984381	1876	1420	52	0.0275471753313982701	t
1743	111	State Street	7984381	2300	660	10	0.00426639368856317029	t
1745	112	PwC	7984381	1440	6805	384	0.265862326511829006	t
1755	112	FRP Advisory LLP	7984381	1440	60	10	0.00693818108862107041	t
1764	114	Barclays	7984381	2840	15928	178	0.0607027531876716125	t
1768	114	Lloyds TSB	7984381	2840	1503	42	0.0146056850354664546	t
1772	114	Lloyds	7984381	2840	12501	210	0.0724037337800194081	t
1775	114	Santander	7984381	2840	4198	41	0.0139157929757046401	t
1776	114	Clydesdale Bank	7984381	2840	477	17	0.00592828251205844339	t
1777	114	Bank of America	7984381	2840	1301	17	0.00582504430279534493	t
1780	114	Citi	7984381	2840	3422	16	0.00520706818006874683	t
1781	114	Lloyds Bank Private Banking	7984381	2840	33	14	0.00492719697209941399	t
1782	114	SG Hambros	7984381	2840	36	14	0.00492682110483267949	t
1784	114	Coutts & Co	7984381	2840	83	11	0.00386421862221808824	t
1723	111	Royal Bank of Scotland	7984381	2300	10073	123	0.0522317187710823819	t
1724	111	HSBC	7984381	2300	11527	126	0.0533542844278327918	t
1725	111	Barclays	7984381	2300	15928	161	0.0680247005762031343	t
1726	111	Deutsche Bank	7984381	2300	4194	55	0.0233945070214145907	t
1727	111	Credit Suisse	7984381	2300	2990	50	0.021370805432818836	t
1729	111	Citi	7984381	2300	3422	29	0.0121836185325606191	t
1746	112	EY	7984381	1440	4443	141	0.0973777675316235825	t
1747	112	Grant Thornton UK LLP	7984381	1440	1583	98	0.0678695338876013493	t
1748	112	KPMG	7984381	1440	5288	62	0.0424009096048965153	t
1749	112	Deloitte	7984381	1440	6014	60	0.0409208262552193044	t
1750	112	Begbies Traynor Group	7984381	1440	104	20	0.0138783664511056195	t
1751	112	Ernst & Young	7984381	1440	1872	19	0.0129623244776302087	t
1752	112	RSM UK	7984381	1440	366	16	0.0110672676203474943	t
1753	112	Baker Tilly	7984381	1440	625	14	0.00964568401406059456	t
1754	112	PricewaterhouseCoopers	7984381	1440	918	11	0.00752527161425288645	t
1756	113	Credit Suisse	7984381	144	2990	10	0.0690712090307161186	t
1757	113	HSBC	7984381	144	10049	11	0.0751316616798268361	t
1759	114	Royal Bank of Scotland	7984381	2840	10717	165	0.0567765410831013381	t
1760	114	Halifax	7984381	2840	875	103	0.0361708824571631213	t
1761	114	NatWest	7984381	2840	2331	130	0.0454988866026296707	t
1762	114	HSBC	7984381	2840	11527	111	0.037654206803239533	t
1763	114	Coutts	7984381	2840	681	70	0.0245713356906187182	t
1806	115	Commerzbank AG	7984381	1240	614	11	0.00879543356309534993	t
1819	116	NatWest	7984381	1454	2331	60	0.0409809924325521477	t
1821	116	Halifax	7984381	1454	875	33	0.0225905359070850756	t
1834	117	Lloyds	7984381	2198	12501	49	0.0207330193729046361	t
1835	117	KPMG	7984381	2198	5288	33	0.014355307563447323	t
1836	117	Grant Thornton UK LLP	7984381	2198	1583	28	0.0125440446394941667	t
1837	117	Citi	7984381	2198	3422	26	0.0114034878709956648	t
1838	117	BDO LLP	7984381	2198	1229	23	0.0103129717462631804	t
1839	117	Ernst & Young	7984381	2198	1872	23	0.0102324173415345495	t
1840	117	Credit Suisse	7984381	2198	2990	23	0.0100923554060965877	t
1841	117	EY	7984381	2198	4443	22	0.0094552406689348556	t
1842	117	J.P. Morgan	7984381	2198	3396	21	0.00913132346182223519	t
1843	117	Bank of America Merrill Lynch	7984381	2198	2362	16	0.00698544029676460843	t
1844	117	Goldman Sachs	7984381	2198	3155	19	0.00825134703832459439	t
1845	117	Morgan Stanley	7984381	2198	2749	18	0.0078471259845073818	t
1846	117	Deutsche Bank	7984381	2198	4194	18	0.007666097812138996	t
1847	117	Deloitte	7984381	2198	6014	18	0.00743809001026324301	t
1848	117	PricewaterhouseCoopers	7984381	2198	918	12	0.0053460058593322226	t
1855	118	HSBC	7984381	1454	11527	51	0.0336380854203131019	t
1856	118	J.P. Morgan	7984381	1454	3396	27	0.018147437893328764	t
1857	118	Aon	7984381	1454	714	20	0.0136682226530284029	t
1858	118	Deutsche Bank	7984381	1454	4194	18	0.0118565259701090674	t
1859	118	Citi	7984381	1454	3422	16	0.0105774660005155587	t
1860	118	BNY Mellon	7984381	1454	1074	15	0.0101837105292524981	t
1789	115	BGC Partners	7984381	1240	291	26	0.020934546981267229	t
1790	115	ICAP	7984381	1240	486	24	0.0192969667517601043	t
1809	116	Barclays	7984381	1454	15279	206	0.139789974740641171	t
1810	116	Nationwide Building Society	7984381	1454	3053	115	0.0787241241262151697	t
1811	116	Lloyds	7984381	1454	12172	286	0.195209834478239724	t
1812	116	Santander	7984381	1454	4198	178	0.121917333149102025	t
1813	116	Lloyds TSB	7984381	1454	1420	78	0.0534770081537262118	t
1814	116	TSB Bank	7984381	1454	794	50	0.0342946965626993935	t
1817	116	Royal Bank of Scotland	7984381	1454	10717	75	0.0502487481998482866	t
1818	116	HSBC	7984381	1454	11051	56	0.0371371285550828462	t
1824	116	Clydesdale Bank	7984381	1454	477	18	0.0123221446585926268	t
1825	116	Yorkshire Bank	7984381	1454	220	14	0.00960280565777570788	t
1830	117	PwC	7984381	2198	6805	58	0.025542367619643222	t
1831	117	HSBC	7984381	2198	11051	63	0.0272858545980937534	t
1832	117	Barclays	7984381	2198	15788	99	0.043075443895255465	t
1833	117	Royal Bank of Scotland	7984381	2198	10478	50	0.0214415431469175653	t
1849	117	UBS	7984381	2198	2773	22	0.00966445661900766292	t
1850	117	Standard Life	7984381	2198	924	11	0.00489016985256291673	t
1851	117	American Express	7984381	2198	1795	11	0.00478105183309380632	t
1852	117	Standard Chartered Bank	7984381	2198	1092	10	0.00441403864584642789	t
1853	117	Bank of America	7984381	2198	1301	10	0.00438785533233432192	t
1865	118	State Street	7984381	1454	660	12	0.0081719216767638294	t
1879	119	Aviva	7984381	1234	3140	12	0.00933264782845365931	t
1891	121	HSBC	7984381	844	8854	14	0.0154803990840850676	t
1221	97	PwC	7984381	17806	6805	73	0.0032547110164565349	t
1222	97	KPMG	7984381	17806	5288	53	0.00231940423521089564	t
1223	97	TaxAssist Accountants	7984381	17806	185	37	0.00205937363276987402	t
1224	97	Mazars	7984381	17806	520	33	0.00179217746325406602	t
1225	97	Smith & Williamson	7984381	17806	411	27	0.00146814141435719467	t
1226	97	Saffery Champness	7984381	17806	150	26	0.00144461692848464607	t
1227	97	BDO LLP	7984381	17806	1229	27	0.00136546240863641768	t
1228	97	Crowe Clark Whitehill LLP	7984381	17806	180	24	0.00132827845654655491	t
1229	97	UHY Hacker Young	7984381	17806	117	23	0.00127990012821347613	t
1278	98	Lloyds TSB	7984381	9558	1410	41	0.00411793508279185462	t
1279	98	Royal Bank of Scotland Group	7984381	9558	364	13	0.00131610366328956205	t
1280	98	Future Williams & Glyn Team - RBS	7984381	9558	71	13	0.00135284429063640098	t
1281	98	KPMG	7984381	9558	5288	37	0.0032126555254655487	t
1282	98	Aviva	7984381	9558	3140	34	0.00316775381712710181	t
1283	98	Vodafone	7984381	9558	4493	35	0.00310284467228450281	t
1286	98	Legal & General	7984381	9558	1221	26	0.00257038777271567133	t
1287	98	PwC	7984381	9558	6805	32	0.00249868290262557314	t
1870	119	Royal Bank of Scotland	7984381	1234	10478	168	0.134851154963433417	t
1871	119	Santander	7984381	1234	3832	11	0.00843546718534620224	t
1872	119	HSBC	7984381	1234	11527	104	0.0828478788861161664	t
1873	119	Barclays	7984381	1234	16137	86	0.067681447744278922	t
1874	119	Nationwide Building Society	7984381	1234	3053	25	0.0198800202460300487	t
1875	119	Barclaycard	7984381	1234	1435	23	0.0184617011396722742	t
1876	119	Lloyds	7984381	1234	12265	112	0.0892394184225735188	t
1881	120	Towers Watson	7984381	567	838	90	0.158636469172761724	t
1882	120	Aon Hewitt	7984381	567	569	40	0.070480478154763479	t
1883	120	PwC	7984381	567	6805	39	0.0679356041502504338	t
1884	120	Hymans Robertson	7984381	567	195	27	0.0475980050446589836	t
1885	120	Mercer	7984381	567	619	15	0.0263793733899625633	t
1886	120	KPMG	7984381	567	5288	14	0.0240307714929910952	t
1887	120	Milliman	7984381	567	27	13	0.0229259360464905415	t
1888	120	Deloitte	7984381	567	6014	13	0.0221760438270575712	t
1889	120	Willis Towers Watson	7984381	567	94	10	0.0176261630161566527	t
1890	120	Buck Consultants	7984381	567	78	9	0.0158643733871062544	t
1340	99	Standard Chartered Bank	7984381	10390	1092	13	0.00111588815414656465	t
1341	99	Thomson Reuters	7984381	10390	2085	18	0.00147321728438102695	t
1342	99	Goldman Sachs	7984381	10390	3155	50	0.00442292857933678386	t
1343	99	The Walt Disney Company	7984381	10390	846	13	0.00114673845232222092	t
1344	99	Bloomberg	7984381	10390	321	11	0.00101983390635383784	t
1345	99	Prudential Assurance	7984381	10390	632	13	0.00117357570358071869	t
1346	99	UBS	7984381	10390	2773	23	0.00186879576804465687	t
1347	99	Bank of America	7984381	10390	1301	29	0.00263162671709299585	t
1351	100	Rathbone Brothers Plc	7984381	6656	178	53	0.00794707175728115098	t
1352	100	Schroders	7984381	6656	615	52	0.00774192850248661083	t
1353	100	Investec Wealth & Investment UK	7984381	6656	180	49	0.00734535812470756867	t
1354	100	Aviva Investors	7984381	6656	331	47	0.00702569895561969832	t
1355	100	Aberdeen Asset Management	7984381	6656	470	46	0.00685790970838997139	t
1356	100	Royal Bank of Scotland	7984381	6656	10717	53	0.00662601844947723409	t
1357	100	NatWest	7984381	6656	2331	44	0.00632390371736978214	t
1358	100	Charles Stanley	7984381	6656	109	33	0.00494840616688847768	t
1359	100	Quilter Cheviot Ltd	7984381	6656	102	32	0.00479891787638513697	t
1360	100	Legal & General Investment Management	7984381	6656	352	30	0.0044668491544485522	t
1361	100	Smith & Williamson	7984381	6656	411	30	0.00445945356234679364	t
1362	100	HSBC	7984381	6656	11527	45	0.00532155987527893181	t
1363	100	BlackRock	7984381	6656	1208	28	0.00405881892719560204	t
1364	100	Barclays	7984381	6656	14756	60	0.00717229389849188131	t
1365	100	Aon Hewitt	7984381	6656	569	26	0.00383818548286008875	t
1367	100	M&G	7984381	6656	452	24	0.00355211985077681473	t
1368	100	J.P. Morgan	7984381	6656	3396	26	0.00348382380706905789	t
1369	100	BNY Mellon	7984381	6656	1074	24	0.00347415276116166743	t
1370	100	Cazenove Capital Management	7984381	6656	97	21	0.00314552155150386306	t
1695	109	Deloitte LLP	7984381	5582	352	10	0.00174860899658762993	t
1397	100	Close Brothers Asset Management	7984381	6656	123	12	0.00178897087431181584	t
1443	101	Charles Derby	7984381	7695	37	12	0.00155632005738415183	t
1444	101	Citi	7984381	7695	3422	15	0.00152219800510753462	t
1445	101	NatWest	7984381	7695	2331	20	0.00230937100387624628	t
1446	101	Scottish Widows	7984381	7695	434	10	0.00124639025250746979	t
1566	105	Rothschild	7984381	13821	359	31	0.00220181216881742492	t
1567	105	Macquarie Group	7984381	13821	380	31	0.00219917747313732237	t
1568	105	PA Consulting Group	7984381	13821	647	31	0.00216567919949030123	t
1575	105	Finalta	7984381	13821	30	19	0.001373339550859659	t
1639	108	Bank of America Merrill Lynch	7984381	2911	2362	108	0.0368182485781282445	t
1640	108	Deutsche Bank	7984381	2911	4194	63	0.021124473576004929	t
1642	108	HSBC	7984381	2911	10060	55	0.0176403224249858867	t
1643	108	Bloomberg LP	7984381	2911	1200	38	0.0129083461398450065	t
1645	108	UBS	7984381	2911	2773	72	0.0243953596249707749	t
1646	108	Nomura	7984381	2911	1229	48	0.0163412112460416016	t
1647	108	RBC Capital Markets	7984381	2911	423	28	0.00956919810581682503	t
1648	108	Barclays	7984381	2911	14379	89	0.0287832890114827072	t
1650	108	BNP Paribas	7984381	2911	2012	21	0.00696456300709334848	t
1651	108	JPMorgan Chase	7984381	2911	1367	19	0.00635807548388885296	t
1652	108	Jefferies	7984381	2911	128	18	0.00616966019373359469	t
1653	108	Macquarie Group	7984381	2911	380	18	0.0061380870624683009	t
1656	108	Berenberg	7984381	2911	68	16	0.00548987790152038243	t
1657	108	Exane	7984381	2911	68	14	0.00480257819710114883	t
1658	108	Cambridge Associates	7984381	2911	57	13	0.00446030653712930179	t
1659	108	Societe Generale	7984381	2911	637	13	0.00438763821913775321	t
1660	108	Evercore	7984381	2911	68	12	0.00411527849268191349	t
1661	108	Lazard	7984381	2911	93	12	0.00411214623759607097	t
1662	108	BlackRock	7984381	2911	1208	12	0.00397244766076749155	t
1663	108	Rothschild	7984381	2911	359	10	0.0033915193390634717	t
1664	108	Schroders	7984381	2911	615	10	0.00335944504698444365	t
1665	108	William Blair & Company	7984381	2911	20	9	0.00309034286581788033	t
1691	109	Audit Commission	7984381	5582	106	11	0.00195871329566026445	t
1692	109	Bishop Fleming Chartered Accountants	7984381	5582	57	10	0.00178558197961427344	t
1693	109	haysmacintyre	7984381	5582	68	10	0.00178420332600989014	t
1694	109	UK National Audit Office	7984381	5582	222	10	0.00176490217554852368	t
1713	110	Aviva	7984381	1876	3140	22	0.0113364746886925102	t
1714	110	Bank of Ireland	7984381	1876	433	17	0.00900971972196836467	t
1716	110	Yorkshire Building Society Group	7984381	1876	436	13	0.00687664664221204151	t
1717	110	Skipton Building Society	7984381	1876	257	12	0.0063658963663111726	t
1719	110	Clydesdale Bank	7984381	1876	477	12	0.00633833609544381948	t
1720	110	The Co-operative Bank plc	7984381	1876	717	12	0.00630827034540670708	t
1730	111	American Express	7984381	2300	1795	26	0.0110827264218441284	t
1731	111	RBS	7984381	2300	566	11	0.00471307795548554266	t
1732	111	Barclaycard	7984381	2300	1435	23	0.00982310377456705776	t
1230	97	Haines Watts	7984381	17806	182	22	0.00121545466940086236	t
1231	97	Menzies LLP	7984381	17806	112	20	0.0011116686431499078	t
1232	97	Kingston Smith	7984381	17806	118	20	0.00111091549640867965	t
1233	97	Royal Bank of Scotland	7984381	17806	10717	50	0.00146907285150832596	t
1234	97	Moore Stephens	7984381	17806	284	18	0.000977505698336082795	t
1235	97	Lloyds	7984381	17806	12172	50	0.0012864347667604888	t
1236	97	Francis Clark Chartered Accountants	7984381	17806	77	17	0.000947202891792480535	t
1237	97	Advanced ChemDry	7984381	17806	4703	27	0.000929390445465293332	t
1238	97	Burgess Hodgson	7984381	17806	25	16	0.000897443794433816413	t
1239	97	Wilkins Kennedy LLP	7984381	17806	95	16	0.000888657082452820883	t
1240	97	Baker Tilly	7984381	17806	625	17	0.000878415489426972161	t
1242	97	Augentius	7984381	17806	79	15	0.000834379104646787765	t
1243	97	SJD Accountancy	7984381	17806	67	14	0.00077959902901326907	t
1244	97	Kreston Reeves	7984381	17806	59	13	0.000724316855552264906	t
1245	97	Ernst & Young	7984381	17806	1872	17	0.000721886491708379125	t
1246	97	Duncan & Toplis	7984381	17806	61	12	0.000667779437522547127	t
1247	97	Price Bailey LLP	7984381	17806	67	12	0.000667026290781318871	t
1248	97	haysmacintyre	7984381	17806	68	12	0.000666900766324447585	t
1249	97	Scodie Deyong	7984381	17806	11	11	0.000617769291250140433	t
1250	97	Humphrey & Co	7984381	17806	29	11	0.000615509851026455881	t
1251	97	Beever and Struthers	7984381	17806	37	11	0.000614505655371484945	t
1253	97	SRLV	7984381	17806	43	11	0.000613752508630256688	t
1255	97	Samba Bank Ltd.	7984381	17806	84	11	0.000608606005898530721	t
1256	97	Dixon Wilson	7984381	17806	27	10	0.000559474530824223461	t
1257	97	PKF Cooper Parry	7984381	17806	39	10	0.000557968237341767165	t
1288	98	Nationwide Building Society	7984381	9558	3053	27	0.00244541459886578327	t
1289	98	Santander	7984381	9558	4198	191	0.0194808038034940956	t
1290	98	Barclaycard	7984381	9558	1435	24	0.00233405373525831083	t
1291	98	The Co-operative Bank plc	7984381	9558	717	12	0.00116708956494544682	t
1292	98	American Express	7984381	9558	1795	24	0.00228891166752840606	t
1293	98	British Gas Business	7984381	9558	441	12	0.00120169848353837358	t
1785	114	European Bank for Reconstruction and Development (EBRD)	7984381	2840	801	26	0.00905783053355835484	t
1787	114	Societe Generale Private Banking - SGPB	7984381	2840	40	10	0.00351736808789603452	t
1792	115	Goldman Sachs	7984381	1240	3155	22	0.0173494834402455333	t
1793	115	J.P. Morgan	7984381	1240	3396	22	0.0173192948215051164	t
1794	115	Deutsche Bank	7984381	1240	4194	21	0.01641275729003926	t
1795	115	BNP Paribas	7984381	1240	2012	20	0.0158795064135379069	t
1796	115	HSBC	7984381	1240	10060	23	0.0172911125478215945	t
1797	115	Credit Suisse	7984381	1240	2990	18	0.0141438444891189667	t
1798	115	Citi	7984381	1240	3422	18	0.0140897304505469313	t
1799	115	Morgan Stanley	7984381	1240	2749	16	0.0125608793540965807	t
1800	115	Tullett Prebon	7984381	1240	246	14	0.0112612613377083264	t
1802	115	UBS	7984381	1240	2773	36	0.0286894105562483931	t
1803	115	Barclays	7984381	1240	10678	21	0.0156005456555460189	t
1804	115	Bank of America Merrill Lynch	7984381	1240	2362	25	0.0198685484055833132	t
1854	117	St. James's Place Wealth Management	7984381	2198	1048	14	0.00623988825316404514	t
1862	118	JPMorgan Chase	7984381	1454	1367	14	0.00945912402320733467	t
1863	118	Transact	7984381	1454	86	13	0.00893170830426820266	t
1864	118	Augentius	7984381	1454	79	12	0.00824470199906916779	t
1866	118	Barclays	7984381	1454	15579	37	0.0235001377024884918	t
1867	118	Royal Bank of Scotland	7984381	1454	10717	18	0.0110394071363780315	t
1868	118	Aon Risk Solutions	7984381	1454	260	10	0.00684626225812111702	t
1869	118	Lloyds TSB	7984381	1454	83	9	0.00618055140006822448	t
1895	118	Lloyds	7984381	1454	12265	15	0.00878184377035566739	t
1896	118	Bank of America Merrill Lynch	7984381	1454	2362	13	0.00864659984718222328	t
1877	119	Deutsche Bank	7984381	1234	4194	16	0.0124426118361219921	t
1878	119	UBS	7984381	1234	2773	11	0.00856812163853364755	t
1880	119	Citi	7984381	1234	3422	12	0.00929732341315728586	t
1296	98	WorldPay	7984381	9558	801	19	0.00188980496710451466	t
1297	98	EE	7984381	9558	1826	20	0.00186602526174916216	t
1298	98	BNY Mellon	7984381	9558	1074	19	0.001855572232409337	t
1299	98	Grant Thornton UK LLP	7984381	9558	1583	19	0.00179174636442455551	t
1300	98	IBM	7984381	9558	6116	24	0.00174708146013696948	t
1301	98	Scottish Widows	7984381	9558	434	17	0.00172632521117791599	t
1302	98	Towergate Insurance	7984381	9558	646	17	0.00169974154907030577	t
1303	98	Financial Ombudsman Service	7984381	9558	935	17	0.00166350250025379897	t
1304	98	Apple	7984381	9558	1949	18	0.00164110213585686024	t
1305	98	Clydesdale Bank	7984381	9558	477	16	0.00161618344893455206	t
1306	98	Deutsche Bank	7984381	9558	4194	20	0.00156909077179245718	t
1307	98	Storm Technologies	7984381	9558	46	15	0.00156547874253556204	t
1897	99	IBM	7984381	10390	5856	25	0.00167490737607267799	t
1898	99	Hewlett-Packard	7984381	10390	3812	20	0.00144938175552364193	t
1899	99	Mercer	7984381	10390	619	14	0.00127157780236732219	t
1900	99	Credit Suisse	7984381	10390	2990	17	0.00126335150277862907	t
1901	99	M&G	7984381	10390	452	13	0.00119614909248973557	t
1902	99	BlueBay Asset Management	7984381	10390	172	12	0.00113489145453836513	t
1903	99	Virgin Media	7984381	10390	2558	15	0.00112478403920725396	t
1904	99	BlackRock	7984381	10390	1208	13	0.00110134085907186499	t
1905	99	TSB Bank	7984381	10390	794	12	0.00105688785508609596	t
1906	99	RBS Global Banking & Markets	7984381	10390	342	11	0.00101720034431445261	t
1372	100	Citi	7984381	6656	3422	21	0.00272873606441324497	t
1373	100	Lloyds	7984381	6656	12062	40	0.00450266948211811881	t
1374	100	Hargreave Hale	7984381	6656	40	17	0.00255120351103203932	t
1375	100	Big Lottery Fund	7984381	6656	203	17	0.0025307716209881986	t
1376	100	Fidelity Worldwide Investment	7984381	6656	589	17	0.0024823868997800847	t
1377	100	Rathbones	7984381	6656	37	16	0.0024012138244540026	t
1378	100	Newton Investment Management	7984381	6656	88	16	0.0023948210245016352	t
1379	100	Baring Asset Management	7984381	6656	120	16	0.00239080985590407139	t
1380	100	J M Finn & Co	7984381	6656	51	15	0.00224909320455850964	t
1381	100	Investec Asset Management	7984381	6656	154	15	0.00223618225563510095	t
1382	100	KPMG	7984381	6656	5288	19	0.00219410332829968625	t
1383	100	Scottish Widows Investment Partnership	7984381	6656	52	14	0.00209860212190577733	t
1384	100	Pictet Asset Management	7984381	6656	86	14	0.00209434025527086573	t
1385	100	Charles Stanley & Co. Limited	7984381	6656	117	14	0.00209045443569197582	t
1386	100	State Street	7984381	6656	660	14	0.00202238991855206458	t
1387	100	Aviva	7984381	6656	3140	16	0.0020122558195089838	t
1388	100	University of Exeter	7984381	6656	4506	17	0.00199139479363453576	t
1389	100	Business Growth Fund	7984381	6656	41	13	0.00194961522747713156	t
1390	100	Kames Capital	7984381	6656	84	13	0.00194422521967415533	t
1391	100	Threadneedle Investments	7984381	6656	117	13	0.00194008870205791741	t
1392	100	Octopus Investments	7984381	6656	125	13	0.00193908590990852646	t
1393	100	AXA Investment Managers	7984381	6656	216	13	0.0019276791492092043	t
1394	100	WH Ireland	7984381	6656	49	12	0.0017982467016936822	t
1395	100	CDC Group plc	7984381	6656	58	12	0.00179711856052561757	t
1396	100	Brooks Macdonald	7984381	6656	90	12	0.00179310739192805354	t
1907	124	Barclays	7984381	2100	14693	192	0.0896119227788934741	t
1908	124	Royal Bank of Scotland	7984381	2100	10717	169	0.0791547636810175231	t
1909	124	HSBC	7984381	2100	11164	139	0.0648092920402314199	t
1910	124	Lloyds	7984381	2100	12172	129	0.0599198548098505424	t
1911	124	NatWest	7984381	2100	2331	93	0.0440053432990251403	t
1912	124	Santander	7984381	2100	4117	69	0.0323500196426130746	t
1913	124	Nationwide Building Society	7984381	2100	3053	44	0.0205754210332801321	t
1914	124	Halifax	7984381	2100	875	38	0.0179903808495460414	t
1915	124	Huntswood	7984381	2100	296	34	0.0161576534923025712	t
1916	124	Metro Bank (UK)	7984381	2100	573	32	0.0151703201246909374	t
1917	124	Aviva	7984381	2100	3140	32	0.0148487328490738545	t
1918	124	Lloyds TSB	7984381	2100	1420	27	0.0126826313359373263	t
1919	124	Capita	7984381	2100	3372	25	0.0114854581994676408	t
1920	124	Tesco Bank	7984381	2100	719	21	0.00991255632318631744	t
1921	124	Barclaycard	7984381	2100	1435	19	0.00887022614451278037	t
1922	124	Skipton Building Society	7984381	2100	257	17	0.00806517150149126984	t
1923	124	Post Office	7984381	2100	1606	17	0.00789617218913932391	t
1924	124	Momenta Operations	7984381	2100	79	16	0.00761115513818907789	t
1925	124	Deloitte	7984381	2100	6014	15	0.00639131757666046296	t
1926	124	The Co-operative Bank plc	7984381	2100	717	13	0.00610228084881883712	t
1927	124	HBOS	7984381	2100	411	11	0.00518798424851719606	t
1569	105	RBC Capital Markets	7984381	13821	423	30	0.00212130349366589392	t
1570	105	The Market Mogul	7984381	13821	63	29	0.00209399057891262834	t
1571	105	Bloomberg LP	7984381	13821	1200	30	0.00202381975350209107	t
1572	105	Bank of America	7984381	13821	1301	30	0.00201114812189778737	t
1573	105	Nationwide Building Society	7984381	13821	3053	33	0.00200877660439429491	t
1574	105	JPMorgan Chase & Co.	7984381	13821	493	20	0.00138772991061051568	t
1576	105	Lazard	7984381	13821	93	24	0.00172783109588020177	t
1577	105	Aberdeen Asset Management	7984381	13821	470	24	0.00168053203533740422	t
1578	105	Fidelity Worldwide Investment	7984381	13821	589	24	0.00166560209315015531	t
1579	105	American Express	7984381	13821	1795	26	0.00165925353691716466	t
1580	105	EY	7984381	13821	4443	30	0.00161694746347479075	t
1581	105	Citigroup	7984381	13821	566	23	0.00159600858581619275	t
1582	105	Aon Hewitt	7984381	13821	569	23	0.00159563220071903518	t
1583	105	SC Johnson	7984381	13821	161	22	0.00157434144752029051	t
1584	105	The Blackstone Group	7984381	13821	154	21	0.00150274055300148794	t
1585	105	Lehman Brothers	7984381	13821	248	21	0.00149094715329055154	t
1586	105	IHS	7984381	13821	382	21	0.00147413528561751478	t
1587	105	Jefferies	7984381	13821	128	20	0.00143352343076468295	t
1588	105	BP	7984381	13821	5408	29	0.00142339779747694523	t
1589	105	UK National Audit Office	7984381	13821	222	20	0.00142173003105374677	t
1733	111	Nationwide Building Society	7984381	2300	3053	22	0.00918549185356550522	t
1734	111	BNP Paribas	7984381	2300	2012	21	0.00888100108229921553	t
1735	111	Lloyds	7984381	2300	12172	135	0.0571876494362810878	t
1736	111	J.P. Morgan	7984381	2300	3396	18	0.00740288904610213877	t
1737	111	Bank of America Merrill Lynch	7984381	2300	2362	12	0.00492298186400263321	t
1738	111	UBS	7984381	2300	2773	39	0.0166140045434267081	t
1739	111	Legal & General	7984381	2300	1221	13	0.00550083493264475788	t
1741	111	Aviva	7984381	2300	3140	11	0.00439060565784787221	t
1742	111	Sainsbury's Bank	7984381	2300	369	10	0.00430285034692080934	t
1744	111	JPMorgan Chase	7984381	2300	1367	10	0.00417782029523378669	t
1928	113	UBS	7984381	144	2773	10	0.0690983875826553934	t
1805	115	Natixis	7984381	1240	188	11	0.0088487960177983313	t
1807	115	Tradition	7984381	1240	113	10	0.0080516139392801285	t
1929	117	Lloyds TSB	7984381	2198	1420	11	0.00482803146260117264	t
1930	117	Nomura	7984381	2198	1229	10	0.00439687542119973629	t
1931	131	National Health Service (NHS)	7985312	281	79793	130	0.452656909599476132	t
1932	133	Babcock International Group	7985312	1481	2357	12	0.00780891471375015286	t
1933	133	Arup	7985312	1481	1637	11	0.00722375228391754741	t
\.


--
-- Name: career_company_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geektalent
--

SELECT pg_catalog.setval('career_company_id_seq', 1933, true);


--
-- Name: career_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geektalent
--

SELECT pg_catalog.setval('career_id_seq', 135, true);


--
-- Data for Name: career_institute; Type: TABLE DATA; Schema: public; Owner: geektalent
--

COPY career_institute (id, career_id, institute_name, count, visible) FROM stdin;
1	1	The Open University	69	t
2	1	Sheffield Hallam University	36	t
3	1	Kingston University	36	t
4	1	University of Westminster	35	t
5	1	The University of Manchester	33	t
6	1	University of Portsmouth	32	t
7	1	University of Hertfordshire	32	t
8	1	Bournemouth University	29	t
9	1	The University of Birmingham	25	t
10	1	Nottingham Trent University	25	t
11	1	University of the West of England	24	t
12	1	University of Leeds	24	t
13	1	De Montfort University	24	t
14	1	The University of Sheffield	24	t
15	1	University of Ulster	24	t
16	1	University of Nottingham	23	t
17	1	Coventry University	22	t
18	1	Staffordshire University	22	t
19	1	Northumbria University	22	t
20	1	Aston University	21	t
21	1	University of Plymouth	21	t
22	1	Loughborough University	21	t
23	1	University of Liverpool	21	t
24	1	University of Greenwich	21	t
25	1	Middlesex University	20	t
26	1	University of Central Lancashire	19	t
27	1	University of Cambridge	19	t
28	1	The University of Glasgow	18	t
29	1	University of Leicester	18	t
30	1	Lancaster University	18	t
31	1	University of Madras	17	t
32	1	University of Strathclyde	17	t
33	1	The University of Edinburgh	17	t
34	1	University of Warwick	17	t
35	1	Liverpool John Moores University	17	t
36	1	The University of Huddersfield	17	t
37	1	Cardiff University / Prifysgol Caerdydd	17	t
38	1	University of Sunderland	17	t
39	1	Brunel University	17	t
40	1	University of Exeter	17	t
41	1	The University of Salford	17	t
42	1	University of Southampton	16	t
43	1	University of Kent	16	t
44	1	The Manchester Metropolitan University	16	t
45	1	Oxford Brookes University	16	t
46	1	London Metropolitan University	16	t
47	1	University of Teesside	16	t
48	1	Leeds Beckett University	15	t
49	1	University of Brighton	15	t
50	1	The University of Hull	15	t
51	2	The University of Manchester	40	t
52	2	The Open University	33	t
53	2	Sheffield Hallam University	32	t
54	2	The University of Birmingham	30	t
55	2	Bournemouth University	27	t
56	2	University of Leeds	27	t
57	2	Imperial College London	27	t
58	2	University of Portsmouth	26	t
59	2	University of Hertfordshire	26	t
60	2	University of Southampton	24	t
61	2	University of the West of England	24	t
62	2	University of Nottingham	24	t
63	2	The Manchester Metropolitan University	23	t
64	2	Aston University	22	t
65	2	The University of Sheffield	22	t
66	2	University of Oxford	21	t
67	2	University of Surrey	20	t
68	2	Loughborough University	19	t
69	2	University of Cambridge	19	t
70	2	University of Greenwich	19	t
71	2	University of Bristol	18	t
72	2	Queen Mary, U. of London	18	t
73	2	University of Exeter	17	t
74	2	Kingston University	17	t
75	2	De Montfort University	17	t
76	2	The University of Edinburgh	16	t
77	2	University of Warwick	16	t
78	2	Staffordshire University	16	t
79	2	University of Liverpool	16	t
80	2	Northumbria University	16	t
81	2	University of Strathclyde	15	t
82	2	Cardiff University / Prifysgol Caerdydd	15	t
83	2	City University London	15	t
84	2	University of Central Lancashire	15	t
85	2	Coventry University	15	t
86	2	University of Reading	15	t
87	2	University of Westminster	15	t
88	2	Middlesex University	15	t
89	2	University of Brighton	15	t
90	2	University of Derby	14	t
91	2	Queen's University Belfast	14	t
92	2	University of Bradford	14	t
93	2	University of Plymouth	14	t
94	2	University of Teesside	14	t
95	2	University of Essex	13	t
96	2	Leeds Metropolitan University	13	t
97	2	UCL	13	t
98	2	Brunel University London	12	t
99	2	University of East London	12	t
100	2	The University of Hull	12	t
101	3	The Open University	677	t
102	3	Kingston University	348	t
103	3	University of Hertfordshire	313	t
104	3	University of Greenwich	312	t
105	3	Sheffield Hallam University	312	t
106	3	University of Westminster	308	t
107	3	University of Portsmouth	297	t
108	3	Middlesex University	278	t
109	3	The University of Manchester	273	t
110	3	Coventry University	265	t
111	3	Loughborough University	231	t
112	3	London Metropolitan University	220	t
113	3	De Montfort University	215	t
114	3	Staffordshire University	207	t
115	3	The University of Birmingham	205	t
116	3	London South Bank University	187	t
117	3	University of East London	186	t
118	3	Brunel University	184	t
119	3	The Manchester Metropolitan University	178	t
120	3	University of Surrey	178	t
121	3	Robert Gordon University	174	t
122	3	University of Southampton	170	t
123	3	The University of Sheffield	167	t
124	3	University of Plymouth	160	t
125	3	Bournemouth University	158	t
126	3	The University of Wolverhampton	155	t
127	3	Glasgow Caledonian University	153	t
128	3	University of the West of England	152	t
129	3	Nottingham Trent University	149	t
130	3	University of Leeds	149	t
131	3	City University London	147	t
132	3	Birmingham City University	147	t
133	3	University of Strathclyde	146	t
134	3	The University of Salford	144	t
135	3	Imperial College London	143	t
136	3	Queen Mary, U. of London	143	t
137	3	University of Ulster	142	t
138	3	University of Bedfordshire	139	t
139	3	University of Warwick	136	t
140	3	Oxford Brookes University	133	t
141	3	Northumbria University	131	t
142	3	University of Central Lancashire	130	t
143	3	Anglia Ruskin University	127	t
144	3	University of Brighton	125	t
145	3	Queen's University Belfast	123	t
146	3	University of Kent	120	t
147	3	University of Nottingham	119	t
148	3	The University of Huddersfield	119	t
149	3	Brunel University London	119	t
150	3	University of Teesside	118	t
151	4	The Open University	310	t
152	4	The University of Manchester	206	t
153	4	University of Hertfordshire	183	t
154	4	Sheffield Hallam University	173	t
155	4	Kingston University	169	t
156	4	University of Leeds	159	t
157	4	University of Westminster	157	t
158	4	Imperial College London	155	t
159	4	University of Portsmouth	146	t
160	4	The University of Birmingham	136	t
161	4	Middlesex University	136	t
162	4	University of Greenwich	131	t
163	4	Loughborough University	126	t
164	4	De Montfort University	125	t
165	4	University of Southampton	121	t
166	4	Brunel University	120	t
167	4	University of Cambridge	118	t
168	4	University of Nottingham	117	t
169	4	The Manchester Metropolitan University	114	t
170	4	Staffordshire University	106	t
171	4	City University London	105	t
172	4	Queen Mary, U. of London	105	t
173	4	University of Surrey	103	t
174	4	University of Bristol	101	t
175	4	University of Strathclyde	98	t
176	4	The University of Sheffield	98	t
177	4	Nottingham Trent University	96	t
178	4	University of Reading	94	t
179	4	University of Oxford	94	t
180	4	Lancaster University	94	t
181	4	Coventry University	94	t
182	4	University of Warwick	93	t
183	4	The University of Salford	90	t
184	4	University of the West of England	87	t
185	4	London Metropolitan University	87	t
186	4	University of Liverpool	86	t
187	4	University of Plymouth	83	t
188	4	University of Ulster	83	t
189	4	Osmania University	82	t
190	4	Jawaharlal Nehru Technological University	81	t
191	4	The University of Glasgow	81	t
192	4	University of Teesside	81	t
193	4	Aston University	80	t
194	4	Queen's University Belfast	78	t
195	4	UCL	77	t
196	4	Brunel University London	77	t
197	4	The University of Wolverhampton	76	t
198	4	The University of Edinburgh	75	t
199	4	University of Brighton	74	t
200	4	University of Madras	74	t
201	5	The Open University	20	t
202	5	De Montfort University	16	t
203	5	Aston University	15	t
204	5	University of Hertfordshire	15	t
205	5	Sheffield Hallam University	13	t
206	5	City University London	13	t
207	5	The University of Birmingham	13	t
208	5	University of Greenwich	13	t
209	5	Coventry University	12	t
210	5	University of the West of England	12	t
211	5	University of Strathclyde	11	t
212	5	The Manchester Metropolitan University	11	t
213	5	University of Nottingham	11	t
214	5	The University of Salford	11	t
215	5	University of Portsmouth	11	t
216	5	The University of Manchester	11	t
217	5	Kingston University	11	t
218	5	The University of Sheffield	11	t
219	5	Bournemouth University	10	t
220	5	University of Oxford	10	t
221	5	Nottingham Trent University	10	t
222	5	Leeds Metropolitan University	10	t
223	5	Loughborough University	9	t
224	5	University of Westminster	9	t
225	5	Imperial College London	9	t
226	5	Anna University	9	t
227	5	University of Kent	8	t
228	5	Brunel University	8	t
229	5	Visvesvaraya Technological University	8	t
230	5	Queen Mary, U. of London	8	t
231	5	University of Leicester	8	t
232	5	London Metropolitan University	8	t
233	5	Heriot-Watt University	7	t
234	5	Cardiff University / Prifysgol Caerdydd	7	t
235	5	The University of Edinburgh	7	t
236	5	University of Warwick	7	t
237	5	University of Bristol	7	t
238	5	University of Sunderland	7	t
239	5	University of Brighton	7	t
240	5	University of Bedfordshire	7	t
241	5	University of East London	7	t
242	5	University of Plymouth	7	t
243	5	University College London, U. of London	7	t
244	5	Middlesex University	6	t
245	5	University of Central Lancashire	6	t
246	5	University of Madras	6	t
247	5	The University of Stirling	6	t
248	5	Liverpool John Moores University	6	t
249	5	Northumbria University	6	t
250	5	University of Surrey	6	t
251	6	The Open University	36	t
252	6	Sheffield Hallam University	25	t
253	6	University of Westminster	25	t
254	6	University of Greenwich	22	t
255	6	Kingston University	21	t
256	6	Middlesex University	21	t
257	6	University of Portsmouth	19	t
258	6	De Montfort University	18	t
259	6	University of Leeds	17	t
260	6	University of Teesside	17	t
261	6	The Manchester Metropolitan University	16	t
262	6	Coventry University	14	t
263	6	London Metropolitan University	14	t
264	6	London South Bank University	14	t
265	6	Bournemouth University	13	t
266	6	Birmingham City University	13	t
267	6	Staffordshire University	12	t
268	6	The University of Birmingham	12	t
269	6	The University of Salford	11	t
270	6	University of Hertfordshire	11	t
271	6	Nottingham Trent University	11	t
272	6	Oxford Brookes University	11	t
273	6	Liverpool John Moores University	10	t
274	6	University of Bradford	9	t
275	6	University of Kent	9	t
1387	83	UCL	13	t
276	6	University of East London	9	t
277	6	Just IT	8	t
278	6	Loughborough University	8	t
279	6	Anglia Ruskin University	8	t
280	6	Brunel University	8	t
281	6	University of Nottingham	8	t
282	6	University of Surrey	8	t
283	6	University of Derby	7	t
284	6	Queen's University Belfast	7	t
285	6	University of Warwick	7	t
286	6	The University of Huddersfield	7	t
287	6	The University of Northampton	7	t
288	6	University of the West of England	7	t
289	6	Queen Mary, U. of London	7	t
290	6	Glasgow Caledonian University	7	t
291	6	University of Sunderland	7	t
292	6	Southampton Solent University	7	t
293	6	Leeds Metropolitan University	7	t
294	6	University of the West of Scotland	7	t
295	6	The University of Hull	6	t
296	6	Leeds Beckett University	6	t
297	6	University of Essex	6	t
298	6	University of Central Lancashire	6	t
299	6	University of Liverpool	6	t
300	6	The University of Manchester	6	t
301	7	The Open University	52	t
302	7	Middlesex University	41	t
303	7	London Metropolitan University	35	t
304	7	University of Westminster	34	t
305	7	Sheffield Hallam University	30	t
306	7	University of Hertfordshire	27	t
307	7	University of Portsmouth	24	t
308	7	Kingston University	24	t
309	7	London South Bank University	23	t
310	7	University of Greenwich	23	t
311	7	Coventry University	20	t
312	7	Glasgow Caledonian University	19	t
313	7	Birmingham City University	19	t
314	7	University of Bedfordshire	19	t
315	7	Nottingham Trent University	18	t
316	7	The University of Manchester	18	t
317	7	Bournemouth University	17	t
318	7	Northumbria University	17	t
319	7	University of Surrey	17	t
320	7	University of East London	17	t
321	7	Brunel University	16	t
322	7	University of Central Lancashire	16	t
323	7	Staffordshire University	16	t
324	7	University of Leeds	15	t
325	7	University of Liverpool	14	t
326	7	The University of Birmingham	14	t
327	7	University of Cambridge	13	t
328	7	Queen Mary, U. of London	13	t
329	7	University of Teesside	13	t
330	7	Robert Gordon University	12	t
331	7	University of Reading	12	t
332	7	University of Essex	11	t
333	7	University of Nottingham	11	t
334	7	Liverpool John Moores University	11	t
335	7	The University of Huddersfield	11	t
336	7	Edinburgh Napier University	11	t
337	7	University of Plymouth	11	t
338	7	Oxford Brookes University	10	t
339	7	Aston University	10	t
340	7	University of the West of England	10	t
341	7	King's College London	10	t
342	7	The University of Hull	9	t
343	7	University of Warwick	9	t
344	7	The University of Wolverhampton	9	t
345	7	De Montfort University	9	t
346	7	Royal Holloway, University of London	8	t
347	7	Durham University	8	t
348	7	The University of Edinburgh	8	t
349	7	Lancaster University	8	t
350	7	Napier University	8	t
351	8	Imperial College London	392	t
352	8	The University of Manchester	364	t
353	8	The Open University	315	t
354	8	University of Southampton	252	t
355	8	The University of Edinburgh	244	t
356	8	University of Cambridge	225	t
357	8	University of Greenwich	218	t
358	8	Sheffield Hallam University	211	t
359	8	The University of Birmingham	204	t
360	8	Queen's University Belfast	198	t
361	8	University of York	190	t
362	8	University of Nottingham	186	t
363	8	The University of Sheffield	186	t
364	8	University of Bristol	179	t
365	8	University of Oxford	176	t
366	8	University of Warwick	175	t
367	8	University of Hertfordshire	169	t
368	8	University of Portsmouth	162	t
369	8	The University of Glasgow	162	t
370	8	Queen Mary, U. of London	159	t
371	8	University of Surrey	157	t
372	8	University of Leeds	156	t
373	8	Kingston University	155	t
374	8	Staffordshire University	152	t
375	8	Loughborough University	150	t
376	8	University of Westminster	148	t
377	8	Coventry University	143	t
378	8	University of Ulster	140	t
379	8	University of Bath	135	t
380	8	University of Leicester	132	t
381	8	University College London, U. of London	131	t
382	8	Bournemouth University	128	t
383	8	University of Reading	127	t
384	8	Nottingham Trent University	126	t
385	8	University of Kent	125	t
386	8	University of the West of England	123	t
387	8	Jawaharlal Nehru Technological University	121	t
388	8	The University of Hull	120	t
389	8	University of Strathclyde	118	t
390	8	De Montfort University	113	t
391	8	University of Liverpool	112	t
392	8	City University London	112	t
393	8	University of Sussex	112	t
394	8	The University of Salford	110	t
395	8	Visvesvaraya Technological University	108	t
396	8	King's College London	107	t
397	8	The Manchester Metropolitan University	106	t
398	8	University of Plymouth	106	t
399	8	Anna University	100	t
400	8	University of Teesside	97	t
401	9	The London School of Economics and Political Science (LSE)	330	t
402	9	University of Oxford	219	t
403	9	Imperial College London	182	t
404	9	University of Cambridge	179	t
405	9	Cass Business School	138	t
406	9	University College London, U. of London	125	t
407	9	University of Warwick	108	t
408	9	University of Nottingham	99	t
409	9	University of Bath	96	t
410	9	Durham University	94	t
411	9	The University of Edinburgh	91	t
412	9	University of Exeter	87	t
413	9	The University of Manchester	82	t
414	9	University of Bristol	79	t
415	9	UCL	75	t
416	9	Queen Mary, U. of London	71	t
417	9	Loughborough University	70	t
418	9	University of Leeds	67	t
419	9	The University of Birmingham	66	t
420	9	University of Southampton	59	t
421	9	King's College London	50	t
422	9	University of Strathclyde	45	t
423	9	London Business School	45	t
424	9	King's College London, U. of London	45	t
425	9	The University of Glasgow	44	t
426	9	University of Warwick - Warwick Business School	44	t
427	9	The University of Sheffield	44	t
428	9	University of York	42	t
429	9	University of St. Andrews	41	t
430	9	University of Reading	41	t
431	9	University of Leicester	37	t
432	9	University of Kent	37	t
433	9	City University London	37	t
434	9	Università Commerciale 'Luigi Bocconi'	35	t
435	9	Cardiff University / Prifysgol Caerdydd	34	t
436	9	Kingston University	34	t
437	9	ESCP Europe	34	t
438	9	School of Oriental and African Studies, U. of London	33	t
439	9	CFA Institute	33	t
440	9	University of Surrey	33	t
441	9	Aston University	30	t
442	9	Heriot-Watt University	29	t
443	9	University of Hertfordshire	29	t
444	9	Lancaster University	29	t
445	9	The Chartered Institute of Management Accountants	28	t
446	9	Middlesex University	28	t
447	9	University of Newcastle-upon-Tyne	28	t
448	9	Institute of Chartered Accountants in England and Wales	27	t
449	9	University of Greenwich	26	t
450	9	University of Essex	25	t
451	10	The Open University	102	t
452	10	Jawaharlal Nehru Technological University	74	t
453	10	University of Hertfordshire	66	t
454	10	University of Westminster	64	t
455	10	University of Greenwich	64	t
456	10	Middlesex University	63	t
457	10	University of Madras	60	t
458	10	Anna University	60	t
459	10	Staffordshire University	59	t
460	10	Kingston University	59	t
461	10	University of Portsmouth	56	t
462	10	Visvesvaraya Technological University	52	t
463	10	The University of Manchester	50	t
464	10	Sheffield Hallam University	48	t
465	10	University of the West of England	47	t
466	10	Osmania University	47	t
467	10	Coventry University	46	t
468	10	Brunel University	40	t
469	10	University of Surrey	39	t
470	10	University of East London	39	t
471	10	University of Ulster	39	t
472	10	Andhra University	38	t
473	10	De Montfort University	38	t
474	10	Liverpool John Moores University	34	t
475	10	University of Plymouth	34	t
476	10	The University of Sheffield	34	t
477	10	University of Leeds	33	t
478	10	Glasgow Caledonian University	32	t
479	10	London Metropolitan University	32	t
480	10	Loughborough University	32	t
481	10	Queen Mary, U. of London	32	t
482	10	University of Pune	32	t
483	10	Oxford Brookes University	32	t
484	10	London South Bank University	31	t
485	10	Northumbria University	31	t
486	10	Bharathiar University	31	t
487	10	Nottingham Trent University	31	t
488	10	Queen's University Belfast	30	t
489	10	University of Kent	30	t
490	10	The Manchester Metropolitan University	30	t
491	10	University of Nottingham	30	t
492	10	The University of Salford	30	t
493	10	The University of Huddersfield	29	t
494	10	City University London	29	t
495	10	The University of Wolverhampton	29	t
496	10	University of Central Lancashire	27	t
497	10	The University of Birmingham	26	t
498	10	Bharathidasan University	26	t
499	10	University of Teesside	26	t
500	10	University of Bedfordshire	26	t
501	11	The Open University	38	t
502	11	University of Greenwich	29	t
503	11	Staffordshire University	27	t
504	11	Kingston University	26	t
505	11	University of Portsmouth	25	t
506	11	Bournemouth University	24	t
507	11	City University London	24	t
508	11	Sheffield Hallam University	23	t
509	11	University of Plymouth	21	t
510	11	University of Hertfordshire	21	t
511	11	University of Westminster	19	t
512	11	De Montfort University	19	t
513	11	University of Kent	17	t
514	11	The Manchester Metropolitan University	17	t
515	11	University of Teesside	17	t
516	11	The University of Salford	16	t
517	11	Nottingham Trent University	16	t
518	11	University of Sussex	15	t
519	11	Middlesex University	15	t
520	11	The University of Wolverhampton	15	t
521	11	Northumbria University	14	t
522	11	University of the West of England	14	t
523	11	The University of Manchester	14	t
524	11	Southampton Solent University	14	t
525	11	University of Bradford	13	t
526	11	The University of Huddersfield	13	t
527	11	Leeds Metropolitan University	13	t
528	11	The University of Edinburgh	12	t
529	11	University of Liverpool	12	t
530	11	University of Brighton	12	t
531	11	University of the West of Scotland	12	t
532	11	University of Leeds	12	t
533	11	Brunel University	12	t
534	11	University of Southampton	12	t
535	11	Queen Mary, U. of London	12	t
536	11	Birkbeck, University of London	11	t
537	11	London Metropolitan University	11	t
538	11	Anglia Ruskin University	11	t
539	11	Coventry University	11	t
540	11	Imperial College London	11	t
541	11	University of Bedfordshire	11	t
542	11	The University of Birmingham	10	t
543	11	University of Bristol	10	t
544	11	University of East Anglia	10	t
545	11	University of Reading	10	t
546	11	University of Leicester	10	t
547	11	Lancaster University	10	t
548	11	University of Lincoln	9	t
549	11	The University of Glamorgan	9	t
550	11	The University of Sheffield	9	t
551	12	University of Ulster	6	t
552	12	Staffordshire University	5	t
553	12	Kingston University	5	t
554	13	Staffordshire University	21	t
555	13	University of Greenwich	20	t
556	13	Jawaharlal Nehru Technological University	18	t
557	13	The Open University	18	t
558	13	Osmania University	18	t
559	13	University of Westminster	17	t
560	13	University of Portsmouth	14	t
561	13	Anna University	14	t
562	13	University of Warwick	13	t
563	13	The University of Manchester	12	t
564	13	Sheffield Hallam University	11	t
565	13	Glasgow Caledonian University	10	t
566	13	University of Hertfordshire	10	t
567	13	Nottingham Trent University	10	t
568	13	University of East London	10	t
569	13	London Metropolitan University	10	t
570	13	University of Madras	9	t
571	13	The University of Hull	9	t
572	13	University of Nottingham	9	t
573	13	University of Leeds	9	t
574	13	London South Bank University	9	t
575	13	Visvesvaraya Technological University	9	t
576	13	City University London	8	t
577	13	Queen Mary, U. of London	8	t
578	13	Kingston University	8	t
579	13	University of Mumbai	8	t
580	13	Coventry University	7	t
581	13	University of Liverpool	7	t
582	13	University of Pune	7	t
583	13	Aston University	7	t
584	13	University of East Anglia	7	t
585	13	Bangalore University	6	t
586	13	University of Kent	6	t
587	13	The Manchester Metropolitan University	6	t
588	13	University of Cambridge	6	t
589	13	The University of Salford	6	t
590	13	Edinburgh Napier University	6	t
591	13	Andhra University	6	t
592	13	University of Bedfordshire	6	t
593	13	De Montfort University	6	t
594	13	The University of Sheffield	6	t
595	13	UCL	6	t
596	13	Birmingham City University	6	t
597	13	Loughborough University	6	t
598	13	Middlesex University	5	t
599	13	Queensland University of Technology	5	t
600	13	University of Sunderland	5	t
601	13	The University of Wolverhampton	5	t
602	13	Sikkim Manipal University of Health, Medical and Technological Sciences	5	t
603	13	Heriot-Watt University	5	t
604	14	London Metropolitan University	12	t
605	14	The University of Manchester	12	t
606	14	University of the Arts London	12	t
607	14	The Open University	11	t
608	14	Oxford Brookes University	8	t
609	14	The Manchester Metropolitan University	8	t
610	14	The University of Birmingham	8	t
611	14	Chartered Institute of Marketing	7	t
612	14	Kingston University	7	t
613	14	Staffordshire University	7	t
614	14	University of Westminster	6	t
615	14	University of Surrey	6	t
616	14	University of Leeds	6	t
617	14	University of Kent	6	t
618	14	Middlesex University	6	t
619	14	University of Nottingham	6	t
620	14	University of Greenwich	6	t
621	14	University of Bristol	5	t
622	14	University of Derby	5	t
623	14	University of Oxford	5	t
624	14	University of Sunderland	5	t
625	14	The University of Hull	5	t
626	14	Nottingham Trent University	5	t
627	14	Brunel University	5	t
628	14	University of Portsmouth	5	t
629	14	University of Warwick	5	t
630	14	Birkbeck, University of London	5	t
631	14	University of Sussex	5	t
632	14	Bournemouth University	5	t
633	14	University of Reading	5	t
634	14	Birmingham City University	5	t
635	14	The University of Salford	5	t
636	14	Southampton Solent University	5	t
637	14	Loughborough University	5	t
638	15	University of Hertfordshire	34	t
639	15	Bournemouth University	29	t
640	15	University of Teesside	27	t
641	15	Escape Studios	23	t
642	15	University of the Arts London	19	t
643	15	University of Portsmouth	17	t
644	15	De Montfort University	15	t
645	15	The University of Huddersfield	14	t
646	15	Staffordshire University	12	t
647	15	University of Westminster	10	t
648	15	Southampton Solent University	9	t
649	15	Kingston University	8	t
650	15	Middlesex University	7	t
651	15	University of the West of England	7	t
652	15	University of South Wales	7	t
653	15	University of Derby	6	t
654	15	Anglia Ruskin University	6	t
655	15	University for the Creative Arts	6	t
656	15	University of Brighton	6	t
657	15	London Metropolitan University	6	t
658	15	The University of Salford	6	t
659	15	University of Central Lancashire	5	t
660	15	Glasgow Caledonian University	5	t
661	15	The Manchester Metropolitan University	5	t
662	15	University College for the Creative Arts at Canterbury, Epsom, Farnham, Maidstone and Rochester	5	t
663	15	Birmingham City University	5	t
664	15	University of Bradford	5	t
665	15	Thames Valley University	5	t
666	15	University of the West of Scotland	5	t
667	16	Royal Holloway, University of London	25	t
668	16	Middlesex University	18	t
669	16	Kingston University	13	t
670	16	University of Greenwich	13	t
671	16	University of Westminster	11	t
672	16	Sheffield Hallam University	11	t
673	16	Staffordshire University	11	t
674	16	Birmingham City University	10	t
675	16	The Open University	10	t
676	16	University of Oxford	8	t
677	16	Edinburgh Napier University	8	t
678	16	De Montfort University	7	t
679	16	University of Hertfordshire	6	t
680	16	Loughborough University	6	t
681	16	Anglia Ruskin University	6	t
682	16	Brunel University London	6	t
683	16	University of Bedfordshire	6	t
684	16	Northumbria University	5	t
685	16	University of Liverpool	5	t
686	16	The University of Wolverhampton	5	t
687	16	University of Warwick	5	t
688	16	London Metropolitan University	5	t
689	16	King's College London	5	t
690	16	The University of Birmingham	5	t
691	16	Cranfield University	5	t
692	18	Imperial College London	11	t
693	18	UCL	7	t
694	18	Lancaster University	6	t
695	18	University of Bristol	5	t
696	18	University of Oxford	5	t
697	18	University College London, U. of London	5	t
698	18	Cardiff University / Prifysgol Caerdydd	5	t
699	18	The University of Dundee	5	t
700	18	The University of Edinburgh	5	t
701	19	University of Teesside	14	t
702	19	University of Lincoln	5	t
703	19	Sheffield Hallam University	5	t
704	20	University of Teesside	10	t
705	20	University of Hertfordshire	8	t
706	20	Northumbria University	5	t
707	20	University of the Arts London	5	t
769	41	University of Hertfordshire	7	t
770	41	Coventry University	5	t
771	42	University of Hertfordshire	8	t
772	42	Southampton Solent University	6	t
773	44	Loughborough University	12	t
774	44	Oxford Brookes University	9	t
775	44	Aston University	6	t
776	44	University of Hertfordshire	6	t
777	44	Swansea University	5	t
778	44	University of Liverpool	5	t
779	45	Coventry University	7	t
780	46	Loughborough University	15	t
781	47	Coventry University	45	t
782	47	Loughborough University	26	t
783	47	University of Hertfordshire	18	t
784	47	Cranfield University	18	t
785	47	University of Bath	12	t
786	47	University of Warwick	12	t
787	47	Oxford Brookes University	10	t
788	47	Birmingham City University	9	t
789	47	Sheffield Hallam University	9	t
790	47	University of Leeds	8	t
791	47	Brunel University London	7	t
792	47	Kingston University	7	t
793	47	The University of Huddersfield	7	t
794	47	Swansea University	6	t
795	47	The Open University	6	t
796	47	University of Strathclyde	5	t
797	47	The University of Birmingham	5	t
798	47	University of Plymouth	5	t
799	47	University of Liverpool	5	t
800	47	The University of Wolverhampton	5	t
801	47	University of Brighton	5	t
802	47	Brunel University	5	t
803	48	Coventry University	9	t
804	48	The Open University	5	t
805	49	Coventry University	5	t
806	49	University of Warwick	5	t
807	54	Loughborough University	12	t
808	54	Coventry University	10	t
809	54	University of Hertfordshire	7	t
810	54	The University of Huddersfield	6	t
811	54	Brunel University	5	t
812	57	Coventry University	9	t
813	57	Loughborough University	5	t
1137	78	London South Bank University	218	t
1138	78	King's College London	188	t
1139	78	Anglia Ruskin University	127	t
1140	78	University of Surrey	122	t
1141	78	University of Hertfordshire	122	t
1142	78	University of Nottingham	121	t
1143	78	University of the West of England	115	t
1144	78	Birmingham City University	113	t
1145	78	Middlesex University	106	t
1146	78	University of Southampton	100	t
1147	78	City University London	100	t
1148	78	Oxford Brookes University	97	t
1149	78	University of Greenwich	87	t
1150	78	University of West London	84	t
1151	78	The University of Wolverhampton	83	t
1152	78	Kingston University	83	t
1153	78	Sheffield Hallam University	81	t
1154	78	Coventry University	78	t
1155	78	The University of Manchester	76	t
1156	78	University of Brighton	74	t
1157	78	University of Plymouth	74	t
1158	78	Buckinghamshire New University	72	t
1159	78	Glasgow Caledonian University	71	t
1160	78	Northumbria University	70	t
1161	78	University of Bedfordshire	66	t
1162	78	University of Chester	61	t
1163	78	University of Teesside	57	t
1164	78	University of Central Lancashire	57	t
1165	78	The University of Salford	57	t
1166	78	Robert Gordon University	56	t
1167	78	The University of Huddersfield	55	t
1168	78	The Open University	55	t
1169	78	Bournemouth University	53	t
1170	78	University of the West of Scotland	53	t
1171	78	De Montfort University	52	t
1172	78	University of Leeds	51	t
1173	78	Liverpool John Moores University	49	t
1174	78	The University of Hull	49	t
1175	78	King's College London, U. of London	48	t
1176	78	Canterbury Christ Church University	48	t
1177	78	University of East Anglia	45	t
1178	78	The University of Dundee	44	t
1179	78	Edinburgh Napier University	43	t
1180	78	The University of Northampton	42	t
1181	78	The University of Sheffield	39	t
1182	78	Cardiff University / Prifysgol Caerdydd	39	t
1183	78	The University of Birmingham	38	t
1184	78	Edge Hill University	37	t
1185	78	University of Ulster	36	t
1186	78	Staffordshire University	35	t
1187	79	The Open University	58	t
1188	79	University of the West of England	41	t
1189	79	Anglia Ruskin University	35	t
1190	79	University of Bedfordshire	35	t
1191	79	University of Central Lancashire	33	t
1192	79	University of Hertfordshire	32	t
1193	79	University of East London	31	t
1194	79	Nottingham Trent University	30	t
1195	79	Middlesex University	29	t
1196	79	University of Southampton	29	t
1197	79	The University of Wolverhampton	29	t
1198	79	University of Surrey	26	t
1199	79	Kingston University	26	t
1200	79	University of Plymouth	25	t
1201	79	Oxford Brookes University	25	t
1202	79	University of Portsmouth	24	t
1203	79	London Metropolitan University	24	t
1204	79	University of Nottingham	24	t
1205	79	The University of Salford	24	t
1206	79	University of Greenwich	23	t
1207	79	Sheffield Hallam University	22	t
1208	79	Bournemouth University	22	t
1209	79	The University of Birmingham	21	t
1210	79	Coventry University	21	t
1211	79	University of Westminster	20	t
1212	79	The Manchester Metropolitan University	20	t
1213	79	University of Derby	20	t
1214	79	Staffordshire University	19	t
1215	79	University of Bradford	19	t
1216	79	University of Teesside	19	t
1217	79	The University of Huddersfield	19	t
1218	79	University of Chester	18	t
1219	79	The University of Northampton	18	t
1220	79	Birmingham City University	17	t
1221	79	University of East Anglia	17	t
1222	79	University of Leeds	16	t
1223	79	Liverpool John Moores University	16	t
1224	79	University of Ulster	16	t
1225	79	King's College London	16	t
1226	79	The University of Manchester	15	t
1227	79	University of Essex	15	t
1228	79	University of Lincoln	15	t
1229	79	University of Reading	14	t
1230	79	University of Sunderland	14	t
1231	79	Brunel University	14	t
1232	79	Glasgow Caledonian University	14	t
1233	79	Aston University	14	t
1234	79	Queen Mary, U. of London	14	t
1235	79	London South Bank University	13	t
1236	79	Cardiff University / Prifysgol Caerdydd	13	t
1237	80	Middlesex University	29	t
1238	80	The Open University	25	t
1239	80	University of Central Lancashire	19	t
1240	80	University of East London	17	t
1241	80	The University of Birmingham	15	t
1242	80	The Manchester Metropolitan University	15	t
1243	80	London South Bank University	14	t
1244	80	London Metropolitan University	13	t
1245	80	Kingston University	12	t
1246	80	University of Bradford	12	t
1247	80	The University of Northampton	12	t
1248	80	Sheffield Hallam University	12	t
1249	80	University of Derby	12	t
1250	80	University of Bedfordshire	11	t
1251	80	University of East Anglia	11	t
1252	80	The University of Huddersfield	10	t
1253	80	University of Nottingham	10	t
1254	80	Canterbury Christ Church University	10	t
1255	80	Anglia Ruskin University	9	t
1256	80	Goldsmiths College, U. of London	9	t
1257	80	University of Leeds	9	t
1258	80	The University of Wolverhampton	9	t
1259	80	De Montfort University	9	t
1260	80	Nottingham Trent University	8	t
1261	80	University of Surrey	8	t
1262	80	University of Southampton	8	t
1263	80	University of Lincoln	8	t
1264	80	University of Greenwich	8	t
1265	80	University of Plymouth	8	t
1266	80	University of Ulster	8	t
1267	80	University of Teesside	7	t
1268	80	Liverpool John Moores University	7	t
1269	80	University of Exeter	7	t
1270	80	Queen's University Belfast	7	t
1271	80	Queen Margaret University	7	t
1272	80	Birkbeck, University of London	7	t
1273	80	Royal Holloway, University of London	7	t
1274	80	Coventry University	7	t
1275	80	Bournemouth University	7	t
1276	80	University of the West of England	7	t
1277	80	Southampton Solent University	7	t
1278	80	Oxford Brookes University	7	t
1279	80	University of Hertfordshire	7	t
1280	80	The University of Hull	6	t
1281	80	University of Leicester	6	t
1282	80	University of Strathclyde	6	t
1283	80	Swansea University	6	t
1284	80	Edge Hill University	6	t
1285	80	University of Portsmouth	6	t
1286	80	University of Sunderland	6	t
1287	81	Imperial College London	219	t
1288	81	The University of Manchester	216	t
1289	81	King's College London	194	t
1290	81	University of Cambridge	165	t
1291	81	UCL	164	t
1292	81	The University of Birmingham	156	t
1293	81	University of Leeds	146	t
1294	81	University of Nottingham	137	t
1295	81	University of Southampton	124	t
1296	81	University College London, U. of London	119	t
1297	81	The University of Edinburgh	118	t
1298	81	University of Oxford	118	t
1299	81	University of Liverpool	110	t
1300	81	The University of Glasgow	110	t
1301	81	The University of Sheffield	102	t
1302	81	University of Bristol	92	t
1303	81	University of Leicester	88	t
1304	81	Cardiff University / Prifysgol Caerdydd	83	t
1305	81	University of London	82	t
1306	81	The University of Dundee	81	t
1307	81	Queen Mary, U. of London	80	t
1308	81	St. George's, U. of London	76	t
1309	81	London School of Hygiene and Tropical Medicine, U. of London	72	t
1310	81	King's College London, U. of London	70	t
1311	81	University of Surrey	66	t
1312	81	Newcastle University	62	t
1313	81	University of Warwick	62	t
1314	81	University of Aberdeen	58	t
1315	81	The Open University	55	t
1316	81	Royal College of Physicians	51	t
1317	81	Middlesex University	49	t
1318	81	University of Newcastle-upon-Tyne	47	t
1319	81	University of Hertfordshire	46	t
1320	81	Aston University	44	t
1321	81	Queen's University Belfast	43	t
1322	81	Royal College of Surgeons of England	43	t
1323	81	Sheffield Hallam University	42	t
1324	81	De Montfort University	40	t
1325	81	The Manchester Metropolitan University	39	t
1326	81	Royal College of Surgeons of Edinburgh	35	t
1327	81	University of the West of England	33	t
1328	81	Keele University	33	t
1329	81	Royal College of Physicians, London	33	t
1330	81	University of East Anglia	32	t
1331	81	Oxford Brookes University	32	t
1332	81	University of Westminster	31	t
1333	81	City University London	31	t
1334	81	University of Central Lancashire	29	t
1335	81	University of Ibadan	29	t
1336	81	University of Brighton	28	t
1337	82	Royal College of General Practitioners	43	t
1338	82	The University of Manchester	40	t
1339	82	Imperial College London	30	t
1340	82	The University of Birmingham	27	t
1341	82	King's College London	27	t
1342	82	University of Liverpool	22	t
1343	82	The University of Sheffield	21	t
1344	82	University of Leeds	21	t
1345	82	UCL	20	t
1346	82	University of Southampton	20	t
1347	82	The University of Edinburgh	20	t
1348	82	University of Nottingham	19	t
1349	82	The University of Dundee	15	t
1350	82	The University of Glasgow	14	t
1351	82	University of London	13	t
1352	82	Cardiff University / Prifysgol Caerdydd	13	t
1353	82	University of Bristol	12	t
1354	82	University College London, U. of London	12	t
1355	82	University of Leicester	12	t
1356	82	University of Cambridge	12	t
1357	82	University of Oxford	11	t
1358	82	Queen Mary, U. of London	11	t
1359	82	St. George's, U. of London	9	t
1360	82	RCGP	9	t
1361	82	King's College London, U. of London	9	t
1362	82	University of Aberdeen	8	t
1363	82	Queen's University Belfast	8	t
1364	82	University of Warwick	7	t
1365	82	University of Wales, Cardiff	7	t
1366	82	University of Westminster	6	t
1367	82	University of Newcastle-upon-Tyne	6	t
1368	82	London School of Hygiene and Tropical Medicine, U. of London	5	t
1369	82	St George's Hospital Medical School	5	t
1370	82	Charing Cross and Westminster Medical School	5	t
1371	82	University of Ibadan	5	t
1372	82	University of Wales College of Medicine	5	t
1373	82	Dow Medical College	5	t
1374	82	Keele University	5	t
1375	82	Newcastle University	5	t
1376	83	Royal College of Surgeons of England	38	t
1377	83	Royal College of Surgeons of Edinburgh	36	t
1378	83	Royal College of Surgeons	33	t
1379	83	Imperial College London	27	t
1380	83	University of Cambridge	24	t
1381	83	University of Liverpool	22	t
1382	83	The University of Manchester	21	t
1383	83	University of Oxford	19	t
1384	83	The University of Edinburgh	16	t
1385	83	University of Nottingham	14	t
1386	83	The University of Glasgow	14	t
1388	83	University of London	11	t
1389	83	University of Bristol	11	t
1390	83	The University of Dundee	11	t
1391	83	The University of Sheffield	10	t
1392	83	Queen's University Belfast	10	t
1393	83	University College London, U. of London	9	t
1394	83	Cardiff University / Prifysgol Caerdydd	9	t
1395	83	The University of Birmingham	8	t
1396	83	King's College London	8	t
1397	83	Royal College of Surgeons in Ireland	7	t
1398	83	University of Leeds	7	t
1399	83	University of Aberdeen	6	t
1400	83	Aristoteleion Panepistimion Thessalonikis	6	t
1401	83	University of Southampton	5	t
1402	83	St. George's, U. of London	5	t
1403	83	University of Leicester	5	t
1404	83	Royal College of Physicians and Surgeons of Glasgow	5	t
1405	84	King's College London	56	t
1406	84	The University of Birmingham	42	t
1407	84	The University of Sheffield	40	t
1408	84	University of Leeds	33	t
1409	84	The University of Manchester	33	t
1410	84	University of Bristol	30	t
1411	84	The University of Glasgow	25	t
1412	84	University of Liverpool	23	t
1413	84	University of Newcastle-upon-Tyne	22	t
1414	84	University of Central Lancashire	22	t
1415	84	University of Portsmouth	18	t
1416	84	King's College London, U. of London	14	t
1417	84	Royal College of Surgeons	14	t
1418	84	Queen Mary, U. of London	13	t
1419	84	The University of Dundee	12	t
1420	84	University of Warwick	11	t
1421	84	Cardiff University / Prifysgol Caerdydd	11	t
1422	84	University College London, U. of London	10	t
1423	84	Kings College Hospital	10	t
1424	84	Newcastle University	10	t
1425	84	Barts and The London School of Medicine and Dentistry	9	t
1426	84	Karolinska institutet	9	t
1427	84	Royal College of Surgeons of Edinburgh	9	t
1428	84	Tempdent	9	t
1429	84	Royal College of Surgeons of England	9	t
1430	84	UCL	8	t
1431	84	Eastman Dental Hospital	8	t
1432	84	University of Essex	7	t
1433	84	University of Pretoria/Universiteit van Pretoria	7	t
1434	84	The Royal London Hospital	7	t
1435	84	Guy's Hospital, London	7	t
1436	84	Leeds Dental Institute	7	t
1437	84	The University of Edinburgh	7	t
1438	84	Queen's University Belfast	7	t
1439	84	University of Teesside	6	t
1440	84	UCL Eastman	5	t
1441	84	University Dental Hospital of Manchester	5	t
1442	84	Harriet Ellis	5	t
1443	84	Peninsula College of Medicine and Dentistry	5	t
1444	84	Guy's Hospital Dental School	5	t
1445	84	The Open University	5	t
1446	85	University of Brighton	51	t
1447	85	The University of Salford	43	t
1448	85	University of Southampton	34	t
1449	85	University of East London	32	t
1450	85	Sheffield Hallam University	31	t
1451	85	Glasgow Caledonian University	30	t
1452	85	Coventry University	30	t
1453	85	Queen Margaret University	22	t
1454	85	University of the West of England	22	t
1455	85	King's College London	21	t
1456	85	The British School of Osteopathy	21	t
1457	85	The University of Birmingham	21	t
1458	85	University of Plymouth	21	t
1459	85	The Manchester Metropolitan University	20	t
1460	85	The University of Huddersfield	18	t
1461	85	University of Hertfordshire	18	t
1462	85	Cardiff University / Prifysgol Caerdydd	18	t
1463	85	University of Teesside	16	t
1464	85	St. George's, U. of London	16	t
1465	85	Keele University	14	t
1466	85	Oxford Brookes University	13	t
1467	85	University of Essex	12	t
1468	85	University of Ulster	12	t
1469	85	University of East Anglia	11	t
1470	85	University of Nottingham	11	t
1471	85	King's College London, U. of London	11	t
1472	85	Northumbria University	11	t
1473	85	University of Central Lancashire	9	t
1474	85	New College Durham	9	t
1475	85	Brunel University	9	t
1476	85	Queen Margaret University College	8	t
1477	85	University of Bradford	8	t
1478	85	University of Liverpool	8	t
1479	85	The University of Northampton	8	t
1480	85	Brunel University London	8	t
1481	85	Robert Gordon University	7	t
1482	85	Leeds Metropolitan University	7	t
1483	85	University College London, U. of London	5	t
1484	85	Royal Veterinary College, U. of London	5	t
1485	85	University of Cape Town	5	t
1486	85	The Open University	5	t
1487	85	UCL	5	t
1488	85	University of Wales, Cardiff	5	t
1489	85	University of Northumbria at Newcastle	5	t
1490	85	Bournemouth University	5	t
1491	85	Queens College Glasgow	5	t
1492	86	Coventry University	29	t
1493	86	University of Derby	20	t
1494	86	The University of Salford	16	t
1495	86	The University of Northampton	15	t
1496	86	Brunel University	14	t
1497	86	Oxford Brookes University	13	t
1498	86	University of Ulster	12	t
1499	86	London South Bank University	11	t
1500	86	York St. John University	10	t
1501	86	University of Liverpool	9	t
1502	86	Canterbury Christ Church University	9	t
1503	86	University of East Anglia	9	t
1504	86	Northumbria University	8	t
1505	86	Cardiff University / Prifysgol Caerdydd	8	t
1506	86	University of Southampton	8	t
1507	86	Sheffield Hallam University	7	t
1508	86	Queen Margaret University	6	t
1509	86	Glasgow Caledonian University	6	t
1510	86	University of Cumbria	6	t
1511	86	Brunel University London	6	t
1512	86	University of Plymouth	5	t
1513	87	City University London	31	t
1514	87	UCL	11	t
1515	87	The University of Sheffield	10	t
1516	87	University of Reading	9	t
1517	87	De Montfort University	9	t
1518	87	University College London, U. of London	8	t
1519	87	University of Newcastle-upon-Tyne	8	t
1520	87	City University (GB)	8	t
1521	87	The Manchester Metropolitan University	8	t
1522	87	The University of Manchester	8	t
1523	87	Birmingham City University	8	t
1524	87	University of Ulster	6	t
1525	87	Queen Margaret University College	5	t
1526	87	Leeds Metropolitan University	5	t
1527	88	The Open University	23	t
1528	88	University of Bradford	16	t
1529	88	Sheffield Hallam University	13	t
1530	88	The University of Birmingham	11	t
1531	88	University of East London	9	t
1532	88	Anglia Ruskin University	8	t
1533	88	De Montfort University	8	t
1534	88	Coventry University	8	t
1535	88	University of Hertfordshire	8	t
1536	88	The University of Salford	7	t
1537	88	Glyndwr University	6	t
1538	88	University of Ulster	6	t
1539	88	Loughborough University	6	t
1540	88	University of Surrey	6	t
1541	88	Staffordshire University	6	t
1542	88	The University of Stirling	5	t
1543	88	The University of Wolverhampton	5	t
1544	88	University of Nottingham	5	t
1545	88	Leeds Metropolitan University	5	t
1546	88	University of Greenwich	5	t
1547	88	King's College London	5	t
1548	88	Middlesex University	5	t
1549	88	The University of Huddersfield	5	t
1550	88	University of East Anglia	5	t
1551	88	University of Portsmouth	5	t
1552	88	London Metropolitan University	5	t
1553	88	Birmingham City University	5	t
1554	89	The Open University	24	t
1555	89	University of Hertfordshire	14	t
1556	89	St. George's, U. of London	12	t
1557	89	Birmingham City University	10	t
1558	89	University of Plymouth	8	t
1559	89	Coventry University	8	t
1560	89	Anglia Ruskin University	7	t
1561	89	University of Cumbria	7	t
1562	89	Oxford Brookes University	6	t
1563	89	Glasgow Caledonian University	6	t
1564	89	University of Portsmouth	6	t
1565	89	Sheffield Hallam University	6	t
1566	89	University of Teesside	6	t
1567	89	University of Worcester	6	t
1568	89	Edge Hill University	5	t
1569	89	University of Greenwich	5	t
1570	89	The University of Northampton	5	t
1571	89	Liverpool John Moores University	5	t
1572	90	The Open University	51	t
1573	90	University of Westminster	17	t
1574	90	Kingston University	13	t
1575	90	London Metropolitan University	13	t
1576	90	Middlesex University	10	t
1577	90	Birkbeck, University of London	8	t
1578	90	Coventry University	8	t
1579	90	University of Leeds	8	t
1580	90	Staffordshire University	8	t
1581	90	University of Plymouth	8	t
1582	90	The University of Salford	8	t
1583	90	Anglia Ruskin University	7	t
1584	90	The University of Birmingham	7	t
1585	90	University of Greenwich	7	t
1586	90	University of Portsmouth	7	t
1587	90	The University of Northampton	7	t
1588	90	University of Derby	7	t
1589	90	University of Central Lancashire	7	t
1590	90	Lancaster University	7	t
1591	90	The University of Wolverhampton	6	t
1592	90	University of Roehampton	6	t
1593	90	Leeds Metropolitan University	6	t
1594	90	University of Ulster	6	t
1595	90	University of the West of England	6	t
1596	90	University of East London	6	t
1597	90	Northumbria University	6	t
1598	90	Queen Mary, U. of London	6	t
1599	90	London South Bank University	6	t
1600	90	University of Lincoln	6	t
1601	90	Pitman Training Group	6	t
1602	90	North East Scotland College	5	t
1603	90	The Manchester Metropolitan University	5	t
1604	90	Bournemouth University	5	t
1605	90	Leeds Beckett University	5	t
1606	90	University of Warwick	5	t
1607	90	University of Sussex	5	t
1608	90	The University of Glasgow	5	t
1609	90	University of Brighton	5	t
1610	90	Canterbury Christ Church University	5	t
1611	90	The University of Edinburgh	5	t
1612	90	University of Hertfordshire	5	t
1613	91	The Open University	29	t
1614	91	The University of Birmingham	19	t
1615	91	The University of Manchester	14	t
1616	91	Sheffield Hallam University	12	t
1617	91	University of Brighton	11	t
1618	91	The Manchester Metropolitan University	11	t
1619	91	Staffordshire University	11	t
1620	91	The University of Huddersfield	11	t
1621	91	Kingston University	11	t
1622	91	University of Portsmouth	10	t
1623	91	University of Hertfordshire	10	t
1624	91	University of Leeds	9	t
1625	91	The University of Sheffield	9	t
1626	91	University of Westminster	8	t
1627	91	De Montfort University	8	t
1628	91	University of the West of England	8	t
1629	91	Middlesex University	8	t
1630	91	London South Bank University	8	t
1631	91	King's College London	8	t
1632	91	University of East London	7	t
1633	91	Coventry University	7	t
1634	91	Nottingham Trent University	7	t
1635	91	University of Surrey	7	t
1636	91	University of Central Lancashire	7	t
1637	91	Brunel University	7	t
1638	91	University of Kent	6	t
1639	91	University of Nottingham	6	t
1640	91	The University of Hull	6	t
1641	91	Leeds Metropolitan University	6	t
1642	91	University of Warwick	6	t
1643	91	The University of Wolverhampton	6	t
1644	91	Cardiff University / Prifysgol Caerdydd	6	t
1645	91	University of Liverpool	6	t
1646	91	University of London	5	t
1647	91	University College London, U. of London	5	t
1648	91	Northumbria University	5	t
1649	91	University of Reading	5	t
1650	91	University of Ulster	5	t
1651	91	Bournemouth University	5	t
1652	91	London Metropolitan University	5	t
1653	91	University of West London	5	t
1654	91	University of East Anglia	5	t
1655	92	University of Westminster	31	t
1656	92	The Manchester Metropolitan University	19	t
1657	92	University of Greenwich	17	t
1658	92	Sheffield Hallam University	15	t
1659	92	University of Ulster	14	t
1660	92	The University of Hull	11	t
1661	92	The University of Wolverhampton	10	t
1662	92	Glasgow Caledonian University	10	t
1663	92	University of Essex	8	t
1664	92	University of Brighton	7	t
1665	92	De Montfort University	7	t
1666	92	Aston University	7	t
1667	92	University of the West of England	7	t
1668	92	Middlesex University	7	t
1669	92	Nottingham Trent University	6	t
1670	92	Kingston University	6	t
1671	92	Liverpool John Moores University	6	t
1672	92	Queen Mary, U. of London	5	t
1673	92	University of Portsmouth	5	t
1674	93	University of Hertfordshire	24	t
1675	93	Royal College of Radiologists	21	t
1676	93	City University London	20	t
1677	93	Birmingham City University	19	t
1678	93	University of Leeds	18	t
1679	93	University of the West of England	16	t
1680	93	University of Liverpool	14	t
1681	93	Sheffield Hallam University	13	t
1682	93	University of Portsmouth	13	t
1683	93	London South Bank University	12	t
1684	93	University of Teesside	10	t
1685	93	St. George's, U. of London	9	t
1686	93	Canterbury Christ Church University	9	t
1687	93	University of Bradford	9	t
1688	93	Imperial College London	8	t
1689	93	The University of Salford	8	t
1690	93	Robert Gordon University	7	t
1691	93	University of Derby	7	t
1692	93	University of Exeter	6	t
1693	93	University of Cumbria	6	t
1694	93	Glasgow Caledonian University	6	t
1695	93	The Open University	6	t
1696	93	King's College London	6	t
1697	93	Anglia Ruskin University	5	t
1698	93	University Campus Suffolk	5	t
1699	93	University College London, U. of London	5	t
1700	93	City University (GB)	5	t
1701	93	Kingston University	5	t
1702	93	De La Salle University	5	t
1703	93	The University of Edinburgh	5	t
1704	93	University of South Australia	5	t
1705	93	University of Nottingham	5	t
1706	94	Aston University	88	t
1707	94	City University London	74	t
1708	94	University of Bradford	57	t
1709	94	Glasgow Caledonian University	40	t
1710	94	The University of Manchester	33	t
1711	94	Cardiff University / Prifysgol Caerdydd	33	t
1712	94	Anglia Ruskin University	27	t
1713	94	City University (GB)	22	t
1714	94	University of Ulster	14	t
1715	94	University of Wales, Cardiff	11	t
1716	94	College of Optometrists	7	t
1717	94	City and Islington College	7	t
1718	94	UMIST	5	t
1719	95	University of Strathclyde	30	t
1720	95	Aston University	29	t
1721	95	School of Pharmacy, U. of London	25	t
1722	95	University of Brighton	22	t
1723	95	University of Bath	21	t
1724	95	University of Bradford	20	t
1725	95	University of Nottingham	18	t
1726	95	University of Portsmouth	18	t
1727	95	University of Hertfordshire	18	t
1728	95	The University of Manchester	17	t
1729	95	Robert Gordon University	17	t
1730	95	King's College London	16	t
1731	95	De Montfort University	15	t
1732	95	University of Sunderland	15	t
1733	95	Keele University	13	t
1734	95	UCL	13	t
1735	95	Liverpool John Moores University	11	t
1736	95	Queen's University Belfast	10	t
1737	95	Cardiff University / Prifysgol Caerdydd	10	t
1738	95	Kingston University	9	t
1739	95	University of Reading	8	t
1740	95	University of Kent	7	t
1741	95	University of Leeds	7	t
1742	95	University of East Anglia	7	t
1743	95	Medway School of Pharmacy	6	t
1744	95	University of Derby	5	t
1745	96	King's College London	14	t
1746	96	Anglia Ruskin University	13	t
1747	96	University of Greenwich	12	t
1748	96	University of West London	11	t
1749	96	Middlesex University	11	t
1750	96	London South Bank University	11	t
1751	96	University of Nottingham	8	t
1752	96	City University London	7	t
1753	96	King's College London, U. of London	7	t
1754	96	University of Surrey	7	t
1755	96	University of Central Lancashire	7	t
1756	96	University of the West of England	6	t
1757	96	Birmingham City University	6	t
1758	96	The University of Manchester	6	t
1759	96	Sheffield Hallam University	6	t
1760	96	Edinburgh Napier University	6	t
1761	96	The University of Salford	6	t
1762	96	University of Hertfordshire	6	t
1763	96	University of Bradford	6	t
1764	96	Coventry University	5	t
1765	96	University of York	5	t
1766	96	City University (GB)	5	t
1767	97	ACCA	190	t
1768	97	Kaplan Financial	147	t
1769	97	Institute of Chartered Accountants in England and Wales	115	t
1770	97	The Chartered Institute of Management Accountants	92	t
1771	97	BPP University	84	t
1772	97	Oxford Brookes University	71	t
1773	97	University of Westminster	64	t
1774	97	London School of Business and Finance	63	t
1775	97	London Metropolitan University	62	t
1776	97	Middlesex University	61	t
1777	97	The Manchester Metropolitan University	58	t
1778	97	University of Kent	54	t
1779	97	The University of Manchester	52	t
1780	97	London South Bank University	51	t
1781	97	University of Greenwich	51	t
1782	97	Association of Chartered Certified Accountants	51	t
1783	97	Home Learning College	51	t
1784	97	Kingston University	51	t
1785	97	University of Leeds	50	t
1786	97	University of Hertfordshire	50	t
1787	97	The University of Birmingham	46	t
1788	97	Sheffield Hallam University	46	t
1789	97	Anglia Ruskin University	46	t
1790	97	University of Ulster	44	t
1791	97	Institute of Chartered Accountants of Scotland	43	t
1792	97	The University of Sheffield	42	t
1793	97	University of Portsmouth	39	t
1794	97	The Open University	38	t
1795	97	University of Exeter	36	t
1796	97	Bournemouth University	35	t
1797	97	Kaplan	34	t
1798	97	University of Nottingham	34	t
1799	97	Durham University	33	t
1800	97	Birmingham City University	31	t
1801	97	Coventry University	31	t
1802	97	University of Reading	30	t
1803	97	University of Bristol	29	t
1804	97	University of Oxford	28	t
1805	97	Queen's University Belfast	28	t
1806	97	University of Leicester	28	t
1807	97	Nottingham Trent University	28	t
1808	97	University of Warwick	27	t
1809	97	Liverpool John Moores University	27	t
1810	97	University of Liverpool	27	t
1811	97	University of Plymouth	26	t
1812	97	Leeds Metropolitan University	26	t
1813	97	Loughborough University	26	t
1814	97	The University of Salford	26	t
1817	98	University of Leeds	54	t
1818	98	The University of Manchester	54	t
1819	98	The University of Birmingham	49	t
1820	98	The Open University	46	t
1821	98	Nottingham Trent University	39	t
1822	98	The Manchester Metropolitan University	36	t
1823	98	The University of Edinburgh	35	t
1824	98	Sheffield Hallam University	35	t
1825	98	University of the West of England	34	t
1826	98	De Montfort University	33	t
1827	98	London Metropolitan University	32	t
1828	98	Bournemouth University	31	t
1829	98	University of East Anglia	31	t
1830	98	University of Westminster	31	t
1831	98	Institute of Chartered Accountants in England and Wales	30	t
1832	98	The University of Sheffield	30	t
1833	98	Durham University	30	t
1834	98	University of Reading	29	t
1835	98	University of Exeter	29	t
1836	98	University of Hertfordshire	28	t
1837	98	University of Nottingham	28	t
1838	98	University of Southampton	28	t
1839	98	The University of Glasgow	28	t
1840	98	Loughborough University	28	t
1841	98	Kingston University	28	t
1842	98	Oxford Brookes University	27	t
1843	98	The University of Salford	27	t
1844	98	University of Bristol	26	t
1845	98	ifs University College	26	t
1846	98	University of Strathclyde	25	t
1847	98	University of Liverpool	25	t
1848	98	University of Cambridge	24	t
1849	98	University of Portsmouth	24	t
1850	98	University of Leicester	23	t
1851	98	Leeds Metropolitan University	23	t
1852	98	Chartered Insurance Institute	23	t
1853	98	University of Bath	23	t
1854	98	University of Warwick	22	t
1855	98	Brunel University	22	t
1856	98	The University of Hull	22	t
1857	98	University of Ulster	22	t
1858	98	Lancaster University	22	t
1859	98	Institute of Chartered Accountants of Scotland	22	t
1860	98	Northumbria University	21	t
1861	98	Cardiff University / Prifysgol Caerdydd	21	t
1862	98	Coventry University	21	t
1863	98	Southampton Solent University	20	t
1864	98	Chartered Institute of Marketing	19	t
1872	99	Association of Chartered Certified Accountants	51	t
1865	98	University of Oxford	19	t
1815	97	University of East London	25	t
1816	97	De Montfort University	25	t
1867	99	The Chartered Institute of Management Accountants	182	t
1896	99	Institute of Chartered Accountants of Scotland	29	t
1917	100	Cass Business School	97	t
1918	100	University of Oxford	97	t
1919	100	University of Cambridge	95	t
1920	100	The London School of Economics and Political Science (LSE)	82	t
1921	100	The University of Edinburgh	68	t
1922	100	Durham University	59	t
1923	100	CFA Institute	56	t
1924	100	University of Warwick	55	t
1925	100	University of Exeter	53	t
1926	100	London Business School	52	t
1927	100	The University of Manchester	52	t
1928	100	University of Nottingham	49	t
1929	100	University of Bristol	48	t
1930	100	Imperial College London	48	t
1931	100	University of Leeds	44	t
1932	100	The University of Birmingham	43	t
1933	100	Chartered Institute for Securities and Investment	38	t
1934	100	University of Reading	36	t
1935	100	INSEAD	32	t
1936	100	Institute of Chartered Accountants in England and Wales	28	t
1937	100	University of Bath	27	t
1938	100	The Open University	26	t
1939	100	University College London, U. of London	26	t
1940	100	Heriot-Watt University	25	t
1941	100	University of the West of England	24	t
1942	100	Oxford Brookes University	24	t
1943	100	University of Newcastle-upon-Tyne	24	t
1944	100	University of St. Andrews	22	t
1945	100	Northumbria University	22	t
1946	100	Loughborough University	22	t
1947	100	Cardiff University / Prifysgol Caerdydd	21	t
1948	100	University of Leicester	20	t
1949	100	The University of Sheffield	20	t
1950	100	University of Southampton	20	t
1951	100	Newcastle University	20	t
1952	100	University of Aberdeen	19	t
1953	100	The University of Glasgow	18	t
1954	100	London Metropolitan University	18	t
1955	100	University of Liverpool	18	t
1956	100	University of Strathclyde	17	t
1957	100	UCL	17	t
1958	100	The University of Stirling	17	t
1959	100	City University London	16	t
1960	100	Sheffield Hallam University	16	t
1961	100	Kingston University	16	t
1962	100	CISI	15	t
1963	100	The University of Hull	14	t
1964	100	ESCP Europe	14	t
1965	100	CFA	14	t
1967	101	Chartered Insurance Institute	179	t
1890	99	BPP	33	t
1966	100	University of Westminster	13	t
1968	101	The University of Manchester	45	t
1969	101	ifs University College	44	t
1970	101	The Chartered Institute of Management Accountants	41	t
1971	101	The Manchester Metropolitan University	38	t
1972	101	The London School of Economics and Political Science (LSE)	37	t
1973	101	University of Leeds	37	t
1974	101	Institute of Financial Services	36	t
1975	101	University of Southampton	34	t
1976	101	University of the West of England	33	t
1977	101	IFS School of Finance	32	t
1978	101	CII	32	t
1979	101	University of Exeter	28	t
1980	101	The University of Birmingham	26	t
1981	101	Loughborough University	26	t
1982	101	University of Nottingham	25	t
1983	101	The University of Edinburgh	24	t
1984	101	Durham University	24	t
1985	101	University of Leicester	23	t
1986	101	Nottingham Trent University	22	t
1987	101	The University of Sheffield	22	t
1988	101	University of Westminster	22	t
1989	101	University of Portsmouth	22	t
1990	101	The Open University	21	t
1991	101	Sheffield Hallam University	21	t
1992	101	University of Strathclyde	21	t
1993	101	University of Oxford	21	t
1994	101	University of Liverpool	21	t
1995	101	Cardiff University / Prifysgol Caerdydd	20	t
1996	101	London Metropolitan University	19	t
1997	101	Kingston University	19	t
1998	101	Institute of Chartered Accountants in England and Wales	18	t
1999	101	University of Hertfordshire	18	t
2000	101	Northumbria University	18	t
2001	101	London Business School	18	t
2002	101	The University of Hull	18	t
2003	101	Bournemouth University	17	t
2004	101	University of East Anglia	17	t
2005	101	Imperial College London	17	t
2006	101	Middlesex University	17	t
2007	101	Lancaster University	17	t
2008	101	Glasgow Caledonian University	17	t
2009	101	Aston University	17	t
2010	101	Coventry University	16	t
2011	101	University of Bristol	15	t
2012	101	Royal Holloway, University of London	15	t
2013	101	De Montfort University	15	t
2014	101	University of Reading	14	t
2015	101	The University of Huddersfield	14	t
2016	101	University of Wales, Cardiff	14	t
2017	102	International Compliance Association	24	t
2018	102	The University of Manchester	24	t
2019	102	The University of Birmingham	18	t
2020	102	The London School of Economics and Political Science (LSE)	16	t
2021	102	The Open University	16	t
2022	102	Cass Business School	15	t
2023	102	City University London	15	t
2024	102	Durham University	15	t
2025	102	Queen Mary, U. of London	15	t
2026	102	Institute of Chartered Accountants in England and Wales	14	t
2027	102	Chartered Institute for Securities and Investment	14	t
2028	102	Imperial College London	13	t
2029	102	London Metropolitan University	13	t
2030	102	BPP Law School	12	t
2031	102	University of Portsmouth	12	t
2032	102	Bournemouth University	11	t
2033	102	University of Cambridge	11	t
2034	102	Glasgow Caledonian University	11	t
2035	102	The Manchester Metropolitan University	11	t
2036	102	University of Nottingham	11	t
2037	102	University of Strathclyde	11	t
2038	102	University of Westminster	10	t
2039	102	Heriot-Watt University	10	t
2040	102	University of Warwick	10	t
2041	102	University of Reading	10	t
2042	102	University of Bath	10	t
2043	102	University of Brighton	9	t
2044	102	Royal Holloway, University of London	9	t
2045	102	University of Exeter	9	t
2046	102	University of the West of England	9	t
2047	102	UCL	9	t
2048	102	University of Hertfordshire	8	t
2049	102	Northumbria University	8	t
2050	102	Lancaster University	8	t
2051	102	Cardiff University / Prifysgol Caerdydd	8	t
2052	102	Coventry University	8	t
2053	102	King's College London	8	t
2054	102	Manchester Business School	8	t
2055	102	Middlesex University	7	t
2056	102	University of Essex	7	t
2057	102	The University of Glasgow	7	t
2058	102	University of Oxford	7	t
2059	102	King's College London, U. of London	7	t
2060	102	Loughborough University	7	t
2061	102	University of East London	7	t
2062	102	The University of Sheffield	7	t
2063	102	The University of Salford	7	t
2064	102	College of Law	7	t
2065	102	Liverpool John Moores University	7	t
2117	104	Chartered Institute of Taxation	53	t
2118	104	The University of Birmingham	47	t
2119	104	University of Nottingham	37	t
2120	104	Institute of Chartered Accountants of Scotland	33	t
2121	104	The University of Manchester	32	t
2122	104	Institute of Chartered Accountants in England and Wales	28	t
2123	104	University of Cambridge	27	t
2124	104	University of Southampton	26	t
2125	104	University of Bristol	25	t
2126	104	University of Oxford	24	t
2127	104	The London School of Economics and Political Science (LSE)	23	t
2128	104	University of Warwick	23	t
2129	104	Durham University	22	t
2130	104	University of Leeds	21	t
2131	104	The University of Edinburgh	19	t
2132	104	The University of Sheffield	18	t
2133	104	University of Exeter	18	t
2134	104	The University of Glasgow	17	t
2135	104	Cardiff University / Prifysgol Caerdydd	16	t
2136	104	UCL	15	t
2137	104	King's College London, U. of London	15	t
2138	104	Loughborough University	15	t
2139	104	University of Bath	15	t
2140	104	Association of Taxation Technicians	14	t
2141	104	University of Reading	14	t
2142	104	Lancaster University	14	t
2143	104	University of Kent	13	t
2144	104	University of Newcastle-upon-Tyne	13	t
2145	104	King's College London	13	t
2146	104	Queen Mary, U. of London	12	t
2147	104	University of York	11	t
2066	102	Queen's University Belfast	6	t
2148	104	University of Liverpool	11	t
2149	104	University of Strathclyde	11	t
2150	104	Kaplan Financial	10	t
2151	104	University of Aberdeen	10	t
2152	104	ACCA	10	t
2153	104	Association of Chartered Certified Accountants	10	t
2154	104	Bournemouth University	9	t
2155	104	University of Hertfordshire	9	t
2156	104	University of Leicester	9	t
2157	104	BPP	9	t
2158	104	De Montfort University	8	t
2159	104	Imperial College London	8	t
2160	104	University of Ulster	8	t
2161	104	Royal Holloway, University of London	8	t
2162	104	The University of Dundee	8	t
2163	104	BPP Law School	8	t
2164	104	Kingston University	8	t
2165	104	University of Greenwich	8	t
2167	105	The London School of Economics and Political Science (LSE)	488	t
2168	105	University of Oxford	267	t
2169	105	Imperial College London	242	t
2170	105	University of Cambridge	234	t
2171	105	Cass Business School	196	t
2172	105	University of Warwick	159	t
2173	105	University College London, U. of London	145	t
2174	105	University of Nottingham	128	t
2175	105	University of Bath	121	t
2176	105	Durham University	119	t
2177	105	University of Exeter	108	t
2178	105	The University of Edinburgh	107	t
2179	105	The University of Manchester	107	t
2180	105	University of Bristol	97	t
2181	105	UCL	87	t
2182	105	Queen Mary, U. of London	81	t
2183	105	University of Leeds	81	t
2184	105	Loughborough University	81	t
2185	105	The University of Birmingham	78	t
2186	105	University of Southampton	76	t
2187	105	London Business School	70	t
2188	105	CFA Institute	66	t
2189	105	University of Warwick - Warwick Business School	64	t
2190	105	King's College London	62	t
2191	105	Università Commerciale 'Luigi Bocconi'	55	t
2192	105	ESCP Europe	54	t
2193	105	The University of Glasgow	54	t
2194	105	University of Strathclyde	53	t
2195	105	University of St. Andrews	52	t
2196	105	University of York	52	t
2197	105	King's College London, U. of London	51	t
2198	105	The University of Sheffield	51	t
2199	105	HEC Paris	47	t
2200	105	University of Leicester	47	t
2201	105	University of Kent	45	t
2202	105	University of Reading	45	t
2203	105	City University London	45	t
2204	105	Kingston University	42	t
2205	105	Heriot-Watt University	42	t
2206	105	University of Surrey	41	t
2207	105	Cardiff University / Prifysgol Caerdydd	40	t
2208	105	The Chartered Institute of Management Accountants	35	t
2209	105	Institute of Chartered Accountants in England and Wales	34	t
2210	105	Lancaster University	34	t
2211	105	School of Oriental and African Studies, U. of London	34	t
2212	105	Imperial College Business School	33	t
2213	105	University of Newcastle-upon-Tyne	31	t
2214	105	Aston University	31	t
2215	105	University of Essex	31	t
2216	105	University of Hertfordshire	31	t
2217	106	The London School of Economics and Political Science (LSE)	41	t
2218	106	Cass Business School	29	t
2219	106	Durham University	20	t
2220	106	Imperial College London	19	t
2221	106	University of Southampton	14	t
2222	106	University of Bath	14	t
2223	106	Cardiff University / Prifysgol Caerdydd	13	t
2224	106	University of Cambridge	12	t
2225	106	The University of Manchester	12	t
2226	106	Queen Mary, U. of London	12	t
2227	106	University of York	11	t
2228	106	Lancaster University	10	t
2229	106	University of Bristol	10	t
2230	106	CFA Institute	9	t
2231	106	University of Westminster	9	t
2232	106	The University of Glasgow	9	t
2233	106	University of Oxford	9	t
2234	106	London Metropolitan University	9	t
2235	106	University of Warwick	9	t
2236	106	Royal Holloway, University of London	9	t
2237	106	Brunel University	9	t
2238	106	University of Leeds	8	t
2239	106	University of Portsmouth	8	t
2240	106	ACCA	8	t
2241	106	University of Strathclyde	8	t
2242	106	University of Essex	7	t
2243	106	Queen's University Belfast	7	t
2244	106	The University of Birmingham	7	t
2245	106	University of Nottingham	7	t
2246	106	University of Reading	7	t
2247	106	London Business School	7	t
2248	106	Aston University	7	t
2249	106	ifs University College	6	t
2250	106	University of Brighton	6	t
2251	106	The University of Edinburgh	6	t
2252	106	University of Wales, Cardiff	6	t
2253	106	University of Leicester	6	t
2254	106	Loughborough University	6	t
2255	106	University College London, U. of London	6	t
2256	106	Birkbeck, University of London	6	t
2257	106	Kingston University	6	t
2258	106	University of Surrey	6	t
2259	106	Nottingham Trent University	6	t
2260	106	The Open University	5	t
2261	106	Université Paris Dauphine	5	t
2262	106	EDHEC Business School	5	t
2263	106	Sheffield Hallam University	5	t
2264	106	London School of Economics and Political Science, U. of London	5	t
2265	106	UCL	5	t
2266	106	King's College London	5	t
2267	107	ifs University College	57	t
2268	107	Institute of Financial Services	44	t
2269	107	IFS School of Finance	19	t
2270	107	De Montfort University	13	t
2271	107	IFS	12	t
2272	107	Chartered Insurance Institute	9	t
2273	107	Sheffield Hallam University	9	t
2274	107	Coventry University	8	t
2275	107	University of Portsmouth	8	t
2276	107	Kingston University	7	t
2277	107	The Open University	6	t
2278	107	The Manchester Metropolitan University	6	t
2279	107	The University of Northampton	6	t
2280	107	Northumbria University	6	t
2281	107	Heriot-Watt University	6	t
2282	107	University of Leicester	6	t
2283	107	University of Hertfordshire	5	t
2284	107	Cardiff University / Prifysgol Caerdydd	5	t
2285	107	Middlesex University	5	t
2286	107	University of Westminster	5	t
2287	107	University of Teesside	5	t
2288	108	The London School of Economics and Political Science (LSE)	166	t
2289	108	University of Cambridge	79	t
2290	108	Imperial College London	75	t
2291	108	University of Oxford	69	t
2292	108	Cass Business School	66	t
2293	108	University of Warwick	54	t
2294	108	London Business School	54	t
2295	108	CFA Institute	53	t
2296	108	Durham University	34	t
2297	108	University of Nottingham	30	t
2298	108	HEC Paris	30	t
2299	108	University College London, U. of London	29	t
2300	108	Università Commerciale 'Luigi Bocconi'	27	t
2301	108	The University of Edinburgh	25	t
2302	108	ESCP Europe	25	t
2303	108	The University of Manchester	20	t
2304	108	University of Bristol	19	t
2305	108	University of Warwick - Warwick Business School	18	t
2306	108	UCL	16	t
2307	108	The University of Birmingham	15	t
2308	108	EDHEC Business School	15	t
2309	108	University of Exeter	15	t
2310	108	Stockholm School of Economics	14	t
2311	108	University of Leeds	14	t
2312	108	INSEAD	14	t
2313	108	University of Bath	14	t
2314	108	Institute of Chartered Accountants in England and Wales	13	t
2315	108	University of Pennsylvania - The Wharton School	12	t
2316	108	University of St. Andrews	12	t
2317	108	Imperial College Business School	11	t
2318	108	The University of Chicago Booth School of Business	11	t
2319	108	City University London	10	t
2320	108	ESADE Business School	10	t
2321	108	University of York	9	t
2322	108	University of Leicester	9	t
2323	108	Queen Mary, U. of London	9	t
2324	108	ESSEC - ESSEC Business School	8	t
2325	108	Lancaster University	8	t
2326	108	Loughborough University	8	t
2327	108	Babson College	8	t
2328	108	Royal Holloway, University of London	8	t
2329	108	HEC School of Management	8	t
2330	108	University of Westminster	7	t
2331	108	Université Paris Dauphine	7	t
2332	108	King's College London, U. of London	7	t
2333	108	University of Newcastle-upon-Tyne	7	t
2334	108	King's College London	7	t
2339	109	University of Exeter	90	t
2340	109	The University of Birmingham	84	t
2342	109	Durham University	74	t
2345	109	The University of Manchester	56	t
2346	109	Association of Chartered Certified Accountants	55	t
2347	109	Kaplan Financial	55	t
2348	109	University of Southampton	54	t
2350	109	The University of Sheffield	50	t
2351	109	Loughborough University	50	t
2352	109	Lancaster University	48	t
2353	109	University of Warwick	46	t
2355	109	The London School of Economics and Political Science (LSE)	42	t
2357	109	University of York	39	t
2359	109	The University of Glasgow	34	t
2362	109	Cardiff University / Prifysgol Caerdydd	31	t
2363	109	Imperial College London	29	t
2366	109	Birmingham City University	26	t
2367	109	Cass Business School	26	t
2368	109	Queen Mary, U. of London	25	t
2369	109	University of Leicester	24	t
2375	109	BPP University	21	t
2377	109	University of Kent	19	t
2379	109	Brunel University	19	t
2380	109	London School of Business and Finance	19	t
2381	109	BPP	19	t
2382	109	University of Reading	17	t
2384	109	De Montfort University	17	t
2385	109	University of Oxford	17	t
2387	109	Aston University	17	t
2388	110	Middlesex University	17	t
2389	110	ifs University College	13	t
2390	110	Chartered Insurance Institute	13	t
2391	110	Institute of Financial Services	10	t
2392	110	Nottingham Trent University	10	t
2393	110	The Manchester Metropolitan University	8	t
2394	110	CII	8	t
2395	110	The University of Birmingham	7	t
2396	110	Sheffield Hallam University	7	t
2397	110	University of Greenwich	6	t
2398	110	University of Portsmouth	6	t
2399	110	University of Hertfordshire	5	t
2400	110	The University of Manchester	5	t
2401	110	The University of Hull	5	t
2402	110	University of Essex	5	t
2403	110	University of Ulster	5	t
2404	110	Loughborough University	5	t
2405	111	Edinburgh Napier University	19	t
2406	111	The Chartered Institute of Management Accountants	16	t
2407	111	University of Warwick	16	t
2408	111	Imperial College London	14	t
2409	111	University of Leeds	14	t
2410	111	University of Oxford	13	t
2411	111	The University of Manchester	13	t
2412	111	University of Nottingham	13	t
2413	111	The London School of Economics and Political Science (LSE)	12	t
2414	111	Cass Business School	11	t
2415	111	University of Westminster	11	t
2416	111	University of Bristol	11	t
2417	111	City University London	11	t
2418	111	University of Southampton	11	t
2419	111	Queen Mary, U. of London	11	t
2420	111	University of Strathclyde	11	t
2421	111	Napier University	10	t
2338	109	Institute of Chartered Accountants in England and Wales	243	t
2337	108	University of Southampton	6	t
2422	111	The University of Edinburgh	10	t
2423	111	London Metropolitan University	10	t
2424	111	The Open University	10	t
2425	111	The University of Birmingham	10	t
2426	111	University of the West of England	10	t
2427	111	University of Portsmouth	10	t
2428	111	University of Bath	10	t
2429	111	Lancaster University	9	t
2430	111	University of Leicester	9	t
2431	111	Brunel University	9	t
2432	111	Liverpool John Moores University	9	t
2433	111	The University of Northampton	8	t
2434	111	Royal Holloway, University of London	8	t
2435	111	Loughborough University	8	t
2436	111	London South Bank University	8	t
2437	111	Sheffield Hallam University	8	t
2438	111	University of Essex	8	t
2439	111	King's College London	8	t
2440	111	Bournemouth University	7	t
2441	111	University of York	7	t
2442	111	University of Ulster	7	t
2443	111	University of East Anglia	7	t
2444	111	Northumbria University	7	t
2445	111	The Manchester Metropolitan University	7	t
2446	111	Staffordshire University	7	t
2447	111	University of Surrey	7	t
2448	111	Nottingham Trent University	7	t
2455	112	Institute of Chartered Accountants in England and Wales	54	t
2456	112	The University of Birmingham	29	t
2457	112	University of Nottingham	26	t
2458	112	University of Exeter	26	t
2459	112	Durham University	23	t
2460	112	Institute of Chartered Accountants of Scotland	23	t
2461	112	University of Bristol	22	t
2462	112	The London School of Economics and Political Science (LSE)	20	t
2463	112	Loughborough University	19	t
2464	112	University of Strathclyde	19	t
2465	112	University of Bath	19	t
2466	112	University of Cambridge	18	t
2467	112	University of Leeds	18	t
2468	112	University of Warwick	18	t
2469	112	The University of Manchester	18	t
2470	112	BPP Law School	17	t
2471	112	The University of Sheffield	17	t
2472	112	University of Southampton	16	t
2473	112	University of Oxford	14	t
2474	112	Cardiff University / Prifysgol Caerdydd	14	t
2475	112	ACCA	12	t
2476	112	Cass Business School	12	t
2477	112	University of Kent	11	t
2478	112	University of East Anglia	11	t
2479	112	The University of Edinburgh	11	t
2480	112	University of Warwick - Warwick Business School	11	t
2481	112	The University of Glasgow	11	t
2482	112	University of Liverpool	11	t
2483	112	Lancaster University	11	t
2484	112	University of York	10	t
2485	112	Kaplan Financial	10	t
2486	112	University College London, U. of London	10	t
2487	112	Queen Mary, U. of London	10	t
2488	112	Imperial College London	9	t
2489	112	Royal Holloway, University of London	9	t
2490	112	Aston University	9	t
2491	112	University of Reading	8	t
2492	112	BPP University	7	t
2493	112	Association of Taxation Technicians	7	t
2494	112	De Montfort University	6	t
2495	112	UCL	6	t
2496	112	University of the West of England	6	t
2497	112	University of Surrey	6	t
2500	112	University of Leicester	5	t
2501	112	Glasgow Caledonian University	5	t
2502	112	The Manchester Metropolitan University	5	t
2504	112	University of Portsmouth	5	t
2505	113	Imperial College London	15	t
2506	113	University of Cambridge	10	t
2507	113	Université Pierre et Marie Curie (Paris VI)	6	t
2508	113	University of Oxford	5	t
2509	114	ifs University College	20	t
2510	114	Chartered Institute for Securities and Investment	14	t
2511	114	The London School of Economics and Political Science (LSE)	12	t
2499	112	Nottingham Trent University	5	t
2498	112	Brunel University	5	t
2503	112	ICAEW	5	t
2512	114	Chartered Insurance Institute	12	t
2513	114	The University of Manchester	11	t
2514	114	Kingston University	11	t
2515	114	University of Exeter	9	t
2516	114	Middlesex University	9	t
2517	114	University of Strathclyde	9	t
2518	114	University College London, U. of London	8	t
2519	114	University of Westminster	8	t
2520	114	University of Cambridge	8	t
2521	114	CFA Institute	7	t
2522	114	Imperial College London	7	t
2523	114	University of Bristol	7	t
2524	114	University of Oxford	7	t
2525	114	Loughborough University	7	t
2526	114	University of Kent	6	t
2527	114	Oxford Brookes University	6	t
2528	114	The University of Edinburgh	6	t
2529	114	City University London	6	t
2530	114	University of Surrey	6	t
2531	114	Queen Mary, U. of London	6	t
2532	114	Birmingham City University	6	t
2533	114	Coventry University	6	t
2534	114	University of Essex	5	t
2535	114	Durham University	5	t
2536	114	Chartered Institute of Bankers	5	t
2537	114	The University of Wolverhampton	5	t
2538	114	London Business School	5	t
2539	114	University of Brighton	5	t
2540	114	University of Liverpool	5	t
2541	114	IFS School of Finance	5	t
2542	115	The London School of Economics and Political Science (LSE)	28	t
2543	115	University of Oxford	16	t
2544	115	University of Cambridge	15	t
2545	115	London Business School	14	t
2546	115	University of Warwick	11	t
2547	115	Cass Business School	11	t
2548	115	University of Bristol	10	t
2549	115	Imperial College London	9	t
2550	115	UCL	9	t
2551	115	Durham University	8	t
2552	115	CFA Institute	7	t
2553	115	University of Nottingham	6	t
2554	115	Queen Mary, U. of London	6	t
2555	115	The University of Birmingham	6	t
2556	115	University of Bath	6	t
2557	115	University of Exeter	5	t
2558	115	University of Newcastle-upon-Tyne	5	t
2559	115	The University of Edinburgh	5	t
2560	115	University of York	5	t
2561	116	ifs University College	14	t
2562	116	London Metropolitan University	11	t
2563	116	Kingston University	11	t
2564	116	University of Westminster	9	t
2565	116	Nottingham Trent University	8	t
2566	116	University of Hertfordshire	7	t
2567	116	Middlesex University	7	t
2568	116	London South Bank University	7	t
2569	116	Institute of Financial Services	5	t
2570	116	De Montfort University	5	t
2571	116	University of Greenwich	5	t
2572	116	Liverpool John Moores University	5	t
2573	116	Brunel University	5	t
2574	116	University of Aberdeen	5	t
2575	116	Glasgow Caledonian University	5	t
2576	116	The Open University	5	t
2577	116	University of Central Lancashire	5	t
2578	117	The Open University	12	t
2579	117	London Metropolitan University	8	t
2580	117	Seevic College	7	t
2581	117	University of Surrey	5	t
2582	117	University of Greenwich	5	t
2583	118	University of Leeds	11	t
2584	118	The University of Manchester	10	t
2585	118	ACCA	10	t
2586	118	Queen Mary, U. of London	10	t
2587	118	The Manchester Metropolitan University	9	t
2588	118	Oxford Brookes University	8	t
2589	118	London Metropolitan University	8	t
2590	118	Chartered Institute for Securities and Investment	7	t
2591	118	Cass Business School	7	t
2592	118	The University of Sheffield	7	t
2593	118	Kingston University	7	t
2594	118	University of Surrey	7	t
2595	118	Loughborough University	7	t
2596	118	University of Nottingham	6	t
2597	118	Durham University	6	t
2598	118	University of Essex	6	t
2599	118	The University of Edinburgh	6	t
2600	118	The Open University	6	t
2601	118	University of Westminster	5	t
2602	118	Cardiff University / Prifysgol Caerdydd	5	t
2603	118	University of Plymouth	5	t
2604	118	Middlesex University	5	t
2605	118	University of Sussex	5	t
2606	118	University of Cambridge	5	t
2607	118	University of the West of England	5	t
2608	118	Royal Holloway, University of London	5	t
2609	118	Association of Chartered Certified Accountants	5	t
2610	118	Leeds Metropolitan University	5	t
2611	118	University of Greenwich	5	t
2612	118	Chartered Insurance Institute	5	t
2613	119	University of Leeds	9	t
2614	119	University of Portsmouth	9	t
2615	119	The University of Edinburgh	9	t
2616	119	The University of Manchester	8	t
2617	119	University of Brighton	7	t
2618	119	The Open University	7	t
2619	119	University of Strathclyde	7	t
2620	119	University of Liverpool	7	t
2621	119	Edinburgh Napier University	6	t
2622	119	Durham University	6	t
2623	119	University of Warwick	6	t
2624	119	The University of Glasgow	6	t
2625	119	Loughborough University	6	t
2626	119	London Business School	6	t
2627	119	Napier University	5	t
2628	119	University of Surrey	5	t
2629	119	Imperial College London	5	t
2630	119	University of Greenwich	5	t
2631	119	Cass Business School	5	t
2632	119	The University of Sheffield	5	t
2633	119	University of Leicester	5	t
2634	120	University of Warwick	35	t
2635	120	Imperial College London	21	t
2636	120	Heriot-Watt University	18	t
2637	120	University of Oxford	16	t
2638	120	Cass Business School	15	t
2639	120	University of Bristol	15	t
2640	120	Institute and Faculty of Actuaries	14	t
2641	120	University of Cambridge	12	t
2642	120	University of York	11	t
2643	120	University of Southampton	10	t
2644	120	The London School of Economics and Political Science (LSE)	10	t
2645	120	The University of Manchester	9	t
2646	120	Queen's University Belfast	8	t
2647	120	Institute of Actuaries	8	t
2648	120	University College London, U. of London	8	t
2649	120	University of Nottingham	8	t
2650	120	Durham University	8	t
2651	120	The University of Glasgow	8	t
2652	120	University of Leeds	8	t
2653	120	University of Kent	7	t
2654	120	Cardiff University / Prifysgol Caerdydd	6	t
2655	120	City University London	5	t
2656	120	The University of Sheffield	5	t
2657	120	University of Bath	5	t
2658	122	Chartered Institute of Payroll Professionals	9	t
2335	108	RSM Erasmus University	6	t
2341	109	ACCA	82	t
2343	109	University of Nottingham	59	t
2344	109	University of Leeds	52	t
2349	109	Institute of Chartered Accountants of Scotland	51	t
2354	109	Oxford Brookes University	43	t
2356	109	University of Bristol	38	t
2358	109	The University of Edinburgh	33	t
2360	109	The Chartered Institute of Management Accountants	32	t
2361	109	University of Liverpool	30	t
2364	109	University of Bath	28	t
2365	109	University of East Anglia	27	t
2370	109	University of Strathclyde	23	t
2371	109	Newcastle University	22	t
2372	109	University of Newcastle-upon-Tyne	21	t
2373	109	Kingston University	20	t
2374	109	King's College London	21	t
2376	109	University of Cambridge	18	t
2378	109	The Manchester Metropolitan University	18	t
2386	109	London Metropolitan University	16	t
2450	111	Glasgow Caledonian University	6	t
2452	111	The University of Glasgow	6	t
2453	111	Birkbeck, University of London	6	t
1866	98	The Chartered Institute of Management Accountants	19	t
1868	99	Institute of Chartered Accountants in England and Wales	143	t
1869	99	ACCA	137	t
1870	99	The University of Manchester	86	t
1871	99	Kaplan Financial	66	t
1873	99	The Manchester Metropolitan University	57	t
2166	104	Heriot-Watt University	7	t
2336	108	The Open University	6	t
2383	109	University of Portsmouth	16	t
2449	111	Leeds Metropolitan University	6	t
1874	99	University of Leeds	60	t
1875	99	The University of Birmingham	63	t
1876	99	University of Nottingham	55	t
1877	99	The London School of Economics and Political Science (LSE)	59	t
1878	99	The University of Sheffield	49	t
1879	99	Loughborough University	53	t
1880	99	Durham University	46	t
1881	99	Kingston University	60	t
1882	99	Oxford Brookes University	47	t
1883	99	University of Bristol	38	t
1884	99	Nottingham Trent University	45	t
1885	99	University of Warwick	46	t
1886	99	University of Westminster	49	t
1887	99	London Metropolitan University	43	t
1888	99	University of Exeter	42	t
1889	99	The University of Glasgow	48	t
1891	99	University of Southampton	42	t
1892	99	Middlesex University	40	t
1893	99	Bournemouth University	35	t
1894	99	Brunel University	40	t
1895	99	University of Cambridge	36	t
1897	99	University of Strathclyde	42	t
1898	99	University of Hertfordshire	45	t
1899	99	University of Leicester	32	t
1900	99	University of Portsmouth	34	t
1901	99	University of Kent	43	t
1902	99	University of Bath	39	t
1903	99	University of Reading	32	t
1904	99	Cass Business School	29	t
1905	99	The Open University	41	t
1906	99	Imperial College London	35	t
1907	99	University of the West of England	30	t
1908	99	University of Greenwich	27	t
1909	99	Sheffield Hallam University	36	t
1910	99	Queen Mary, U. of London	28	t
1911	99	Glasgow Caledonian University	31	t
1912	99	Cardiff University / Prifysgol Caerdydd	29	t
1913	99	King's College London	27	t
1914	99	The University of Edinburgh	27	t
1915	99	University of Surrey	30	t
1916	99	University of Liverpool	31	t
2661	124	The Manchester Metropolitan University	11	t
2662	124	Middlesex University	11	t
2663	124	University of Westminster	10	t
2664	124	University of Greenwich	10	t
2665	124	Coventry University	9	t
2666	124	University of Hertfordshire	9	t
2667	124	Sheffield Hallam University	9	t
2668	124	University of Leeds	8	t
2669	124	The University of Huddersfield	8	t
2670	124	The Open University	8	t
2671	124	University of Chester	8	t
2672	124	University of Leicester	7	t
2673	124	BPP University	7	t
2674	124	The University of Northampton	7	t
2675	124	University of Liverpool	7	t
2676	124	The University of Manchester	7	t
2677	124	Nottingham Trent University	7	t
2678	124	Birmingham City University	7	t
2679	124	University of Central Lancashire	7	t
2680	124	Glasgow Caledonian University	7	t
2681	124	De Montfort University	6	t
2682	124	Leeds Metropolitan University	6	t
2683	124	University of Sunderland	6	t
2684	124	London South Bank University	6	t
2685	124	Oxford Brookes University	5	t
2686	124	The University of Birmingham	5	t
2687	124	University of the West of England	5	t
2688	124	The University of Salford	5	t
2689	124	The University of Glamorgan	5	t
2690	124	Kingston University	5	t
2691	124	Liverpool John Moores University	5	t
2692	124	University of Portsmouth	5	t
2451	111	De Montfort University	6	t
2454	111	University of Warwick - Warwick Business School	6	t
2693	125	The University of Glasgow	4	t
2694	125	University of Hertfordshire	2	t
2695	125	University of East Anglia	2	t
2696	125	University of Greenwich	1	t
2697	125	University of St. Andrews	1	t
2698	125	Universiy of Chester	1	t
2699	125	Maria Curie-Sklodowska University	1	t
2700	125	NESCOT	1	t
2701	125	loreto day school,bowbazar,presidency college	1	t
2702	125	University of East London	1	t
2703	125	Sri Akilandeeswari Women's College,Vandavasi	1	t
2704	125	UCL	1	t
2705	125	Imperial College London	1	t
2706	125	Pembroke College, University of Cambridge	1	t
2707	125	MMU	1	t
2708	125	Instituto Politécnico de Bragança	1	t
2709	125	University of Warwick	1	t
2710	125	University of Bedfordshire	1	t
2711	125	The University of Birmingham	1	t
2712	125	University of Nottingham	1	t
2713	125	Kwame Nkrumah' University of Science and Technology, Kumasi	1	t
2714	125	The University of Edinburgh	1	t
2715	125	University of Bristol	1	t
2716	125	Dean Close, Cheltenham	1	t
2717	125	University of York	1	t
2718	125	University of Oxford	1	t
2719	125	The Open University	1	t
2720	125	Kakatiya University	1	t
2721	125	The Institute of Education, U. of London	1	t
2722	125	University of Otago	1	t
2723	125	Brunel University London	1	t
2724	125	Unoversity of Kent	1	t
2725	125	Università degli Studi di Genova	1	t
2726	125	Southampton Solent University	1	t
2727	125	University of Sussex	1	t
2728	125	University of Leeds	1	t
2729	125	Centro Universitário La Salle	1	t
2730	125	University of Newcastle-upon-Tyne	1	t
2731	125	University of Mumbai	1	t
2732	125	The Scripps Research Institute	1	t
2733	125	Elizabeth Cornu	1	t
2734	125	navodaya vidyalaya	1	t
2735	125	Bharath University	1	t
2736	125	The University of Western Australia	1	t
2737	125	University of Sarajevo	1	t
2738	125	the Faculty of Biology, Adam Mickiewicz University	1	t
2739	126	Liverpool John Moores University	2	t
2740	126	University of Strathclyde	2	t
2741	126	University of Kent	1	t
2742	126	North Tyneside College	1	t
2743	126	Indiana University Bloomington	1	t
2744	126	The University of Wolverhampton	1	t
2745	126	University of Leeds	1	t
2746	126	Newcastle University	1	t
2747	126	University of Coimbra	1	t
2748	126	University of Reading	1	t
2749	126	De Montfort University, Leicester	1	t
2750	126	The University of Manchester	1	t
2751	126	The Open University	1	t
2752	126	Northumbria University	1	t
2753	127	University of Malaya	1	t
2754	127	University of Wales, Cardiff	1	t
2755	127	United Kingdom Sailing Academy	1	t
2756	127	Keele University	1	t
2757	127	University of Kent	1	t
2758	127	Edinburgh Napier University	1	t
2759	127	University of East London	1	t
2760	127	London South Bank University	1	t
2761	127	University of Leeds	1	t
2762	127	Gdańsk University of Technology	1	t
2763	127	Huddersfied University	1	t
2764	127	New College Telford	1	t
2765	128	University of Liverpool	4	t
2766	128	The University of Edinburgh	4	t
2767	128	The University of Glasgow	4	t
2768	128	The University of Manchester	4	t
2769	128	Imperial College London	3	t
2770	128	University of Cambridge	3	t
2771	128	UCL	2	t
2772	128	Heriot-Watt University	2	t
2773	128	University College London, U. of London	2	t
2774	128	University of Bath	2	t
2775	128	Mill Hill	1	t
2776	128	Keele University	1	t
2777	128	University of North Carolina at Chapel Hill School of Medicine	1	t
2778	128	University of East London	1	t
2779	128	ESIL Marseille	1	t
2780	128	Kingston University	1	t
2781	128	École doctorale, ED 425 "Innovation thérapeutique"	1	t
2782	128	\nRandall Division of Cell and Molecular Biophysics, King’s College London\n	1	t
2783	128	Université Paris Sud (Paris XI)	1	t
2784	128	University of Plymouth	1	t
2785	128	University of Leicester	1	t
2786	128	Brunel University London	1	t
2787	128	University of Nottingham	1	t
2788	128	University of Essex	1	t
2789	128	PhD	1	t
2790	128	Royal Holloway University	1	t
2791	128	Lomonosov Moscow State University (MSU)	1	t
2792	128	Imperial College Business School	1	t
2793	128	University of York	1	t
2794	128	University of Oxford	1	t
2795	128	Ecole Nationale Superieure de Technologie des Biomolecules de Bordeaux (ENSTBB)	1	t
2796	128	The Open University	1	t
2797	128	Aarhus University	1	t
2798	128	University of Hertfordshire	1	t
2799	128	Københavns Universitet	1	t
2800	128	University of Derby	1	t
2801	128	Princeton University	1	t
2802	128	John Innes Centre	1	t
2803	128	Mount Lourdes Convent Grammar School	1	t
2804	128	University of London	1	t
2805	128	Sun Yat-Sen University	1	t
2806	128	University of Leeds	1	t
2807	128	UMIST	1	t
2808	128	University of Southampton	1	t
2809	128	Université d'Orléans	1	t
2810	128	Shivaji University	1	t
2811	128	Cardiff University / Prifysgol Caerdydd	1	t
2812	128	University of Bari, Italy	1	t
2813	128	Queen Mary, U. of London	1	t
2814	128	The University of Sheffield	1	t
2815	129	University of Cambridge	5	t
2816	129	University of Nottingham	4	t
2817	129	University of Oxford	4	t
2818	129	University of Surrey	2	t
2819	129	The University of Glasgow	2	t
2820	129	The University of Dundee	2	t
2821	129	Université Claude Bernard Lyon 1	1	t
2822	129	Universidad de Sevilla	1	t
2823	129	Maria Curie-Sklodowska Univeristy, Lublin, Poland	1	t
2824	129	University of Kent	1	t
2825	129	Università degli Studi di Milano	1	t
2826	129	University of Sunderland	1	t
2827	129	University of Birmingham, UK	1	t
2828	129	Nottingham Trent University	1	t
2829	129	Stellenbosch University/Universiteit Stellenbosch	1	t
2830	129	University of Warwick	1	t
2831	129	University of Westminster	1	t
2832	129	University of Ljubljana	1	t
2833	129	The University of Manchester	1	t
2834	129	University of Liverpool	1	t
2835	129	University of Bristol	1	t
2836	129	Universidad Complutense de Madrid	1	t
2837	129	J.W. Goethe Universität, Frankfurt/Main, Germany	1	t
2838	129	Sheffield Hallam University	1	t
2839	129	Lomonosov Moscow State University (MSU)	1	t
2840	129	Florida State University	1	t
2841	129	Delhi University	1	t
2842	129	University of Leeds	1	t
2843	129	Université Paris Sud (Paris XI) / University Paris XI	1	t
2844	129	Bharathidasan University	1	t
2845	129	University of Newcastle-upon-Tyne	1	t
2846	129	MRC Laboratory of Molecular Biology	1	t
2847	129	Abertay University	1	t
2848	129	University of Teesside	1	t
2849	129	University of Washington	1	t
2850	129	Cardiff University / Prifysgol Caerdydd	1	t
2851	129	DCU Dublin	1	t
2852	129	The University of Sheffield	1	t
2853	129	Université de Montpellier	1	t
2854	129	University of Portsmouth	1	t
2855	129	University of Connecticut	1	t
2856	129	Sapienza Università di Roma	1	t
2857	129	Brunel University	1	t
2858	129	Bangalore University	1	t
2859	130	The Manchester Metropolitan University	1	t
2860	130	The University of Huddersfield	1	t
2861	130	University of Westminster	1	t
2862	130	University of Derby	1	t
2863	130	Universidade Atlântica	1	t
2864	130	Università degli Studi di Palermo	1	t
2865	130	Bangor University	1	t
2866	130	University of Bath	1	t
2867	130	Queen Mary, U. of London	1	t
2868	130	Learning Curve	1	t
2869	130	School of Health Professions - Department of Medical Laboratories	1	t
2870	130	Leeds Beckett University	1	t
2871	130	Universitat Autònoma de Barcelona	1	t
2872	130	University of Tirana	1	t
2873	130	Hind Leys Community College	1	t
2874	130	University Campus Suffolk	1	t
2875	130	Inspire motivate and engage	1	t
2876	130	The University of Birmingham	1	t
2877	130	University of East Anglia	1	t
2878	130	University of Nottingham	1	t
2879	130	Gdańsk University of Technology	1	t
2880	130	London Metropolitan University	1	t
2881	130	Harvard University	1	t
2882	131	University of Westminster	5	t
2883	131	University of Brighton	3	t
2884	131	Nottingham Trent University	3	t
2885	131	University of Greenwich	2	t
2886	131	University of Wales, Cardiff	2	t
2887	131	University of Zimbabwe	2	t
2888	131	London Metropolitan University	2	t
2889	131	Nantyglo	1	t
2890	131	Dannhauser Secondary School	1	t
2891	131	University of Ulster	1	t
2892	131	Fatima High School	1	t
2893	131	Edinburgh Napier University	1	t
2894	131	Robert Richardson GrammarSchol	1	t
2895	131	Bergen engineer university _ Norway	1	t
2896	131	PMF Sarajevo, Bosnia & Herzegovina	1	t
2897	131	Aston University	1	t
2898	131	University of Ibadan	1	t
2899	131	Bannerman High School	1	t
2900	131	Institute of Leadership and Management	1	t
2901	131	The University of Hull	1	t
2902	131	University of Bedfordshire	1	t
2903	131	KMC Manipal	1	t
2904	131	High Nursing School -Tirana	1	t
2905	131	Shahid Beheshti University of Medical Sciences and Health Services	1	t
2906	131	Kingston University	1	t
2907	131	King Alfred school Burnham on sea	1	t
2908	131	Mark Hall Comprehensive	1	t
2909	131	Liverpool John Moores University	1	t
2910	131	University of Hertfordshire	1	t
2911	131	University of Essex	1	t
2912	131	De Montfort University	1	t
2913	131	University of Portsmouth	1	t
2914	131	Guildford High School	1	t
2915	131	Staffordshire University	1	t
2916	131	Swansea	1	t
2917	131	University of Plymouth	1	t
2918	132	Sheffield College	1	t
2919	132	University of Illinois at Urbana-Champaign	1	t
2920	132	Imperial College London	1	t
2921	132	Massachusetts Institute of Technology	1	t
2922	133	Loughborough University	24	t
2923	133	Imperial College London	15	t
2924	133	University of Nottingham	15	t
2925	133	University of Bath	14	t
2926	133	University of Strathclyde	14	t
2927	133	The University of Sheffield	12	t
2928	133	The University of Manchester	11	t
2929	133	University of Portsmouth	11	t
2930	133	Brunel University	10	t
2931	133	Kingston University	10	t
2932	133	University of Plymouth	9	t
2933	133	University of Leeds	9	t
2934	133	University of Ulster	8	t
2935	133	London South Bank University	8	t
2936	133	Glasgow Caledonian University	8	t
2937	133	Northumbria University	8	t
2938	133	University of Bristol	8	t
2939	133	University of Teesside	8	t
2940	133	The Manchester Metropolitan University	8	t
2941	133	The Open University	7	t
2942	133	The University of Dundee	7	t
2943	133	The University of Huddersfield	7	t
2944	133	The University of Edinburgh	7	t
2945	133	Sheffield Hallam University	7	t
2946	133	The University of Birmingham	6	t
2947	133	University of Southampton	6	t
2948	133	Queen Mary, U. of London	6	t
2949	133	University of Derby	6	t
2950	133	Brunel University London	6	t
2951	133	University of Exeter	6	t
2952	133	University of Cambridge	6	t
2953	133	Cardiff University / Prifysgol Caerdydd	6	t
2954	133	Staffordshire University	5	t
2955	133	Cranfield University	5	t
2956	133	The University of Glasgow	5	t
2957	133	Birmingham City University	5	t
2958	133	Coventry University	5	t
2959	133	University of Brighton	5	t
2960	133	University of Liverpool	5	t
2961	133	University of Aberdeen	5	t
2962	133	Heriot-Watt University	5	t
2963	133	City University London	5	t
2964	133	Lancaster University	4	t
2965	133	UCL	4	t
2966	133	Aston University	4	t
2967	133	Swansea University	4	t
2968	133	Robert Gordon University	4	t
2969	133	University of Surrey	4	t
2970	133	Oxford Brookes University	4	t
2971	133	University of Central Lancashire	4	t
2972	134	London South Bank University	4	t
2973	134	Blackpool and The Fylde College	2	t
2974	134	Staffordshire University	2	t
2975	134	The Open University	2	t
2976	134	North Warwickshire and Hinckley College	2	t
2977	134	Brunel University	2	t
2978	134	Bingley Grammar School	2	t
2979	134	University of Bath	2	t
2980	134	The University of Northampton	2	t
2981	134	Warsaw University of Technology	2	t
2982	134	The University of Edinburgh	1	t
2983	134	John Smeaton High School, Leeds	1	t
2984	134	HMS Collingwood	1	t
2985	134	Langside College	1	t
2986	134	St Gerards	1	t
2987	134	Hamilton High School	1	t
2988	134	Norham High School	1	t
2989	134	The Henley College	1	t
2990	134	Bedford College	1	t
2991	134	Fulston Manor	1	t
2992	134	Argoed High School	1	t
2993	134	University of Greenwich	1	t
2994	134	Universidad del País Vasco/Euskal Herriko Unibertsitatea	1	t
2995	134	North Glasgow College	1	t
2996	134	University of Westminster	1	t
2997	134	University of Warwick	1	t
2998	134	k	1	t
2999	134	Smithills	1	t
3000	134	St Helens College	1	t
3001	134	University of Rijeka	1	t
3002	134	Longsands St Neots	1	t
3003	134	ts formidable	1	t
3004	134	Lambeth College	1	t
3005	134	Texas A&M University-Kingsville	1	t
3006	134	Queen Elizabeth's School, Wimborne	1	t
3007	134	Thomas Telford School	1	t
3008	134	Charles Keene	1	t
3009	134	Blackburn College	1	t
3010	134	Dublin Institute of Technology	1	t
3011	134	Institute of Technology, Sligo	1	t
3012	134	Lisnagarvey High School	1	t
3013	134	School of Electrical and Mechanical Engineering	1	t
3014	134	The University of Glasgow	1	t
3015	134	Castlebrook High	1	t
3016	134	Ballyclare High School	1	t
3017	134	walton technical college	1	t
3018	134	Stafford College	1	t
3019	134	GTS Offenbach IHK Offenbach (UNIVEG)	1	t
3020	134	Brunel University London	1	t
3021	134	Universitatea din Oradea	1	t
3022	135	University of Reading	2	t
3023	135	Brunel University London	2	t
3024	135	University of Greenwich	2	t
3025	135	Sheffield Hallam University	2	t
3026	135	Queen Mary, U. of London	2	t
3027	135	University of Bristol	2	t
3028	135	University of Hertfordshire	2	t
3029	135	Imperial College London	1	t
3030	135	University of Westminster	1	t
3031	135	University of Kent	1	t
3032	135	UMIST	1	t
3033	135	Ain Shams University	1	t
3034	135	st marylebone church of england secondary school	1	t
3035	135	\nIV Liceum Ogolnoksztalcace in Tarnow, Poland\n	1	t
3036	135	Cardinal Hinsley	1	t
3037	135	University of Teesside	1	t
3038	135	London Metropolitan University	1	t
3039	135	University of the West of England	1	t
3040	135	Edinburgh Napier University	1	t
3041	135	Germiston Technical College	1	t
3042	135	The University of Sheffield	1	t
3043	135	Electronic Engineer	1	t
3044	135	Univercity of Salahaddin	1	t
3045	135	Glasgow Caledonian University	1	t
3046	135	east berks	1	t
3047	135	Amarsingh College, Srinagar	1	t
3048	135	Whitburn Academy, Telford College	1	t
3049	135	UCL	1	t
3050	135	CRC	1	t
3051	135	Swanley School	1	t
3052	135	The University of Manchester	1	t
3053	135	Cranford College, United Kingdom	1	t
3054	135	high school pakistan	1	t
3055	135	University of Liverpool	1	t
3056	135	Canterbury Christ Church University	1	t
3057	135	School name:	1	t
3058	135	Greenwich Community College	1	t
3059	135	Peter Bradsworth	1	t
3060	135	Benue State University	1	t
3061	135	Mid Cheshire College	1	t
3062	135	Osmania University	1	t
3063	135	University of Brighton	1	t
3064	135	MidKent College	1	t
3065	135	Priory Secondary Modern Dunstable	1	t
3066	135	littleport	1	t
3067	135	University of Sunderland	1	t
3068	135	Jawaharlal Nehru Technological University	1	t
3069	135	University of Portsmouth	1	t
3070	135	University of Warwick	1	t
3071	135	Velagapudi Ramakrishna Siddhartha Engineering College	1	t
\.


--
-- Name: career_institute_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geektalent
--

SELECT pg_catalog.setval('career_institute_id_seq', 3071, true);


--
-- Data for Name: career_skill; Type: TABLE DATA; Schema: public; Owner: geektalent
--

COPY career_skill (id, career_id, skill_name, total_count, title_count, skill_count, count, relevance_score, visible) FROM stdin;
1	1	Project Management	7984381	6009	479558	2752	0.398217379695826268	t
2	1	Project Delivery	7984381	6009	94365	2114	0.340242990313395277	t
3	1	PRINCE2	7984381	6009	53617	1688	0.274403244057144891	t
4	1	Business Analysis	7984381	6009	148418	1640	0.254526961159881826	t
5	1	Stakeholder Management	7984381	6009	146503	1637	0.254267357924632176	t
6	1	ITIL	7984381	6009	61484	1546	0.249768185341825794	t
7	1	Change Management	7984381	6009	341196	1747	0.24818442229794746	t
8	1	Management	7984381	6009	738887	1893	0.222653475748570973	t
9	1	IT Service Management	7984381	6009	48722	1367	0.221556673778760732	t
10	1	Program Management	7984381	6009	122326	1391	0.21632824991807853	t
11	1	Service Delivery	7984381	6009	48591	1333	0.215910652249988733	t
12	1	IT Strategy	7984381	6009	47381	1191	0.19241329430871229	t
13	1	Requirements Analysis	7984381	6009	57261	1191	0.191174946435236331	t
14	1	Software Project Management	7984381	6009	28572	1089	0.177783470050122239	t
15	1	Integration	7984381	6009	67927	1064	0.168687199968095947	t
16	1	PMO	7984381	6009	25055	1019	0.166566320201098683	t
17	1	Project Planning	7984381	6009	226745	1131	0.159939473375757119	t
18	1	Project Portfolio Management	7984381	6009	23195	925	0.15114446675266896	t
19	1	Outsourcing	7984381	6009	64839	948	0.149755330272786397	t
20	1	Business Process	7984381	6009	48555	809	0.128646957350411678	t
21	1	IT Management	7984381	6009	30508	750	0.121082947223605339	t
22	1	Business Process Improvement	7984381	6009	81006	777	0.119250230053865244	t
23	1	Microsoft Project	7984381	6009	39932	715	0.114072770568815762	t
24	1	Service Management	7984381	6009	20253	672	0.10937799153040699	t
25	1	Agile Methodologies	7984381	6009	46119	670	0.105802891983513211	t
26	1	Governance	7984381	6009	96897	677	0.100604232335595734	t
27	1	SDLC	7984381	6009	25307	591	0.0952545961877131059	t
28	1	Data Center	7984381	6009	30537	594	0.0950987011233096341	t
29	1	Team Leadership	7984381	6009	284785	781	0.0943749733278439751	t
30	1	Business Transformation	7984381	6009	54432	602	0.0934360682564290695	t
31	1	Team Management	7984381	6009	150662	663	0.0915337955528722907	t
32	1	Infrastructure	7984381	6009	23736	527	0.0847927912093536795	t
33	1	Solution Architecture	7984381	6009	29742	528	0.0842065484346466442	t
34	1	Vendor Management	7984381	6009	28713	525	0.083835894975115649	t
35	1	Requirements Gathering	7984381	6009	25858	495	0.0791974660033590433	t
36	1	Process Improvement	7984381	6009	108186	527	0.0742079250236205579	t
37	1	Resource Management	7984381	6009	14910	445	0.0722425567745398622	t
38	1	Software Development	7984381	6009	47537	463	0.0711508888376914533	t
39	1	CRM	7984381	6009	102251	499	0.0702886244808404448	t
40	1	Telecommunications	7984381	6009	71758	469	0.0691143107446231392	t
41	1	Incident Management	7984381	6009	17789	424	0.0683843162359216716	t
42	1	Business Intelligence	7984381	6009	44693	436	0.0670107082784211494	t
43	1	PMP	7984381	6009	6621	407	0.0669528800935262347	t
44	1	Risk Management	7984381	6009	130308	483	0.0641073141863090779	t
45	1	Agile Project Management	7984381	6009	10946	383	0.0624137724327401278	t
46	1	It Outsourcing	7984381	6009	10742	377	0.0614400872791210223	t
47	1	Testing	7984381	6009	52574	405	0.0608600989945563969	t
48	1	Pre Sales	7984381	6009	27648	378	0.059487651000275546	t
49	1	Managed Services	7984381	6009	34802	382	0.0592571463615222116	t
50	1	IT Operations	7984381	6009	17015	353	0.0566568195315402812	t
51	2	Business Analysis	7984381	5290	148418	1053	0.180585924648178159	t
52	2	Requirements Analysis	7984381	5290	57261	788	0.141882679204392098	t
53	2	Project Management	7984381	5290	479558	1000	0.129059410728452117	t
54	2	SQL	7984381	5290	74090	682	0.119722449805263587	t
55	2	Management	7984381	5290	738887	1117	0.118690205710639596	t
56	2	Integration	7984381	5290	67927	627	0.110090975111783063	t
57	2	Business Intelligence	7984381	5290	44693	608	0.109408771979926905	t
58	2	Business Development	7984381	5290	206995	685	0.103633274277352694	t
59	2	Cloud Computing	7984381	5290	45728	575	0.103036736891457939	t
60	2	Agile Methodologies	7984381	5290	46119	521	0.0927730266190886221	t
61	2	Business Process	7984381	5290	48555	521	0.0924677286847750551	t
62	2	Solution Architecture	7984381	5290	29742	507	0.0921772586354270979	t
63	2	Account Management	7984381	5290	240929	643	0.0914356366179294444	t
64	2	Software Project Management	7984381	5290	28572	497	0.090432279435905899	t
65	2	CRM	7984381	5290	102251	541	0.0895213649513841025	t
66	2	Software Development	7984381	5290	47537	496	0.0878662810304974562	t
67	2	Solution Selling	7984381	5290	39947	483	0.0863584210281597292	t
68	2	IT Strategy	7984381	5290	47381	486	0.0859942196859048297	t
69	2	Pre Sales	7984381	5290	27648	472	0.0858190509910595478	t
70	2	Enterprise Software	7984381	5290	25770	429	0.0779204826388282118	t
71	2	Microsoft SQL Server	7984381	5290	44532	439	0.0774606994161637363	t
72	2	Change Management	7984381	5290	341196	633	0.076977805791575038	t
73	2	New Business Development	7984381	5290	289997	572	0.0718556155898176785	t
74	2	SAAS	7984381	5290	24755	377	0.0682113054035200506	t
75	2	Project Delivery	7984381	5290	94365	421	0.0678103487575540675	t
76	2	IT Service Management	7984381	5290	48722	385	0.0667208697462339795	t
77	2	ITIL	7984381	5290	61484	379	0.0639864719688866407	t
78	2	Consulting	7984381	5290	41734	352	0.0613543376655637657	t
79	2	Business Process Improvement	7984381	5290	81006	366	0.0590807311803791466	t
80	2	XML	7984381	5290	32063	328	0.0580265106257908531	t
81	2	Program Management	7984381	5290	122326	386	0.0576854213201674834	t
82	2	Requirements Gathering	7984381	5290	25858	322	0.0576692006645869865	t
83	2	Managed Services	7984381	5290	34802	323	0.0567374322191097624	t
84	2	Java	7984381	5290	56026	333	0.0559690925455914173	t
85	2	Sales	7984381	5290	353906	523	0.0545771556314306808	t
86	2	Oracle	7984381	5290	25936	303	0.0540653614716807701	t
87	2	Databases	7984381	5290	42473	306	0.0525603033576457351	t
88	2	Strategy	7984381	5290	223349	425	0.0524017438338146152	t
89	2	SDLC	7984381	5290	25307	293	0.0522525800626096118	t
90	2	ERP	7984381	5290	22780	284	0.0508668316053632608	t
91	2	Outsourcing	7984381	5290	64839	304	0.0493789046788717517	t
92	2	Enterprise Architecture	7984381	5290	19356	273	0.0492151794799901288	t
93	2	Professional Services	7984381	5290	18833	272	0.0490915645490902705	t
94	2	Team Leadership	7984381	5290	284785	448	0.0490528285250407259	t
95	2	PRINCE2	7984381	5290	53617	289	0.0479479118829341661	t
96	2	Stakeholder Management	7984381	5290	146503	348	0.0474672496338024164	t
97	2	Virtualization	7984381	5290	25670	258	0.0455864426051844074	t
98	2	Javascript	7984381	5290	44076	267	0.0449821147492266635	t
99	2	Data Center	7984381	5290	30537	258	0.0449764733743534748	t
100	2	Direct Sales	7984381	5290	49654	267	0.0442830376237746542	t
101	3	Active Directory	7984381	60404	34347	10177	0.165431983709010161	t
102	3	Windows Server	7984381	60404	35131	9779	0.158693848570672147	t
103	3	Technical Support	7984381	60404	29935	7533	0.121883168359778832	t
104	3	Windows 7	7984381	60404	22076	6901	0.112332327128337503	t
105	3	Troubleshooting	7984381	60404	38514	6957	0.111192021841730951	t
106	3	Microsoft Office	7984381	60404	601080	10517	0.0995823749524463453	t
107	3	ITIL	7984381	60404	61484	6370	0.098501246497113254	t
108	3	Microsoft Exchange	7984381	60404	19253	6008	0.0977921025389036358	t
109	3	Windows	7984381	60404	91564	6297	0.0934874311019334436	t
110	3	VMware	7984381	60404	24043	5664	0.0914492084729223581	t
111	3	Networking	7984381	60404	56939	5876	0.0908342133421891906	t
112	3	Servers	7984381	60404	22249	5510	0.0891066752192460898	t
113	3	Project Management	7984381	60404	479558	8295	0.0778523028288422014	t
114	3	SQL	7984381	60404	74090	4683	0.0687688665355697254	t
115	3	System Administration	7984381	60404	32282	4323	0.0680397030807286946	t
116	3	Customer Service	7984381	60404	670741	9019	0.0658024799720979547	t
117	3	IT Service Management	7984381	60404	48722	4263	0.0649641036596004529	t
118	3	Network Administration	7984381	60404	14683	3726	0.0603018913999750425	t
119	3	Virtualization	7984381	60404	25670	3806	0.0602498517190982047	t
120	3	Computer Hardware	7984381	60404	15627	3637	0.0586981152119851329	t
121	3	Citrix	7984381	60404	14501	3626	0.0586567202369270083	t
122	3	Microsoft SQL Server	7984381	60404	44532	3803	0.0578194371742665331	t
123	3	Linux	7984381	60404	34632	3630	0.0561829285964770483	t
124	3	Windows XP	7984381	60404	8746	3223	0.0526603950605749119	t
125	3	DNS	7984381	60404	10524	3192	0.0519188895612925014	t
126	3	Software Installation	7984381	60404	11865	3134	0.0507821354913233006	t
127	3	Team Leadership	7984381	60404	284785	5186	0.0505700556655975866	t
128	3	Hardware	7984381	60404	12216	3054	0.0494033280104781772	t
129	3	Management	7984381	60404	738887	8530	0.0490453036886479843	t
130	3	Engineering	7984381	60404	143574	3958	0.0479060265987987441	t
131	3	Business Analysis	7984381	60404	148418	3923	0.0467108686042753546	t
132	3	Cisco Technologies	7984381	60404	20354	2914	0.046040923268531278	t
133	3	Disaster Recovery	7984381	60404	24109	2887	0.0451166474177299645	t
134	3	DHCP	7984381	60404	7710	2704	0.044133493860316543	t
135	3	Testing	7984381	60404	52574	3016	0.0436762854643323248	t
136	3	Integration	7984381	60404	67927	3102	0.043173348198495734	t
137	3	Change Management	7984381	60404	341196	5138	0.0426503225240972075	t
138	3	Operating Systems	7984381	60404	11663	2615	0.042149984111767333	t
139	3	HTML	7984381	60404	75907	3058	0.0414322967894489233	t
140	3	Help Desk Support	7984381	60404	7855	2485	0.040461969621799411	t
141	3	IP	7984381	60404	24395	2566	0.0397258268680048474	t
142	3	Security	7984381	60404	58305	2751	0.0385324680464879873	t
143	3	VPN	7984381	60404	9591	2360	0.038157713429319326	t
144	3	Group Policy	7984381	60404	6615	2335	0.0381162475575400478	t
145	3	Databases	7984381	60404	42473	2545	0.0370940874427160422	t
146	3	Vmware Esx	7984381	60404	8429	2180	0.0353017059948327674	t
147	3	Data Center	7984381	60404	30537	2334	0.035080627567152578	t
148	3	IT Management	7984381	60404	30508	2298	0.0344837571516352012	t
149	3	Xp	7984381	60404	6748	2061	0.0335287610249147064	t
150	3	Unix	7984381	60404	24442	2192	0.0334810540437792334	t
151	4	Business Analysis	7984381	32697	148418	5505	0.150391399151994676	t
152	4	SQL	7984381	32697	74090	4634	0.132990787025442037	t
153	4	Integration	7984381	32697	67927	4596	0.132598877980633495	t
154	4	Requirements Analysis	7984381	32697	57261	4493	0.130777139741389159	t
155	4	ITIL	7984381	32697	61484	3993	0.1148912547000977	t
156	4	Solution Architecture	7984381	32697	29742	3697	0.109793070410840646	t
157	4	Project Management	7984381	32697	479558	5387	0.105123656753472849	t
158	4	Microsoft SQL Server	7984381	32697	44532	3578	0.10427864402993002	t
159	4	Agile Methodologies	7984381	32697	46119	3121	0.0900447741165216753	t
160	4	Software Development	7984381	32697	47537	2885	0.0826189802981436711	t
161	4	IT Strategy	7984381	32697	47381	2813	0.0804275072140963887	t
162	4	IT Service Management	7984381	32697	48722	2809	0.0801360252709923254	t
163	4	Windows Server	7984381	32697	35131	2704	0.078620714431071867	t
164	4	Business Intelligence	7984381	32697	44693	2682	0.0767425905433542638	t
165	4	Business Process	7984381	32697	48555	2678	0.0761340688386097919	t
166	4	Cloud Computing	7984381	32697	45728	2630	0.0750155299681978249	t
167	4	Enterprise Architecture	7984381	32697	19356	2519	0.0749232939819933497	t
168	4	Active Directory	7984381	32697	34347	2488	0.0720860351887191303	t
169	4	Project Delivery	7984381	32697	94365	2562	0.0668107108184956971	t
170	4	Virtualization	7984381	32697	25670	2280	0.0667896527155210779	t
171	4	Databases	7984381	32697	42473	2341	0.0665498013362231106	t
172	4	Change Management	7984381	32697	341196	3553	0.0662025802809890623	t
173	4	Oracle	7984381	32697	25936	2236	0.0654049780559189664	t
174	4	VMware	7984381	32697	24043	2155	0.0631555628199506336	t
175	4	Management	7984381	32697	738887	5061	0.0624992337109504109	t
176	4	XML	7984381	32697	32063	2164	0.0624233578785012636	t
177	4	Java	7984381	32697	56026	2251	0.0620815180362879332	t
178	4	ERP	7984381	32697	22780	2003	0.0586465371186982026	t
179	4	Data Migration	7984381	32697	16676	1955	0.0579401122105613967	t
180	4	Testing	7984381	32697	52574	2096	0.0577556511190802369	t
181	4	Data Center	7984381	32697	30537	1997	0.0574867628551706186	t
182	4	SAP	7984381	32697	46419	2033	0.0565949958696395916	t
183	4	Software Project Management	7984381	32697	28572	1937	0.055891304012862339	t
184	4	Unix	7984381	32697	24442	1918	0.055827208352052668	t
185	4	Pre Sales	7984381	32697	27648	1916	0.0553626041057528051	t
186	4	Disaster Recovery	7984381	32697	24109	1887	0.0549170885145015344	t
187	4	Javascript	7984381	32697	44076	1913	0.0532044978194049015	t
188	4	Servers	7984381	32697	22249	1772	0.0516193966395483012	t
189	4	Linux	7984381	32697	34632	1750	0.0493865051327955495	t
190	4	SDLC	7984381	32697	25307	1705	0.0491772804689657381	t
191	4	SOA	7984381	32697	10997	1621	0.0483972924351533176	t
192	4	Service Delivery	7984381	32697	48591	1750	0.0476310279282185084	t
193	4	Technical Support	7984381	32697	29935	1668	0.0474590099988059441	t
194	4	IT Management	7984381	32697	30508	1660	0.0471412729500828298	t
195	4	Requirements Gathering	7984381	32697	25858	1635	0.0469583146112663163	t
196	4	Team Leadership	7984381	32697	284785	2666	0.0460573810690998037	t
197	4	Stakeholder Management	7984381	32697	146503	2085	0.0456053790718018437	t
198	4	Web Services	7984381	32697	17244	1547	0.0453391619045029337	t
199	4	C#	7984381	32697	29764	1583	0.0448701984408422447	t
200	4	Sap Erp	7984381	32697	7684	1488	0.0447295562570421135	t
201	5	Business Analysis	7984381	1896	148418	1102	0.562768723984990227	t
202	5	Requirements Analysis	7984381	1896	57261	785	0.406954546059172861	t
203	5	Requirements Gathering	7984381	1896	25858	613	0.32014968728119042	t
204	5	Project Management	7984381	1896	479558	567	0.239045383919380516	t
205	5	Business Process	7984381	1896	48555	463	0.238173621929947454	t
206	5	Stakeholder Management	7984381	1896	146503	468	0.228541014673875054	t
207	5	SQL	7984381	1896	74090	433	0.219148200346936245	t
208	5	Project Delivery	7984381	1896	94365	416	0.207639890086467771	t
209	5	Change Management	7984381	1896	341196	468	0.204150990765280149	t
210	5	Business Process Improvement	7984381	1896	81006	396	0.19876240039872739	t
211	5	Agile Methodologies	7984381	1896	46119	387	0.198384881027063198	t
212	5	User Acceptance Testing	7984381	1896	19596	360	0.187463641818401111	t
213	5	SDLC	7984381	1896	25307	339	0.175669620322144698	t
214	5	Software Project Management	7984381	1896	28572	309	0.159434056784591771	t
215	5	Business Intelligence	7984381	1896	44693	309	0.157414510239875433	t
216	5	Business Requirements	7984381	1896	9511	285	0.149160675259408709	t
217	5	Analysis	7984381	1896	128547	300	0.142161798493906727	t
218	5	Integration	7984381	1896	67927	277	0.137622241888344848	t
219	5	Testing	7984381	1896	52574	269	0.135325166315009349	t
220	5	PRINCE2	7984381	1896	53617	262	0.13150164520666846	t
221	5	Management	7984381	1896	738887	382	0.108961116739687697	t
222	5	Visio	7984381	1896	12345	198	0.102908673160477943	t
223	5	Process Improvement	7984381	1896	108186	220	0.102508393184636629	t
224	5	Microsoft SQL Server	7984381	1896	44532	197	0.0983489187214151434	t
225	5	ITIL	7984381	1896	61484	199	0.0972803721255874332	t
226	5	Software Development	7984381	1896	47537	192	0.0953347123599236346	t
227	5	Systems Analysis	7984381	1896	7388	177	0.0924510776017585245	t
228	5	Data Analysis	7984381	1896	113349	197	0.0897279191204136961	t
229	5	Databases	7984381	1896	42473	180	0.0896384840598359739	t
230	5	Scrum	7984381	1896	21173	172	0.0880864145842256974	t
231	5	CRM	7984381	1896	102251	186	0.0853151472143564849	t
232	5	Data Migration	7984381	1896	16676	165	0.0849569129447594468	t
233	5	Business Process Design	7984381	1896	8283	153	0.0796777226973583719	t
234	5	Solution Architecture	7984381	1896	29742	153	0.0769894620867841023	t
235	5	Business Process Mapping	7984381	1896	7443	147	0.0766176444784813365	t
236	5	Business Transformation	7984381	1896	54432	157	0.0760066460406541577	t
237	5	IT Strategy	7984381	1896	47381	149	0.072669543458185562	t
238	5	Software Documentation	7984381	1896	20913	141	0.0717648914221320072	t
239	5	Project Planning	7984381	1896	226745	186	0.0697192519511646291	t
240	5	Team Leadership	7984381	1896	284785	199	0.0693065018333162974	t
241	5	UML	7984381	1896	10842	133	0.0688061171421907591	t
242	5	Sharepoint	7984381	1896	21286	134	0.0680253040762723304	t
243	5	Oracle	7984381	1896	25936	134	0.0674427787097981041	t
244	5	Program Management	7984381	1896	122326	146	0.0616982088123320047	t
245	5	XML	7984381	1896	32063	124	0.0613997088969489638	t
246	5	Microsoft Project	7984381	1896	39932	120	0.058303719909308091	t
247	5	PMO	7984381	1896	25055	115	0.057529668086158961	t
248	5	Agile Project Management	7984381	1896	10946	109	0.0561318541872274021	t
249	5	ERP	7984381	1896	22780	111	0.0557044613173384162	t
250	5	Team Management	7984381	1896	150662	139	0.0544555769884682919	t
251	6	ITIL	7984381	3322	61484	1122	0.330185187651934275	t
252	6	IT Service Management	7984381	3322	48722	1002	0.29564637039091779	t
253	6	Service Delivery	7984381	3322	48591	891	0.262235270062739223	t
254	6	Active Directory	7984381	3322	34347	804	0.237820052069233151	t
255	6	Management	7984381	3322	738887	964	0.197727350645423183	t
256	6	Incident Management	7984381	3322	17789	647	0.192614356182455648	t
257	6	Service Desk	7984381	3322	7572	589	0.176427883075396086	t
258	6	Service Management	7984381	3322	20253	594	0.176344740069511702	t
259	6	Technical Support	7984381	3322	29935	563	0.165796005779924593	t
260	6	Windows Server	7984381	3322	35131	519	0.151894418192553476	t
261	6	Windows 7	7984381	3322	22076	513	0.151723273371105638	t
262	6	Change Management	7984381	3322	341196	631	0.147274160295328527	t
263	6	Customer Service	7984381	3322	670741	739	0.138507341821157648	t
264	6	Project Delivery	7984381	3322	94365	492	0.136341579135877161	t
265	6	Troubleshooting	7984381	3322	38514	465	0.135208505676723656	t
266	6	Project Management	7984381	3322	479558	641	0.1329493522127419	t
267	6	Outsourcing	7984381	3322	64839	461	0.130705476114897384	t
268	6	IT Management	7984381	3322	30508	443	0.129586357617896081	t
269	6	Microsoft Exchange	7984381	3322	19253	423	0.124973595945742214	t
270	6	SLA	7984381	3322	9957	413	0.123126865890344897	t
271	6	IT Strategy	7984381	3322	47381	423	0.121449251620007997	t
272	6	IT Operations	7984381	3322	17015	409	0.12103792698992083	t
273	6	Microsoft Office	7984381	3322	601080	635	0.115916159384882908	t
274	6	Citrix	7984381	3322	14501	372	0.110210418051816569	t
275	6	Team Leadership	7984381	3322	284785	478	0.108266507125899636	t
276	6	PRINCE2	7984381	3322	53617	376	0.106513909181462363	t
277	6	Managed Services	7984381	3322	34802	365	0.105558729213225164	t
278	6	Business Analysis	7984381	3322	148418	409	0.104573570568047489	t
279	6	Data Center	7984381	3322	30537	342	0.0991666975897077529	t
280	6	Networking	7984381	3322	56939	345	0.0967620616208168804	t
281	6	Windows	7984381	3322	91564	347	0.0930259624773122074	t
282	6	Stakeholder Management	7984381	3322	146503	368	0.0924664138273546821	t
283	6	Windows XP	7984381	3322	8746	301	0.0895499371736129535	t
284	6	VMware	7984381	3322	24043	307	0.0894401668934433208	t
285	6	Servers	7984381	3322	22249	296	0.086352312552043356	t
286	6	Help Desk Support	7984381	3322	7855	287	0.0854454936228411926	t
287	6	Team Management	7984381	3322	150662	341	0.0838142880720084138	t
288	6	Disaster Recovery	7984381	3322	24109	285	0.0828066242314684509	t
289	6	Service Improvement	7984381	3322	5848	272	0.0811797323631137657	t
290	6	It Outsourcing	7984381	3322	10742	266	0.0787596378722047741	t
291	6	Cloud Computing	7984381	3322	45728	276	0.0773874968479621728	t
292	6	Problem Management	7984381	3322	4027	244	0.0729757318311344827	t
293	6	Virtualization	7984381	3322	25670	237	0.068155894880870177	t
294	6	Infrastructure	7984381	3322	23736	234	0.0674947722831347324	t
295	6	Integration	7984381	3322	67927	249	0.0664750194275048056	t
296	6	CRM	7984381	3322	102251	249	0.0621743370243299856	t
297	6	Information Technology	7984381	3322	16594	213	0.0620655166904472907	t
298	6	Process Improvement	7984381	3322	108186	237	0.0578169160561302492	t
299	6	Account Management	7984381	3322	240929	292	0.0577478448226756425	t
300	6	System Administration	7984381	3322	32282	205	0.0576906725471626261	t
301	7	Cisco Technologies	7984381	4987	20354	1052	0.208529485322119207	t
302	7	Networking	7984381	4987	56939	1068	0.207154897529899351	t
303	7	Windows Server	7984381	4987	35131	901	0.176379941876515622	t
304	7	Active Directory	7984381	4987	34347	891	0.174471728168628826	t
305	7	Network Administration	7984381	4987	14683	804	0.159479814697575939	t
306	7	Network Security	7984381	4987	14836	712	0.141001145903284886	t
307	7	Firewalls	7984381	4987	10647	681	0.135306076085272092	t
308	7	IP	7984381	4987	24395	635	0.12435339102515644	t
309	7	VPN	7984381	4987	9591	623	0.123800909619461247	t
310	7	Data Center	7984381	4987	30537	612	0.118968784784846904	t
311	7	Troubleshooting	7984381	4987	38514	616	0.118771671520928865	t
312	7	VMware	7984381	4987	24043	601	0.117575517587792513	t
313	7	Switches	7984381	4987	8402	591	0.117529224722516062	t
314	7	Servers	7984381	4987	22249	568	0.111179006306645331	t
315	7	ITIL	7984381	4987	61484	583	0.109271666415563948	t
316	7	Network Design	7984381	4987	10581	517	0.102408292144856666	t
317	7	WAN	7984381	4987	9599	516	0.102330712456331074	t
318	7	Security	7984381	4987	58305	541	0.101242907107776309	t
319	7	Microsoft Exchange	7984381	4987	19253	463	0.0904865721919729665	t
320	7	Virtualization	7984381	4987	25670	467	0.090484962496371002	t
321	7	DNS	7984381	4987	10524	451	0.089172754775046853	t
322	7	CCNA	7984381	4987	6012	445	0.0885343311796136928	t
323	7	Telecommunications	7984381	4987	71758	474	0.0861136120289045237	t
324	7	Routing	7984381	4987	4902	429	0.0854630926346455488	t
325	7	Project Management	7984381	4987	479558	683	0.0769421298761095995	t
326	7	Routers	7984381	4987	5089	383	0.0762099100680776187	t
327	7	Disaster Recovery	7984381	4987	24109	390	0.0752307971564957212	t
328	7	Windows 7	7984381	4987	22076	387	0.0748836383743339412	t
329	7	Technical Support	7984381	4987	29935	388	0.0740993731658661087	t
330	7	Cisco IOS	7984381	4987	3245	364	0.0726287184234845062	t
331	7	VoIP	7984381	4987	20943	370	0.0716146355754458952	t
332	7	System Administration	7984381	4987	32282	374	0.0709961870572466264	t
333	7	Windows	7984381	4987	91564	408	0.0703887878786700477	t
334	7	IT Service Management	7984381	4987	48722	378	0.0697384669352137943	t
335	7	DHCP	7984381	4987	7710	352	0.0696613919806849946	t
336	7	OSPF	7984381	4987	2674	332	0.066279584036014097	t
337	7	Cisco Routers	7984381	4987	2914	292	0.0582236394309828265	t
338	7	CCNP	7984381	4987	1946	277	0.0553352517267104715	t
339	7	Change Management	7984381	4987	341196	484	0.0543533541711561513	t
340	7	BGP	7984381	4987	2450	271	0.0540682089654609538	t
341	7	Linux	7984381	4987	34632	290	0.053847357497506923	t
342	7	Juniper	7984381	4987	2791	264	0.0526209471423199002	t
343	7	Management	7984381	4987	738887	708	0.0494584603804780198	t
344	7	IT Management	7984381	4987	30508	265	0.0493480217674283905	t
345	7	Citrix	7984381	4987	14501	249	0.0481437169770787057	t
346	7	MPLS	7984381	4987	7734	242	0.0475872496177778895	t
347	7	LAN WAN	7984381	4987	4119	231	0.0458331780789401413	t
348	7	Vmware Esx	7984381	4987	8429	229	0.044891743453417704	t
349	7	Wireless Networking	7984381	4987	6122	224	0.0441776297618623262	t
350	7	Network Architecture	7984381	4987	4856	219	0.0433330550352960114	t
351	8	SQL	7984381	33573	74090	9475	0.274093985234271476	t
352	8	Java	7984381	33573	56026	9177	0.267452294848630368	t
353	8	Javascript	7984381	33573	44076	8350	0.244218382635798537	t
354	8	Software Development	7984381	33573	47537	7661	0.223173979476355699	t
355	8	C#	7984381	33573	29764	6905	0.20279617019492438	t
356	8	XML	7984381	33573	32063	6814	0.199785060392619673	t
357	8	Agile Methodologies	7984381	33573	46119	6362	0.184497140593169379	t
358	8	HTML	7984381	33573	75907	5947	0.168337283659542841	t
359	8	Microsoft SQL Server	7984381	33573	44532	5731	0.165822515023726996	t
360	8	C++	7984381	33573	41117	5623	0.163021576893426667	t
361	8	CSS	7984381	33573	39569	5094	0.147393030707755696	t
362	8	Linux	7984381	33573	34632	4757	0.137933760241572029	t
363	8	MySQL	7984381	33573	28574	4699	0.136960821815591133	t
364	8	jQuery	7984381	33573	21454	4207	0.123139814594273742	t
365	8	.NET	7984381	33573	18072	4179	0.122727654997797975	t
366	8	C	7984381	33573	30049	4143	0.120144449144426554	t
367	8	PHP	7984381	33573	28191	3788	0.109759513402170814	t
368	8	Software Engineering	7984381	33573	15605	3705	0.1088598332743968	t
369	8	Web Services	7984381	33573	17244	3647	0.106918817138578093	t
370	8	Scrum	7984381	33573	21173	3506	0.102207116066417483	t
371	8	ASP.NET	7984381	33573	14310	3431	0.100826927787483991	t
372	8	Databases	7984381	33573	42473	3438	0.0974941533643352981	t
373	8	Visual Studio	7984381	33573	12585	3161	0.0929677513069624845	t
374	8	Programming	7984381	33573	26495	3166	0.0913678016499351736	t
375	8	Web Development	7984381	33573	32187	3151	0.0902032253701495201	t
376	8	Python	7984381	33573	19693	2973	0.0864503708381022806	t
377	8	Requirements Analysis	7984381	33573	57261	2979	0.081904786158000828	t
378	8	HTML 5	7984381	33573	22908	2810	0.081170416469400708	t
379	8	Unix	7984381	33573	24442	2784	0.0801997781606889198	t
380	8	Eclipse	7984381	33573	8860	2689	0.0793179757226359916	t
381	8	Git	7984381	33573	9310	2616	0.0770778299383676896	t
382	8	Oracle	7984381	33573	25936	2640	0.0757046004305098885	t
383	8	Subversion	7984381	33573	8392	2476	0.0730056640547642605	t
384	8	AJAX	7984381	33573	9966	2415	0.070983088349102344	t
385	8	Testing	7984381	33573	52574	2484	0.0676880374623092668	t
386	8	UML	7984381	33573	10842	2291	0.0671638708319281102	t
387	8	Test Driven Development	7984381	33573	7723	2157	0.0635480018379957767	t
388	8	Web Applications	7984381	33573	12091	2030	0.0591998488364800859	t
389	8	Java Enterprise Edition	7984381	33573	8329	2009	0.0590448644169466047	t
390	8	OOP	7984381	33573	6685	1983	0.0584739339115171938	t
391	8	Business Analysis	7984381	33573	148418	2492	0.0558727064855954747	t
392	8	Software Design	7984381	33573	8139	1892	0.055569102615749176	t
393	8	Spring	7984381	33573	5821	1882	0.0555615291798644065	t
394	8	ASP.NET MVC	7984381	33573	6240	1873	0.0552396256146974324	t
395	8	Integration	7984381	33573	67927	2039	0.0524463708806746018	t
396	8	Hibernate	7984381	33573	5003	1727	0.0510281117603252551	t
397	8	VB.NET	7984381	33573	7032	1621	0.0476022865728760181	t
398	8	Object Oriented Design	7984381	33573	4966	1566	0.046216995651448857	t
399	8	Windows	7984381	33573	91564	1921	0.0459438951287111583	t
400	8	Embedded Systems	7984381	33573	9982	1519	0.0441802705547398936	t
401	9	Data Analysis	7984381	11543	113349	1512	0.116961226841333588	t
402	9	Microsoft Excel	7984381	11543	428419	1944	0.114922766970715184	t
403	9	Analysis	7984381	11543	128547	1454	0.11002303975283681	t
404	9	Financial Analysis	7984381	11543	97681	1274	0.098277991038582535	t
405	9	Financial Modeling	7984381	11543	47994	1095	0.0889803403041949936	t
406	9	Microsoft Office	7984381	11543	601080	1850	0.0851113603159646542	t
407	9	Economics	7984381	11543	30444	958	0.0792957156754677123	t
408	9	Research	7984381	11543	383551	1464	0.0789065259280290893	t
409	9	Teamwork	7984381	11543	285884	1231	0.0709418746587934523	t
410	9	Corporate Finance	7984381	11543	49388	846	0.0672027504251348218	t
411	9	Valuation	7984381	11543	31348	752	0.0613101791963643478	t
412	9	Business Analysis	7984381	11543	148418	903	0.0597270352601297766	t
413	9	Investment Banking	7984381	11543	44007	709	0.0559918186019053993	t
414	9	Powerpoint	7984381	11543	268322	1005	0.0535372916243611885	t
415	9	Finance	7984381	11543	102182	728	0.0503435719781925514	t
416	9	Bloomberg	7984381	11543	19492	606	0.050130557612344244	t
417	9	SQL	7984381	11543	74090	622	0.0446706852105816926	t
418	9	Equities	7984381	11543	39231	550	0.0427963277634163183	t
419	9	Derivatives	7984381	11543	38143	519	0.0402432925625069646	t
420	9	Investments	7984381	11543	60931	522	0.0376453622953943356	t
421	9	Microsoft Word	7984381	11543	319543	895	0.0375694721790740677	t
422	9	Market Research	7984381	11543	77513	532	0.0364331309857963831	t
423	9	Capital Markets	7984381	11543	31475	464	0.0363079412076616759	t
424	9	Fixed Income	7984381	11543	34489	448	0.0345417794168318276	t
425	9	Banking	7984381	11543	78690	502	0.0336827642468581351	t
426	9	Statistics	7984381	11543	36968	441	0.033623542610184895	t
427	9	VBA	7984381	11543	13934	404	0.033302555057800623	t
428	9	Financial Markets	7984381	11543	27599	386	0.0300269664819276666	t
429	9	English	7984381	11543	149229	560	0.0298673150517630367	t
430	9	Risk Management	7984381	11543	130308	522	0.0289436929525580741	t
431	9	Portfolio Management	7984381	11543	52908	396	0.0277201437608398521	t
432	9	Project Management	7984381	11543	479558	983	0.025134159950281669	t
433	9	Matlab	7984381	11543	43522	340	0.0240389418550358142	t
434	9	Asset Management	7984381	11543	38451	332	0.023980912214895362	t
435	9	Time Management	7984381	11543	218895	589	0.0236453801316176826	t
436	9	Business Strategy	7984381	11543	247930	614	0.0221725909410081558	t
437	9	Analytics	7984381	11543	20051	283	0.0220376050593713846	t
438	9	Strategy	7984381	11543	223349	569	0.0213515730455969589	t
439	9	Hedge Funds	7984381	11543	21026	273	0.0210477346832208048	t
440	9	Private Equity	7984381	11543	24099	271	0.0204887850055765902	t
441	9	Econometrics	7984381	11543	6860	242	0.0201350187763946892	t
442	9	Management Consulting	7984381	11543	71135	334	0.0200550096981264928	t
443	9	Public Speaking	7984381	11543	243457	583	0.0200441222495399869	t
444	9	Leadership	7984381	11543	330397	678	0.0173816102839704639	t
445	9	Emerging Markets	7984381	11543	15273	222	0.0173446507418133673	t
446	9	Accounting	7984381	11543	101909	347	0.0173230087462774712	t
447	9	Equity Research	7984381	11543	5054	206	0.0172382492521460408	t
448	9	SPSS	7984381	11543	27885	232	0.0166303600651493792	t
449	9	Databases	7984381	11543	42473	249	0.0162755340239180112	t
450	9	Financial Reporting	7984381	11543	76474	298	0.0162620724604488273	t
451	10	Testing	7984381	11546	52574	4643	0.396118819222494478	t
452	10	Test Planning	7984381	11546	9700	3378	0.291775912479226629	t
453	10	User Acceptance Testing	7984381	11546	19596	3093	0.265815078195415222	t
454	10	System Testing	7984381	11546	11248	3062	0.264173332876236677	t
455	10	Regression Testing	7984381	11546	8074	3055	0.263964286129486858	t
456	10	Manual Testing	7984381	11546	7313	2900	0.250615731605385528	t
457	10	Test Management	7984381	11546	8881	2775	0.23957712538115325	t
458	10	Quality Center	7984381	11546	8579	2660	0.229640420661776173	t
459	10	Agile Methodologies	7984381	11546	46119	2434	0.205329707748634904	t
460	10	Test Automation	7984381	11546	6997	2376	0.20520596035766539	t
461	10	Quality Assurance	7984381	11546	35754	2086	0.17644579065022728	t
462	10	Test Strategy	7984381	11546	5128	2015	0.174128863223573987	t
463	10	SQL	7984381	11546	74090	2016	0.165565977862023955	t
464	10	Requirements Analysis	7984381	11546	57261	1927	0.159957310170830896	t
465	10	Test Cases	7984381	11546	4551	1811	0.156507190475670882	t
466	10	Agile Testing	7984381	11546	4326	1673	0.144565911293851934	t
467	10	Defect Tracking	7984381	11546	3967	1559	0.134723091358048858	t
468	10	HP Quality Center	7984381	11546	3609	1384	0.119589280050265895	t
469	10	ISEB	7984381	11546	3756	1323	0.114279976496985403	t
470	10	SDLC	7984381	11546	25307	1315	0.110883038882251164	t
471	10	Test Execution	7984381	11546	2956	1282	0.110824161416616274	t
472	10	Integration Testing	7984381	11546	3249	1270	0.109746585540362152	t
473	10	JIRA	7984381	11546	6492	1246	0.107258177173362307	t
474	10	Scrum	7984381	11546	21173	1256	0.106284154618582496	t
475	10	QTP	7984381	11546	3040	1198	0.103527843026798586	t
476	10	System Integration Testing	7984381	11546	3113	1165	0.100656415194826016	t
477	10	Software Quality Assurance	7984381	11546	3281	985	0.0850229523274370902	t
478	10	Waterfall	7984381	11546	4775	987	0.0850090370484795355	t
479	10	Integration	7984381	11546	67927	1056	0.0830728906592452104	t
480	10	Functional Testing	7984381	11546	2496	902	0.0779223645514407481	t
481	10	Java	7984381	11546	56026	955	0.0758052980484527072	t
482	10	V-Model	7984381	11546	2051	871	0.0752893783499411912	t
483	10	Performance Testing	7984381	11546	2600	867	0.0748735775019636757	t
484	10	Selenium	7984381	11546	2612	861	0.0743516593472950682	t
485	10	XML	7984381	11546	32063	789	0.0644127846599188147	t
486	10	Unix	7984381	11546	24442	770	0.0637206807996886504	t
487	10	Business Analysis	7984381	11546	148418	935	0.062482238212280973	t
488	10	Microsoft SQL Server	7984381	11546	44532	748	0.0592926933214808632	t
489	10	Web Testing	7984381	11546	1587	674	0.0582606810266045883	t
490	10	Requirements Gathering	7984381	11546	25858	601	0.0488847769903899068	t
491	10	Engineering	7984381	11546	143574	768	0.0486049715473471158	t
492	10	Software Development	7984381	11546	47537	561	0.0426962486265333035	t
493	10	Oracle	7984381	11546	25936	526	0.042369830721783304	t
494	10	Software Project Management	7984381	11546	28572	503	0.0400442913829831201	t
495	10	Linux	7984381	11546	34632	505	0.0394576814477332893	t
496	10	HTML	7984381	11546	75907	558	0.038877709340904211	t
497	10	ISTQB	7984381	11546	1116	449	0.0388042674798049353	t
498	10	Test Estimation	7984381	11546	958	432	0.0373495811475798647	t
499	10	HP QTP	7984381	11546	1018	432	0.0373420555936207071	t
500	10	Stakeholder Management	7984381	11546	146503	633	0.0365283056010132084	t
501	11	CSS	7984381	3401	39569	1859	0.541878956369017284	t
502	11	HTML 5	7984381	3401	22908	1839	0.538083415306070623	t
503	11	Javascript	7984381	3401	44076	1781	0.518370034467325325	t
504	11	jQuery	7984381	3401	21454	1639	0.479434305406590766	t
505	11	PHP	7984381	3401	28191	1476	0.430642669655426857	t
506	11	HTML	7984381	3401	75907	1492	0.429370458705148117	t
507	11	Web Development	7984381	3401	32187	1358	0.395431516370482461	t
508	11	MySQL	7984381	3401	28574	1191	0.346760087979503528	t
509	11	Web Design	7984381	3401	51816	844	0.241775620862328511	t
510	11	Wordpress	7984381	3401	22554	791	0.229851795232108774	t
511	11	Photoshop	7984381	3401	197298	838	0.221782093602046371	t
512	11	AJAX	7984381	3401	9966	673	0.196718582250234975	t
513	11	XHTML	7984381	3401	7108	648	0.189722772006293255	t
514	11	SQL	7984381	3401	74090	653	0.182800850679355781	t
515	11	CSS 3	7984381	3401	6306	623	0.182469349288695404	t
516	11	XML	7984381	3401	32063	615	0.176888799666340524	t
517	11	CMS	7984381	3401	14922	522	0.151679979633790457	t
518	11	Java	7984381	3401	56026	538	0.151236238370191761	t
519	11	SEO	7984381	3401	45328	533	0.151105892932897223	t
520	11	Git	7984381	3401	9310	480	0.140028579886345178	t
521	11	Front End	7984381	3401	3127	445	0.130507820493767884	t
522	11	Web Applications	7984381	3401	12091	426	0.123795677317500394	t
523	11	User Experience	7984381	3401	18200	403	0.116264633772793044	t
524	11	C#	7984381	3401	29764	403	0.114815688906373142	t
525	11	Linux	7984381	3401	34632	371	0.104792731863492666	t
526	11	User Interface Design	7984381	3401	13071	358	0.103670245746103465	t
527	11	MVC	7984381	3401	4887	346	0.101165806142504283	t
528	11	JSON	7984381	3401	5118	344	0.10054854939818772	t
529	11	Microsoft SQL Server	7984381	3401	44532	351	0.097669153391606367	t
530	11	e-Commerce	7984381	3401	54314	355	0.0976201152362057845	t
531	11	Apache	7984381	3401	7106	329	0.0958871102034501988	t
532	11	SASS	7984381	3401	1527	299	0.0877614532078390408	t
533	11	Dreamweaver	7984381	3401	13855	287	0.0826869031666745274	t
534	11	Software Development	7984381	3401	47537	297	0.0814081840941142248	t
535	11	Illustrator	7984381	3401	81326	311	0.0812926840075068879	t
536	11	ASP.NET	7984381	3401	14310	282	0.0811591102981121804	t
537	11	Graphic Design	7984381	3401	84470	301	0.0779571827712830651	t
538	11	Agile Methodologies	7984381	3401	46119	280	0.0765851966018924885	t
539	11	Angularjs	7984381	3401	2792	258	0.0755425362965401748	t
540	11	OOP	7984381	3401	6685	245	0.0712307175408033039	t
541	11	Flash	7984381	3401	9620	231	0.0667447777039927165	t
542	11	Subversion	7984381	3401	8392	224	0.0648395482635738263	t
543	11	Databases	7984381	3401	42473	229	0.0620400530046130022	t
544	11	Web Services	7984381	3401	17244	214	0.0607888466384253409	t
545	11	.NET	7984381	3401	18072	214	0.0606850999807467054	t
546	11	Lamp	7984381	3401	2154	203	0.0594438707680553791	t
547	11	Node.Js	7984381	3401	2507	202	0.0591054841456571528	t
548	11	Programming	7984381	3401	26495	208	0.0578647770136716741	t
549	11	Adobe Creative Suite	7984381	3401	52699	218	0.0575230356055084699	t
550	11	Drupal	7984381	3401	2830	194	0.0567117612037349797	t
551	12	Web Design	7984381	677	51816	246	0.3569083913000205	t
552	12	CSS	7984381	677	39569	197	0.286058114707576583	t
553	12	HTML	7984381	677	75907	177	0.251961990666568325	t
554	12	Web Development	7984381	677	32187	159	0.230848003261521106	t
555	12	Photoshop	7984381	677	197298	157	0.207212540800855077	t
556	12	HTML 5	7984381	677	22908	138	0.200988413028061946	t
557	12	Wordpress	7984381	677	22554	134	0.195123832830933042	t
558	12	Javascript	7984381	677	44076	129	0.18504194095810389	t
559	12	PHP	7984381	677	28191	125	0.181122698413773736	t
560	12	Graphic Design	7984381	677	84470	120	0.16668731347557042	t
561	12	SEO	7984381	677	45328	108	0.153863288795495046	t
562	12	jQuery	7984381	677	21454	105	0.152421939732002187	t
563	12	Dreamweaver	7984381	677	13855	85	0.123829150984987743	t
564	12	User Interface Design	7984381	677	13071	70	0.101768899074593674	t
565	12	Illustrator	7984381	677	81326	75	0.100605759819014262	t
566	12	User Experience	7984381	677	18200	69	0.0996492353076836312	t
567	12	MySQL	7984381	677	28574	69	0.0983498384362565398	t
568	12	XHTML	7984381	677	7108	62	0.0906979544658910314	t
569	12	Flash	7984381	677	9620	56	0.0815199327647848498	t
570	12	CMS	7984381	677	14922	53	0.0764241395986549193	t
571	12	Website Development	7984381	677	12488	52	0.0752517804913364757	t
572	12	Adobe Creative Suite	7984381	677	52699	51	0.0687379157370150845	t
573	12	CSS 3	7984381	677	6229	44	0.0642179114054738653	t
574	12	Social Media	7984381	677	321965	68	0.0601238761392406881	t
575	12	e-Commerce	7984381	677	54314	44	0.0581950177711407224	t
576	12	Logo Design	7984381	677	30154	36	0.0494033410310865256	t
577	12	Indesign	7984381	677	60114	32	0.039741776376618021	t
578	12	Online Marketing	7984381	677	74576	33	0.0394075666031262553	t
579	12	Interaction Design	7984381	677	8979	26	0.0372833174248322005	t
580	12	Google Analytics	7984381	677	18331	26	0.0361119313113189705	t
581	12	Email Marketing	7984381	677	66606	30	0.0359741597178504305	t
582	12	Front End	7984381	677	3127	23	0.0335846201430186272	t
583	12	SQL	7984381	677	74090	29	0.033559520085101685	t
584	12	Joomla	7984381	677	2889	22	0.0321372007378735031	t
585	12	Graphics	7984381	677	24803	23	0.0308695896258551657	t
586	12	Adobe Fireworks	7984381	677	2256	20	0.0292620269853058473	t
587	12	Social Media Marketing	7984381	677	132195	31	0.0292360301597574326	t
588	12	User Interface	7984381	677	3682	20	0.0290834131489211313	t
589	12	XML	7984381	677	32063	22	0.0284830071455258911	t
590	12	Flash Animation	7984381	677	3852	19	0.0275848896447262459	t
591	12	Java	7984381	677	56026	23	0.0269587482419561646	t
592	12	Web Analytics	7984381	677	16510	19	0.0259994100227362544	t
593	12	Responsive Web Design	7984381	677	1281	17	0.0249524603626449723	t
594	12	Web Services	7984381	677	17244	17	0.0229530124873229407	t
595	12	Information Architecture	7984381	677	6781	16	0.0227863269370401772	t
596	12	Phpmyadmin	7984381	677	1828	15	0.0219294855392961306	t
597	12	After Effects	7984381	677	14110	16	0.0218683319813153636	t
598	12	Access	7984381	677	21525	16	0.0209395650831437907	t
599	12	AJAX	7984381	677	9966	15	0.0209101591714849003	t
600	12	ASP.NET	7984381	677	14310	15	0.020366050822778585	t
601	13	SQL	7984381	2242	74090	969	0.423042812696985737	t
602	13	Oracle	7984381	2242	25936	775	0.342521343201376116	t
603	13	Databases	7984381	2242	42473	692	0.303418677149047578	t
604	13	Microsoft SQL Server	7984381	2242	44532	681	0.298253014533987004	t
605	13	Data Warehousing	7984381	2242	13115	667	0.295942748413735246	t
606	13	Business Intelligence	7984381	2242	44693	656	0.287078954257742991	t
607	13	ETL	7984381	2242	6932	491	0.218193965496239234	t
608	13	Data Migration	7984381	2242	16676	482	0.212957839586258357	t
609	13	Unix	7984381	2242	24442	429	0.188338670098350619	t
610	13	Database Design	7984381	2242	10486	386	0.170902382407883802	t
611	13	Performance Tuning	7984381	2242	3368	374	0.166440256013781679	t
612	13	SSIS	7984381	2242	5366	362	0.160836079850814384	t
613	13	Data Modeling	7984381	2242	7329	360	0.159697844575088344	t
614	13	Requirements Analysis	7984381	2242	57261	370	0.157903934562714843	t
615	13	Business Analysis	7984381	2242	148418	392	0.156299236128001395	t
616	13	SSRS	7984381	2242	5880	312	0.138463905595428011	t
617	13	Database Administration	7984381	2242	13528	314	0.138398077649503848	t
618	13	T-SQL	7984381	2242	7737	285	0.126185059724051141	t
619	13	Business Objects	7984381	2242	7585	277	0.122634857360725436	t
620	13	Oracle RAC	7984381	2242	986	258	0.11498462153262072	t
621	13	Unix Shell Scripting	7984381	2242	5473	247	0.109514779799656986	t
622	13	ITIL	7984381	2242	61484	249	0.103390049597082034	t
623	13	SQL Tuning	7984381	2242	1282	231	0.102901337276996213	t
624	13	Solaris	7984381	2242	5818	228	0.100994601716725613	t
625	13	RMAN	7984381	2242	610	221	0.098523969139490325	t
626	13	PL/SQL	7984381	2242	5086	218	0.0966247503613754666	t
627	13	Shell Scripting	7984381	2242	6227	206	0.0911279389035329485	t
628	13	Agile Methodologies	7984381	2242	46119	205	0.0856841253978079392	t
629	13	Linux	7984381	2242	34632	201	0.0853385909024681338	t
630	13	Disaster Recovery	7984381	2242	24109	196	0.0844261311640607248	t
631	13	Software Development	7984381	2242	47537	199	0.0828295451209365569	t
632	13	Integration	7984381	2242	67927	196	0.0789366251557088311	t
633	13	Oracle E-Business Suite	7984381	2242	4016	172	0.0762356415939613452	t
634	13	Solution Architecture	7984381	2242	29742	175	0.0743511627942715636	t
635	13	XML	7984381	2242	32063	174	0.0736142329947811758	t
636	13	Oracle Applications	7984381	2242	4030	157	0.069541553531649411	t
637	13	SDLC	7984381	2242	25307	159	0.0677682885190442064	t
638	13	Data Guard	7984381	2242	363	136	0.0606316863960031233	t
639	13	Analysis Services	7984381	2242	1285	132	0.0587315560711494447	t
640	13	Sap Bi	7984381	2242	1836	129	0.0573240601257239205	t
641	13	High Availability	7984381	2242	4175	126	0.0556925640720567355	t
642	13	Requirements Gathering	7984381	2242	25858	132	0.0556530579392577329	t
643	13	C#	7984381	2242	29764	132	0.0551637154209177194	t
644	13	OLAP	7984381	2242	1495	124	0.0551360024554839595	t
645	13	Sap Bw	7984381	2242	4086	117	0.0516883134777024189	t
646	13	Oracle Enterprise Manager	7984381	2242	596	116	0.0516793840299974508	t
647	13	Java	7984381	2242	56026	129	0.0505351530420462269	t
648	13	Windows Server	7984381	2242	35131	120	0.0491374719399044618	t
649	13	Oracle Sql	7984381	2242	3170	109	0.0482338248071600417	t
650	13	Testing	7984381	2242	52574	122	0.0478445293070523664	t
651	14	Digital Marketing	7984381	2223	103490	499	0.21156878386005093	t
652	14	SEO	7984381	2223	45328	460	0.201306539032383686	t
653	14	Online Marketing	7984381	2223	74576	413	0.176493878790761949	t
654	14	Social Media Marketing	7984381	2223	132195	420	0.172425179630690512	t
655	14	Online Advertising	7984381	2223	74910	404	0.172402324959104181	t
656	14	Social Media	7984381	2223	321965	470	0.171149298784793374	t
657	14	Email Marketing	7984381	2223	66606	332	0.141044961048444856	t
658	14	Marketing	7984381	2223	249999	349	0.125719048425519814	t
659	14	Project Management	7984381	2223	479558	400	0.119908393192793616	t
660	14	e-Commerce	7984381	2223	54314	279	0.11873660025819141	t
661	14	Google Analytics	7984381	2223	18331	249	0.10974549403111282	t
662	14	Digital Strategy	7984381	2223	39900	254	0.109293181730339958	t
663	14	Web Analytics	7984381	2223	16510	232	0.102324174639838228	t
664	14	Marketing Strategy	7984381	2223	206871	275	0.0978244788243748942	t
665	14	PPC	7984381	2223	16464	209	0.091980677298707833	t
666	14	Digital Media	7984381	2223	63648	222	0.0919190757305238387	t
667	14	Advertising	7984381	2223	110578	210	0.0806400992683027201	t
668	14	Web Design	7984381	2223	51816	188	0.078102475269942212	t
669	14	SEM	7984381	2223	10414	156	0.0688903224662417296	t
670	14	Marketing Communications	7984381	2223	160246	196	0.0681181721278370511	t
671	14	Social Networking	7984381	2223	104923	176	0.0660496479267939085	t
672	14	Google Adwords	7984381	2223	9836	149	0.0658129591204093672	t
673	14	Wordpress	7984381	2223	22554	152	0.0655695591588867643	t
674	14	CMS	7984381	2223	14922	145	0.063375916731633064	t
675	14	Web Marketing	7984381	2223	5119	135	0.0601043523877832983	t
676	14	User Experience	7984381	2223	18200	132	0.0571156689954058841	t
677	14	Blogging	7984381	2223	58168	139	0.0552582766022513619	t
678	14	Web Development	7984381	2223	32187	125	0.0522136111246092258	t
679	14	HTML	7984381	2223	75907	125	0.0467363955646065282	t
680	14	Affiliate Marketing	7984381	2223	7665	106	0.0467363238234091358	t
681	14	Mobile Marketing	7984381	2223	11679	107	0.046683420128691186	t
682	14	Web Project Management	7984381	2223	4191	103	0.0458216409707353986	t
683	14	Integrated Marketing	7984381	2223	34345	111	0.0456437084867905851	t
684	14	Management	7984381	2223	738887	304	0.0442228984183428153	t
685	14	Copywriting	7984381	2223	75820	116	0.0426975843621976575	t
686	14	Lead Generation	7984381	2223	33930	103	0.0420959567635322829	t
687	14	Photoshop	7984381	2223	197298	146	0.0409779279108126032	t
688	14	CRM	7984381	2223	102251	119	0.0407362279282524123	t
689	14	Facebook	7984381	2223	28976	95	0.0391168482568076542	t
690	14	Content Management	7984381	2223	15567	88	0.0376469449487244756	t
691	14	Website Development	7984381	2223	12488	84	0.0362328088968059403	t
692	14	Entrepreneurship	7984381	2223	63865	97	0.0356459107860077756	t
693	14	CSS	7984381	2223	39569	90	0.0355399243535364368	t
694	14	Content Strategy	7984381	2223	14878	80	0.0341335197822694864	t
695	14	Web Content Management	7984381	2223	7454	77	0.0337136905769427411	t
696	14	Account Management	7984381	2223	240929	142	0.033711990879760359	t
697	14	Strategy	7984381	2223	223349	137	0.0336645636364149362	t
698	14	PRINCE2	7984381	2223	53617	87	0.0324300957771123041	t
699	14	Direct Marketing	7984381	2223	43343	84	0.0323673128743017444	t
700	14	Link Building	7984381	2223	1636	72	0.0321927269791428064	t
701	15	Photoshop	7984381	1010	197298	544	0.513968382677958857	t
702	15	Maya	7984381	1010	7154	391	0.386281576993473097	t
703	15	3D	7984381	1010	7984	374	0.369343798292329328	t
704	15	3D Studio Max	7984381	1010	11760	365	0.359958796705286688	t
705	15	Texturing	7984381	1010	3298	344	0.340224040274924422	t
706	15	3D Modeling	7984381	1010	8777	338	0.333596393089714838	t
707	15	Animation	7984381	1010	13442	338	0.3330120534667661	t
708	15	After Effects	7984381	1010	14110	290	0.28539761456707452	t
709	15	ZBrush	7984381	1010	2489	284	0.28091191969749707	t
710	15	Computer Animation	7984381	1010	4848	261	0.257841272270017796	t
711	15	Illustrator	7984381	1010	81326	245	0.232418021419674464	t
712	15	Character Animation	7984381	1010	5080	219	0.216222792512978379	t
713	15	Video Games	7984381	1010	8386	177	0.174219262380602508	t
714	15	Modeling	7984381	1010	10239	165	0.162104463672980481	t
715	15	UV Mapping	7984381	1010	1191	160	0.158286698143373816	t
716	15	Game Development	7984381	1010	6187	146	0.143797757554390532	t
717	15	Mudbox	7984381	1010	1241	143	0.141446622530311511	t
718	15	Composition	7984381	1010	26177	141	0.136342681420028117	t
719	15	Visual Effects	7984381	1010	5126	133	0.131057743292741002	t
720	15	Premiere	7984381	1010	7413	122	0.119878805855097775	t
721	15	Graphic Design	7984381	1010	84470	128	0.116167963196856502	t
722	15	VRay	7984381	1010	3675	117	0.115395907764321168	t
723	15	Storyboarding	7984381	1010	6232	117	0.115075616999931046	t
724	15	Rendering	7984381	1010	7796	107	0.104977467079587508	t
725	15	Mental Ray	7984381	1010	1163	106	0.104818094839117637	t
726	15	Nuke	7984381	1010	2420	101	0.0997095212035116613	t
727	15	Traditional Animation	7984381	1010	2796	100	0.0986721990343712857	t
728	15	Lighting	7984381	1010	9359	100	0.097850115230424306	t
729	15	3D Visualization	7984381	1010	7327	94	0.0921632986792915027	t
730	15	Unity3D	7984381	1010	2821	93	0.0917374976332456238	t
731	15	Game Design	7984381	1010	4952	93	0.0914705677861922944	t
732	15	Motion Graphics	7984381	1010	6992	93	0.0912150366327484641	t
733	15	Adobe Creative Suite	7984381	1010	52699	98	0.0904408822828956793	t
734	15	3D Rendering	7984381	1010	3813	91	0.0896327908063244416	t
735	15	Low Poly Modeling	7984381	1010	604	88	0.0870640785207101586	t
736	15	Digital Sculpting	7984381	1010	607	88	0.0870637027396021501	t
737	15	Art	7984381	1010	57918	95	0.0868164756045242403	t
738	15	Drawing	7984381	1010	36069	91	0.0855923923330479258	t
739	15	Concept Design	7984381	1010	15819	88	0.0851582420012749475	t
740	15	Unreal Engine 3	7984381	1010	1348	82	0.0810295391843028207	t
741	15	Character Rigging	7984381	1010	804	73	0.0721856623927882302	t
742	15	Rigging	7984381	1010	4829	69	0.0677205923251327224	t
743	15	Photography	7984381	1010	95563	79	0.0662574606765750779	t
744	15	Environment Art	7984381	1010	648	66	0.0652736331185122531	t
745	15	Computer Games	7984381	1010	3815	66	0.0648769335288276461	t
746	15	Film	7984381	1010	52838	72	0.0646776400645296262	t
747	15	Texture Painting	7984381	1010	604	65	0.0642889203044926805	t
748	15	3D Animation	7984381	1010	916	63	0.0622693905287194441	t
749	15	Flash	7984381	1010	9620	62	0.0601889000037554509	t
750	15	Computer Graphics	7984381	1010	2698	58	0.0570950551992124786	t
751	16	Network Security	7984381	1422	14836	399	0.278782240016906324	t
752	16	Security	7984381	1422	58305	375	0.256456372474298644	t
753	16	Firewalls	7984381	1422	10647	300	0.209674328203469901	t
754	16	Cisco Technologies	7984381	1422	20354	290	0.201424761572847333	t
755	16	Networking	7984381	1422	56939	282	0.191214993272142975	t
756	16	Information Security	7984381	1422	9031	211	0.147277706298954258	t
757	16	IP	7984381	1422	24395	198	0.136209424746457669	t
758	16	VPN	7984381	1422	9591	192	0.133843714073508341	t
759	16	Data Center	7984381	1422	30537	188	0.128406434379097906	t
760	16	Computer Security	7984381	1422	6623	180	0.125775184269455276	t
761	16	ITIL	7984381	1422	61484	172	0.113276039310296325	t
762	16	Switches	7984381	1422	8402	158	0.110078411331493042	t
763	16	CCNA	7984381	1422	6012	152	0.106157638181083924	t
764	16	Network Administration	7984381	1422	14683	145	0.100147928432352956	t
765	16	Network Design	7984381	1422	10581	139	0.096441612101777166	t
766	16	Checkpoint	7984381	1422	1940	133	0.0933038819307945994	t
767	16	Windows Server	7984381	1422	35131	134	0.0898495105902932661	t
768	16	Routing	7984381	1422	4902	126	0.0880093205374541526	t
769	16	Juniper	7984381	1422	2791	125	0.087570398676775324	t
770	16	Linux	7984381	1422	34632	129	0.0863952180040462314	t
771	16	Virtualization	7984381	1422	25670	126	0.0854077789286346589	t
772	16	WAN	7984381	1422	9599	121	0.0839041414816661807	t
773	16	Troubleshooting	7984381	1422	38514	124	0.0823921314179803244	t
774	16	Information Security Management	7984381	1422	4949	118	0.082376551817982771	t
775	16	Active Directory	7984381	1422	34347	114	0.0758805168424791787	t
776	16	DNS	7984381	1422	10524	100	0.0690177065672367002	t
777	16	Routers	7984381	1422	5089	99	0.0689951716628230821	t
778	16	VMware	7984381	1422	24043	101	0.0680275843854746265	t
779	16	OSPF	7984381	1422	2674	97	0.0678909707724006661	t
780	16	Network Architecture	7984381	1422	4856	97	0.0676176385405803521	t
781	16	Cisco IOS	7984381	1422	3245	95	0.0664127231156100423	t
782	16	Cisco Routers	7984381	1422	2914	91	0.0636407458485326039	t
783	16	Cloud Computing	7984381	1422	45728	98	0.0632010926480112978	t
784	16	Disaster Recovery	7984381	1422	24109	94	0.0630957957434410549	t
785	16	BGP	7984381	1422	2450	86	0.0601820689230950501	t
786	16	Penetration Testing	7984381	1422	2548	86	0.0601697927733615967	t
787	16	IT Service Management	7984381	1422	48722	90	0.0571991625686982946	t
788	16	ISO 27001	7984381	1422	4196	82	0.0571499124417688548	t
789	16	Telecommunications	7984381	1422	71758	94	0.0571269563694695726	t
790	16	CISSP	7984381	1422	2251	80	0.0559868361393594804	t
791	16	Servers	7984381	1422	22249	83	0.0555918304345836486	t
792	16	Windows	7984381	1422	91564	94	0.0546459214549723307	t
793	16	Vulnerability Assessment	7984381	1422	2716	78	0.0545218667669744306	t
794	16	Asa	7984381	1422	919	76	0.0533402509731308663	t
795	16	CCNP	7984381	1422	1946	74	0.0518048816400294848	t
796	16	TCP/IP	7984381	1422	5883	68	0.0470915452308086832	t
797	16	Cyber Security	7984381	1422	850	66	0.0463152929118370374	t
798	16	Ids	7984381	1422	948	65	0.0455996566148194962	t
799	16	Business Continuity	7984381	1422	11669	66	0.0449600310346308513	t
800	16	MPLS	7984381	1422	7734	65	0.0447495958791950255	t
801	17	Training	7984381	111	286184	39	0.315512758718587194	t
802	17	Training Delivery	7984381	111	66235	25	0.216932669988491006	t
803	17	Microsoft Office	7984381	111	601080	32	0.213009270920388655	t
804	17	Software Documentation	7984381	111	20913	19	0.168554275700451867	t
805	17	Team Leadership	7984381	111	284785	21	0.153523561649038381	t
806	17	Project Management	7984381	111	479558	23	0.147147239295300408	t
807	17	Change Management	7984381	111	341196	20	0.137449160312365093	t
808	17	e-Learning	7984381	111	36661	15	0.130545360490740614	t
809	17	Windows 7	7984381	111	22076	13	0.114353808762063996	t
810	17	Coaching	7984381	111	219497	15	0.10764583429736288	t
811	17	Business Analysis	7984381	111	148418	13	0.098529945090119031	t
812	17	Sharepoint	7984381	111	21286	11	0.0964344848012359257	t
813	17	Stakeholder Management	7984381	111	146503	12	0.0897606574332186075	t
814	17	ITIL	7984381	111	61484	10	0.0823907011666193123	t
815	17	Hands On Training	7984381	111	2111	9	0.0808178134310642421	t
816	18	Data Analysis	7984381	199	113349	87	0.423000130777423877	t
817	18	Machine Learning	7984381	199	5786	75	0.376169132804772932	t
818	18	Python	7984381	199	19693	70	0.349301059414199089	t
819	18	R	7984381	199	14529	69	0.344922587381880752	t
820	18	SQL	7984381	199	74090	70	0.342487963219748615	t
821	18	Statistics	7984381	199	36968	61	0.301910148449061111	t
822	18	Matlab	7984381	199	43522	59	0.291038773626207725	t
823	18	Data Mining	7984381	199	5969	54	0.270615944094052929	t
824	18	Java	7984381	199	56026	53	0.259321171807055995	t
825	18	Research	7984381	199	383551	54	0.223324687456867066	t
826	18	Data Science	7984381	199	616	35	0.175806628102652157	t
827	18	Algorithms	7984381	199	7545	35	0.174938787164156534	t
828	18	Programming	7984381	199	26495	33	0.162514842522629127	t
829	18	Hadoop	7984381	199	1456	32	0.160625667452729715	t
830	18	Latex	7984381	199	12672	32	0.15922088985622701	t
831	18	C++	7984381	199	41117	32	0.155658220568377609	t
832	18	Business Intelligence	7984381	199	44693	31	0.150185084110824457	t
833	18	Analysis	7984381	199	128547	33	0.149733069762439025	t
834	18	Analytics	7984381	199	20051	26	0.128145182222353188	t
835	18	Statistical Modeling	7984381	199	4097	25	0.125118132289380735	t
836	18	Computer Science	7984381	199	7312	25	0.124715461107786918	t
837	18	Mathematical Modeling	7984381	199	8955	25	0.124509679225560291	t
838	18	Artificial Intelligence	7984381	199	3795	24	0.120130706202658297	t
839	18	Big Data	7984381	199	2763	23	0.11523471089744862	t
840	18	SAS	7984381	199	5139	23	0.114937122490771509	t
841	18	Software Development	7984381	199	47537	23	0.109626872799569577	t
842	18	Javascript	7984381	199	44076	22	0.105035104026270115	t
843	18	Data Modeling	7984381	199	7329	21	0.104612328394660045	t
844	18	Predictive Analytics	7984381	199	1089	20	0.100368622829338561	t
845	18	Databases	7984381	199	42473	21	0.100210625126873815	t
846	18	C	7984381	199	30049	20	0.0967414510038466097	t
847	18	SPSS	7984381	199	27885	19	0.0919872360338046258	t
848	18	Business Analysis	7984381	199	148418	22	0.091966514156951007	t
849	18	Data Warehousing	7984381	199	13115	18	0.0888118928880772818	t
850	18	VBA	7984381	199	13934	18	0.0887093150660787227	t
851	18	MySQL	7984381	199	28574	18	0.0868756895299874904	t
852	18	Linux	7984381	199	34632	18	0.0861169392910776099	t
853	18	Predictive Modeling	7984381	199	1007	17	0.0853031405089431649	t
854	18	Software Engineering	7984381	199	15605	17	0.0834747753739800563	t
855	18	C#	7984381	199	29764	16	0.0766761430797839039	t
856	18	HTML	7984381	199	75907	17	0.0759220918304435999	t
857	18	Science	7984381	199	39873	16	0.0754100146273012362	t
858	18	Microsoft SQL Server	7984381	199	44532	16	0.0748264858450164577	t
859	18	ETL	7984381	199	6932	15	0.0745105464553657976	t
860	18	Pattern Recognition	7984381	199	1286	14	0.0701924437883750391	t
861	18	Mathematics	7984381	199	13271	14	0.0686913507521692002	t
862	18	Tableau	7984381	199	1161	13	0.0651828488683269119	t
863	18	Mapreduce	7984381	199	370	12	0.0602566688804534248	t
864	18	Natural Language Processing	7984381	199	762	12	0.0602075718032575383	t
865	18	Mongodb	7984381	199	2410	12	0.0600011636828013672	t
866	19	Game Development	7984381	302	6187	120	0.396591106106828906	t
867	19	C++	7984381	302	41117	99	0.32267709532055	t
868	19	Video Games	7984381	302	8386	93	0.306908327740380127	t
869	19	C#	7984381	302	29764	89	0.290985214914407708	t
870	19	Unity3D	7984381	302	2821	86	0.284425655189816107	t
871	19	Game Design	7984381	302	4952	84	0.2775359819583465	t
872	19	Java	7984381	302	56026	72	0.231402398838060436	t
873	19	Programming	7984381	302	26495	67	0.218544217147899816	t
874	19	Game Programming	7984381	302	1368	52	0.172020602435196179	t
875	19	Computer Games	7984381	302	3815	49	0.161779966909626149	t
876	19	Javascript	7984381	302	44076	50	0.160048689912256681	t
877	19	Photoshop	7984381	302	197298	51	0.144169131065471606	t
878	19	Visual Studio	7984381	302	12585	41	0.134190462665372851	t
879	19	OpenGL	7984381	302	2029	38	0.125578443289517783	t
880	19	Gameplay	7984381	302	1948	37	0.122277204952307039	t
881	19	HTML	7984381	302	75907	37	0.113013894807204515	t
882	19	Level Design	7984381	302	1551	31	0.102458627744752437	t
883	19	Unreal Engine 3	7984381	302	1348	30	0.0991726698174675014	t
884	19	Mobile Games	7984381	302	2197	30	0.0990663331942953085	t
885	19	PHP	7984381	302	28191	30	0.0958106038860056519	t
886	19	3D Studio Max	7984381	302	11760	29	0.0945571909773759711	t
887	19	CSS	7984381	302	39569	30	0.0943855177865319389	t
888	19	Actionscript	7984381	302	3394	28	0.0922936427732413134	t
889	19	SQL	7984381	302	74090	26	0.0768162539142084322	t
890	19	Xbox 360	7984381	302	2474	23	0.0758519544569563609	t
891	19	Flash	7984381	302	9620	23	0.0749569232329416746	t
892	19	Microsoft Office	7984381	302	601080	45	0.0737274325185615503	t
893	19	Directx	7984381	302	869	22	0.0727415959945564849	t
894	19	XNA	7984381	302	639	21	0.0694590197973370821	t
895	19	MySQL	7984381	302	28574	22	0.0692715651995205045	t
896	19	PS3	7984381	302	2291	21	0.0692521080170303005	t
897	19	XML	7984381	302	32063	22	0.0688345705254948675	t
898	19	Maya	7984381	302	7154	21	0.0686430208574468348	t
899	19	Software Development	7984381	302	47537	22	0.0668964634501515443	t
900	19	Android	7984381	302	6764	20	0.0653804845420973557	t
901	19	HTML 5	7984381	302	22908	20	0.0633584604614238073	t
902	19	Game Testing	7984381	302	434	18	0.0595505453137607568	t
903	19	LUA	7984381	302	796	18	0.0595052050810300978	t
904	19	Python	7984381	302	19693	18	0.0571383697829324702	t
905	19	Perforce	7984381	302	1669	17	0.0560844789481700426	t
906	19	iOS Development	7984381	302	2920	17	0.0559277921217997132	t
907	19	Artificial Intelligence	7984381	302	3795	17	0.0558181990178236581	t
908	19	Web Development	7984381	302	32187	18	0.0555735055074161599	t
909	19	Scrum	7984381	302	21173	17	0.0536416173482284556	t
910	19	Gameplay Programming	7984381	302	451	16	0.052925649021497316	t
911	19	Git	7984381	302	9310	16	0.0518160658122129442	t
912	19	C	7984381	302	30049	16	0.0492185213740880187	t
913	19	OOP	7984381	302	6685	15	0.0488334615967337057	t
914	19	Subversion	7984381	302	8392	15	0.04861966110703414	t
915	19	3D Modeling	7984381	302	8777	15	0.0485714401412846788	t
916	20	Photoshop	7984381	215	197298	114	0.505535676837217229	t
917	20	Video Games	7984381	215	8386	101	0.468729763034649083	t
918	20	Game Design	7984381	215	4952	99	0.459857288235414385	t
919	20	Game Development	7984381	215	6187	89	0.413189726696797155	t
920	20	Maya	7984381	215	7154	77	0.357253155517360033	t
921	20	3D Studio Max	7984381	215	11760	74	0.34272239958845524	t
922	20	Animation	7984381	215	13442	63	0.291347564201329234	t
923	20	Computer Games	7984381	215	3815	59	0.273948173550406626	t
924	20	Illustrator	7984381	215	81326	60	0.268891371852389982	t
925	20	Texturing	7984381	215	3298	55	0.255407774558725598	t
926	20	3D Modeling	7984381	215	8777	55	0.254721541331610846	t
927	20	Level Design	7984381	215	1551	53	0.246324006557420649	t
928	20	3D	7984381	215	7984	49	0.22691313468228505	t
929	20	Unity3D	7984381	215	2821	46	0.213605925458195678	t
930	20	Concept Design	7984381	215	15819	44	0.202675377217101133	t
931	20	Character Animation	7984381	215	5080	41	0.190066550266125872	t
932	20	ZBrush	7984381	215	2489	40	0.185739779528399013	t
933	20	Gameplay	7984381	215	1948	39	0.181156250602027336	t
934	20	Mobile Games	7984381	215	2197	39	0.181125063875699238	t
935	20	Traditional Animation	7984381	215	2796	34	0.157793600192483285	t
936	20	Flash	7984381	215	9620	34	0.156938908544038108	t
937	20	Drawing	7984381	215	36069	34	0.15362622691893163	t
938	20	Storyboarding	7984381	215	6232	33	0.152711960380140538	t
939	20	UV Mapping	7984381	215	1191	32	0.148692046989818555	t
940	20	Character Designs	7984381	215	1918	32	0.148600991768772284	t
941	20	Xbox 360	7984381	215	2474	32	0.148531353938095939	t
942	20	Unreal Engine 3	7984381	215	1348	31	0.144021095031410695	t
943	20	Graphic Design	7984381	215	84470	33	0.142912815422483103	t
944	20	Art	7984381	215	57918	32	0.141587109542375689	t
945	20	Game Mechanics	7984381	215	984	30	0.139415397227287685	t
946	20	After Effects	7984381	215	14110	28	0.128468817255389944	t
947	20	Flash Animation	7984381	215	3852	27	0.125102322143194944	t
948	20	Game Art	7984381	215	463	25	0.116224211188599685	t
949	20	Conceptual Art	7984381	215	1541	24	0.111437905917146973	t
950	20	PS3	7984381	215	2291	24	0.11134396999447202	t
951	20	Casual Games	7984381	215	1235	23	0.106824943735003786	t
952	20	Digital Painting	7984381	215	1721	23	0.106764073257110417	t
953	20	User Interface Design	7984381	215	13071	22	0.100691221588701529	t
954	20	Social Games	7984381	215	1449	21	0.0974955646078780463	t
955	20	Computer Animation	7984381	215	4848	21	0.0970698470063151575	t
956	20	Unreal Editor	7984381	215	664	20	0.0929425961683499197	t
957	20	Console	7984381	215	1036	20	0.092896003950703146	t
958	20	Digital Illustration	7984381	215	7420	20	0.0920964213768939305	t
959	20	Environment Art	7984381	215	648	18	0.0836420240575111718	t
960	20	Mudbox	7984381	215	1241	17	0.0789164640160549408	t
961	20	Microsoft Office	7984381	215	601080	32	0.0735572113664109267	t
962	20	Adobe Creative Suite	7984381	215	52699	16	0.0678201696987832947	t
963	20	Low Poly Modeling	7984381	215	604	14	0.0650423828105964746	t
964	20	Web Design	7984381	215	51816	15	0.0632794755531513597	t
965	20	Unreal Engine 4	7984381	215	251	13	0.0604353072796075808	t
1866	42	Sales	7984381	1748	353906	582	0.288690358708777683	t
1867	42	Customer Satisfaction	7984381	1748	79371	515	0.28474398076028562	t
1868	42	Automotive	7984381	1748	37962	504	0.283637082757293935	t
1869	42	Sales Process	7984381	1748	48637	449	0.250828383844093339	t
1870	42	Sales Management	7984381	1748	180284	462	0.241775406949719857	t
1871	42	Vehicles	7984381	1748	20721	408	0.230864961868833846	t
1872	42	Negotiation	7984381	1748	275641	430	0.211519204779992559	t
1873	42	Customer Retention	7984381	1748	32444	356	0.199641600907739025	t
1874	42	Account Management	7984381	1748	240929	396	0.196412584537879714	t
1875	42	Customer Service	7984381	1748	670741	478	0.189490224723174894	t
1876	42	Automobile	7984381	1748	13346	324	0.183723399745949811	t
1877	42	New Business Development	7984381	1748	289997	372	0.176532756864347384	t
1878	42	Profit	7984381	1748	23219	273	0.153303999543693614	t
1879	42	B2B	7984381	1748	101291	288	0.152106882660474507	t
1882	42	Retail	7984381	1748	167010	181	0.0826479166513235941	t
1824	41	Customer Service	7984381	630	670741	239	0.295381748722628235	t
1825	41	Customer Satisfaction	7984381	630	79371	190	0.291669532358276251	t
1826	41	Automotive	7984381	630	37962	165	0.257170521069846114	t
1827	41	Vehicles	7984381	630	20721	137	0.214882080739257408	t
1828	41	Sales	7984381	630	353906	157	0.204897727857812656	t
1829	41	Automobile	7984381	630	13346	108	0.169770453583964309	t
1830	41	Customer Retention	7984381	630	32444	106	0.164203491228820553	t
1831	41	Automotive Aftermarket	7984381	630	8117	91	0.143439152570987966	t
1832	41	Warranty	7984381	630	3034	75	0.118676991256246284	t
1833	41	Parts	7984381	630	6008	63	0.0992553625482558294	t
1834	41	Profit	7984381	630	23219	58	0.0891624747346700663	t
1835	41	Account Management	7984381	630	240929	73	0.0857047403343624281	t
1836	41	Sales Management	7984381	630	180284	68	0.0853636596600524239	t
1841	41	Retail	7984381	630	167010	57	0.0695645914045260327	t
1880	42	Automotive Aftermarket	7984381	1748	8117	199	0.112852490294605132	t
1881	42	Sales Operations	7984381	1748	45024	188	0.101934794275470128	t
1883	42	Dealers	7984381	1748	3397	111	0.0630895005379012719	t
1926	43	Manufacturing	7984381	1536	84658	52	0.0232556895573153011	t
1939	43	Mechanical Engineering	7984381	1536	30057	20	0.00925813970718876965	t
1944	43	Automotive Parts	7984381	1536	886	11	0.00705184828829300003	t
1915	43	Automotive	7984381	1536	37962	220	0.138501278301052633	t
1916	43	Vehicles	7984381	1536	20721	176	0.112009689475786295	t
1917	43	Automobile	7984381	1536	13346	118	0.0751658633229026346	t
1918	43	Customer Satisfaction	7984381	1536	79371	110	0.061685667013399767	t
1919	43	Continuous Improvement	7984381	1536	68212	104	0.0591765379646395848	t
1920	43	Automotive Repair	7984381	1536	2315	88	0.0570126934434611529	t
1921	43	Automotive Aftermarket	7984381	1536	8117	83	0.0530300502169287202	t
1922	43	Parts	7984381	1536	6008	76	0.0487360731956046553	t
1923	43	Automotive Engineering	7984381	1536	9172	67	0.042479220855132678	t
1924	43	Engineering	7984381	1536	143574	81	0.0347592044937456504	t
1925	43	Warranty	7984381	1536	3034	38	0.0243642785391152313	t
1927	43	Automotive Electronics	7984381	1536	1261	34	0.0219817120663643936	t
1928	43	Mechanics	7984381	1536	2847	31	0.0198295352245711487	t
1929	43	Powertrain	7984381	1536	3475	30	0.0190996995940983447	t
1930	43	Suspension	7984381	1536	653	26	0.0168485399067730031	t
1931	43	Vehicle Maintenance	7984381	1536	1018	21	0.0135469821829654717	t
1932	43	Troubleshooting	7984381	1536	38514	28	0.0134080784456126444	t
1933	43	Fleet Management	7984381	1536	8847	21	0.0125662541342560202	t
1934	43	Maintenance & Repair	7984381	1536	11706	21	0.0122081111413756618	t
1935	43	Electronics	7984381	1536	24782	22	0.0112212655635824908	t
1936	43	Lean Manufacturing	7984381	1536	42373	25	0.0109711660239603399	t
1937	43	Brake	7984381	1536	351	16	0.0103747016779940811	t
1938	43	Motorsports	7984381	1536	3552	15	0.00932254988079124665	t
1940	43	Chassis	7984381	1536	1194	13	0.00831559942301794176	t
1941	43	Welding	7984381	1536	7563	14	0.00816893049903678892	t
1942	43	Dealers	7984381	1536	3397	13	0.00803963264676210883	t
1943	43	Tires	7984381	1536	447	12	0.00775800814903709109	t
1945	43	Dealer Management	7984381	1536	3247	11	0.00675608906961845408	t
1946	44	Sales Management	7984381	1857	180284	760	0.386772622348717288	t
1947	44	Automotive	7984381	1857	37962	677	0.35989567669108441	t
1948	44	Sales	7984381	1857	353906	713	0.339706831833159473	t
1949	44	Sales Process	7984381	1857	48637	568	0.299847902705765557	t
1950	44	Customer Satisfaction	7984381	1857	79371	564	0.29384322908806243	t
1951	44	Vehicles	7984381	1857	20721	545	0.290956592792194157	t
1952	44	Account Management	7984381	1857	240929	587	0.285992716490357901	t
1953	44	Negotiation	7984381	1857	275641	592	0.284337358370777227	t
1954	44	New Business Development	7984381	1857	289997	572	0.271766364994821208	t
1955	44	B2B	7984381	1857	101291	486	0.249084228090771576	t
1956	44	Automobile	7984381	1857	13346	460	0.246097086025726386	t
2180	48	TQM	7984381	344	1831	22	0.0637269112657995601	t
1969	44	Retail	7984381	1857	167010	212	0.0932672319019076934	t
1985	44	Strategic Planning	7984381	1857	267451	144	0.0440579001776068013	t
1988	44	Budgets	7984381	1857	165031	104	0.0353432990495902016	t
2023	45	Business Strategy	7984381	618	247930	76	0.0919325870588864058	t
1996	45	Automotive	7984381	618	37962	265	0.424080880699561069	t
1997	45	Sales Management	7984381	618	180284	239	0.36417999570890397	t
1998	45	Customer Satisfaction	7984381	618	79371	217	0.341218313625941905	t
1999	45	New Business Development	7984381	618	289997	231	0.337491993716873828	t
2000	45	Vehicles	7984381	618	20721	209	0.335618487723307213	t
2001	45	Sales	7984381	618	353906	233	0.332723618291898671	t
2002	45	Negotiation	7984381	618	275641	217	0.3166346680442782	t
2003	45	Sales Process	7984381	618	48637	198	0.314321160395848065	t
2004	45	Account Management	7984381	618	240929	210	0.309654754876526495	t
2005	45	Automobile	7984381	618	13346	173	0.27828530125277523	t
2006	45	B2B	7984381	618	101291	179	0.276979308343907882	t
2007	45	Customer Retention	7984381	618	32444	161	0.256474217397725357	t
2008	45	Profit	7984381	618	23219	127	0.202609247695648781	t
2009	45	Automotive Aftermarket	7984381	618	8117	120	0.193173099291455236	t
2010	45	Management	7984381	618	738887	176	0.192262974571479839	t
2011	45	Business Development	7984381	618	206995	131	0.186063521253612391	t
2012	45	Customer Service	7984381	618	670741	163	0.179761321575538979	t
2013	45	Business Planning	7984381	618	140725	115	0.168472146647954291	t
2014	45	Key Account Management	7984381	618	74920	108	0.165386762914505603	t
2015	45	Sales Operations	7984381	618	45024	96	0.149712384269768184	t
2016	45	Fleet Management	7984381	618	8847	88	0.141297720301424373	t
2017	45	Dealer Management	7984381	618	3247	67	0.108015931065480367	t
2018	45	Continuous Improvement	7984381	618	68212	71	0.106351783648272233	t
2019	45	Team Building	7984381	618	154308	76	0.103659137558945097	t
2020	45	Parts	7984381	618	6008	64	0.102815359471864529	t
2021	45	Dealers	7984381	618	3397	60	0.0966694053116585877	t
2022	45	Operations Management	7984381	618	139638	69	0.0941688793321027728	t
2024	45	Product Development	7984381	618	108713	62	0.0867146284366403924	t
2025	45	Retail	7984381	618	167010	62	0.0794126832260924342	t
2026	45	Team Leadership	7984381	618	284785	67	0.0727521087300728592	t
2027	45	Pricing	7984381	618	23421	46	0.0715058395865965229	t
2028	45	Direct Sales	7984381	618	49654	47	0.0698382938886577126	t
2029	45	Purchasing	7984381	618	49234	46	0.0682726524291120129	t
2030	45	Marketing Strategy	7984381	618	206871	57	0.0663286836409425207	t
2031	45	Warranty	7984381	618	3034	40	0.0643499079618824049	t
2043	45	Contract Negotiation	7984381	618	143599	37	0.0418888039601778006	t
2080	46	Team Leadership	7984381	808	284785	98	0.0856280322156011964	t
2046	46	Automotive	7984381	808	37962	407	0.499008837141013961	t
2047	46	Vehicles	7984381	808	20721	352	0.433092200449573361	t
2048	46	Customer Satisfaction	7984381	808	79371	351	0.424508116649817913	t
2049	46	Automobile	7984381	808	13346	339	0.417925235045104759	t
2050	46	Automotive Aftermarket	7984381	808	8117	322	0.397538471611124711	t
2051	46	Parts	7984381	808	6008	298	0.368096662576101352	t
2052	46	Profit	7984381	808	23219	246	0.30157791188888422	t
2053	46	Customer Retention	7984381	808	32444	232	0.283093927944788659	t
2054	46	Warranty	7984381	808	3034	229	0.283064495138149796	t
2055	46	Dealer Management	7984381	808	3247	209	0.258282834963024399	t
2056	46	Aftersales	7984381	808	1894	199	0.24607481775886611	t
2057	46	Negotiation	7984381	808	275641	214	0.230352270323273101	t
2096	47	Automotive	7984381	1151	37962	408	0.349770259120276872	t
2097	47	Engineering	7984381	1151	143574	377	0.309604042552393321	t
2098	47	Automotive Engineering	7984381	1151	9172	314	0.271696679481478576	t
2099	47	FMEA	7984381	1151	12047	279	0.240923824795355401	t
2100	47	Manufacturing	7984381	1151	84658	252	0.208367138658722639	t
2101	47	Vehicles	7984381	1151	20721	204	0.174667172668003301	t
2102	47	Continuous Improvement	7984381	1151	68212	209	0.173063002367365937	t
2103	47	Lean Manufacturing	7984381	1151	42373	181	0.151969482404553963	t
2104	47	CATIA	7984381	1151	8001	169	0.145847787943286733	t
2117	47	Engineering Management	7984381	1151	26924	93	0.0774383846229752953	t
2129	47	Automobile	7984381	1151	13346	59	0.0495954101865967029	t
2138	47	Simulations	7984381	1151	12224	41	0.0340951249247372981	t
2146	48	FMEA	7984381	344	12047	134	0.388042781417296145	t
2147	48	Automotive	7984381	344	37962	135	0.387704031720084163	t
2148	48	Continuous Improvement	7984381	344	68212	134	0.381008119629030362	t
2149	48	Lean Manufacturing	7984381	344	42373	120	0.34354502440889384	t
2150	48	TS 16949	7984381	344	2584	109	0.31655047156289251	t
2151	48	Manufacturing	7984381	344	84658	111	0.312084913571044731	t
2152	48	APQP	7984381	344	4233	104	0.301808424473355597	t
2153	48	PPAP	7984381	344	3965	103	0.298934889457959152	t
2154	48	Kaizen	7984381	344	12685	95	0.274585894197821034	t
2155	48	Supplier Quality	7984381	344	3695	93	0.269897686995444308	t
2156	48	Root Cause Analysis	7984381	344	14649	92	0.265618597371520881	t
2157	48	5S	7984381	344	16523	91	0.262476777026284414	t
2158	48	SPC	7984381	344	5436	80	0.231887300960363085	t
2159	48	Engineering	7984381	344	143574	84	0.226213935410439354	t
2160	48	Quality Management	7984381	344	23788	77	0.220867408435921786	t
2161	48	Six Sigma	7984381	344	31465	77	0.219905864795780837	t
2162	48	Automotive Engineering	7984381	344	9172	67	0.193627041333764155	t
2163	48	Quality System	7984381	344	14495	58	0.166796418059662527	t
2164	48	Manufacturing Engineering	7984381	344	8612	57	0.164626161348211814	t
2165	48	Vehicles	7984381	344	20721	50	0.142759796101401659	t
2166	48	Value Stream Mapping	7984381	344	8075	44	0.126901094632166783	t
2167	48	Quality Assurance	7984381	344	35754	44	0.123434302080979955	t
2168	48	Process Improvement	7984381	344	108186	47	0.123083505817280614	t
2169	48	Poka Yoke	7984381	344	1433	41	0.119011698622208062	t
2170	48	ISO	7984381	344	8211	41	0.118162754660650765	t
2171	48	DFMEA	7984381	344	2798	40	0.115933630486536723	t
2172	48	8D Problem Solving	7984381	344	844	33	0.095828654872565186	t
2173	48	Quality Control	7984381	344	10786	32	0.0916763181682486855	t
2174	48	DMAIC	7984381	344	3917	30	0.0867224558843637527	t
2175	48	5 Why	7984381	344	1451	29	0.0841242201943586815	t
2176	48	Powertrain	7984381	344	3475	28	0.0809636123610381619	t
2177	48	Kanban	7984381	344	4574	26	0.0750117587101292449	t
2178	48	PFMEA	7984381	344	570	24	0.0696990554038392218	t
2179	48	Product Development	7984381	344	108713	28	0.0677825612211198497	t
2183	48	GD&T	7984381	344	2099	20	0.0578791402988761972	t
2195	48	Supplier Development	7984381	344	4462	13	0.037233460777846103	t
2196	49	Automotive	7984381	373	37962	140	0.370597900941246949	t
2197	49	Lean Manufacturing	7984381	373	42373	131	0.345915607954456472	t
2198	49	Continuous Improvement	7984381	373	68212	122	0.318549449921438521	t
2199	49	Manufacturing	7984381	373	84658	120	0.311127401450298047	t
2200	49	FMEA	7984381	373	12047	97	0.258556877315716582	t
2201	49	5S	7984381	373	16523	95	0.252634075839318628	t
2202	49	Engineering	7984381	373	143574	95	0.236720890381588611	t
2203	49	Kaizen	7984381	373	12685	88	0.234347153995689922	t
2204	49	Manufacturing Engineering	7984381	373	8612	68	0.181235490818532324	t
2205	49	Six Sigma	7984381	373	31465	69	0.181054234385045087	t
2206	49	Root Cause Analysis	7984381	373	14649	54	0.142944088732034874	t
2207	49	Automotive Engineering	7984381	373	9172	53	0.140948994640823222	t
2208	49	PPAP	7984381	373	3965	52	0.138920082948226387	t
2246	50	Automotive	7984381	596	37962	316	0.525486034943317359	t
2247	50	Vehicles	7984381	596	20721	275	0.458848455266459454	t
2248	50	Customer Satisfaction	7984381	596	79371	267	0.438078494736603152	t
2249	50	Automobile	7984381	596	13346	251	0.419500740117995763	t
2250	50	Sales Management	7984381	596	180284	260	0.413692907335044657	t
2251	50	Profit	7984381	596	23219	222	0.369602758137379583	t
2252	50	Sales Process	7984381	596	48637	218	0.359707144757957509	t
2253	50	Automotive Aftermarket	7984381	596	8117	200	0.334578834878629217	t
2254	50	Customer Retention	7984381	596	32444	191	0.316429985461345709	t
2263	50	Fleet Management	7984381	596	8847	124	0.206961101732738989	t
2272	50	Operations Management	7984381	596	139638	86	0.126815873396544987	t
2289	50	Lean Manufacturing	7984381	596	42373	30	0.0450319456853136013	t
2308	51	Automotive Parts	7984381	265	886	23	0.0866843632182641988	t
2322	52	Training	7984381	438	286184	77	0.139963785829614995	t
2296	51	Customer Satisfaction	7984381	265	79371	58	0.208934075871794411	t
2297	51	Automotive	7984381	265	37962	56	0.20657307820526713	t
2298	51	Vehicles	7984381	265	20721	55	0.204958780564471144	t
2299	51	Parts	7984381	265	6008	52	0.195480433948775123	t
2300	51	Automobile	7984381	265	13346	52	0.194561359125713929	t
2301	51	Automotive Aftermarket	7984381	265	8117	43	0.161252893090930161	t
2302	51	Profit	7984381	265	23219	40	0.148040257043567547	t
2303	51	Purchasing	7984381	265	49234	33	0.118365941520284748	t
2304	51	Customer Retention	7984381	265	32444	31	0.112921446569900386	t
2305	51	Customer Service	7984381	265	670741	52	0.112223502311008333	t
2306	51	Inventory Management	7984381	265	40826	27	0.0967767715062407413	t
2307	51	Sales Management	7984381	265	180284	31	0.0944046815329194627	t
2309	51	Dealers	7984381	265	3397	23	0.0863698637796287833	t
2310	51	Warranty	7984381	265	3034	21	0.0788679087422416852	t
2311	51	Sales	7984381	265	353906	32	0.0764324651501216146	t
2312	51	Continuous Improvement	7984381	265	68212	22	0.0744781603496383476	t
2313	51	Sales Process	7984381	265	48637	20	0.0693824829765537221	t
2314	51	Automotive Repair	7984381	265	2315	16	0.0600894117723570348	t
2315	51	Dealer Management	7984381	265	3247	15	0.0561989698470842167	t
2316	51	Fleet Management	7984381	265	8847	15	0.0554975772320470614	t
2317	51	Negotiation	7984381	265	275641	23	0.0522716617995974339	t
2318	51	Spare Parts	7984381	265	517	12	0.0452197682838899259	t
2319	51	Aftersales	7984381	265	1894	12	0.0450473008497995347	t
2320	51	Stock Control	7984381	265	11135	11	0.0401161676319653424	t
2321	52	Coaching	7984381	438	219497	74	0.141466734799079036	t
2323	52	Vehicles	7984381	438	20721	48	0.10699971900278428	t
2324	52	Automotive	7984381	438	37962	43	0.0934241083268959327	t
2325	52	Team Building	7984381	438	154308	47	0.0879845305970934077	t
2326	52	Training Delivery	7984381	438	66235	38	0.0784667242590883357	t
2327	52	Automobile	7984381	438	13346	31	0.0691085333805866175	t
2550	57	JIT	7984381	281	2003	23	0.0816025409219685305	t
2332	52	Customer Satisfaction	7984381	438	79371	26	0.0494226586409393029	t
2387	53	Selling	7984381	456	33136	24	0.0484842453990197014	t
2345	53	Automotive	7984381	456	37962	182	0.394390798638206641	t
2346	53	Sales Management	7984381	456	180284	165	0.339281898347386535	t
2347	53	New Business Development	7984381	456	289997	154	0.301415976257995155	t
2348	53	Negotiation	7984381	456	275641	152	0.298827873925836374	t
2349	53	Vehicles	7984381	456	20721	130	0.282508662004996969	t
2350	53	Account Management	7984381	456	240929	134	0.263699671417605641	t
2351	53	B2B	7984381	456	101291	125	0.261451595802508652	t
2352	53	Automobile	7984381	456	13346	116	0.252728885217769539	t
2353	53	Sales	7984381	456	353906	133	0.247356004930741058	t
2354	53	Sales Process	7984381	456	48637	114	0.243922412848317088	t
2355	53	Key Account Management	7984381	456	74920	109	0.229664884467138425	t
2356	53	Customer Satisfaction	7984381	456	79371	108	0.226914281542368923	t
2357	53	Automotive Aftermarket	7984381	456	8117	93	0.20294234896007321	t
2358	53	Business Planning	7984381	456	140725	91	0.181946759082628168	t
2359	53	Sales Operations	7984381	456	45024	78	0.16542306967800266	t
2395	54	Automotive	7984381	384	37962	151	0.388493318193777748	t
2396	54	Automotive Engineering	7984381	384	9172	131	0.34001344312827686	t
2397	54	Engineering	7984381	384	143574	136	0.336200978553306939	t
2398	54	CATIA	7984381	384	8001	127	0.329742943851202175	t
2399	54	CAD	7984381	384	35636	102	0.261174347025055265	t
2400	54	FMEA	7984381	384	12047	82	0.212043043859067915	t
2401	54	Manufacturing	7984381	384	84658	85	0.21076135206515817	t
2423	54	CAE	7984381	384	1985	28	0.0726715513441033023	t
2461	55	Powertrain	7984381	203	3475	16	0.0783845021659073937	t
2467	55	Team Building	7984381	203	154308	17	0.0644192481483208956	t
2406	54	DFMEA	7984381	384	2798	61	0.158511355916612529	t
2445	55	Automotive	7984381	203	37962	83	0.404122737117718789	t
2446	55	Vehicles	7984381	203	20721	75	0.36687226388591021	t
2447	55	Automobile	7984381	203	13346	65	0.318533629516317751	t
2448	55	Automotive Aftermarket	7984381	203	8117	59	0.289631148052321541	t
2449	55	Customer Satisfaction	7984381	203	79371	60	0.285632981441854561	t
2450	55	Automotive Repair	7984381	203	2315	40	0.196759396438177525	t
2451	55	Parts	7984381	203	6008	40	0.196296856650111678	t
2452	55	Warranty	7984381	203	3034	39	0.191743109713561094	t
2453	55	Automotive Engineering	7984381	203	9172	36	0.176195638411553196	t
2454	55	Continuous Improvement	7984381	203	68212	37	0.17372724731460798	t
2455	55	Customer Service	7984381	203	670741	49	0.157376674131055827	t
2456	55	Customer Retention	7984381	203	32444	24	0.114166070270600828	t
2457	55	Suspension	7984381	203	653	20	0.0984428856881056219	t
2458	55	Automotive Electronics	7984381	203	1261	19	0.0934405014591499911	t
2459	55	Brake	7984381	203	351	18	0.0886282432519338859	t
2460	55	Profit	7984381	203	23219	18	0.0857640786503931773	t
2462	55	Dealers	7984381	203	3397	15	0.0734680378650896526	t
2463	55	Negotiation	7984381	203	275641	21	0.0689275024023590227	t
2464	55	Vehicle Maintenance	7984381	203	1018	14	0.0688397685418888905	t
2465	55	Aftersales	7984381	203	1894	14	0.0687300515491064135	t
2466	55	Dealer Management	7984381	203	3247	14	0.0685605913992951288	t
2468	55	Tires	7984381	203	447	13	0.0639850513614384636	t
2469	55	Fleet Management	7984381	203	8847	12	0.0580067369866368934	t
2470	55	Chassis	7984381	203	1194	10	0.0491127904567939047	t
2471	55	Motors	7984381	203	1495	9	0.044148857274395617	t
2472	56	Automotive	7984381	181	37962	101	0.553269059292655463	t
2473	56	Vehicles	7984381	181	20721	93	0.511228552080967624	t
2474	56	B2B	7984381	181	101291	86	0.462462462119592299	t
2475	56	Customer Satisfaction	7984381	181	79371	81	0.437582948699371865	t
2559	57	Parts	7984381	281	6008	17	0.0597478542874425519	t
2562	57	Forecasting	7984381	281	72454	17	0.0514255637349695163	t
2563	57	Low Cost Country Sourcing	7984381	281	550	14	0.0497549306292519727	t
2564	57	Kanban	7984381	281	4574	14	0.049250928925866494	t
2565	57	Logistics Management	7984381	281	21257	14	0.0471614009890921546	t
2566	57	Pricing	7984381	281	23421	14	0.0468903622996969804	t
2567	57	Automotive Aftermarket	7984381	281	8117	13	0.0452483278487524204	t
2580	58	Process Improvement	7984381	94	108186	13	0.124749636912515699	t
2582	58	Mechanical Engineering	7984381	94	30057	11	0.113258135315878361	t
2583	58	Pneumatics	7984381	94	2893	10	0.106021894508871381	t
2585	58	Electronics	7984381	94	24782	10	0.103280384841195366	t
2490	56	Sales Operations	7984381	181	45024	36	0.193260399233237012	t
2508	56	Aftersales	7984381	181	1894	14	0.0771126012548817019	t
2511	56	Retail	7984381	181	167010	16	0.0674822318277493033	t
2514	56	CRM	7984381	181	102251	14	0.0645431515917971044	t
2515	56	Fleet	7984381	181	493	11	0.0607131114337556982	t
2532	57	Logistics	7984381	281	69734	48	0.16209040824510601	t
2548	57	Operations Management	7984381	281	139638	30	0.0892758129023426966	t
2518	57	Automotive	7984381	281	37962	115	0.404512372700172207	t
2519	57	Purchasing	7984381	281	49234	107	0.374629813854680305	t
2520	57	Supply Chain Management	7984381	281	55114	98	0.341863753141753546	t
2521	57	Continuous Improvement	7984381	281	68212	94	0.325987866186536801	t
2522	57	Supply Management	7984381	281	17740	92	0.325191742074918411	t
2523	57	Lean Manufacturing	7984381	281	42373	78	0.272282667584742843	t
2524	57	Negotiation	7984381	281	275641	86	0.271536852537122175	t
2525	57	Supply Chain	7984381	281	54836	77	0.267162846031933299	t
2526	57	Strategic Sourcing	7984381	281	14173	70	0.247343934593135528	t
2527	57	Procurement	7984381	281	112661	71	0.23856726186355881	t
2528	57	Manufacturing	7984381	281	84658	70	0.238515763603293213	t
2529	57	Supplier Development	7984381	281	4462	61	0.216530629982963019	t
2530	57	Global Sourcing	7984381	281	8722	61	0.215997069531565861	t
2531	57	Supplier Negotiation	7984381	281	7987	49	0.173382998175065112	t
2533	57	Vehicles	7984381	281	20721	41	0.14331732539061956	t
2534	57	MRP	7984381	281	5777	40	0.141630201324063981	t
2535	57	Kaizen	7984381	281	12685	40	0.14076498170006127	t
2536	57	Supplier Quality	7984381	281	3695	39	0.138332125490872176	t
2537	57	Product Development	7984381	281	108713	42	0.135855265453968754	t
2538	57	PPAP	7984381	281	3965	38	0.134739464169021717	t
2539	57	Management	7984381	281	738887	63	0.131662371133446227	t
2540	57	Supplier Evaluation	7984381	281	3117	32	0.113492610602718799	t
2541	57	APQP	7984381	281	4233	32	0.113352832794324621	t
2542	57	Materials Management	7984381	281	7721	32	0.112915964518626677	t
2543	57	Sourcing	7984381	281	47464	33	0.111497040314243775	t
2544	57	TS 16949	7984381	281	2584	30	0.106441680063325148	t
2545	57	5S	7984381	281	16523	30	0.10469583519665264	t
2546	57	Process Improvement	7984381	281	108186	31	0.0967739864297016417	t
2547	57	Value Stream Mapping	7984381	281	8075	26	0.0915185617357558573	t
2549	57	Contract Negotiation	7984381	281	143599	29	0.0852208577715469207	t
2552	57	Inventory Management	7984381	281	40826	21	0.0696223134048316039	t
2556	57	FMEA	7984381	281	12047	18	0.0625503200957097938	t
2560	57	Engineering	7984381	281	143574	20	0.0531943920035733014	t
2561	57	Spend Analysis	7984381	281	3965	15	0.0528860496357506996	t
2584	58	Maintenance & Repair	7984381	94	11706	10	0.104918101521470006	t
1837	41	Teamwork	7984381	630	285884	76	0.0848362089767038391	t
1838	41	Negotiation	7984381	630	275641	74	0.0829443361878554331	t
1839	41	Sales Process	7984381	630	48637	54	0.0796290508416049453	t
1840	41	Team Leadership	7984381	630	284785	67	0.0706870219950099243	t
1842	41	Time Management	7984381	630	218895	57	0.0630657664787486749	t
1843	41	Continuous Improvement	7984381	630	68212	45	0.0628903542421887368	t
1844	41	Microsoft Excel	7984381	630	428419	73	0.0622207914987837687	t
1845	41	Automotive Repair	7984381	630	2315	39	0.0616196828736147659	t
1846	41	Dealers	7984381	630	3397	39	0.0614841576048532554	t
1847	41	Team Building	7984381	630	154308	49	0.0584561581531176377	t
1848	41	Dealer Management	7984381	630	3247	36	0.0567406652408301362	t
1849	41	Management	7984381	630	738887	89	0.0487321356224582336	t
1850	41	Fleet Management	7984381	630	8847	30	0.0465146795093708473	t
1851	41	Team Management	7984381	630	150662	41	0.0462134209886738839	t
1852	41	Microsoft Word	7984381	630	319543	52	0.0425220266784213305	t
1853	41	Leadership	7984381	630	330397	52	0.041162515340956024	t
1854	41	Aftersales	7984381	630	1894	25	0.0394484391951873056	t
1855	41	Purchasing	7984381	630	49234	24	0.0319314687091437691	t
1856	41	Operations Management	7984381	630	139638	31	0.0317199571583006157	t
1857	41	Powerpoint	7984381	630	268322	41	0.0314759874189145042	t
1858	41	Process Improvement	7984381	630	108186	28	0.0308971782534021647	t
1859	41	B2B	7984381	630	101291	27	0.0301733805504276302	t
1860	41	Inventory Management	7984381	630	40826	18	0.023460046715957375	t
1861	41	Automotive Engineering	7984381	630	9172	15	0.0226625692013452708	t
1862	41	Customer Experience	7984381	630	42804	16	0.0200374398147850769	t
1863	41	Sales Operations	7984381	630	45024	16	0.0197593750304499924	t
1864	41	Call Centers	7984381	630	26223	14	0.0189394294597725922	t
1865	41	Pricing	7984381	630	23421	13	0.0177029654674811694	t
1884	42	Dealer Management	7984381	1748	3247	106	0.0602472530713006327	t
1885	42	Team Building	7984381	1748	154308	135	0.0579175689735981908	t
1886	42	Direct Sales	7984381	1748	49654	107	0.0550059653513478922	t
1887	42	Fleet Management	7984381	1748	8847	93	0.052107030679173022	t
1888	42	Key Account Management	7984381	1748	74920	106	0.0512686366173060667	t
1889	42	Parts	7984381	1748	6008	88	0.0496016394854337309	t
1890	42	Pricing	7984381	1748	23421	87	0.0468480713727307471	t
1891	42	Management	7984381	1748	738887	240	0.0447680213045653363	t
2568	58	Engineering	7984381	94	143574	34	0.34372431699219741	t
2569	58	Continuous Improvement	7984381	94	68212	32	0.331886259716887677	t
2570	58	Manufacturing	7984381	94	84658	29	0.297911194665648194	t
2571	58	Automotive	7984381	94	37962	24	0.250567566233794892	t
2572	58	5S	7984381	94	16523	21	0.221337445846994441	t
2573	58	Lean Manufacturing	7984381	94	42373	21	0.218099836778081951	t
2574	58	Root Cause Analysis	7984381	94	14649	20	0.210933733730401529	t
2575	58	Kaizen	7984381	94	12685	18	0.189902870635361154	t
2576	58	PLC	7984381	94	7875	14	0.14795161141621968	t
2577	58	Preventive Maintenance	7984381	94	10012	13	0.137045537598450451	t
2578	58	FMEA	7984381	94	12047	13	0.136790661990897761	t
2579	58	Manufacturing Engineering	7984381	94	8612	12	0.126582458878427562	t
2581	58	Automation	7984381	94	11971	11	0.115523334450127926	t
1892	42	Purchasing	7984381	1748	49234	88	0.0441866341858038955	t
1893	42	Selling	7984381	1748	33136	78	0.0404811855146567645	t
1894	42	Team Leadership	7984381	1748	284785	132	0.0398558378314259887	t
1895	42	Business Planning	7984381	1748	140725	92	0.0350142088390344858	t
1896	42	Warranty	7984381	1748	3034	55	0.0310913457541614376	t
1897	42	Business Development	7984381	1748	206995	95	0.0284290596849435494	t
1898	42	Operations Management	7984381	1748	139638	78	0.0271394723230318942	t
1899	42	Marketing	7984381	1748	249999	101	0.0264751106690315277	t
1900	42	Marketing Strategy	7984381	1748	206871	84	0.0221503092367749087	t
1901	42	Sales Presentations	7984381	1748	16560	39	0.020241594932926335	t
1902	42	Continuous Improvement	7984381	1748	68212	48	0.0189209170510663896	t
1903	42	Inventory Management	7984381	1748	40826	42	0.0189183687558781774	t
1904	42	Forecasting	7984381	1748	72454	44	0.0161006828330029911	t
1905	42	Aftersales	7984381	1748	1894	28	0.0157845491779334893	t
1906	42	Cold Calling	7984381	1748	14306	30	0.015374089041337087	t
1907	42	CRM	7984381	1748	102251	46	0.0135123698501088806	t
1908	42	Logistics	7984381	1748	69734	38	0.0130081766254317339	t
1909	42	Automotive Repair	7984381	1748	2315	20	0.0111541484725917531	t
1910	42	Vehicle Leasing	7984381	1748	517	16	0.00909055683098150893	t
1911	42	Automotive Parts	7984381	1748	886	13	0.00732770852608867831	t
1912	42	Automotive Sales Training	7984381	1748	179	10	0.00569965283912028317	t
1913	42	Product Knowledge	7984381	1748	1747	10	0.00550322642192184724	t
1914	42	Automotive Sales	7984381	1748	104	9	0.00513684058353863163	t
1957	44	Customer Retention	7984381	1857	32444	419	0.221620852008617225	t
1958	44	Profit	7984381	1857	23219	379	0.201231372107921719	t
1959	44	Automotive Aftermarket	7984381	1857	8117	331	0.177269099625460863	t
1960	44	Customer Service	7984381	1857	670741	458	0.162665551634756655	t
1961	44	Sales Operations	7984381	1857	45024	304	0.158102662287846418	t
1962	44	Key Account Management	7984381	1857	74920	286	0.144662172701511466	t
1963	44	Management	7984381	1857	738887	439	0.143894716306101345	t
1964	44	Business Planning	7984381	1857	140725	262	0.123491461834511027	t
1965	44	Dealer Management	7984381	1857	3247	201	0.107857511745717088	t
1966	44	Dealers	7984381	1857	3397	184	0.098682040694418216	t
1967	44	Parts	7984381	1857	6008	179	0.0956618099902133423	t
1968	44	Pricing	7984381	1857	23421	182	0.0950963044494985699	t
1970	44	Fleet Management	7984381	1857	8847	164	0.0872267345371915415	t
1971	44	Business Strategy	7984381	1857	247930	213	0.0836687155449722803	t
1972	44	Marketing Strategy	7984381	1857	206871	202	0.0828874161739869553	t
1973	44	Team Building	7984381	1857	154308	188	0.0819313802849389594	t
1974	44	Purchasing	7984381	1857	49234	163	0.0816286789827866399	t
1975	44	Business Development	7984381	1857	206995	198	0.0807173692984019808	t
1976	44	Product Development	7984381	1857	108713	175	0.0806410657662708918	t
1977	44	Forecasting	7984381	1857	72454	163	0.0787198245903663885	t
1978	44	Operations Management	7984381	1857	139638	150	0.0633012719354897613	t
1979	44	Direct Sales	7984381	1857	49654	126	0.0616468193346718096	t
1980	44	Team Leadership	7984381	1857	284785	173	0.057506625377148228	t
1981	44	Continuous Improvement	7984381	1857	68212	117	0.0544743366277818108	t
1982	44	Selling	7984381	1857	33136	94	0.0464799861220368468	t
1983	44	Warranty	7984381	1857	3034	86	0.0459419479613042345	t
1984	44	Marketing	7984381	1857	249999	141	0.0446282913910736878	t
1986	44	Team Management	7984381	1857	150662	106	0.0382206127454514308	t
1987	44	Manufacturing	7984381	1857	84658	87	0.0362552389475099129	t
1989	44	Aftersales	7984381	1857	1894	55	0.0293872846358340968	t
1990	44	FMCG	7984381	1857	39801	58	0.0262544207007067466	t
1991	44	CRM	7984381	1857	102251	72	0.0259718759102603725	t
1992	44	Contract Negotiation	7984381	1857	143599	80	0.0251010864871360484	t
1993	44	Coaching	7984381	1857	219497	97	0.0247497462191078356	t
1994	44	Process Improvement	7984381	1857	108186	71	0.0246897485008882901	t
1995	44	Logistics	7984381	1857	69734	59	0.0230432324620457041	t
2131	47	AutoCAD	7984381	1151	70871	66	0.0484722251278147109	t
2032	45	Process Improvement	7984381	618	108186	45	0.0592704174734918141	t
2033	45	Manufacturing	7984381	618	84658	43	0.0589809022772148223	t
2034	45	Team Management	7984381	618	150662	48	0.0588048639579329402	t
2035	45	Forecasting	7984381	618	72454	40	0.055654760072347105	t
2036	45	CRM	7984381	618	102251	40	0.0519225601059903896	t
2037	45	Selling	7984381	618	33136	34	0.0508700160693096523	t
2038	45	Marketing	7984381	618	249999	49	0.047980733827314978	t
2039	45	Strategic Planning	7984381	618	267451	49	0.045794797195678992	t
2040	45	Lean Manufacturing	7984381	618	42373	31	0.0448582981528382954	t
2041	45	Six Sigma	7984381	618	31465	30	0.0446063229431549538	t
2042	45	Project Management	7984381	618	479558	64	0.0435012240196974223	t
2044	45	Automotive Engineering	7984381	618	9172	24	0.0376891258600348319	t
2045	45	Budgets	7984381	618	165031	36	0.0375861073049806177	t
2058	46	Dealers	7984381	808	3397	172	0.212467332658703018	t
2059	46	Sales Management	7984381	808	180284	177	0.196499707419643593	t
2060	46	Automotive Repair	7984381	808	2315	155	0.191561127616310223	t
2061	46	Customer Service	7984381	808	670741	221	0.189527393739099242	t
2062	46	Sales Process	7984381	808	48637	154	0.184521214578192427	t
2063	46	Continuous Improvement	7984381	808	68212	150	0.177118308809827624	t
2064	46	Fleet Management	7984381	808	8847	140	0.172176712292246653	t
2065	46	New Business Development	7984381	808	289997	162	0.164191128942064696	t
2066	46	Management	7984381	808	738887	200	0.154998887176589883	t
2067	46	Automotive Engineering	7984381	808	9172	122	0.149856521349873317	t
2068	46	B2B	7984381	808	101291	128	0.145744447460249227	t
2069	46	Operations Management	7984381	808	139638	127	0.139703460592155798	t
2070	46	Account Management	7984381	808	240929	137	0.139393523742408654	t
2071	46	Sales	7984381	808	353906	146	0.136382082233849511	t
2072	46	Team Building	7984381	808	154308	119	0.127963945311501015	t
2073	46	Purchasing	7984381	808	49234	106	0.125034483090131043	t
2074	46	Automotive Parts	7984381	808	886	100	0.123663924078421361	t
2075	46	Business Planning	7984381	808	140725	105	0.112336827585075183	t
2076	46	Retail	7984381	808	167010	92	0.0929537048285037221	t
2077	46	Sales Operations	7984381	808	45024	78	0.0909048433540091683	t
2078	46	Process Improvement	7984381	808	108186	83	0.0891820931852973231	t
2079	46	Pricing	7984381	808	23421	72	0.0861842805282177493	t
2081	46	Team Management	7984381	808	150662	71	0.0690086801230526126	t
2082	46	Spare Parts	7984381	808	517	55	0.068011438104291666	t
2083	46	Powertrain	7984381	808	3475	51	0.0626899312283776544	t
2084	46	Key Account Management	7984381	808	74920	57	0.0611674246916167341	t
2085	46	Coaching	7984381	808	219497	67	0.05543560468253729	t
2086	46	Forecasting	7984381	808	72454	49	0.0515743167902143543	t
2087	46	Tires	7984381	808	447	40	0.0494539708146482654	t
2088	46	Inventory Management	7984381	808	40826	44	0.049347206414029815	t
2089	46	Suspension	7984381	808	653	38	0.0469526697922951486	t
2090	46	Business Strategy	7984381	808	247930	62	0.045685421616969174	t
2091	46	Motorsports	7984381	808	3552	37	0.0453518001499100473	t
2092	46	Manufacturing	7984381	808	84658	43	0.0426191838039196094	t
2093	46	Budgets	7984381	808	165031	47	0.0375028829463789348	t
2094	46	Product Development	7984381	808	108713	41	0.0371306238186936144	t
2095	46	Marketing Strategy	7984381	808	206871	49	0.0347376197374035384	t
2105	47	Product Development	7984381	1151	108713	181	0.143659562735447582	t
2106	47	DFMEA	7984381	1151	2798	160	0.138679114216547439	t
2107	47	APQP	7984381	1151	4233	152	0.131547882465821414	t
2108	47	Powertrain	7984381	1151	3475	144	0.124691351556734692	t
2109	47	PPAP	7984381	1151	3965	132	0.114202752972700078	t
2110	47	Mechanical Engineering	7984381	1151	30057	132	0.110934401691326498	t
2111	47	Manufacturing Engineering	7984381	1151	8612	127	0.109275982789347886	t
2112	47	CAD	7984381	1151	35636	116	0.0963326018560847763	t
2113	47	Kaizen	7984381	1151	12685	108	0.0922560234223745584	t
2114	47	Six Sigma	7984381	1151	31465	110	0.0916414621247966521	t
2115	47	Matlab	7984381	1151	43522	105	0.0857864962111448276	t
2116	47	Solidworks	7984381	1151	18639	97	0.0819519250852536185	t
2118	47	5S	7984381	1151	16523	86	0.072658695782345642	t
2119	47	Finite Element Analysis	7984381	1151	11586	82	0.0698013771751309908	t
2120	47	Product Design	7984381	1151	19493	82	0.0688109259417329922	t
2121	47	Project Management	7984381	1151	479558	147	0.0676627708592608124	t
2122	47	Testing	7984381	1151	52574	84	0.0664049844634512776	t
2123	47	GD&T	7984381	1151	2099	72	0.0623003933550875452	t
2124	47	TS 16949	7984381	1151	2584	69	0.0596328360232174087	t
2125	47	Root Cause Analysis	7984381	1151	14649	68	0.0572526079819147549	t
2126	47	Design for Manufacturing	7984381	1151	7274	62	0.0529628095623513317	t
2127	47	Vehicle Dynamics	7984381	1151	1298	58	0.0502356387775093338	t
2128	47	Pro Engineer	7984381	1151	4965	58	0.0497763008904636151	t
2130	47	CAE	7984381	1151	1985	57	0.0492806483906397946	t
2132	47	Automotive Design	7984381	1151	1550	54	0.0467283326339215654	t
2133	47	Simulink	7984381	1151	4716	51	0.0437249463205489491	t
2134	47	SPC	7984381	1151	5436	46	0.0392900822954810602	t
2135	47	Teamcenter	7984381	1151	1610	45	0.038900401939764323	t
2136	47	Electronics	7984381	1151	24782	48	0.0386046223766683891	t
2137	47	Project Engineering	7984381	1151	44758	48	0.0361023770448916509	t
2139	47	ANSYS	7984381	1151	6586	40	0.0339324203670371485	t
2140	47	Injection Molding	7984381	1151	3434	39	0.0334583130312634605	t
2141	47	Supplier Quality	7984381	1151	3695	39	0.0334256194974431875	t
2142	47	Automotive Electronics	7984381	1151	1261	38	0.0328615736280183438	t
2143	47	Quality Management	7984381	1151	23788	40	0.0317776534368597666	t
2144	47	Chassis	7984381	1151	1194	35	0.0302631612412393516	t
2145	47	Systems Engineering	7984381	1151	19629	36	0.0288228805410927387	t
2181	48	Quality Auditing	7984381	344	7455	22	0.0630225057125687743	t
2182	48	Toyota Production System	7984381	344	1903	21	0.0608107912774126097	t
2184	48	Process Capability	7984381	344	423	19	0.0551819571716285484	t
2185	48	JIT	7984381	344	2003	19	0.0549840622971433726	t
2186	48	ISO 9000	7984381	344	5149	19	0.054590026047060862	t
2187	48	ISO 14001	7984381	344	8838	19	0.054127979090114145	t
2188	48	CATIA	7984381	344	8001	18	0.0513257112795164616	t
2189	48	Automobile	7984381	344	13346	17	0.0477491484600153782	t
2190	48	Manufacturing Operations Management	7984381	344	4312	16	0.0459735542482499621	t
2191	48	TPM	7984381	344	4981	16	0.0458897620513951596	t
2192	48	QS 9000	7984381	344	204	15	0.0435809789278048115	t
2193	48	Problem Solving	7984381	344	62532	17	0.0415886058673395204	t
2194	48	Supply Management	7984381	344	17740	15	0.0413845963208604797	t
2209	49	APQP	7984381	373	4233	52	0.138886515847592207	t
2210	49	Value Stream Mapping	7984381	373	8075	50	0.133043123109261641	t
2211	49	Vehicles	7984381	373	20721	50	0.131459206860680716	t
2212	49	Process Improvement	7984381	373	108186	45	0.107098730778375562	t
2213	49	SPC	7984381	373	5436	39	0.10388166447409336	t
2214	49	Product Development	7984381	373	108713	41	0.0963083622391724126	t
2215	49	TS 16949	7984381	373	2584	34	0.0908334265558782411	t
2216	49	Kanban	7984381	373	4574	31	0.0825409071151462365	t
2217	49	Quality Management	7984381	373	23788	31	0.0801343464002772093	t
2218	49	DFMEA	7984381	373	2798	28	0.0747200805885495922	t
2219	49	Toyota Production System	7984381	373	1903	26	0.0694699988789654888	t
2220	49	Process Engineering	7984381	373	24975	27	0.0692613126132436419	t
2221	49	JIT	7984381	373	2003	25	0.0667763834435868425	t
2222	49	CATIA	7984381	373	8001	25	0.066025131691334088	t
2223	49	Powertrain	7984381	373	3475	23	0.0612298340951927533	t
2224	49	Poka Yoke	7984381	373	1433	22	0.0588045049641364448	t
2225	49	Manufacturing Operations Management	7984381	373	4312	21	0.0557628187352415608	t
2226	49	TPM	7984381	373	4981	21	0.0556790262340316477	t
2227	49	Supplier Quality	7984381	373	3695	20	0.053159007819096861	t
2228	49	Project Management	7984381	373	479558	41	0.04985988673664285	t
2229	49	DMAIC	7984381	373	3917	18	0.0477690214400785518	t
2230	49	Mechanical Engineering	7984381	373	30057	19	0.0471760670223207793	t
2231	49	5 Why	7984381	373	1451	17	0.0453967984682345158	t
2232	49	Solidworks	7984381	373	18639	17	0.0432439950141297602	t
2233	49	Engineering Management	7984381	373	26924	17	0.0422062956531070801	t
2234	49	Automobile	7984381	373	13346	16	0.0412258548538259884	t
2235	49	Testing	7984381	373	52574	16	0.0363125331236874432	t
2236	49	Operations Management	7984381	373	139638	20	0.0361320960224152943	t
2237	49	GD&T	7984381	373	2099	13	0.0345912746335957783	t
2238	49	SMED	7984381	373	2349	13	0.0345599620397206223	t
2239	49	CAD	7984381	373	35636	14	0.0330718431882598696	t
2240	49	PDCA	7984381	373	656	12	0.0320909205276145928	t
2241	49	Matlab	7984381	373	43522	14	0.0320841187270619332	t
2242	49	Machine Tools	7984381	373	2780	12	0.0318248887300512651	t
2243	49	Injection Molding	7984381	373	3434	12	0.0317429749844738568	t
2244	49	8D Problem Solving	7984381	373	844	11	0.0293862830591918901	t
2245	49	Industrial Engineering	7984381	373	2839	11	0.0291364085600681437	t
2255	50	Negotiation	7984381	596	275641	208	0.314494238328103193	t
2256	50	Sales	7984381	596	353906	206	0.301335288678004354	t
2257	50	New Business Development	7984381	596	289997	200	0.299272272890800106	t
2258	50	Dealer Management	7984381	596	3247	172	0.288205448364462491	t
2259	50	Parts	7984381	596	6008	156	0.261011980772622498	t
2260	50	Dealers	7984381	596	3397	153	0.256305085828893109	t
2261	50	Account Management	7984381	596	240929	161	0.239977103465748243	t
2262	50	B2B	7984381	596	101291	147	0.233975617475644104	t
2264	50	Warranty	7984381	596	3034	112	0.187553471267578847	t
2265	50	Business Planning	7984381	596	140725	110	0.166951184904379574	t
2266	50	Customer Service	7984381	596	670741	149	0.166005754162969088	t
2267	50	Sales Operations	7984381	596	45024	97	0.1571243970575881	t
2268	50	Team Building	7984381	596	154308	103	0.153504018314503748	t
2269	50	Continuous Improvement	7984381	596	68212	94	0.149186077419932256	t
2270	50	Management	7984381	596	738887	141	0.144046382846123866	t
2271	50	Aftersales	7984381	596	1894	84	0.140712887803594422	t
2273	50	Purchasing	7984381	596	49234	74	0.118003593382330102	t
2274	50	Retail	7984381	596	167010	81	0.114997536344565637	t
2275	50	Business Strategy	7984381	596	247930	81	0.104861992864875242	t
2276	50	Pricing	7984381	596	23421	64	0.104456995601819494	t
2277	50	Key Account Management	7984381	596	74920	62	0.0946505911417526574	t
2278	50	Team Leadership	7984381	596	284785	71	0.0834659853119321393	t
2279	50	Strategic Planning	7984381	596	267451	62	0.0705353375371027269	t
2280	50	Automotive Engineering	7984381	596	9172	37	0.0609363427742572183	t
2281	50	Forecasting	7984381	596	72454	41	0.0597219375346909609	t
2282	50	Automotive Repair	7984381	596	2315	35	0.0584392533821687793	t
2283	50	Marketing Strategy	7984381	596	206871	49	0.0563095083834624505	t
2284	50	Manufacturing	7984381	596	84658	37	0.0514814288455880467	t
2285	50	Budgets	7984381	596	165031	42	0.0498042872492821392	t
2286	50	Business Development	7984381	596	206995	45	0.0495820664916242354	t
2287	50	Product Development	7984381	596	108713	37	0.0484684469078229402	t
2288	50	Coaching	7984381	596	219497	45	0.0480161425595544283	t
2290	50	Team Management	7984381	596	150662	38	0.044892149752539752	t
2291	50	Selling	7984381	596	33136	29	0.0445109381160832956	t
2292	50	Automotive Parts	7984381	596	886	26	0.0435164427422321531	t
2293	50	Process Improvement	7984381	596	108186	33	0.0418225452879234169	t
2294	50	Inventory Management	7984381	596	40826	27	0.0401917806197059774	t
2295	50	Marketing	7984381	596	249999	41	0.0374837384849921046	t
2328	52	Customer Service	7984381	438	670741	65	0.0643987217524338712	t
2329	52	Defensive Driving	7984381	438	1819	27	0.0614193851162281174	t
2330	52	Teaching	7984381	438	185728	34	0.0543671381947605711	t
2331	52	Driver Training	7984381	438	773	22	0.0501342467044829446	t
2333	52	Team Leadership	7984381	438	284785	37	0.04880980156245876	t
2334	52	Instructor-led Training	7984381	438	3516	16	0.0360913004820736863	t
2335	52	Personal Development	7984381	438	43723	18	0.0356217781834542724	t
2336	52	Fleet Management	7984381	438	8847	14	0.030857124745774768	t
2337	52	Staff Development	7984381	438	67376	16	0.0280927463841799535	t
2338	52	Continuous Improvement	7984381	438	68212	16	0.0279880362177872336	t
2339	52	Fleet	7984381	438	493	12	0.0273370143528782264	t
2340	52	Road Safety	7984381	438	2023	11	0.024862149443985862	t
2341	52	Motorsports	7984381	438	3552	11	0.0246706400607149649	t
2342	52	Trainers	7984381	438	1140	10	0.022689516151727037	t
2343	52	Courses	7984381	438	7504	10	0.0218924162726322098	t
2344	52	Vehicle Dynamics	7984381	438	1298	9	0.0203864961570581378	t
2360	53	Customer Retention	7984381	456	32444	72	0.153840089535172891	t
2361	53	Profit	7984381	456	23219	71	0.15280242855311954	t
2362	53	Pricing	7984381	456	23421	71	0.152777127714246452	t
2363	53	Operations Management	7984381	456	139638	75	0.146993184331081078	t
2364	53	Product Development	7984381	456	108713	72	0.144287269337087354	t
2365	53	Purchasing	7984381	456	49234	67	0.14077157532935286	t
2366	53	Business Strategy	7984381	456	247930	78	0.140008752784995777	t
2367	53	Parts	7984381	456	6008	60	0.130833950390117776	t
2368	53	Continuous Improvement	7984381	456	68212	61	0.125235902745148703	t
2369	53	Management	7984381	456	738887	99	0.124570826774787438	t
2370	53	Fleet Management	7984381	456	8847	55	0.119512822338351032	t
2371	53	Business Development	7984381	456	206995	62	0.110046206882041323	t
2372	53	Manufacturing	7984381	456	84658	52	0.103438044285147746	t
2373	53	Team Building	7984381	456	154308	54	0.0991004803566640363	t
2374	53	Dealer Management	7984381	456	3247	43	0.0938969392390378299	t
2375	53	Dealers	7984381	456	3397	42	0.0916850437795814349	t
2376	53	Marketing Strategy	7984381	456	206871	53	0.0903237687197009781	t
2377	53	Logistics	7984381	456	69734	39	0.0767969001198625656	t
2378	53	Forecasting	7984381	456	72454	38	0.0742631078490007535	t
2379	53	Supply Chain Management	7984381	456	55114	36	0.0720487565227695137	t
2380	53	Direct Sales	7984381	456	49654	34	0.0683464152667731528	t
2381	53	Customer Service	7984381	456	670741	69	0.0673129963612739551	t
2382	53	Lean Manufacturing	7984381	456	42373	31	0.0626790496078496323	t
2383	53	International Sales	7984381	456	33024	30	0.0616569198338173877	t
2384	53	Contract Negotiation	7984381	456	143599	34	0.0565796464156128609	t
2385	53	Strategic Planning	7984381	456	267451	41	0.056418729597504283	t
2386	53	Team Management	7984381	456	150662	32	0.0513087784011612286	t
2388	53	Automotive Engineering	7984381	456	9172	21	0.0449064534773244151	t
2389	53	Team Leadership	7984381	456	284785	35	0.0410889707712575325	t
2390	53	Supply Chain	7984381	456	54836	21	0.0391869608718703327	t
2391	53	Warranty	7984381	456	3034	17	0.0369028174430979655	t
2392	53	Retail	7984381	456	167010	26	0.0361025177290178814	t
2393	53	Six Sigma	7984381	456	31465	15	0.0289555715819105573	t
2394	53	CRM	7984381	456	102251	19	0.0288619371633208784	t
2402	54	Mechanical Engineering	7984381	384	30057	79	0.201974405736771528	t
2403	54	Product Design	7984381	384	19493	69	0.177254633354383767	t
2404	54	Vehicles	7984381	384	20721	69	0.177100825681359847	t
2405	54	Solidworks	7984381	384	18639	63	0.161735845819142965	t
2407	54	Powertrain	7984381	384	3475	59	0.153217977461143018	t
2408	54	GD&T	7984381	384	2099	55	0.142973154546421621	t
2409	54	Product Development	7984381	384	108713	60	0.142641152201084254	t
2410	54	Pro Engineer	7984381	384	4965	51	0.132197018806808175	t
2411	54	Design Engineering	7984381	384	3932	45	0.116700651119671012	t
2412	54	Continuous Improvement	7984381	384	68212	48	0.116462421641691502	t
2413	54	Design for Manufacturing	7984381	384	7274	45	0.116282063788037501	t
2414	54	Finite Element Analysis	7984381	384	11586	44	0.113137691507566113	t
2415	54	Automotive Design	7984381	384	1550	43	0.111790414090732593	t
2416	54	Teamcenter	7984381	384	1610	42	0.109178607140633946	t
2417	54	Manufacturing Engineering	7984381	384	8612	39	0.10048872705143802	t
2418	54	Lean Manufacturing	7984381	384	42373	35	0.0858429756293537238	t
2419	54	Unigraphics	7984381	384	1638	33	0.0857364728703555318	t
2420	54	APQP	7984381	384	4233	33	0.0854114476981266413	t
2421	54	Matlab	7984381	384	43522	34	0.0830947708324122208	t
2422	54	Motorsports	7984381	384	3552	32	0.082892451404144224	t
2424	54	Geometric Dimensioning & Tolerancing	7984381	384	594	27	0.0702414829392470907	t
2425	54	Injection Molding	7984381	384	3434	26	0.0672814794655275106	t
2426	54	AutoCAD	7984381	384	70871	29	0.0666478340073065334	t
2427	54	PTC Creo	7984381	384	1577	25	0.0649097778160696581	t
2428	54	PPAP	7984381	384	3965	25	0.0646106795072902279	t
2429	54	Engineering Management	7984381	384	26924	26	0.0643393440914786507	t
2430	54	Six Sigma	7984381	384	31465	24	0.0585619975182856412	t
2431	54	Chassis	7984381	384	1194	22	0.0571448730243343805	t
2432	54	Sheet Metal	7984381	384	2326	21	0.0543987974867099766	t
2433	54	Kaizen	7984381	384	12685	20	0.0504970351420890237	t
2434	54	NX Unigraphics	7984381	384	742	19	0.0493886105204156059	t
2435	54	ANSYS	7984381	384	6586	19	0.0486566463175232486	t
2436	54	Composition	7984381	384	26177	19	0.0462028628303801508	t
2437	54	Testing	7984381	384	52574	20	0.0455009160303208246	t
2438	54	Components	7984381	384	1123	17	0.0441323062271733527	t
2439	54	Vehicle Dynamics	7984381	384	1298	17	0.0441103873812619604	t
2440	54	5S	7984381	384	16523	17	0.0422034477869710281	t
2441	54	Electronics	7984381	384	24782	15	0.0359604196760720252	t
2442	54	CFD	7984381	384	4629	14	0.0358803020540129636	t
2443	54	Geometric Dimensioning	7984381	384	277	13	0.0338211005219774818	t
2444	54	CATIA V5	7984381	384	505	12	0.031188251479803912	t
2476	56	Sales Management	7984381	181	180284	82	0.430468848627973966	t
2477	56	Sales Process	7984381	181	48637	78	0.424857339793052624	t
2478	56	Negotiation	7984381	181	275641	80	0.407475661530971145	t
2479	56	Account Management	7984381	181	240929	78	0.400773273762642546	t
2480	56	Automobile	7984381	181	13346	72	0.396127521744949029	t
2481	56	Fleet Management	7984381	181	8847	71	0.391166022507712374	t
2482	56	Customer Retention	7984381	181	32444	68	0.371635599092738522	t
2483	56	Sales	7984381	181	353906	73	0.358998266742562411	t
2484	56	New Business Development	7984381	181	289997	64	0.31727781636688257	t
2485	56	Profit	7984381	181	23219	55	0.300966173385807112	t
2486	56	Business Planning	7984381	181	140725	48	0.247573946804607592	t
2487	56	Management	7984381	181	738887	60	0.238955578842800165	t
2488	56	Automotive Aftermarket	7984381	181	8117	42	0.231032826434417915	t
2489	56	Key Account Management	7984381	181	74920	40	0.211615952556021891	t
2491	56	Operations Management	7984381	181	139638	36	0.181410245178979856	t
2492	56	Customer Service	7984381	181	670741	48	0.181190840169002276	t
2493	56	Dealer Management	7984381	181	3247	30	0.16534293558507332	t
2494	56	Dealers	7984381	181	3397	30	0.165324148480541888	t
2495	56	Purchasing	7984381	181	49234	30	0.159583185077821516	t
2496	56	Parts	7984381	181	6008	29	0.159472140488514547	t
2497	56	Pricing	7984381	181	23421	28	0.151766221021323727	t
2498	56	Business Strategy	7984381	181	247930	29	0.12917204780546554	t
2499	56	Team Building	7984381	181	154308	25	0.118798007971821704	t
2500	56	Forecasting	7984381	181	72454	23	0.118000031415637058	t
2501	56	Business Development	7984381	181	206995	26	0.117724087254648363	t
2502	56	Direct Sales	7984381	181	49654	21	0.109805697052784215	t
2503	56	Team Leadership	7984381	181	284785	25	0.10245610771882202	t
2504	56	Logistics	7984381	181	69734	19	0.096240755741207662	t
2505	56	Continuous Improvement	7984381	181	68212	18	0.0909063951027035272	t
2506	56	Team Management	7984381	181	150662	18	0.0805797499785833871	t
2507	56	Selling	7984381	181	33136	15	0.0787246102488879662	t
2509	56	Contract Hire	7984381	181	369	13	0.0717786163584681891	t
2510	56	Marketing Strategy	7984381	181	206871	17	0.0680147337953784653	t
2512	56	Warranty	7984381	181	3034	12	0.0659198450088095272	t
2513	56	Contract Negotiation	7984381	181	143599	15	0.0648894107298378375	t
2516	56	Vehicle Leasing	7984381	181	517	11	0.0607101054970306669	t
2517	56	Process Improvement	7984381	181	108186	13	0.0582748213633528384	t
2551	57	New Business Development	7984381	281	289997	32	0.0775611969180204641	t
2553	57	Purchase Management	7984381	281	1861	18	0.0638261057196373577	t
2554	57	Six Sigma	7984381	281	31465	19	0.0636770804393661238	t
2555	57	Sales Management	7984381	281	180284	24	0.0628318801411399536	t
2557	57	Automobile	7984381	281	13346	18	0.0623876217327133456	t
2558	57	Project Management	7984381	281	479558	34	0.060936572291521926	t
2586	58	TPM	7984381	94	4981	9	0.0951219577450432147	t
2587	58	Automotive Engineering	7984381	94	9172	9	0.0945970517640833675	t
2588	58	Six Sigma	7984381	94	31465	9	0.0918049427128931894	t
3483	78	Nursing	7984381	36796	21188	5278	0.141437638318305858	t
3484	78	Healthcare	7984381	36796	101770	5574	0.139380054339301035	t
3485	78	Hospitals	7984381	36796	52210	4720	0.122299412405255145	t
3486	78	Patient Safety	7984381	36796	22036	3561	0.0944522180429561709	t
3487	78	Healthcare Management	7984381	36796	39981	3521	0.091102191785069439	t
3488	78	Clinical Research	7984381	36796	55891	3403	0.0858786082199335526	t
3489	78	Critical Care	7984381	36796	9006	1962	0.0524347061811082302	t
3490	78	Acute Care	7984381	36796	6066	1820	0.048927647690938901	t
3491	78	Public Health	7984381	36796	27137	1860	0.0473685097184336143	t
3492	78	Medicine	7984381	36796	29753	1759	0.0442817812905040992	t
3493	78	Inpatient	7984381	36796	6857	1597	0.0427396204115722267	t
3494	78	BLS	7984381	36796	5640	1482	0.0397529391737167712	t
3495	78	Treatment	7984381	36796	32447	1573	0.038864509788399032	t
3496	78	Nursing Education	7984381	36796	3526	1284	0.0346129990205641183	t
3497	78	Pediatrics	7984381	36796	11474	1183	0.0308553749683663572	t
3498	78	Healthcare Information Technology	7984381	36796	17838	1152	0.0292082451435818902	t
3499	78	Health Promotion	7984381	36796	7845	1068	0.0281721821486907546	t
3500	78	Mental Health	7984381	36796	33710	1037	0.0240713509794098224	t
3501	78	Surgery	7984381	36796	16530	956	0.0240214959184708206	t
3502	78	Wound Care	7984381	36796	3176	892	0.0239543825124665342	t
3503	78	Health Education	7984381	36796	5948	697	0.0182815724853533021	t
3504	78	ICU	7984381	36796	3373	670	0.0178683976096104258	t
3505	78	Medical Education	7984381	36796	20275	642	0.0149772384831901809	t
3506	78	Medication Administration	7984381	36796	2196	556	0.0149039860877655094	t
3507	78	Emergency Medicine	7984381	36796	9085	585	0.0148289599467013086	t
3508	78	Patient Education	7984381	36796	2752	542	0.0144517900492361542	t
3509	78	ACLS	7984381	36796	2665	507	0.0135071425705129596	t
3510	78	Palliative Care	7984381	36796	1958	494	0.0132411654224918133	t
3511	78	CPR Certified	7984381	36796	5281	437	0.0112667975771122524	t
3512	78	Nursing Care	7984381	36796	1220	418	0.0112590192699316902	t
3513	78	Home Care	7984381	36796	5132	436	0.0112582427191371993	t
3514	78	Patient Advocacy	7984381	36796	1238	337	0.00904523642464058822	t
3515	78	Infection Control	7984381	36796	1755	335	0.00892557983438841199	t
3516	78	IV	7984381	36796	967	324	0.0087243998444774748	t
3517	78	Registered Nurses	7984381	36796	881	322	0.00868061535877026613	t
3518	78	Case Management	7984381	36796	9038	357	0.00860986004532451887	t
3519	78	Clinical Supervision	7984381	36796	7572	334	0.00816635669164509324	t
3520	78	Rehabilitation	7984381	36796	12244	352	0.0080699536077591047	t
3521	78	Nutrition	7984381	36796	19227	365	0.00754625691146150641	t
3522	78	Orthopedic	7984381	36796	5893	293	0.00725820548625298167	t
3523	78	Medical/Surgical	7984381	36796	820	260	0.00699552377723710369	t
3524	78	Quality Improvement	7984381	36796	3650	272	0.00696707306309387459	t
3525	78	Surgical	7984381	36796	619	252	0.00680239294726078803	t
3526	78	Diabetes	7984381	36796	7155	282	0.00679908550576628981	t
3527	78	Psychiatry	7984381	36796	3927	264	0.00671379817677843042	t
3528	78	Phlebotomy	7984381	36796	1157	244	0.00651627789629155314	t
3529	78	Nursing Management	7984381	36796	680	215	0.00578451807658905345	t
3530	78	Dietetics	7984381	36796	1109	216	0.00575784210658302886	t
3531	78	Clinical Trials	7984381	36796	18615	296	0.00573937572636478745	t
3532	78	EMR	7984381	36796	1966	207	0.00540428638515608097	t
3533	79	Healthcare	7984381	18717	101770	1472	0.066053790186495237	t
3534	79	Hospitals	7984381	18717	52210	882	0.0406792801957162192	t
3535	79	Nursing	7984381	18717	21188	727	0.0362730450717603375	t
3536	79	Patient Safety	7984381	18717	22036	568	0.0276516763735280661	t
3537	79	Mental Health	7984381	18717	33710	562	0.0258648188495718724	t
3538	79	Healthcare Management	7984381	18717	39981	500	0.0217572848886902204	t
3539	79	Home Care	7984381	18717	5132	391	0.0202949203987145901	t
3540	79	Clinical Research	7984381	18717	55891	503	0.0199206210934125758	t
3541	79	Elder Care	7984381	18717	3161	291	0.0151870669673977842	t
3542	79	Public Health	7984381	18717	27137	271	0.01110609031070936	t
3543	79	First Aid	7984381	18717	37379	283	0.0104629566439383287	t
3544	79	Treatment	7984381	18717	32447	265	0.010118161790035253	t
3545	79	Psychology	7984381	18717	26897	240	0.0094760795921445054	t
3546	79	CPR Certified	7984381	18717	5281	177	0.00881589359347276225	t
3547	79	Medication Administration	7984381	18717	2196	161	0.0083463343613461409	t
3548	79	Critical Care	7984381	18717	9006	168	0.00786628537781610196	t
3549	79	Acute Care	7984381	18717	6066	160	0.00780694625233838407	t
3550	79	Social Services	7984381	18717	14219	168	0.00721185154781774865	t
3551	79	Inpatient	7984381	18717	6857	149	0.00711856310418364831	t
3552	79	Medicine	7984381	18717	29753	202	0.00708253037965646259	t
3553	79	BLS	7984381	18717	5640	145	0.00705713222186113692	t
3554	79	Healthcare Information Technology	7984381	18717	17838	171	0.00691818529800524145	t
3555	79	Phlebotomy	7984381	18717	1157	103	0.00537070073768743453	t
3556	79	Palliative Care	7984381	18717	1958	103	0.00527014414880796426	t
3557	79	Data Entry	7984381	18717	27582	161	0.00515940606509864615	t
3558	79	Teamwork	7984381	18717	285884	764	0.00502488099556946954	t
3559	79	Pediatrics	7984381	18717	11474	111	0.00450394004273587008	t
3560	79	Medical Terminology	7984381	18717	3260	91	0.0044640577631138139	t
3561	79	Infection Control	7984381	18717	1755	87	0.00443878205881538101	t
3562	79	Rehabilitation	7984381	18717	12244	102	0.00392529901826377259	t
3563	79	Learning Disabilities	7984381	18717	7064	84	0.0036116377898814285	t
3564	79	Laboratory	7984381	18717	9729	88	0.00349128847158287469	t
3565	79	Case Management	7984381	18717	9038	82	0.00325671836522300247	t
3566	79	Nursing Care	7984381	18717	1220	60	0.00306001690719945535	t
3567	79	Communication	7984381	18717	89342	265	0.00297563104809082588	t
3568	79	Wound Care	7984381	18717	3176	60	0.00281446298978591664	t
3569	79	SPSS	7984381	18717	27885	117	0.00276504001528141098	t
3570	79	Laboratory Skills	7984381	18717	4422	60	0.00265804162930673984	t
3571	79	Microbiology	7984381	18717	8838	69	0.00258563837172024174	t
3572	79	Manual Handling	7984381	18717	3554	55	0.00249924479708335751	t
3573	79	Health Promotion	7984381	18717	7845	63	0.00238898098676061958	t
3574	79	Personal Care	7984381	18717	2546	49	0.00230447049431248925	t
3575	79	Mental Health Care	7984381	18717	999	45	0.0022844674201425684	t
3576	79	Care Planning	7984381	18717	839	42	0.00214389491722837304	t
3577	79	Caring	7984381	18717	849	42	0.00214263952910253696	t
3578	79	Childcare	7984381	18717	5138	52	0.00213973260502334835	t
3579	79	Dementia	7984381	18717	750	41	0.00210151496723912307	t
3580	79	Health Education	7984381	18717	5948	53	0.0020915990711398158	t
3581	79	Emergency Medicine	7984381	18717	9085	59	0.00201910124192018064	t
3582	79	Vital Signs	7984381	18717	454	37	0.00192446283852710739	t
3583	80	Healthcare	7984381	7355	101770	577	0.0657644792486528212	t
3584	80	Mental Health	7984381	7355	33710	511	0.0653147198410611585	t
3585	80	Social Services	7984381	7355	14219	317	0.0413571772630642112	t
3586	80	Case Management	7984381	7355	9038	238	0.0312557714741714746	t
3587	80	Psychology	7984381	7355	26897	229	0.0277921815720045227	t
3588	80	Hospitals	7984381	7355	52210	240	0.0261159040237909298	t
3589	80	Home Care	7984381	7355	5132	184	0.0243967139485298211	t
3590	80	Treatment	7984381	7355	32447	203	0.0235581640004322128	t
3591	80	Nursing	7984381	7355	21188	184	0.0223839337469860372	t
3592	80	Clinical Research	7984381	7355	55891	185	0.0181696528678564409	t
3593	80	Healthcare Management	7984381	7355	39981	169	0.0179867338584304148	t
3594	80	Crisis Intervention	7984381	7355	4923	136	0.0178907242372944621	t
3595	80	Community Outreach	7984381	7355	25161	146	0.0167145614115500711	t
3596	80	Elder Care	7984381	7355	3161	118	0.0156620373299374595	t
3597	80	Group Therapy	7984381	7355	7307	108	0.0137814218525899486	t
3598	80	Learning Disabilities	7984381	7355	7064	102	0.0129953605892466767	t
3599	80	Psychotherapy	7984381	7355	14982	106	0.012547109251407413	t
3600	80	Public Health	7984381	7355	27137	112	0.0118398821639292134	t
3601	80	CBT	7984381	7355	9304	94	0.0116258558581548103	t
3602	80	Adolescents	7984381	7355	7552	87	0.0108928755480539683	t
3603	80	Counseling Psychology	7984381	7355	12739	85	0.00997045863330896232	t
3604	80	Nonprofits	7984381	7355	48047	117	0.00989904096313605486	t
3605	80	Patient Safety	7984381	7355	22036	93	0.00989368501454964203	t
3606	80	Mental Health Counseling	7984381	7355	5966	65	0.00809777611759357127	t
3607	80	Medication Administration	7984381	7355	2196	61	0.00802603416470017324	t
3608	80	Public Speaking	7984381	7355	243457	280	0.00758467123543273003	t
3609	80	Motivational Interviewing	7984381	7355	3708	59	0.00756431525946397228	t
3610	80	Fundraising	7984381	7355	65234	111	0.00692795485469387129	t
3611	80	Child Welfare	7984381	7355	4531	53	0.00664462023336250072	t
3612	80	Interventions	7984381	7355	5582	52	0.00637677957998110823	t
3613	80	Care Planning	7984381	7355	839	45	0.00601875103761927155	t
3614	80	SPSS	7984381	7355	27885	69	0.00589435938352769404	t
3615	80	Autism Spectrum Disorders	7984381	7355	3509	45	0.00568403983071083183	t
3616	80	First Aid	7984381	7355	37379	75	0.00552071526293464697	t
3617	80	Palliative Care	7984381	7355	1958	42	0.00547021132273792839	t
3618	80	Therapists	7984381	7355	10821	50	0.00544784394510155513	t
3619	80	Program Development	7984381	7355	8196	45	0.00509647749858354541	t
3620	80	Volunteer Management	7984381	7355	31484	64	0.00476275228090551877	t
3621	80	CPR Certified	7984381	7355	5281	39	0.00464537816215388876	t
3622	80	Child Development	7984381	7355	7441	40	0.00451068784722704133	t
3623	80	Rehabilitation	7984381	7355	12244	43	0.00431684562678562138	t
3624	80	Community Development	7984381	7355	24499	53	0.00414143170169668957	t
3625	80	Mental Health Care	7984381	7355	999	31	0.00409347136793724361	t
3626	80	Clinical Supervision	7984381	7355	7572	35	0.00381382923357807477	t
3627	80	Inpatient	7984381	7355	6857	32	0.00349519976344207913	t
3628	80	Psychological Assessment	7984381	7355	6468	30	0.00327179022312458403	t
3629	80	Family Therapy	7984381	7355	5098	28	0.00317135884534535794	t
3630	80	Personal Care	7984381	7355	2546	25	0.00308301569996247181	t
3631	80	Acute Care	7984381	7355	6066	28	0.00305001036284072505	t
3632	80	Community Engagement	7984381	7355	31555	51	0.00298471694211577439	t
3633	81	Clinical Research	7984381	26592	55891	6585	0.241434924311920623	t
3634	81	Healthcare	7984381	26592	101770	6565	0.234915010296848831	t
3635	81	Hospitals	7984381	26592	52210	5377	0.196318492873855638	t
3636	81	Medicine	7984381	26592	29753	5050	0.186802484659529117	t
3637	81	Medical Education	7984381	26592	20275	4427	0.164487132249817841	t
3638	81	Healthcare Management	7984381	26592	39981	4149	0.151521609990033002	t
3639	81	Public Health	7984381	26592	27137	2629	0.0957845701808093669	t
3640	81	Clinical Trials	7984381	26592	18615	2508	0.0922900247509155086	t
3641	81	Surgery	7984381	26592	16530	2435	0.0897976722758992152	t
3642	81	Treatment	7984381	26592	32447	2444	0.0881370722038864879	t
3643	81	Patient Safety	7984381	26592	22036	2408	0.0880870356856837955	t
3644	81	Internal Medicine	7984381	26592	6856	1908	0.0711291217786794994	t
3645	81	Healthcare Information Technology	7984381	26592	17838	1868	0.0682398518998012654	t
3646	81	Emergency Medicine	7984381	26592	9085	1819	0.0674909636000855517	t
3647	81	Pediatrics	7984381	26592	11474	1555	0.0572297817068345704	t
3648	81	Critical Care	7984381	26592	9006	1105	0.0405609870608725706	t
3649	81	Oncology	7984381	26592	11598	1088	0.0395938421635183418	t
3650	81	Medical Research	7984381	26592	3816	966	0.0359685751221939451	t
3651	81	Cancer	7984381	26592	6218	879	0.032384139152496022	t
3652	81	Clinical Development	7984381	26592	8406	866	0.0316186859569470152	t
3653	81	Pharmaceutical Industry	7984381	26592	31572	924	0.0308959714048577701	t
3654	81	GCP	7984381	26592	6199	822	0.0302358621517185358	t
3655	81	Nursing	7984381	26592	21188	867	0.030050191869142498	t
3656	81	Epidemiology	7984381	26592	6082	810	0.0297977932335742428	t
3657	81	Research	7984381	26592	383551	2062	0.0296030484223299625	t
3658	81	Medical Devices	7984381	26592	17988	722	0.024981324722990382	t
3659	81	Mental Health	7984381	26592	33710	772	0.0248921982175264386	t
3660	81	Cardiology	7984381	26592	6014	631	0.0230524968617737448	t
3661	81	CRO	7984381	26592	6142	631	0.0230364119919688297	t
3662	81	ICH GCP	7984381	26592	3420	582	0.0215296498657417609	t
3663	81	ICU	7984381	26592	3373	554	0.0204790892084891069	t
3664	81	Informatics	7984381	26592	5075	554	0.0202652107053018539	t
3665	81	Rehabilitation	7984381	26592	12244	570	0.0199680276591149529	t
3666	81	General Surgery	7984381	26592	2981	529	0.0195850751754951084	t
3667	81	Family Medicine	7984381	26592	2839	527	0.0195274574121932117	t
3668	81	CTMS	7984381	26592	3005	485	0.0179218971160887419	t
3669	81	Inpatient	7984381	26592	6857	475	0.0170605334866884006	t
3670	81	Lifesciences	7984381	26592	17493	508	0.0169691029460745414	t
3671	81	Diabetes	7984381	26592	7155	465	0.016645776320465204	t
3672	81	Infectious Diseases	7984381	26592	4813	442	0.016072267141647209	t
3673	81	Orthopedic	7984381	26592	5893	442	0.0159365510526682241	t
3674	81	Board Certified	7984381	26592	1675	419	0.015598785746928542	t
3675	81	Molecular Biology	7984381	26592	22134	478	0.0152539720164750845	t
3676	81	Quality Improvement	7984381	26592	3650	412	0.0150864845272644533	t
3677	81	Clinical Monitoring	7984381	26592	2050	396	0.0146838500738921164	t
3678	81	Clinical Supervision	7984381	26592	7572	412	0.0145936340633981698	t
3679	81	Acute Care	7984381	26592	6066	396	0.0141791872837628476	t
3680	81	Science	7984381	26592	39873	495	0.0136662615387998908	t
3681	81	Life Sciences	7984381	26592	14612	410	0.0136335043083860141	t
3682	81	Drug Development	7984381	26592	5480	379	0.013611399544533824	t
3683	82	Medicine	7984381	4918	29753	834	0.1659569518210742	t
3684	82	Healthcare	7984381	4918	101770	794	0.148793257338488055	t
3685	82	Medical Education	7984381	4918	20275	733	0.146595289978112026	t
3686	82	Family Medicine	7984381	4918	2839	581	0.117854477813812031	t
3687	82	Healthcare Management	7984381	4918	39981	581	0.113199778619141919	t
3688	82	Clinical Research	7984381	4918	55891	550	0.104898649780396397	t
3689	82	Hospitals	7984381	4918	52210	531	0.101494218817200901	t
3690	82	Emergency Medicine	7984381	4918	9085	437	0.0877734768440022045	t
3691	82	Pediatrics	7984381	4918	11474	384	0.0766907027006910463	t
3692	82	Public Health	7984381	4918	27137	378	0.0735070285912848148	t
3693	82	Surgery	7984381	4918	16530	353	0.0697498157729613405	t
3694	82	Internal Medicine	7984381	4918	6856	339	0.0681137379098914753	t
3695	82	Treatment	7984381	4918	32447	302	0.0573786094699114887	t
3696	82	Patient Safety	7984381	4918	22036	260	0.0501380134147063408	t
3697	82	Healthcare Information Technology	7984381	4918	17838	234	0.0453741537046462445	t
3698	82	Primary Care	7984381	4918	1508	200	0.0405030169743881563	t
3699	82	Urgent Care	7984381	4918	491	73	0.0147910478120467908	t
3700	82	General Surgery	7984381	4918	2981	72	0.0142755367273187193	t
3701	82	Sports Medicine	7984381	4918	3503	68	0.0133962787488419652	t
3702	82	Board Certified	7984381	4918	1675	65	0.0130149868147816754	t
3703	82	Epidemiology	7984381	4918	6082	64	0.0122592339995010579	t
3704	82	Mental Health	7984381	4918	33710	79	0.0118487457749379098	t
3705	82	Health Promotion	7984381	4918	7845	63	0.0118348318026768474	t
3706	82	Psychiatry	7984381	4918	3927	59	0.0115120022455111517	t
3707	82	Diabetes	7984381	4918	7155	57	0.0107005437233831571	t
3708	82	Informatics	7984381	4918	5075	53	0.0101473728512693259	t
3709	82	Clinical Trials	7984381	4918	18615	57	0.00926435685216137061	t
3710	82	Critical Care	7984381	4918	9006	51	0.00924781316243374583	t
3711	82	Travel Medicine	7984381	4918	354	42	0.00850095655816130238	t
3712	82	Clinical Governance	7984381	4918	1211	42	0.00839355584711094782	t
3713	82	Physicians	7984381	4918	1378	39	0.00776224708861021455	t
3714	82	Medical Research	7984381	4918	3816	40	0.00766017275436961607	t
3715	82	Dermatology	7984381	4918	2519	39	0.00761925501007059379	t
3716	82	Quality Improvement	7984381	4918	3650	38	0.00727405613808165125	t
3717	82	Obstetrics	7984381	4918	784	34	0.00681938813514585893	t
3718	82	Women'S Health	7984381	4918	836	33	0.00660941139527282309	t
3719	82	General Practice	7984381	4918	178	32	0.00648841307412295273	t
3720	82	Gynecology	7984381	4918	776	32	0.00641347068764907581	t
3721	82	Primary Health Care	7984381	4918	447	31	0.0062512415217669216	t
3722	82	Health Education	7984381	4918	5948	33	0.00596876678046603763	t
3723	82	BLS	7984381	4918	5640	30	0.00539698583730826697	t
3724	82	Orthopedic	7984381	4918	5893	30	0.00536527944303085737	t
3725	82	Inpatient	7984381	4918	6857	30	0.00524446930831377195	t
3726	82	Evidence Based Medicine	7984381	4918	898	26	0.00517742137454804772	t
3727	82	Family Planning	7984381	4918	199	21	0.00424772120131739882	t
3728	82	Prevention	7984381	4918	2968	22	0.00410416537891149322	t
3729	82	ICU	7984381	4918	3373	22	0.00405341008372433597	t
3730	82	Acute Care	7984381	4918	6066	23	0.0039193787117733055	t
3731	82	Contraception	7984381	4918	166	19	0.0038449367967334034	t
3732	82	Healthcare Consulting	7984381	4918	1900	20	0.0038310889509169002	t
3733	83	Surgery	7984381	2824	16530	1169	0.412027279523028978	t
3734	83	Medical Education	7984381	2824	20275	1067	0.375426313194216377	t
3735	83	Hospitals	7984381	2824	52210	1067	0.371425214160531592	t
3736	83	Clinical Research	7984381	2824	55891	1066	0.370609793011194899	t
3737	83	Healthcare	7984381	2824	101770	1063	0.363798967611174751	t
3738	83	Medicine	7984381	2824	29753	938	0.328542776644358048	t
3739	83	Healthcare Management	7984381	2824	39981	788	0.27412638177736165	t
3740	83	Treatment	7984381	2824	32447	523	0.181198579426816636	t
3741	83	Orthopedic	7984381	2824	5893	482	0.170001948784463675	t
3742	83	General Surgery	7984381	2824	2981	478	0.168949858129752439	t
3743	83	Reconstructive Surgery	7984381	2824	1014	423	0.149713489707652053	t
3744	83	Patient Safety	7984381	2824	22036	404	0.140349241946683995	t
3745	83	Healthcare Information Technology	7984381	2824	17838	379	0.132019381048502527	t
3746	83	Cancer	7984381	2824	6218	367	0.129224442092452346	t
3747	83	Emergency Medicine	7984381	2824	9085	360	0.126385608431669905	t
3748	83	Public Health	7984381	2824	27137	356	0.122706962582276716	t
3749	83	Clinical Trials	7984381	2824	18615	331	0.11491885061854501	t
3750	83	Pediatrics	7984381	2824	11474	319	0.111562742958193128	t
3751	83	Sports Medicine	7984381	2824	3503	283	0.0998090345316661604	t
3752	83	Internal Medicine	7984381	2824	6856	263	0.0923042823074165381	t
3753	83	Medical Research	7984381	2824	3816	253	0.0891428309985600464	t
3754	83	Laparoscopic Surgery	7984381	2824	989	223	0.0788700344160025574	t
3755	83	Surgeons	7984381	2824	1499	219	0.0773892053584959716	t
3756	83	Sports Injuries	7984381	2824	7338	206	0.0720526156465298301	t
3757	83	Arthroscopy	7984381	2824	361	201	0.0711555911797270013	t
3758	83	Medical Devices	7984381	2824	17988	204	0.0700098236493201936	t
3759	83	Minimally Invasive Procedures	7984381	2824	581	168	0.0594383406958431532	t
3760	83	Board Certified	7984381	2824	1675	159	0.0561131782692732076	t
3761	83	Knee	7984381	2824	817	156	0.055157977279377525	t
3762	83	Endoscopy	7984381	2824	780	144	0.0509118177156188331	t
3763	83	Trauma Surgery	7984381	2824	365	139	0.0491926478954720567	t
3764	83	Oncology	7984381	2824	11598	141	0.0484937442561035048	t
3765	83	Critical Care	7984381	2824	9006	140	0.0484642599859997844	t
3766	83	Plastic Surgery	7984381	2824	808	137	0.048428679065220949	t
3767	83	Rehabilitation	7984381	2824	12244	122	0.0416823818532178342	t
3768	83	Arthroplasty	7984381	2824	191	108	0.0382332270887893386	t
3769	83	Knee Surgery	7984381	2824	202	103	0.0364606842237592058	t
3770	83	Hip	7984381	2824	372	103	0.0364393851213409628	t
3771	83	Hand Surgery	7984381	2824	199	102	0.0361068271527094989	t
3772	83	Spine	7984381	2824	1114	100	0.0352837219910383457	t
3773	83	Wound Care	7984381	2824	3176	96	0.0336084446573370402	t
3774	83	Microsurgery	7984381	2824	241	86	0.0304338380205163503	t
3775	83	Joint Replacement	7984381	2824	166	82	0.0290263029330960556	t
3776	83	Epidemiology	7984381	2824	6082	81	0.0279308612313784281	t
3777	83	Aesthetics	7984381	2824	3683	79	0.0275229632780251525	t
3778	83	Shoulder	7984381	2824	730	75	0.0264760094656618442	t
3779	83	Research	7984381	2824	383551	205	0.0245630931908941419	t
3780	83	Informatics	7984381	2824	5075	71	0.0245146977153673784	t
3781	83	Teaching	7984381	2824	185728	132	0.0234891024998739456	t
3782	83	Urology	7984381	2824	2519	67	0.0234180042344155973	t
3783	84	Dentistry	7984381	5410	4978	1160	0.213939237099208618	t
3784	84	Healthcare	7984381	5410	101770	916	0.156676105574596436	t
3785	84	Cosmetic Dentistry	7984381	5410	3022	810	0.149445506944305168	t
3786	84	Restorative Dentistry	7984381	5410	2840	749	0.138185255910554472	t
3787	84	Teeth Whitening	7984381	5410	2143	642	0.118481011742838163	t
3788	84	Treatment	7984381	5410	32447	605	0.107839204387783563	t
3789	84	Oral Surgery	7984381	5410	2101	565	0.104243723179022613	t
3790	84	Surgery	7984381	5410	16530	561	0.101695471777986698	t
3791	84	Periodontics	7984381	5410	1603	525	0.0969074087224656572	t
3792	84	Endodontics	7984381	5410	1722	481	0.0887538931469204623	t
3793	84	Prosthodontics	7984381	5410	1830	443	0.0817115654732190333	t
3794	84	Clinical Research	7984381	5410	55891	470	0.0799302721460005555	t
3795	84	Aesthetics	7984381	5410	3683	403	0.0740806014935594115	t
3796	84	Dentures	7984381	5410	1484	396	0.0730614234502057064	t
3797	84	Veneers	7984381	5410	1555	376	0.0693531607998120192	t
3798	84	Patient Education	7984381	5410	2752	358	0.0658737136213366492	t
3799	84	Dental Care	7984381	5410	912	301	0.0555611316578927678	t
3800	84	Orthodontics	7984381	5410	1175	281	0.0518288057542299618	t
3801	84	Healthcare Management	7984381	5410	39981	307	0.0517744448839168175	t
3802	84	Pediatric Dentistry	7984381	5410	869	278	0.05131225192514835	t
3803	84	Hospitals	7984381	5410	52210	304	0.0496868864729160531	t
3804	84	CPR Certified	7984381	5410	5281	250	0.0455801884539283123	t
3805	84	Crowns	7984381	5410	842	212	0.0391077337625951593	t
3806	84	Public Health	7984381	5410	27137	212	0.0358121960297220904	t
3807	84	Health Education	7984381	5410	5948	193	0.0349534055741006072	t
3808	84	Patient Safety	7984381	5410	22036	190	0.0323822008382792584	t
3809	84	Nursing	7984381	5410	21188	187	0.0319335755679052771	t
3810	84	Dental Assisting	7984381	5410	380	168	0.0310270345940778791	t
3811	84	Invisalign	7984381	5410	647	161	0.0296987941415488531	t
3812	84	Implantology	7984381	5410	681	160	0.0295095647274560141	t
3813	84	Dental Surgery	7984381	5410	571	155	0.0285985099013426509	t
3814	84	Root Canal	7984381	5410	546	151	0.0278617702854730281	t
3815	84	Sedation Dentistry	7984381	5410	558	144	0.0265654888411920552	t
3816	84	Infection Control	7984381	5410	1755	130	0.0238259145146890484	t
3817	84	Tooth Colored Fillings	7984381	5410	453	123	0.0226943159599686459	t
3818	84	TMJ Dysfunction	7984381	5410	649	122	0.0224847831759299871	t
3819	84	Practice Management	7984381	5410	1834	114	0.0208565220807148642	t
3820	84	Periodontal Disease	7984381	5410	292	110	0.0203099072315601446	t
3821	84	Oral Care	7984381	5410	279	106	0.0195716636623612036	t
3822	84	Prevention	7984381	5410	2968	92	0.016645097805246041	t
3823	84	Dental Implants	7984381	5410	366	86	0.0158613957408617612	t
3824	84	Pediatrics	7984381	5410	11474	91	0.0153940773406530864	t
3825	84	Local Anesthesia	7984381	5410	150	75	0.0138538165578655	t
3826	84	Medicine	7984381	5410	29753	90	0.012918212218772868	t
3827	84	Sedation	7984381	5410	241	67	0.0123626658745067397	t
3828	84	Cosmetics	7984381	5410	10333	73	0.0122076504025069432	t
3829	84	Dental Software	7984381	5410	158	64	0.0118181635793885922	t
3830	84	Dental Restoration	7984381	5410	190	50	0.00922459805527376525	t
3831	84	Radiography	7984381	5410	843	47	0.00858785328929063778	t
3832	84	Digital Radiography	7984381	5410	191	46	0.00848459987385728059	t
3833	85	Rehabilitation	7984381	3301	12244	654	0.196669596862256324	t
3834	85	Healthcare	7984381	3301	101770	600	0.169086872808023148	t
3835	85	Physical Therapy	7984381	3301	4832	555	0.167594977048013322	t
3836	85	Treatment	7984381	3301	32447	527	0.155649132616086289	t
3837	85	Sports Injuries	7984381	3301	7338	458	0.13788379587400057	t
3838	85	Manual Therapy	7984381	3301	3611	371	0.111984224696860965	t
3839	85	Musculoskeletal	7984381	3301	3627	371	0.111982219955647999	t
3840	85	Hospitals	7984381	3301	52210	351	0.0998336725626023797	t
3841	85	Sports Medicine	7984381	3301	3503	317	0.0956323115103299287	t
3842	85	Injury Prevention	7984381	3301	5426	307	0.0923607286777002184	t
3843	85	Clinical Research	7984381	3301	55891	318	0.0893713513935768672	t
3844	85	Orthopedic	7984381	3301	5893	289	0.0868470668969738291	t
3845	85	Pain Management	7984381	3301	8293	248	0.0741207399228348135	t
3846	85	Musculoskeletal Physiotherapy	7984381	3301	1427	199	0.0601308983051794185	t
3847	85	Exercise Prescription	7984381	3301	2520	189	0.0569633114229724652	t
3848	85	Healthcare Management	7984381	3301	39981	200	0.0556032875596893864	t
3849	85	Pediatrics	7984381	3301	11474	177	0.0522046425239496362	t
3850	85	Biomechanics	7984381	3301	2092	167	0.0503495346546081052	t
3851	85	Podiatry	7984381	3301	424	156	0.0472248271281544493	t
3852	85	Back Pain	7984381	3301	4121	136	0.0407003306154408093	t
3853	85	Wound Care	7984381	3301	3176	133	0.0399095442439029655	t
3854	85	Acupuncture	7984381	3301	2723	126	0.0378448568808279137	t
3855	85	Fitness	7984381	3301	29999	133	0.036548720896686801	t
3856	85	Surgery	7984381	3301	16530	125	0.0358118267105521637	t
3857	85	Medicine	7984381	3301	29753	127	0.0347611609939785723	t
3858	85	Injury	7984381	3301	2686	111	0.0333035358477388535	t
3859	85	Wellness	7984381	3301	22449	108	0.0299181131613163072	t
3860	85	Orthotics	7984381	3301	449	98	0.0296439943310521925	t
3861	85	Neck Pain	7984381	3301	2295	84	0.025169804116271486	t
3862	85	Gait Analysis	7984381	3301	479	83	0.0250942784441338246	t
3863	85	Sports	7984381	3301	36804	97	0.0247857826064003389	t
3864	85	Patient Safety	7984381	3301	22036	90	0.0245147121473031984	t
3865	85	Low Back Pain	7984381	3301	1695	77	0.0231235353130905888	t
3866	85	Strength Training	7984381	3301	9861	78	0.0224034293163313039	t
3867	85	Exercise Physiology	7984381	3301	5783	76	0.0223082601333674906	t
3868	85	Diabetic Foot Care	7984381	3301	221	72	0.0217929030982873112	t
3869	85	Ankle	7984381	3301	301	65	0.0196614327935552419	t
3870	85	Therapeutic Massage	7984381	3301	8119	66	0.0189849299181780277	t
3871	85	Diabetes	7984381	3301	7155	62	0.0178934603770209803	t
3872	85	Shoulder	7984381	3301	730	58	0.0174862340711152975	t
3873	85	Rehabilitation Psychology	7984381	3301	1144	58	0.0174343613922297337	t
3874	85	Public Health	7984381	3301	27137	64	0.0159959167942939351	t
3875	85	Health Promotion	7984381	3301	7845	56	0.0159886231133540835	t
3876	85	Musculoskeletal Injuries	7984381	3301	621	52	0.0156815085717710266	t
3877	85	Neurology	7984381	3301	3689	53	0.0156001632439938861	t
3878	85	Chronic Pain	7984381	3301	2687	52	0.0154226463626464458	t
3879	85	Kinesio Taping	7984381	3301	733	49	0.0147582839838514366	t
3880	85	Therapists	7984381	3301	10821	51	0.0141004222486938967	t
3881	85	Inpatient	7984381	3301	6857	49	0.013990969284587677	t
3882	85	Knee	7984381	3301	817	46	0.0138385676930545421	t
3883	86	Healthcare	7984381	1141	101770	232	0.190611515832066092	t
3884	86	Occupational Therapy	7984381	1141	1653	211	0.184744875527376229	t
3885	86	Rehabilitation	7984381	1141	12244	202	0.175529276120940519	t
3886	86	Treatment	7984381	1141	32447	172	0.146702115801139732	t
3887	86	Hospitals	7984381	1141	52210	173	0.145103103951946727	t
3888	86	Mental Health	7984381	1141	33710	134	0.113235030192811337	t
3889	86	Clinical Research	7984381	1141	55891	109	0.0885428480554579511	t
3890	86	Inpatient	7984381	1141	6857	98	0.0850429218230598083	t
3891	86	Occupational Therapists	7984381	1141	598	96	0.0840738404362924713	t
3892	86	Pediatrics	7984381	1141	11474	94	0.0809583874009213167	t
3893	86	Healthcare Management	7984381	1141	39981	89	0.0730047841990582869	t
3894	86	Acute Care	7984381	1141	6066	84	0.0728703120768070534	t
3895	86	Therapists	7984381	1141	10821	71	0.0608795463744572912	t
3896	86	Traumatic Brain Injury	7984381	1141	1048	60	0.052461692082774937	t
3897	86	Patient Safety	7984381	1141	22036	52	0.0428202886976348646	t
3898	86	Orthopedic	7984381	1141	5893	46	0.0395831033104625876	t
3899	86	Sensory Integration	7984381	1141	358	44	0.0385233319281546027	t
3900	86	Home Care	7984381	1141	5132	39	0.0335425818535932674	t
3901	86	Autism Spectrum Disorders	7984381	1141	3509	36	0.0311162344138138508	t
3902	86	Stroke Rehabilitation	7984381	1141	577	35	0.0306069543915361564	t
3903	86	Learning Disabilities	7984381	1141	7064	33	0.0280412781385240492	t
3904	86	Early Intervention	7984381	1141	1048	32	0.0279183074342676044	t
3905	86	Case Management	7984381	1141	9038	33	0.0277940101120084972	t
3906	86	Cognition	7984381	1141	3629	27	0.0232122578572486228	t
3907	86	Interventions	7984381	1141	5582	26	0.022091070889921044	t
3908	86	Sensory Processing	7984381	1141	159	22	0.0192641712125728969	t
4278	94	Lenses	7984381	1613	585	158	0.097900632534705434	t
3909	86	Cognitive Rehabilitation	7984381	1141	146	21	0.0183892501723626339	t
3910	86	CPR Certified	7984381	1141	5281	19	0.0159929287176529648	t
3911	86	Splinting	7984381	1141	78	18	0.0157681196620504532	t
3912	86	Health Promotion	7984381	1141	7845	19	0.0156717558605172676	t
3913	86	Vocational Rehabilitation	7984381	1141	349	17	0.0148576240932026919	t
3914	86	Clinical Supervision	7984381	1141	7572	18	0.0148294030507497773	t
3915	86	Physical Therapy	7984381	1141	4832	17	0.0142960726429143363	t
3916	86	Psychology	7984381	1141	26897	20	0.0141618055953427521	t
3917	86	Social Services	7984381	1141	14219	18	0.0139967837132376899	t
3918	86	Cerebral Palsy	7984381	1141	285	15	0.0131125419849237954	t
3919	86	Neurology	7984381	1141	3689	15	0.0126861486909729693	t
3920	86	Public Health	7984381	1141	27137	18	0.0123786437099307617	t
3921	86	Assistive Technology	7984381	1141	370	14	0.0122253452270850993	t
3922	86	Developmental Disabilities	7984381	1141	807	14	0.0121706055474562775	t
3923	86	Elder Care	7984381	1141	3161	14	0.011875737799524359	t
3924	86	Geriatric Rehabilitation	7984381	1141	129	13	0.0113789840197246524	t
3925	86	Neurorehabilitation	7984381	1141	158	13	0.0113753514094060357	t
3926	86	Acquired Brain Injury	7984381	1141	341	13	0.0113524283856713121	t
3927	86	Spinal Cord Injury	7984381	1141	521	13	0.0113298811492109266	t
3928	86	Group Therapy	7984381	1141	7307	13	0.0104798503346544315	t
3929	86	Orthopedic Rehabilitation	7984381	1141	354	12	0.0104742505224167688	t
3930	86	Child Development	7984381	1141	7441	12	0.00958651571800151793	t
3931	86	Palliative Care	7984381	1141	1958	11	0.00939678014133738145	t
3932	86	Functional Capacity Evaluations	7984381	1141	52	10	0.00875898087123549302	t
3933	87	Speech Therapy	7984381	542	876	110	0.202856085701788841	t
3934	87	Speech	7984381	542	803	87	0.160426923998883836	t
3935	87	Healthcare	7984381	542	101770	82	0.13855478312886968	t
3936	87	Language Disorders	7984381	542	435	74	0.13648614897098893	t
3937	87	Treatment	7984381	542	32447	70	0.125095974265160004	t
3938	87	Autism Spectrum Disorders	7984381	542	3509	61	0.11211425302494922	t
3939	87	Learning Disabilities	7984381	542	7064	54	0.0987529725923004531	t
3940	87	Rehabilitation	7984381	542	12244	53	0.0962590182104169217	t
3941	87	Clinical Research	7984381	542	55891	55	0.0944823867573785087	t
3942	87	Dysphagia	7984381	542	301	50	0.0922194839995056498	t
3943	87	Pediatrics	7984381	542	11474	50	0.0908200319313965526	t
3944	87	Aphasia	7984381	542	215	46	0.0848496809469628382	t
3945	87	Hospitals	7984381	542	52210	44	0.0746468624135974701	t
3946	87	Therapists	7984381	542	10821	41	0.0742955288289763732	t
3947	87	Early Intervention	7984381	542	1048	35	0.0644487644403388404	t
3948	87	Apraxia	7984381	542	143	29	0.0534912562102986891	t
3949	87	AAC	7984381	542	161	27	0.0497987142493942769	t
3950	87	Traumatic Brain Injury	7984381	542	1048	26	0.0478424711114373916	t
3951	87	Dysarthria	7984381	542	116	25	0.0461140632291764108	t
3952	87	Cognition	7984381	542	3629	23	0.0419837619397083819	t
3953	87	Child Development	7984381	542	7441	21	0.0378160099952359122	t
3954	87	Developmental Disabilities	7984381	542	807	20	0.036801794871621489	t
3955	87	Interventions	7984381	542	5582	19	0.0343585679655801016	t
3956	87	Communication Disorders	7984381	542	129	18	0.0331964290173494894	t
3957	87	Teaching	7984381	542	185728	30	0.0320913169402686493	t
3958	87	Stroke Rehabilitation	7984381	542	577	17	0.031295171958144935	t
3959	87	Articulation	7984381	542	448	15	0.0276210421921758119	t
3960	87	Mental Health	7984381	542	33710	16	0.0253000197189398868	t
3961	87	Healthcare Management	7984381	542	39981	16	0.0245145579880607957	t
3962	87	Acute Care	7984381	542	6066	12	0.0213819395781441705	t
3963	87	Special Education	7984381	542	8622	12	0.02106179284171825	t
3964	87	Language Development	7984381	542	717	11	0.020206774315129402	t
3965	87	Voice Therapy	7984381	542	77	10	0.0184417925490513827	t
3966	87	Voice Disorders	7984381	542	80	10	0.0184414167899710699	t
3967	87	Phonological Disorders	7984381	542	94	9	0.0165945195443850078	t
3968	87	Acquired Brain Injury	7984381	542	341	9	0.0165635820467726416	t
3969	88	Healthcare	7984381	3263	101770	641	0.183773957470861948	t
3970	88	Healthcare Management	7984381	3263	39981	428	0.126211815164907232	t
3971	88	Coaching	7984381	3263	219497	403	0.0960544335924243681	t
3972	88	Training	7984381	3263	286184	427	0.0950570389999588483	t
3973	88	Mental Health	7984381	3263	33710	301	0.0880603940009628272	t
3974	88	Nursing	7984381	3263	21188	286	0.0850304710577602929	t
3975	88	Hospitals	7984381	3263	52210	297	0.0845160560593158361	t
3976	88	Change Management	7984381	3263	341196	412	0.0835653942779278486	t
3977	88	Performance Management	7984381	3263	139406	313	0.0784962374545348091	t
3978	88	Management	7984381	3263	738887	550	0.076046070215006159	t
3979	88	Home Care	7984381	3263	5132	240	0.0729389993544399262	t
3980	88	Social Services	7984381	3263	14219	238	0.0711872535874833456	t
3981	88	Policy	7984381	3263	107537	237	0.059188314988149221	t
3982	88	Leadership Development	7984381	3263	89104	229	0.0590451572640905559	t
3983	88	Leadership	7984381	3263	330397	326	0.058551573419812597	t
3984	88	Team Building	7984381	3263	154308	253	0.0582335762380953026	t
3985	88	Elder Care	7984381	3263	3161	186	0.056630003403473593	t
3986	88	Clinical Research	7984381	3263	55891	180	0.04818360917446423	t
3987	88	Customer Service	7984381	3263	670741	410	0.0416616297085929538	t
3988	88	Case Management	7984381	3263	9038	138	0.0411772369953160161	t
3989	88	Recruiting	7984381	3263	160827	198	0.0405542278081854959	t
3990	88	Patient Safety	7984381	3263	22036	124	0.0352563587794361977	t
3991	88	Learning Disabilities	7984381	3263	7064	115	0.0343729607988069036	t
3992	88	Staff Development	7984381	3263	67376	134	0.0326413677920086853	t
3993	88	Public Sector	7984381	3263	80391	138	0.0322370108265010724	t
3994	88	Strategic Planning	7984381	3263	267451	212	0.0314869803003258661	t
3995	88	Organizational Development	7984381	3263	60426	124	0.0304462557337225534	t
3996	88	Treatment	7984381	3263	32447	95	0.0250607445503052452	t
3997	88	Medication Administration	7984381	3263	2196	82	0.0248653730661941366	t
3998	88	Team Leadership	7984381	3263	284785	196	0.0244096363271322225	t
3999	88	Care Planning	7984381	3263	839	79	0.0241156241578179692	t
4000	88	Budgets	7984381	3263	165031	139	0.0219385720408623273	t
4001	88	Healthcare Information Technology	7984381	3263	17838	78	0.0216791303187292006	t
4002	88	Psychology	7984381	3263	26897	72	0.0187045258815760722	t
4003	88	Personal Development	7984381	3263	43723	73	0.0169028916789543925	t
4004	88	Private Sector	7984381	3263	15879	60	0.0164059333745506866	t
4005	88	Local Government	7984381	3263	41107	69	0.0160042983560437641	t
4006	88	Quality Improvement	7984381	3263	3650	53	0.0157920326839102038	t
4007	88	Infection Control	7984381	3263	1755	52	0.0157228763531755307	t
4008	88	Autism Spectrum Disorders	7984381	3263	3509	49	0.0145833324311183243	t
4009	88	Palliative Care	7984381	3263	1958	47	0.0141644826318695349	t
4010	88	Training Delivery	7984381	3263	66235	73	0.0140822342221920676	t
4011	88	Stakeholder Engagement	7984381	3263	64800	71	0.0136488501183508627	t
4012	88	Public Speaking	7984381	3263	243457	144	0.0136450878673671158	t
4013	88	Child Welfare	7984381	3263	4531	46	0.0135355049828684224	t
4014	88	Medicine	7984381	3263	29753	56	0.0134412134763908248	t
4015	88	Adult Social Care	7984381	3263	1496	44	0.0133025940458191393	t
4016	88	Rehabilitation	7984381	3263	12244	47	0.0128756907608559758	t
4017	88	Residential Homes	7984381	3263	26340	48	0.0114161138990730073	t
4018	88	Crisis Intervention	7984381	3263	4923	39	0.0113402468934274223	t
4019	89	Healthcare	7984381	1855	101770	263	0.12906282549005374	t
4020	89	Emergency Medicine	7984381	1855	9085	235	0.125575964502621179	t
4021	89	First Aid	7984381	1855	37379	234	0.12149226361426578	t
4022	89	Ambulance	7984381	1855	1427	193	0.103888539026543936	t
4023	89	BLS	7984381	1855	5640	183	0.0979686729120831518	t
4024	89	Emergency Services	7984381	1855	4943	168	0.0899678561577370584	t
4025	89	CPR Certified	7984381	1855	5281	162	0.0866902606816783161	t
4026	89	Hospitals	7984381	1855	52210	153	0.0759584150656813506	t
4027	89	ACLS	7984381	1855	2665	140	0.0751553822001745087	t
4028	89	Paramedic	7984381	1855	993	126	0.0678159160656097021	t
4029	89	Medicine	7984381	1855	29753	117	0.0593601670135324652	t
4030	89	Patient Safety	7984381	1855	22036	111	0.0570916506184563494	t
4031	89	Emergency Management	7984381	1855	16166	107	0.05567017149391848	t
4032	89	Healthcare Management	7984381	1855	39981	107	0.0526867800210939624	t
4033	89	Critical Care	7984381	1855	9006	99	0.0522534600243709027	t
4034	89	Pre Hospital Care	7984381	1855	706	82	0.0441266810075730057	t
4035	89	PALS	7984381	1855	672	70	0.037660434331991538	t
4036	89	Emergency Medical	7984381	1855	700	69	0.037117717838801266	t
4037	89	PHTLS	7984381	1855	439	58	0.031219117108565949	t
4038	89	Military	7984381	1855	34073	64	0.0302409168628193434	t
4039	89	Clinical Research	7984381	1855	55891	68	0.0296645321532776271	t
4040	89	Nursing	7984381	1855	21188	59	0.0291590234136027485	t
4041	89	AED	7984381	1855	1017	49	0.0262938294668242332	t
4042	89	Military Experience	7984381	1855	22301	53	0.0257843408751279243	t
4043	89	Command	7984381	1855	21744	52	0.0253149094548581755	t
4044	89	First Responder	7984381	1855	2261	47	0.0250595714092819929	t
4045	89	Training	7984381	1855	286184	112	0.0245400809170260303	t
4046	89	Weapons	7984381	1855	16537	49	0.0243495827459241053	t
4047	89	Pediatrics	7984381	1855	11474	46	0.0233662166344249835	t
4048	89	Military Operations	7984381	1855	21903	48	0.0231381556215376379	t
4049	89	Ems	7984381	1855	692	43	0.0230992904067420859	t
4050	89	Risk Assessment	7984381	1855	63657	57	0.0227603600036695511	t
4051	89	Prehospital Care	7984381	1855	384	42	0.0225986658528702609	t
4052	89	ATLS	7984381	1855	531	42	0.0225802506294184371	t
4053	89	Army	7984381	1855	14871	41	0.0202446179590682028	t
4054	89	Rescue	7984381	1855	3199	38	0.0200891852611276428	t
4055	89	Operational Planning	7984381	1855	21167	40	0.018916686359782435	t
4056	89	Security Clearance	7984381	1855	30049	42	0.0188824236508404776	t
4057	89	Public Health	7984381	1855	27137	41	0.0187080116266866957	t
4058	89	Medical Education	7984381	1855	20275	37	0.0174108039420414022	t
4059	89	Force Protection	7984381	1855	9744	34	0.0171124340334985851	t
4060	89	Disaster Response	7984381	1855	2345	32	0.0169609159507462803	t
4061	89	Firefighting	7984381	1855	4357	32	0.0167088654093512402	t
4062	89	EKG	7984381	1855	500	31	0.0166528369645306124	t
4063	89	Afghanistan	7984381	1855	10732	33	0.0164494548565412881	t
4064	89	Ministry Of Defence	7984381	1855	22404	34	0.0155264698913210337	t
4065	89	Close Protection	7984381	1855	9079	29	0.0144996968388309989	t
4066	89	Security Operations	7984381	1855	15468	29	0.0136993236236357084	t
4067	89	EMT	7984381	1855	172	25	0.0134586737253352389	t
4068	89	CBRN	7984381	1855	1911	25	0.0132408228846364415	t
4069	90	Healthcare	7984381	9524	101770	900	0.0818496073749928749	t
4070	90	Hospitals	7984381	9524	52210	674	0.0643062743950330307	t
4071	90	Healthcare Management	7984381	9524	39981	495	0.0470226491681220715	t
4072	90	Medical Terminology	7984381	9524	3260	416	0.0433225056028288327	t
4073	90	Office Administration	7984381	9524	55039	400	0.0351477518975067404	t
4074	90	Data Entry	7984381	9524	27582	347	0.0330191630562061966	t
4075	90	Healthcare Information Technology	7984381	9524	17838	320	0.0314026742051018506	t
4076	90	Outlook	7984381	9524	88197	390	0.0299387014554295464	t
4077	90	Microsoft Word	7984381	9524	319543	655	0.0287869514122423009	t
4078	90	Administrative Assistants	7984381	9524	23875	295	0.0280175876821233266	t
4079	90	Administration	7984381	9524	46008	295	0.0252422401116277062	t
4080	90	Clinical Research	7984381	9524	55891	303	0.0248439565944539066	t
4081	90	Patient Safety	7984381	9524	22036	258	0.0243586255451215261	t
4082	90	Medical Records	7984381	9524	980	201	0.0210068959061187818	t
4083	90	Microsoft Excel	7984381	9524	428419	709	0.0208112014846013188	t
4084	90	Medicine	7984381	9524	29753	223	0.0197116439961441195	t
4085	90	Office Management	7984381	9524	23264	204	0.0185279837092487583	t
4086	90	Powerpoint	7984381	9524	268322	472	0.0159721996770389799	t
4087	90	Public Health	7984381	9524	27137	183	0.0158347431908494943	t
4088	90	Customer Service	7984381	9524	670741	947	0.0154447968802537555	t
4089	90	Nursing	7984381	9524	21188	159	0.014057753620347389	t
4090	90	Receptionist Duties	7984381	9524	8755	124	0.0119374631455798422	t
4091	90	Diary Management	7984381	9524	13262	126	0.0115825585342834245	t
4092	90	Audio Typing	7984381	9524	3098	102	0.0103341050867487919	t
4093	90	Telephone Skills	7984381	9524	15359	114	0.0100581275811487351	t
4094	90	Surgery	7984381	9524	16530	113	0.0098061677982792441	t
4095	90	Medical Coding	7984381	9524	379	86	0.00899307893290505513	t
4096	90	EMR	7984381	9524	1966	87	0.00889920179355763348	t
4097	90	Secretarial Skills	7984381	9524	4430	79	0.00774924438302576971	t
4098	90	Pediatrics	7984381	9524	11474	87	0.00770695471000491187	t
4099	90	Medical Education	7984381	9524	20275	96	0.00754947090098076826	t
4100	90	Medical Billing	7984381	9524	401	72	0.00751859414478994216	t
4101	90	Confidentiality	7984381	9524	5776	75	0.00715997075059061211	t
4102	90	Medical Transcription	7984381	9524	251	64	0.00669641690636649505	t
4103	90	Time Management	7984381	9524	218895	324	0.006611806224966401	t
4104	90	Spreadsheets	7984381	9524	8817	68	0.00604278423966676023	t
4105	90	Filing	7984381	9524	3627	60	0.00585259325504071653	t
4106	90	Typing	7984381	9524	5258	61	0.00575319877538236438	t
4107	90	Invoicing	7984381	9524	20378	79	0.00574945930850970059	t
4108	90	CPR Certified	7984381	9524	5281	60	0.00564519141698894937	t
4109	90	Inpatient	7984381	9524	6857	60	0.00544757031857928502	t
4110	90	Appointment Scheduling	7984381	9524	865	52	0.00535794540052973289	t
4111	90	ICD 10	7984381	9524	101	39	0.00408714366756347553	t
4112	90	System Administration	7984381	9524	32282	77	0.00404652137792731181	t
4113	90	Informatics	7984381	9524	5075	44	0.00398904989493234063	t
4114	90	Minute Taking	7984381	9524	2636	38	0.0036641463350551638	t
4115	90	Copy Typing	7984381	9524	1386	34	0.00340039578096485882	t
4116	90	Travel Arrangements	7984381	9524	5585	39	0.003399482434264872	t
4117	90	HIPAA	7984381	9524	560	33	0.00339884801175279177	t
4118	90	EHR	7984381	9524	917	32	0.00324895902463550072	t
4119	91	Healthcare	7984381	3557	101770	894	0.238695597400948117	t
4120	91	Healthcare Management	7984381	3557	39981	610	0.166559631157278426	t
4121	91	Hospitals	7984381	3557	52210	526	0.141401401768980362	t
4122	91	Change Management	7984381	3557	341196	551	0.112222883513237504	t
4123	91	Healthcare Information Technology	7984381	3557	17838	356	0.0978938401065656272	t
4124	91	Clinical Research	7984381	3557	55891	287	0.0737187709448403616	t
4125	91	Public Sector	7984381	3557	80391	258	0.0624923409151404152	t
4126	91	Performance Management	7984381	3557	139406	282	0.0618480071936254594	t
4127	91	Project Management	7984381	3557	479558	421	0.0583221356274712804	t
4128	91	Management	7984381	3557	738887	522	0.0542354924599640631	t
4129	91	Policy	7984381	3557	107537	238	0.0534657159731415157	t
4130	91	Patient Safety	7984381	3557	22036	189	0.050397227407117072	t
4131	91	Nursing	7984381	3557	21188	176	0.046847087943514408	t
4132	91	Training	7984381	3557	286184	284	0.0440191953438227798	t
4133	91	Coaching	7984381	3557	219497	249	0.0425309613333771097	t
4134	91	Strategic Planning	7984381	3557	267451	265	0.0410224860156508594	t
4135	91	Public Health	7984381	3557	27137	153	0.0396326711461362224	t
4136	91	Leadership	7984381	3557	330397	281	0.0376355079267821982	t
4137	91	Program Management	7984381	3557	122326	178	0.0347369838361703959	t
4138	91	Governance	7984381	3557	96897	164	0.0339855910622823346	t
4139	91	Medicine	7984381	3557	29753	134	0.033960924754122275	t
4140	91	Practice Management	7984381	3557	1834	118	0.0329590076612402971	t
4141	91	Stakeholder Management	7984381	3557	146503	174	0.0305825530411521496	t
4142	91	Process Improvement	7984381	3557	108186	156	0.0303209867569573036	t
4143	91	Mental Health	7984381	3557	33710	119	0.0292461949552847676	t
4144	91	Team Building	7984381	3557	154308	171	0.0287608005822061197	t
4145	91	Stakeholder Engagement	7984381	3557	64800	125	0.0270381737650957632	t
4146	91	Performance Improvement	7984381	3557	18972	98	0.0251863885712686995	t
4147	91	Leadership Development	7984381	3557	89104	129	0.0251179185377183242	t
4148	91	Customer Service	7984381	3557	670741	386	0.0245227016707543904	t
4149	91	Organizational Development	7984381	3557	60426	113	0.0242111044066357743	t
4150	91	Treatment	7984381	3557	32447	100	0.0240604886012418355	t
4151	91	Informatics	7984381	3557	5075	76	0.0207399435082383891	t
4152	91	Surgery	7984381	3557	16530	81	0.0207109335017560819	t
4153	91	Data Analysis	7984381	3557	113349	124	0.0206737062303142399	t
4154	91	PRINCE2	7984381	3557	53617	94	0.0197203137655568225	t
4155	91	Medical Devices	7984381	3557	17988	75	0.0188406790652679429	t
4156	91	Pharmaceutical Sales	7984381	3557	7573	61	0.0162080269126490609	t
4157	91	Quality Improvement	7984381	3557	3650	59	0.0161370579879352334	t
4158	91	EMR	7984381	3557	1966	57	0.0157855415909303187	t
4159	91	Recruiting	7984381	3557	160827	127	0.0155684797206725734	t
4160	91	Team Leadership	7984381	3557	284785	180	0.0149433372775707243	t
4161	91	Pharmaceutical Industry	7984381	3557	31572	66	0.0146072493794051107	t
4162	91	Cardiology	7984381	3557	6014	54	0.014434542527874232	t
4163	91	Sales Effectiveness	7984381	3557	5655	53	0.0141982642627721343	t
4164	91	Market Access	7984381	3557	5200	47	0.0125677093861289429	t
4165	91	Diabetes	7984381	3557	7155	47	0.0123227472117970697	t
4166	91	Medical Education	7984381	3557	20275	52	0.0120851121310116584	t
4167	91	Product Launch	7984381	3557	12889	48	0.0118855361229176712	t
4168	91	Critical Care	7984381	3557	9006	45	0.0115282940954759532	t
4169	92	Healthcare	7984381	1124	101770	202	0.166992675623397452	t
4170	92	Hospitals	7984381	1124	52210	176	0.150065738761836792	t
4171	92	Clinical Research	7984381	1124	55891	174	0.147825038803174158	t
4172	92	Pathology	7984381	1124	1476	116	0.103032490440155916	t
4173	92	Laboratory Medicine	7984381	1124	897	106	0.0942069674550552044	t
4174	92	Laboratory	7984381	1124	9729	96	0.0842026023006494095	t
4175	92	Public Health	7984381	1124	27137	98	0.0838016486084274398	t
4176	92	Hematology	7984381	1124	2129	94	0.0833749847468247818	t
4177	92	Immunology	7984381	1124	6758	89	0.0783461213299595782	t
4178	92	Molecular Biology	7984381	1124	22134	90	0.0773098953654123566	t
4179	92	Microbiology	7984381	1124	8838	85	0.0745263561313963263	t
4180	92	Biomedical Sciences	7984381	1124	1359	82	0.0727937768789884559	t
4181	92	Healthcare Information Technology	7984381	1124	17838	78	0.0671703618668215569	t
4182	92	PCR	7984381	1124	12065	70	0.0607750604854965029	t
4183	92	Life Sciences	7984381	1124	14612	70	0.0604560177689711514	t
4184	92	Medicine	7984381	1124	29753	66	0.0550002035242604451	t
4185	92	Biochemistry	7984381	1124	16710	60	0.0512951679868000193	t
4186	92	Healthcare Management	7984381	1124	39981	62	0.0501598022619953732	t
4187	92	ELISA	7984381	1124	5154	57	0.0500732825527171813	t
4188	92	Lifesciences	7984381	1124	17493	48	0.0405194279875291177	t
4189	92	Clinical Trials	7984381	1124	18615	45	0.0377094689138277664	t
4190	92	Cancer	7984381	1124	6218	40	0.0348133189997346659	t
4191	92	Science	7984381	1124	39873	44	0.0341568409807740392	t
4192	92	Infectious Diseases	7984381	1124	4813	36	0.0314300924219373529	t
4193	92	Microscopy	7984381	1124	7423	35	0.0302133532119950136	t
4194	92	Histology	7984381	1124	939	31	0.0274663331348778093	t
4195	92	Medical Microbiology	7984381	1124	391	29	0.0257553668425621225	t
4196	92	Data Analysis	7984381	1124	113349	44	0.0249530786567000451	t
4197	92	Cell Culture	7984381	1124	13990	30	0.0249417317328502128	t
4198	92	Immunohistochemistry	7984381	1124	3417	25	0.0218171036424939721	t
4199	92	Serology	7984381	1124	175	24	0.0213333985813958966	t
4200	92	Blood Transfusion	7984381	1124	211	23	0.0204390841662459612	t
4201	92	Histopathology	7984381	1124	318	23	0.0204256811153357871	t
4202	92	Coagulation	7984381	1124	146	22	0.0195574212290579655	t
4203	92	Blood Bank	7984381	1124	152	22	0.0195566696561097313	t
4204	92	Flow Cytometry	7984381	1124	2893	21	0.0183235211034642881	t
4205	92	Immunoassays	7984381	1124	1220	20	0.0176432797164030181	t
4206	92	Clinical Chemistry	7984381	1124	219	19	0.0168788621591395294	t
4207	92	Virology	7984381	1124	1163	19	0.0167606146819507078	t
4208	92	Medical Education	7984381	1124	20275	21	0.0161462142724302857	t
4209	92	Biomedical Engineering	7984381	1124	2721	18	0.0156756512622654061	t
4210	92	Western Blotting	7984381	1124	8273	17	0.0140903907833723162	t
4211	92	Medical Devices	7984381	1124	17988	18	0.0137632738954839053	t
4212	92	Laboratory Skills	7984381	1124	4422	16	0.0136829703765199966	t
4213	92	Haematology	7984381	1124	283	15	0.0133116254711829127	t
4214	92	Patient Safety	7984381	1124	22036	18	0.0132562126797420091	t
4215	92	Laboratory Automation	7984381	1124	812	15	0.0132453617895802785	t
4216	92	Clinical Microbiology	7984381	1124	200	14	0.0124322172528396196	t
4217	92	Cell Biology	7984381	1124	11301	15	0.0119314870139091457	t
4218	92	Epidemiology	7984381	1124	6082	12	0.00991581528433312792	t
4219	93	Healthcare	7984381	1997	101770	519	0.247205528910665273	t
4220	93	Hospitals	7984381	1997	52210	503	0.245400177964536892	t
4221	93	Radiology	7984381	1997	2316	385	0.192547276094950592	t
4222	93	Clinical Research	7984381	1997	55891	377	0.181828610812325708	t
4223	93	Healthcare Management	7984381	1997	39981	345	0.167793704822646411	t
4224	93	Medical Imaging	7984381	1997	3631	324	0.161829077787023629	t
4225	93	Patient Safety	7984381	1997	22036	299	0.14700146556718896	t
4226	93	Healthcare Information Technology	7984381	1997	17838	268	0.132000205137742355	t
4227	93	Medicine	7984381	1997	29753	270	0.131509296101462586	t
4228	93	Medical Education	7984381	1997	20275	235	0.115165986589099142	t
4229	93	MRI	7984381	1997	1328	226	0.113031700637051161	t
4230	93	PACS	7984381	1997	1371	221	0.110521931762443959	t
4231	93	Ultrasound	7984381	1997	1604	186	0.0929620683984993257	t
4232	93	Radiography	7984381	1997	843	124	0.0620030663680663646	t
4233	93	Computed Tomography	7984381	1997	498	117	0.0585401517210501973	t
4234	93	Pediatrics	7984381	1997	11474	112	0.0546607418970724776	t
4235	93	Surgery	7984381	1997	16530	112	0.0540273471618655521	t
4236	93	X-ray	7984381	1997	803	104	0.0519905493514144293	t
4237	93	Cancer	7984381	1997	6218	80	0.0392911469222478812	t
4238	93	Digital Imaging	7984381	1997	2903	75	0.0372020543769177453	t
4239	93	Interventional Radiology	7984381	1997	437	74	0.0370101082388125738	t
4240	93	Informatics	7984381	1997	5075	73	0.0359282024094672928	t
4241	93	Public Health	7984381	1997	27137	70	0.0316617372350259801	t
4242	93	RIS	7984381	1997	405	55	0.0274974654178486017	t
4243	93	Internal Medicine	7984381	1997	6856	55	0.0266893108615155576	t
4244	93	Vascular	7984381	1997	849	53	0.0264400901320511472	t
4245	93	Oncology	7984381	1997	11598	52	0.0245926235379017658	t
4246	93	BLS	7984381	1997	5640	46	0.0223337586812329993	t
4247	93	Inpatient	7984381	1997	6857	42	0.0201777923525409651	t
4248	93	Orthopedic	7984381	1997	5893	40	0.0192968054740163299	t
4249	93	Medical Devices	7984381	1997	17988	42	0.0187833467833977141	t
4250	93	Fluoroscopy	7984381	1997	121	33	0.0165137629053166077	t
4251	93	Emergency Medicine	7984381	1997	9085	35	0.0163925429243366137	t
4252	93	Musculoskeletal Radiology	7984381	1997	71	31	0.0155182738930935635	t
4253	93	Treatment	7984381	1997	32447	39	0.0154693539530581133	t
4254	93	Nuclear Medicine	7984381	1997	340	30	0.0149836982848952482	t
4255	93	Mammography	7984381	1997	114	27	0.0135093814210338337	t
4256	93	DICOM	7984381	1997	546	27	0.0134552622506205824	t
4257	93	Teleradiology	7984381	1997	64	26	0.0130147688113582648	t
4258	93	Nursing	7984381	1997	21188	31	0.0128728236115736548	t
4259	93	Angiography	7984381	1997	117	25	0.0125072527883665734	t
4260	93	Clinical Trials	7984381	1997	18615	29	0.0121934055876668865	t
4261	93	Breast Imaging	7984381	1997	42	23	0.0115148956725794824	t
4262	93	Computed Radiography	7984381	1997	113	23	0.0115060010867013788	t
4263	93	Diagnostic Ultrasound	7984381	1997	154	23	0.011500864776546417	t
4264	93	Board Certified	7984381	1997	1675	23	0.0113103201973830999	t
4265	93	Hardware Diagnostics	7984381	1997	2789	23	0.0111707628921970809	t
4266	93	Neuroradiology	7984381	1997	67	21	0.0105100109710485837	t
4267	93	Critical Care	7984381	1997	9006	23	0.0103919228865045447	t
4268	93	Medical Research	7984381	1997	3816	21	0.0100403517815132268	t
4269	94	Contact Lenses	7984381	1613	1255	418	0.25903960048419189	t
4270	94	Optometry	7984381	1613	1101	388	0.240456249876306732	t
4271	94	Eyewear	7984381	1613	1072	321	0.198913981873185486	t
4272	94	Healthcare	7984381	1613	101770	325	0.188779912697604718	t
4273	94	Glaucoma	7984381	1613	786	273	0.169185581585885397	t
4274	94	Eye Exams	7984381	1613	598	258	0.159907811233207853	t
4275	94	Ocular Disease	7984381	1613	525	219	0.135733521120426442	t
4276	94	Dry Eye	7984381	1613	469	179	0.110937013348451269	t
4277	94	Glass	7984381	1613	2062	164	0.101436137426377235	t
4279	94	Ophthalmology	7984381	1613	1426	151	0.093454664102210816	t
4280	94	Pediatrics	7984381	1613	11474	138	0.0841348079013279487	t
4281	94	Sunglasses	7984381	1613	453	112	0.0693931168375241936	t
4282	94	Cataract	7984381	1613	367	107	0.0663034496826934022	t
4283	94	Low Vision	7984381	1613	311	106	0.0656903767211784312	t
4284	94	Clinical Research	7984381	1613	55891	111	0.0618283198624840977	t
4285	94	Treatment	7984381	1613	32447	91	0.0523633843442606745	t
4286	94	Customer Service	7984381	1613	670741	217	0.0505354997777425763	t
4287	94	Retail	7984381	1613	167010	99	0.0404674046227874867	t
4288	94	Opticians	7984381	1613	357	64	0.0396409152822930141	t
4289	94	Macular Degeneration	7984381	1613	148	44	0.0272653352357555973	t
4290	94	Diabetes	7984381	1613	7155	44	0.0263875695284220037	t
4291	94	Vision Therapy	7984381	1613	107	40	0.0247901190105831448	t
4292	94	Lasik	7984381	1613	163	35	0.0216826635397196071	t
4293	94	Coaching	7984381	1613	219497	79	0.0214906055504685452	t
4294	94	Refractive Surgery	7984381	1613	179	34	0.0210605711503570603	t
4295	94	Diabetic Retinopathy	7984381	1613	192	33	0.0204388545704881665	t
4296	94	Medical Devices	7984381	1613	17988	36	0.0200698168703496438	t
4297	94	Hospitals	7984381	1613	52210	40	0.0182631849947129596	t
4298	94	Refraction	7984381	1613	80	27	0.0167323563592059119	t
4299	94	Cornea	7984381	1613	130	27	0.0167260928676450892	t
4300	94	Optics	7984381	1613	2536	26	0.0158046055816752525	t
4301	94	Patient Education	7984381	1613	2752	24	0.0145373711540063375	t
4302	94	Medicine	7984381	1613	29753	28	0.0136353127295835638	t
4303	94	Pharmacists	7984381	1613	4064	17	0.010032400631008789	t
4304	94	Public Health	7984381	1613	27137	21	0.00962240210360419505	t
4305	94	Store Management	7984381	1613	28277	21	0.00947959449601745371	t
4306	94	Surgery	7984381	1613	16530	18	0.00909087498712772904	t
4307	94	Quality Patient Care	7984381	1613	656	14	0.00859905599960517075	t
4308	94	Practice Management	7984381	1613	1834	14	0.00845148813843220326	t
4309	94	Binocular Vision	7984381	1613	68	13	0.0080526265882973555	t
4310	94	Medical Education	7984381	1613	20275	17	0.00800165139715907671	t
4311	94	Eye	7984381	1613	71	12	0.00743216270674062346	t
4312	94	Dispensing	7984381	1613	285	10	0.00616517881873413984	t
4313	94	Primary Care	7984381	1613	1508	10	0.00601197381515643399	t
4314	94	Orthokeratology	7984381	1613	29	9	0.00557715982346246569	t
4315	94	Retina	7984381	1613	66	9	0.00557252483970745692	t
4316	95	Healthcare	7984381	1522	101770	396	0.247485009355292079	t
4317	95	Pharmacy	7984381	1522	5246	363	0.237890285477783875	t
4318	95	Pharmacists	7984381	1522	4064	319	0.209123511091467484	t
4319	95	Hospitals	7984381	1522	52210	303	0.192577850681705853	t
4320	95	Clinical Research	7984381	1522	55891	247	0.155316030149045547	t
4321	95	Patient Safety	7984381	1522	22036	225	0.145099571120345716	t
4322	95	Clinical Pharmacy	7984381	1522	1763	219	0.14369620450791043	t
4323	95	Medicine	7984381	1522	29753	196	0.125075365590744225	t
4324	95	Healthcare Management	7984381	1522	39981	184	0.11590825446116558	t
4325	95	Community Pharmacy	7984381	1522	2433	163	0.10681156713732276	t
4326	95	Medication Therapy Management	7984381	1522	1574	150	0.0983761513023668904	t
4327	95	Pharmaceutical Industry	7984381	1522	31572	130	0.0814752399069305494	t
4328	95	Hospital Pharmacy	7984381	1522	832	122	0.0800687466873328396	t
4329	95	Patient Counseling	7984381	1522	1484	112	0.0734155167705034528	t
4330	95	Pharmacology	7984381	1522	5992	109	0.0708793403334413291	t
4331	95	Pharmacy Practice	7984381	1522	1330	102	0.0668632531866632795	t
4332	95	Pharmacy Automation	7984381	1522	1368	100	0.0655441820037542255	t
4333	95	Clinical Pharmacology	7984381	1522	1808	97	0.0635175974309602903	t
4334	95	Diabetes	7984381	1522	7155	95	0.0615334762953964401	t
4335	95	Clinical Trials	7984381	1522	18615	88	0.0554978119520275343	t
4336	95	Public Health	7984381	1522	27137	86	0.0531159636362642101	t
4337	95	Pharmaceutics	7984381	1522	7377	82	0.0529626453165679273	t
4338	95	Healthcare Information Technology	7984381	1522	17838	80	0.050337901566975686	t
4339	95	Inpatient	7984381	1522	6857	69	0.0444847634929230462	t
4340	95	Medical Education	7984381	1522	20275	65	0.0401752900914446667	t
4341	95	Pharmaceutical Care	7984381	1522	443	52	0.0341165916706382896	t
4342	95	Patient Education	7984381	1522	2752	52	0.03382734692762078	t
4343	95	Oncology	7984381	1522	11598	45	0.0281191341902491815	t
4344	95	Critical Care	7984381	1522	9006	37	0.023186585957027897	t
4345	95	Evidence Based Medicine	7984381	1522	898	30	0.0196021737277198883	t
4346	95	Pharmacovigilance	7984381	1522	4362	29	0.0185110884871985334	t
4347	95	Informatics	7984381	1522	5075	29	0.0184217721157080676	t
4348	95	Pharmaceutical Sales	7984381	1522	7573	28	0.0174516961526899189	t
4349	95	Prescription	7984381	1522	382	24	0.0157238792730165708	t
4350	95	Medication Reconciliation	7984381	1522	106	21	0.0137869868769227386	t
4351	95	Pediatrics	7984381	1522	11474	22	0.0130200911609972877	t
4352	95	Acute Care	7984381	1522	6066	20	0.0123832317019831484	t
4353	95	Managed Care	7984381	1522	1012	18	0.0117020272282318087	t
4354	95	Infectious Diseases	7984381	1522	4813	18	0.0112258820276213509	t
4355	95	Pharmacy Benefit Management	7984381	1522	260	17	0.0111390735756540706	t
4356	95	Pharmacokinetics	7984381	1522	1160	17	0.0110263320127628808	t
4357	95	Sop	7984381	1522	7907	18	0.0108383015880820829	t
4358	95	Immunization	7984381	1522	271	16	0.0104805401314252457	t
4359	95	Pharmacy Education	7984381	1522	171	15	0.00983591147995300022	t
4360	95	Medical Terminology	7984381	1522	3260	15	0.00944895738242979358	t
4361	95	Pharmacoeconomics	7984381	1522	564	14	0.00912952550569702537	t
4362	95	Mental Health	7984381	1522	33710	20	0.00892031196357864938	t
4363	95	GMP	7984381	1522	13128	15	0.00821280877952950544	t
4364	95	Pharmacy Consulting	7984381	1522	113	12	0.00787171057195885579	t
4365	95	Medicines Management	7984381	1522	122	12	0.00787058315632994249	t
4366	96	Healthcare	7984381	1325	101770	185	0.126897564796956935	t
4367	96	Hospitals	7984381	1325	52210	151	0.107441077277144692	t
4368	96	Nursing	7984381	1325	21188	133	0.0977398973478657979	t
4369	96	Patient Safety	7984381	1325	22036	117	0.085556196420244493	t
4370	96	Public Health	7984381	1325	27137	114	0.0826526913247541406	t
4371	96	Healthcare Management	7984381	1325	39981	109	0.0772695724260965833	t
4372	96	Midwifery	7984381	1325	757	98	0.0738797143103810811	t
4373	96	Clinical Research	7984381	1325	55891	95	0.0647088098630635572	t
4374	96	Treatment	7984381	1325	32447	56	0.0382066822246499224	t
4375	96	Health Education	7984381	1325	5948	49	0.0362421920003926784	t
4376	96	Health Promotion	7984381	1325	7845	48	0.0352497214572162001	t
4377	96	Pediatrics	7984381	1325	11474	43	0.0310209224079997688	t
4378	96	Healthcare Information Technology	7984381	1325	17838	44	0.030978576209316995	t
4379	96	Medicine	7984381	1325	29753	44	0.0294860400176630705	t
4380	96	Nursing Education	7984381	1325	3526	35	0.025977793135672677	t
4381	96	Birth	7984381	1325	491	34	0.0256031311109382494	t
4382	96	Pregnancy	7984381	1325	2222	33	0.0246314546095422575	t
4383	96	Cannulation	7984381	1325	681	29	0.0218051194694513922	t
4384	96	BLS	7984381	1325	5640	28	0.0204290865411431988	t
4385	96	Obstetrics	7984381	1325	784	25	0.0187728481565465066	t
4386	96	Critical Care	7984381	1325	9006	26	0.0184977590082965535	t
4387	96	IV	7984381	1325	967	22	0.0164853978651311774	t
4388	96	Inpatient	7984381	1325	6857	21	0.0149927429314155296	t
4389	96	Maternity	7984381	1325	622	18	0.0135092454119712345	t
4390	96	Surgery	7984381	1325	16530	19	0.0122713670762221554	t
4391	96	Suturing	7984381	1325	128	14	0.0105517574902889606	t
4392	96	Prenatal Care	7984381	1325	302	13	0.00977511907956901856	t
4393	96	Babies	7984381	1325	1051	12	0.00892645311448894002	t
4394	96	Acute Care	7984381	1325	6066	12	0.00829824757515663577	t
4395	96	Lactation	7984381	1325	105	11	0.00829011185313134787	t
4396	96	Childbirth	7984381	1325	200	11	0.00827821164849793477	t
4397	96	Phlebotomy	7984381	1325	1157	10	0.00740349049853627691	t
4409	97	Accounts Receivable	7984381	17806	22858	1736	0.0948438987501669939	t
4411	97	Microsoft Office	7984381	17806	601080	2741	0.0788306972106471021	t
4426	97	Teamwork	7984381	17806	285884	1390	0.0423526192429918014	t
4477	98	Investments	7984381	9558	60931	640	0.059399447189148101	t
4448	98	Banking	7984381	9558	78690	2017	0.201413028928341759	t
4449	98	Relationship Management	7984381	9558	42975	1814	0.184627290243460723	t
4450	98	Management	7984381	9558	738887	2639	0.183782239953203808	t
4451	98	Portfolio Management	7984381	9558	52908	1398	0.139805831452419538	t
4452	98	Commercial Banking	7984381	9558	13155	1331	0.137772408147660674	t
4453	98	Credit	7984381	9558	26674	1324	0.135343949558474147	t
4454	98	Financial Services	7984381	9558	73327	1357	0.132950656934971906	t
4455	98	Credit Risk	7984381	9558	25070	1278	0.130726592069191933	t
4456	98	New Business Development	7984381	9558	289997	1536	0.124531614847768882	t
4457	98	Risk Management	7984381	9558	130308	1327	0.122663051584487329	t
4458	98	Account Management	7984381	9558	240929	1424	0.118952501858618109	t
4459	98	Sales	7984381	9558	353906	1514	0.114213273827087153	t
4460	98	Financial Risk	7984381	9558	46720	1123	0.111775580352213216	t
4461	98	Business Development	7984381	9558	206995	1294	0.109590170225193975	t
4462	98	Retail Banking	7984381	9558	25392	1068	0.10868875845861882	t
4463	98	Credit Analysis	7984381	9558	11704	886	0.0913406978557186749	t
4464	98	Loans	7984381	9558	15537	851	0.0871938174725475496	t
4465	98	Business Strategy	7984381	9558	247930	1070	0.080993187298932609	t
4466	98	Finance	7984381	9558	102182	887	0.0800999920819101402	t
4467	98	Sales Management	7984381	9558	180284	972	0.0792101528965022117	t
4468	98	Corporate Finance	7984381	9558	49388	812	0.0788638418363287186	t
4469	98	Customer Service	7984381	9558	670741	1550	0.0782548579621533125	t
4470	98	Negotiation	7984381	9558	275641	1050	0.0754233807745773727	t
4471	98	Change Management	7984381	9558	341196	1074	0.0697171306686093784	t
4472	98	Strategy	7984381	9558	223349	932	0.0696200413226206877	t
4473	98	B2B	7984381	9558	101291	748	0.0656514974666630308	t
4474	98	Stakeholder Management	7984381	9558	146503	778	0.0631246491295861245	t
4475	98	Business Planning	7984381	9558	140725	771	0.0631159307653550439	t
4476	98	Financial Analysis	7984381	9558	97681	719	0.0630664280920614356	t
4478	98	CRM	7984381	9558	102251	660	0.0563131368316615727	t
4498	99	Accounting	7984381	10390	101909	2918	0.268432733008177216	t
4499	99	Financial Reporting	7984381	10390	76474	2622	0.243096425919691217	t
4500	99	Financial Analysis	7984381	10390	97681	2498	0.228486801471973588	t
4501	99	Finance	7984381	10390	102182	2267	0.205660455893458743	t
4502	99	Financial Accounting	7984381	10390	52966	1965	0.182728238912143265	t
4503	99	Auditing	7984381	10390	53141	1405	0.128738085414970727	t
4504	99	Management Accounting	7984381	10390	27852	1285	0.120344905331790514	t
4505	99	Budgets	7984381	10390	165031	1324	0.106900100377096421	t
4506	99	Microsoft Excel	7984381	10390	428419	1979	0.136992740834941618	t
4546	99	Microsoft Word	7984381	10390	319543	825	0.0394335758978190468	t
4548	100	Investments	7984381	6656	60931	2091	0.306777107971998697	t
4549	100	Portfolio Management	7984381	6656	52908	1752	0.256808799446873348	t
4550	100	Asset Management	7984381	6656	38451	1651	0.243434031112801569	t
4551	100	Equities	7984381	6656	39231	1445	0.212360917749619932	t
4552	100	Fixed Income	7984381	6656	34489	1066	0.15596670974886323	t
4553	100	Investment Management	7984381	6656	10236	1023	0.15254107295249611	t
4554	100	Hedge Funds	7984381	6656	21026	911	0.134347594873990506	t
4555	100	Valuation	7984381	6656	31348	841	0.122528140948854711	t
4556	100	Alternative Investments	7984381	6656	11093	814	0.121007210513974367	t
4557	100	Investment Strategies	7984381	6656	9606	767	0.114126415023941663	t
4558	100	Financial Modeling	7984381	6656	47994	791	0.112923294502306537	t
4559	100	Derivatives	7984381	6656	38143	733	0.105436895134487452	t
4560	100	Asset Allocation	7984381	6656	6176	689	0.102827834934536469	t
4561	100	Financial Markets	7984381	6656	27599	689	0.100142482907486161	t
4566	100	Private Equity	7984381	6656	24099	629	0.0915592604548012001	t
4624	101	Financial Analysis	7984381	7695	97681	824	0.0949400098040131951	t
4627	101	Life Insurance	7984381	7695	6444	626	0.0806221513827699021	t
4628	101	Financial Risk	7984381	7695	46720	618	0.0745322976587834973	t
4633	101	Fixed Annuities	7984381	7695	2426	505	0.0653862037097231036	t
4598	101	Investments	7984381	7695	60931	3081	0.393137478284003417	t
4599	101	Wealth Management	7984381	7695	21921	2873	0.370971365126681385	t
4600	101	Pensions	7984381	7695	21667	2721	0.35123106597221615	t
4601	101	Retirement Planning	7984381	7695	11670	2597	0.336354438058864835	t
4602	101	Financial Services	7984381	7695	73327	2448	0.309242884614499502	t
4603	101	Financial Advisory	7984381	7695	13434	2259	0.292166293720891312	t
4604	101	Strategic Financial Planning	7984381	7695	21890	2020	0.260017112733030409	t
4605	101	Income Protection	7984381	7695	9494	1910	0.247262354622351299	t
4606	101	Inheritance Tax Planning	7984381	7695	10247	1903	0.246257395347986102	t
4607	101	Financial Planning	7984381	7695	14327	1867	0.241063029010917557	t
4608	101	Wealth	7984381	7695	8111	1767	0.228834311874862806	t
4609	101	Retirement	7984381	7695	9007	1749	0.226380546662106164	t
4610	101	Portfolio Management	7984381	7695	52908	1703	0.214893208070931957	t
4611	101	Investment Advisory	7984381	7695	8330	1609	0.208254235624166451	t
4612	101	Finance	7984381	7695	102182	1637	0.200130683850609808	t
4613	101	Investment Strategies	7984381	7695	9606	1249	0.161265512187182602	t
4614	101	Critical Illness	7984381	7695	6444	1240	0.160491198479717906	t
4615	101	Protection	7984381	7695	12288	1154	0.148571693609107464	t
4616	101	Mortgage Lending	7984381	7695	14555	1041	0.133588463786828593	t
4617	101	Banking	7984381	7695	78690	1079	0.130491192811803186	t
4618	101	Estate Planning	7984381	7695	5350	999	0.12927909678323915	t
4619	101	Insurance	7984381	7695	48752	1020	0.126569667544479708	t
4620	101	Savings	7984381	7695	4606	937	0.121307415962178963	t
4621	101	High Net Worth Individuals	7984381	7695	5273	911	0.117841720363523916	t
4622	101	Relationship Management	7984381	7695	42975	923	0.11467615466534492	t
4623	101	Wealth Management Services	7984381	7695	4029	775	0.10030681100180476	t
4625	101	Asset Management	7984381	7695	38451	711	0.0876663726622033401	t
4626	101	Risk Management	7984381	7695	130308	751	0.081353883329020521	t
4629	101	Asset Allocation	7984381	7695	6176	557	0.0716802374881752857	t
4630	101	SIPP	7984381	7695	2027	523	0.0677776623455379201	t
4631	101	Retail Banking	7984381	7695	25392	542	0.0673200187812374451	t
4632	101	Financial Planners	7984381	7695	2567	516	0.0667994058898620929	t
4649	102	Financial Risk	7984381	2693	46720	721	0.261968088186313008	t
4661	102	Investment Banking	7984381	2693	44007	264	0.0925515149647278962	t
4662	102	Portfolio Management	7984381	2693	52908	266	0.0921792540682249972	t
4664	102	Stakeholder Management	7984381	2693	146503	293	0.0904824138181967996	t
4677	102	Financial Analysis	7984381	2693	97681	210	0.0657681201393643944	t
4694	102	Loans	7984381	2693	15537	119	0.0422569656112913028	t
4635	101	Private Banking	7984381	7695	7972	441	0.05636581510004713	t
4636	101	Investment Management	7984381	7695	10236	426	0.0541307897378140931	t
4637	101	Residential Mortgages	7984381	7695	5590	418	0.0536725980850186468	t
4638	101	Holistic Financial Planning	7984381	7695	1116	389	0.0504611660861450373	t
4639	101	Mutual Funds	7984381	7695	8527	390	0.0496621633885048486	t
4640	101	Management	7984381	7695	738887	1048	0.0436928911861770158	t
4641	101	Business Planning	7984381	7695	140725	456	0.0416743875468714303	t
4642	101	Equity Release	7984381	7695	1309	321	0.0415915386483285063	t
4643	101	Equities	7984381	7695	39231	357	0.0415203097244077265	t
4648	102	Risk Management	7984381	2693	130308	951	0.336931042387737356	t
4650	102	Financial Services	7984381	2693	73327	709	0.254177082321753844	t
4651	102	Banking	7984381	2693	78690	685	0.244590168371451255	t
4652	102	Operational Risk	7984381	2693	11219	421	0.154978382446495422	t
4653	102	FSA	7984381	2693	2473	147	0.0542945465557218218	t
4654	102	Management	7984381	2693	738887	560	0.115443914553387081	t
4655	102	Operational Risk Management	7984381	2693	6731	288	0.106136705971212081	t
4656	102	Credit Risk	7984381	2693	25070	292	0.105324905176571532	t
4657	102	Investments	7984381	2693	60931	281	0.0967459538091008098	t
4658	102	Relationship Management	7984381	2693	42975	272	0.0956524779036518613	t
4659	102	Derivatives	7984381	2693	38143	263	0.0929147382785486392	t
4660	102	Retail Banking	7984381	2693	25392	258	0.0926549781659278537	t
4663	102	Governance	7984381	2693	96897	279	0.0914969726826130869	t
4665	102	Compliance	7984381	2693	11410	244	0.089206320728228608	t
4758	104	Financial Reporting	7984381	3097	76474	448	0.135130583835562007	t
4761	104	Tax Preparation	7984381	3097	4739	279	0.0895283738132937046	t
4781	104	Trusts	7984381	3097	7284	117	0.0368805195036319006	t
4748	104	Tax	7984381	3097	27555	1303	0.417440543384700213	t
4749	104	Corporate Tax	7984381	3097	15335	1047	0.336278910983022927	t
4750	104	Tax Advisory	7984381	3097	8167	1005	0.323610238639574332	t
4751	104	Income Tax	7984381	3097	13691	954	0.306444180236188246	t
4752	104	Accounting	7984381	3097	101909	860	0.265027340431295499	t
4753	104	International Tax	7984381	3097	4823	672	0.216464086482343526	t
4754	104	Tax Accounting	7984381	3097	5246	635	0.204459406117712794	t
4755	104	Tax Returns	7984381	3097	8095	553	0.177614935938559787	t
4756	104	IFRS	7984381	3097	20168	278	0.087272207798986548	t
4757	104	Financial Accounting	7984381	3097	52966	450	0.138722011408201618	t
4759	104	Auditing	7984381	3097	53141	388	0.118672943350645946	t
4760	104	Tax Law	7984381	3097	2816	313	0.100751938616317968	t
4762	104	Big 4	7984381	3097	5201	274	0.0878553963128479443	t
4763	104	VAT	7984381	3097	17993	549	0.175082710942514791	t
4764	104	Partnership Taxation	7984381	3097	1678	249	0.0802213435986056378	t
4765	104	Financial Analysis	7984381	3097	97681	261	0.0720690488720932831	t
4766	104	Due Diligence	7984381	3097	37983	236	0.0714733373570865804	t
4767	104	Transfer Pricing	7984381	3097	1892	212	0.0682428494967366461	t
4768	104	Inheritance Tax Planning	7984381	3097	10247	212	0.0671960254518837174	t
4769	104	Expatriate Tax	7984381	3097	986	204	0.0657722177424138604	t
4770	104	Finance	7984381	3097	102182	230	0.0614915336437991816	t
4771	104	Restructuring	7984381	3097	24781	191	0.0585916284729008224	t
4772	104	Bookkeeping	7984381	3097	20608	164	0.0503929794577792217	t
4773	104	Personal Tax Planning	7984381	3097	1175	150	0.0483055429051305885	t
4774	104	Microsoft Excel	7984381	3097	428419	299	0.0429045516596992457	t
4775	104	Indirect Taxation	7984381	3097	1139	127	0.0408806299010736479	t
4776	104	Internal Controls	7984381	3097	28669	137	0.0406614943726718858	t
4777	104	Payroll	7984381	3097	31714	138	0.0406029952278392434	t
4778	104	High Net Worth Individuals	7984381	3097	5273	127	0.0403626681295090745	t
4779	104	UK GAAP	7984381	3097	6183	125	0.039602614556341259	t
4780	104	Mergers & Acquisitions	7984381	3097	36659	135	0.0390143654868100251	t
4788	104	Capital Gains Tax	7984381	3097	464	87	0.0280444661392851985	t
4828	105	Statistics	7984381	13821	36968	527	0.033558431528640402	t
4853	106	Credit Analysis	7984381	1586	11704	305	0.190879746331376998	t
4798	105	Financial Analysis	7984381	13821	97681	1915	0.126542302854157435	t
4799	105	Microsoft Excel	7984381	13821	428419	2434	0.122664018040843675	t
4800	105	Financial Modeling	7984381	13821	47994	1700	0.117193106116363077	t
4801	105	Analysis	7984381	13821	128547	1752	0.110855704446018832	t
4802	105	Data Analysis	7984381	13821	113349	1715	0.110080743670968623	t
4803	105	Economics	7984381	13821	30444	1383	0.0964190758620767085	t
4804	105	Corporate Finance	7984381	13821	49388	1354	0.0919404347692729662	t
4805	105	Valuation	7984381	13821	31348	1259	0.0873182468110241389	t
4806	105	Microsoft Office	7984381	13821	601080	2236	0.0866508085911279619	t
4807	105	Research	7984381	13821	383551	1784	0.0811818013860211851	t
4808	105	Investment Banking	7984381	13821	44007	1171	0.0793518640384473783	t
4809	105	Teamwork	7984381	13821	285884	1510	0.0735759885104483591	t
4810	105	Bloomberg	7984381	13821	19492	1024	0.0717731260081307387	t
4811	105	Investments	7984381	13821	60931	1042	0.0678787429365126926	t
4812	105	Equities	7984381	13821	39231	1002	0.0677020967494654236	t
4848	106	Credit Risk	7984381	1586	25070	401	0.249747055593718736	t
4849	106	Financial Analysis	7984381	1586	97681	398	0.238759191764215423	t
4850	106	Risk Management	7984381	1586	130308	390	0.229626888458137834	t
4851	106	Banking	7984381	1586	78690	343	0.206452856947224955	t
4852	106	Credit	7984381	1586	26674	308	0.190896390180910897	t
4854	106	Financial Risk	7984381	1586	46720	286	0.174511109183696389	t
4855	106	Portfolio Management	7984381	1586	52908	275	0.166798876862926604	t
4859	106	Financial Modeling	7984381	1586	47994	217	0.130837197716181991	t
4864	106	Capital Markets	7984381	1586	31475	160	0.0969599123370688959	t
4875	106	Teamwork	7984381	1586	285884	161	0.0657208899327957063	t
4921	107	Strategic Financial Planning	7984381	2375	21890	173	0.0701213606282879015	t
4923	107	Risk Management	7984381	2375	130308	196	0.0662256515203663992	t
4898	107	Mortgage Lending	7984381	2375	14555	949	0.397874363332778869	t
4899	107	Residential Mortgages	7984381	2375	5590	695	0.292018324584993827	t
4900	107	Financial Services	7984381	2375	73327	700	0.28563800153811747	t
4901	107	Banking	7984381	2375	78690	586	0.236951833173924348	t
4902	107	Loans	7984381	2375	15537	474	0.197691827764652273	t
4903	107	Income Protection	7984381	2375	9494	437	0.182865322827369448	t
4904	107	Finance	7984381	2375	102182	460	0.180940296277190937	t
4905	107	Insurance	7984381	2375	48752	436	0.177525832399577393	t
4906	107	Credit	7984381	2375	26674	356	0.146597570691140211	t
4907	107	Investments	7984381	2375	60931	363	0.145254037802421826	t
4908	107	Relationship Management	7984381	2375	42975	341	0.138237683530734151	t
4909	107	Critical Illness	7984381	2375	6444	329	0.137760217643218219	t
4910	107	Retail Banking	7984381	2375	25392	320	0.131595777064720726	t
4911	107	Financial Advisory	7984381	2375	13434	312	0.129724473403381502	t
4912	107	Sales	7984381	2375	353906	409	0.127923789372720281	t
4913	107	Life Insurance	7984381	2375	6444	275	0.115016610321291485	t
4914	107	Customer Service	7984381	2375	670741	452	0.106340783691929605	t
4915	107	Protection	7984381	2375	12288	249	0.103333837792549621	t
4916	107	Wealth Management	7984381	2375	21921	240	0.0983363970885197669	t
4917	107	Portfolio Management	7984381	2375	52908	242	0.0952966460864731607	t
4918	107	Commercial Mortgages	7984381	2375	1927	210	0.0882059437980350913	t
4919	107	Pensions	7984381	2375	21667	203	0.0827846358685431077	t
4920	107	Financial Planning	7984381	2375	14327	183	0.0752806459402495382	t
4922	107	Refinance	7984381	2375	2182	160	0.0671151012731175112	t
4924	107	Mortgage Banking	7984381	2375	1144	141	0.059242763417195074	t
4925	107	Buy To Let	7984381	2375	1014	139	0.0584166942231656647	t
4926	107	Mortgage Marketing	7984381	2375	829	137	0.0575975155275899042	t
4927	107	General Insurance	7984381	2375	22948	141	0.0565111192665893186	t
4928	107	Retirement Planning	7984381	2375	11670	135	0.0553969798147430498	t
4929	107	Financial Risk	7984381	2375	46720	137	0.0518482088996570292	t
4939	107	First Time Home Buyers	7984381	2375	1890	82	0.0342998063130338024	t
4969	108	Hedge Funds	7984381	2911	21026	213	0.0705630667032513953	t
5003	109	External Audit	7984381	5582	12659	1262	0.224655430450946991	t
4948	108	Investment Banking	7984381	2911	44007	806	0.271468134898444458	t
4949	108	Financial Modeling	7984381	2911	47994	807	0.271312252709563884	t
4950	108	Corporate Finance	7984381	2911	49388	717	0.240209111467111741	t
4951	108	Valuation	7984381	2911	31348	685	0.231472551466348014	t
4952	108	Financial Analysis	7984381	2911	97681	695	0.226598174924076357	t
4953	108	Equities	7984381	2911	39231	571	0.191308805640783786	t
4954	108	Bloomberg	7984381	2911	19492	474	0.160447873302028782	t
4955	108	Investments	7984381	2911	60931	457	0.149413925074376064	t
4956	108	Capital Markets	7984381	2911	31475	430	0.143825927297059536	t
4957	108	Finance	7984381	2911	102182	407	0.127063086282051513	t
4958	108	Economics	7984381	2911	30444	376	0.125398009477480393	t
4959	108	Private Equity	7984381	2911	24099	336	0.112446981729882545	t
4960	108	Equity Research	7984381	2911	5054	318	0.108647436314504311	t
4961	108	Microsoft Excel	7984381	2911	428419	467	0.106807777317027466	t
4962	108	Derivatives	7984381	2911	38143	298	0.0976287117288941741	t
4963	108	Portfolio Management	7984381	2911	52908	299	0.0961224517274051476	t
4998	109	Auditing	7984381	5582	53141	2154	0.379492885866493046	t
4999	109	Accounting	7984381	5582	101909	2148	0.372305052230375744	t
5000	109	Financial Reporting	7984381	5582	76474	1733	0.301094750015139911	t
5001	109	Financial Accounting	7984381	5582	52966	1686	0.295615246313791713	t
5002	109	Internal Controls	7984381	5582	28669	1346	0.237707760456034339	t
5063	110	Management	7984381	1876	738887	345	0.0913818391269246993	t
5068	110	Investments	7984381	1876	60931	146	0.0702103823480210026	t
5048	110	Banking	7984381	1876	78690	757	0.393755148260534538	t
5049	110	Retail Banking	7984381	1876	25392	591	0.311925063497970556	t
5050	110	Credit	7984381	1876	26674	509	0.268044168496631374	t
5051	110	Relationship Management	7984381	1876	42975	474	0.247340976692861481	t
5052	110	Financial Services	7984381	1876	73327	432	0.221145340297085657	t
5053	110	Loans	7984381	1876	15537	417	0.220387307641052105	t
5054	110	Risk Management	7984381	1876	130308	427	0.211341233296131636	t
5055	110	Mortgage Lending	7984381	1876	14555	390	0.206114620177591495	t
5056	110	Credit Risk	7984381	1876	25070	381	0.199998795673858587	t
5057	110	Portfolio Management	7984381	1876	52908	329	0.168786354865019333	t
5058	110	Financial Risk	7984381	1876	46720	318	0.163696632660970509	t
5059	110	Commercial Banking	7984381	1876	13155	292	0.154038920901393567	t
5060	110	Customer Service	7984381	1876	670741	416	0.137774134629431055	t
5061	110	Finance	7984381	1876	102182	241	0.115694266161104231	t
5062	110	Credit Analysis	7984381	1876	11704	201	0.105701830798370033	t
5064	110	Wealth Management	7984381	1876	21921	172	0.0889598516448622395	t
5065	110	Cross Selling	7984381	1876	4344	153	0.081031480038271167	t
5066	110	Private Banking	7984381	1876	7972	148	0.0779111145445257475	t
5067	110	Sales	7984381	1876	353906	223	0.0745626665742150085	t
5069	110	Branch Banking	7984381	1876	2506	128	0.0679323757122166777	t
5070	110	Residential Mortgages	7984381	1876	5590	128	0.0675460308242397806	t
5071	110	Credit Cards	7984381	1876	9868	119	0.0622115399995963186	t
5072	110	Coaching	7984381	1876	219497	168	0.0620760267647625236	t
5073	110	Insurance	7984381	1876	48752	122	0.0589399103411608061	t
5074	110	Financial Analysis	7984381	1876	97681	126	0.0549430780841838606	t
5075	110	Team Management	7984381	1876	150662	134	0.0525713330052945196	t
5076	110	Commercial Lending	7984381	1876	3367	94	0.0496965881419712263	t
5077	110	Consumer Lending	7984381	1876	1447	83	0.0440721966830957546	t
5078	110	Team Leadership	7984381	1876	284785	149	0.0437668285880659716	t
5080	110	Customer Experience	7984381	1876	42804	86	0.0404907645253195017	t
5113	111	Derivatives	7984381	2300	38143	281	0.117430538477372004	t
5115	111	Fixed Income	7984381	2300	34489	234	0.0974476430394529969	t
5148	112	Accounting	7984381	1440	101909	407	0.269924026033206976	t
5098	111	Business Analysis	7984381	2300	148418	1090	0.455455701339036734	t
5099	111	Stakeholder Management	7984381	2300	146503	571	0.229978419161619652	t
5100	111	Requirements Gathering	7984381	2300	25858	515	0.220738056905210561	t
5101	111	Banking	7984381	2300	78690	497	0.206290889556244778	t
5102	111	Requirements Analysis	7984381	2300	57261	473	0.198537738466948638	t
5103	111	Financial Services	7984381	2300	73327	434	0.179563572456856807	t
5104	111	Analysis	7984381	2300	128547	427	0.169601221786649381	t
5105	111	Project Delivery	7984381	2300	94365	416	0.169099576914842148	t
5106	111	Change Management	7984381	2300	341196	485	0.168185082311241907	t
5107	111	Risk Management	7984381	2300	130308	418	0.16546643162353275	t
5108	111	Business Requirements	7984381	2300	9511	368	0.15885455935613782	t
5109	111	User Acceptance Testing	7984381	2300	19596	361	0.154546749149751805	t
5110	111	Business Process Improvement	7984381	2300	81006	364	0.148157990378699506	t
5111	111	Project Management	7984381	2300	479558	471	0.144762295697074495	t
5112	111	Investment Banking	7984381	2300	44007	293	0.121914787634953836	t
5114	111	Business Process	7984381	2300	48555	272	0.112211945731946344	t
5116	111	Equities	7984381	2300	39231	228	0.0942441150371688685	t
5149	112	Microsoft Excel	7984381	1440	428419	424	0.240830744931946505	t
5150	112	Teamwork	7984381	1440	285884	367	0.219095219818666365	t
5151	112	Microsoft Office	7984381	1440	601080	387	0.193502920007801615	t
5154	112	Financial Analysis	7984381	1440	97681	231	0.148209386166911011	t
5167	112	Liquidation	7984381	1440	1957	105	0.0726846719669689001	t
5187	112	Communication	7984381	1440	89342	72	0.0388174045129483017	t
5193	112	Business Advisory	7984381	1440	3156	47	0.0322494334237915029	t
5198	113	Derivatives	7984381	144	38143	53	0.363284905586122031	t
5199	113	Quantitative Finance	7984381	144	3852	52	0.360635173335215942	t
5200	113	C++	7984381	144	41117	42	0.286522155049589167	t
5201	113	Fixed Income	7984381	144	34489	40	0.273463151345721744	t
5202	113	VBA	7984381	144	13934	38	0.262148459590510086	t
5203	113	Matlab	7984381	144	43522	35	0.23760894869756774	t
5204	113	Equities	7984381	144	39231	31	0.210368103879069623	t
5205	113	Quantitative Analytics	7984381	144	3972	29	0.200895040823006077	t
5206	113	Market Risk	7984381	144	6726	27	0.18666097179981006	t
5207	113	Bloomberg	7984381	144	19492	27	0.185062071366368514	t
5208	113	Financial Modeling	7984381	144	47994	27	0.181492287553588399	t
5209	113	Interest Rate Derivatives	7984381	144	5872	24	0.165934223478920589	t
5210	113	Risk Management	7984381	144	130308	26	0.164238154155772448	t
5211	113	Statistics	7984381	144	36968	23	0.1550949798194729	t
5212	113	Equity Derivatives	7984381	144	10334	20	0.137597093567682877	t
5213	113	Investment Banking	7984381	144	44007	19	0.126435088948108343	t
5214	113	Financial Markets	7984381	144	27599	18	0.121545568474482904	t
5215	113	Financial Risk	7984381	144	46720	18	0.119150724734248245	t
5216	113	Structured Products	7984381	144	10212	17	0.116778664601542043	t
5217	113	FX Options	7984381	144	13675	17	0.116344934991561774	t
5218	113	Capital Markets	7984381	144	31475	17	0.114115542251842242	t
5219	113	Portfolio Management	7984381	144	52908	17	0.111431127949010306	t
5220	113	Credit Derivatives	7984381	144	6124	16	0.110346103759751166	t
5221	113	Options	7984381	144	9365	16	0.109940178935625826	t
5222	113	Python	7984381	144	19693	16	0.108646630159455984	t
5223	113	Credit Risk	7984381	144	25070	16	0.10797317820656431	t
5224	113	SQL	7984381	144	74090	16	0.101833580897516499	t
5225	113	Hedge Funds	7984381	144	21026	15	0.101535106506315725	t
5373	116	Retail	7984381	1454	167010	62	0.0217278591351898163	t
5226	113	Stochastic Calculus	7984381	144	583	13	0.0902063871113935045	t
5231	113	Latex	7984381	144	12672	12	0.0817477090589036059	t
5233	113	R	7984381	144	14529	12	0.0815151257826306069	t
5245	114	Portfolio Management	7984381	2840	52908	381	0.127573869604208995	t
5252	114	Investments	7984381	2840	60931	276	0.0895836889036206035	t
5263	114	Financial Advisory	7984381	2840	13434	104	0.0349496147546684982	t
5278	114	Capital Markets	7984381	2840	31475	71	0.0210654214518223998	t
5243	114	Banking	7984381	2840	78690	598	0.200779304750411142	t
5244	114	Retail Banking	7984381	2840	25392	383	0.131725800104989077	t
5246	114	Private Banking	7984381	2840	7972	345	0.1205232933583084	t
5247	114	Credit	7984381	2840	26674	310	0.105851808037401282	t
5248	114	Relationship Management	7984381	2840	42975	312	0.104513946529344981	t
5249	114	Wealth Management	7984381	2840	21921	278	0.0951756921923497812	t
5250	114	Financial Services	7984381	2840	73327	289	0.092609698904361562	t
5251	114	Loans	7984381	2840	15537	260	0.0896352543633464893	t
5253	114	Credit Risk	7984381	2840	25070	247	0.0838617799318646523	t
5254	114	Risk Management	7984381	2840	130308	279	0.0819482216776413336	t
5255	114	Financial Risk	7984381	2840	46720	242	0.0793880813312038414	t
5256	114	Commercial Banking	7984381	2840	13155	214	0.0737307465764522607	t
5257	114	Finance	7984381	2840	102182	221	0.0650423006139424636	t
5258	114	Mortgage Lending	7984381	2840	14555	178	0.0608747751067471449	t
5293	115	Equities	7984381	1240	39231	339	0.268515330134972197	t
5294	115	Financial Markets	7984381	1240	27599	279	0.221577788116231439	t
5295	115	Derivatives	7984381	1240	38143	256	0.201705736562071358	t
5296	115	Trading	7984381	1240	23464	247	0.196285294605784366	t
5297	115	Bloomberg	7984381	1240	19492	231	0.183877613096997045	t
5298	115	Capital Markets	7984381	1240	31475	227	0.179150267338988339	t
5319	115	Corporate Finance	7984381	1240	49388	64	0.0454343827662530009	t
5338	115	Equity Sales	7984381	1240	86	21	0.0169273417123863013	t
5345	116	Customer Service	7984381	1454	670741	349	0.156049290297571003	t
5367	116	Financial Analysis	7984381	1454	97681	64	0.031788284636498701	t
5343	116	Banking	7984381	1454	78690	368	0.243283722289236309	t
5344	116	Retail Banking	7984381	1454	25392	334	0.22657219276878815	t
5346	116	Credit	7984381	1454	26674	198	0.132859488032752104	t
5347	116	Loans	7984381	1454	15537	187	0.126687875413423412	t
5348	116	Sales	7984381	1454	353906	207	0.0980589556774508764	t
5349	116	Financial Services	7984381	1454	73327	152	0.0953727648777732556	t
5350	116	Finance	7984381	1454	102182	140	0.0835035777744309177	t
5351	116	Relationship Management	7984381	1454	42975	128	0.0826656828274618255	t
5352	116	Financial Risk	7984381	1454	46720	117	0.074629841711492742	t
5353	116	Credit Risk	7984381	1454	25070	110	0.0725266973033570767	t
5354	116	Teamwork	7984381	1454	285884	155	0.0708099652365928589	t
5355	116	Commercial Banking	7984381	1454	13155	101	0.0678283090246602494	t
5356	116	Risk Management	7984381	1454	130308	112	0.0607195797343109411	t
5357	116	Portfolio Management	7984381	1454	52908	90	0.0552818416684662528	t
5358	116	Credit Cards	7984381	1454	9868	80	0.0537945160510033826	t
5359	116	Customer Experience	7984381	1454	42804	79	0.0489808278908907407	t
5360	116	Cross Selling	7984381	1454	4344	71	0.0482955442269478175	t
5361	116	Mortgage Lending	7984381	1454	14555	69	0.0456406731043774577	t
5362	116	Credit Analysis	7984381	1454	11704	67	0.0446220439266476407	t
5363	116	Time Management	7984381	1454	218895	103	0.0434315736374880079	t
5364	116	Branch Banking	7984381	1454	2506	52	0.0354560052363083605	t
5365	116	Team Leadership	7984381	1454	284785	101	0.0338019425052119363	t
5366	116	Private Banking	7984381	1454	7972	48	0.0320197612706834139	t
5368	116	Team Management	7984381	1454	150662	73	0.0313424444887048376	t
5369	116	Microsoft Office	7984381	1454	601080	151	0.0285746692440610045	t
5370	116	Customer Satisfaction	7984381	1454	79371	53	0.0265152146194010049	t
5371	116	Microsoft Word	7984381	1454	319543	95	0.0253206013758665652	t
5372	116	Insurance	7984381	1454	48752	44	0.0241598265961242772	t
5374	116	Consumer Lending	7984381	1454	1447	31	0.021143116637700899	t
5383	116	Cashiering	7984381	1454	6921	15	0.00945127241476140939	t
5397	117	Customer Service	7984381	2198	670741	375	0.0866268549603772947	t
5398	117	Event Management	7984381	2198	237669	239	0.0789902180069310955	t
5399	117	Travel Arrangements	7984381	2198	5585	174	0.0784849906071810044	t
5415	117	Stakeholder Management	7984381	2198	146503	113	0.0330707784968682986	t
5440	118	Banking	7984381	1454	78690	247	0.160049857926431005	t
5388	117	Microsoft Excel	7984381	2198	428419	429	0.141559269676649668	t
5389	117	Outlook	7984381	2198	88197	310	0.130026910113031718	t
5390	117	Microsoft Office	7984381	2198	601080	440	0.124934397841994949	t
5391	117	Diary Management	7984381	2198	13262	277	0.124396909899716537	t
5392	117	Administrative Assistants	7984381	2198	23875	278	0.123522408077849241	t
5393	117	Office Administration	7984381	2198	55039	273	0.117342791283783124	t
5394	117	PowerPoint	7984381	2198	268322	310	0.107461028072993292	t
5395	117	Office Management	7984381	2198	23264	242	0.107215917577094491	t
5396	117	Microsoft Word	7984381	2198	319543	288	0.091032256478996959	t
5400	117	Time Management	7984381	2198	218895	211	0.0685998448630666391	t
5401	117	Banking	7984381	2198	78690	171	0.0679612154353933379	t
5402	117	Event Planning	7984381	2198	139843	182	0.0653059556730250929	t
5438	118	Financial Services	7984381	1454	73327	351	0.232261517011643104	t
5439	118	Relationship Management	7984381	1454	42975	246	0.163835897660610769	t
5441	118	Investments	7984381	1454	60931	228	0.149204700194695727	t
5442	118	Equities	7984381	1454	39231	200	0.132662272445773416	t
5443	118	Portfolio Management	7984381	1454	52908	194	0.126821692029885663	t
5444	118	Management	7984381	1454	738887	298	0.112430780403878661	t
5445	118	Risk Management	7984381	1454	130308	187	0.112310817975719179	t
5446	118	Finance	7984381	1454	102182	179	0.11033102165996321	t
5449	118	Customer Service	7984381	1454	670741	255	0.0913882717016726992	t
5454	118	Financial Analysis	7984381	1454	97681	126	0.074437041582729499	t
5457	118	Account Management	7984381	1454	240929	140	0.066123110685103903	t
5465	118	Mutual Funds	7984381	1454	8527	81	0.054650382725337697	t
5491	119	Project Delivery	7984381	1234	94365	434	0.339935620929304017	t
5500	119	Management	7984381	1234	738887	364	0.20246542939159401	t
5503	119	Program Management	7984381	1234	122326	203	0.149208071300041989	t
5513	119	Business Requirements	7984381	1234	9511	111	0.0887738971238323932	t
5488	119	Stakeholder Management	7984381	1234	146503	557	0.433095870892909574	t
5489	119	Change Management	7984381	1234	341196	536	0.391687410776979217	t
5490	119	Business Analysis	7984381	1234	148418	475	0.36639515165556219	t
5492	119	Risk Management	7984381	1234	130308	399	0.307065829908062971	t
5493	119	Banking	7984381	1234	78690	348	0.272196301270603402	t
5494	119	Project Management	7984381	1234	479558	408	0.270611900728922494	t
5495	119	Financial Services	7984381	1234	73327	332	0.259900122914912102	t
5496	119	Governance	7984381	1234	96897	295	0.226959225860052627	t
5497	119	PMO	7984381	1234	25055	281	0.224611461321489209	t
5498	119	Business Process Improvement	7984381	1234	81006	280	0.216792323710784884	t
5499	119	Business Transformation	7984381	1234	54432	271	0.212826603846759776	t
5501	119	PRINCE2	7984381	1234	53617	244	0.191045246957553483	t
5502	119	Project Portfolio Management	7984381	1234	23195	234	0.186751044483915773	t
5504	119	Requirements Gathering	7984381	1234	25858	178	0.141029576780645816	t
5505	119	Financial Risk	7984381	1234	46720	155	0.119774866818763467	t
5506	119	Relationship Management	7984381	1234	42975	148	0.114570493816942301	t
5507	119	Process Improvement	7984381	1234	108186	156	0.112885894958353175	t
5508	119	Retail Banking	7984381	1234	25392	143	0.112720518513041865	t
5509	119	Portfolio Management	7984381	1234	52908	144	0.110084255515439725	t
5510	119	Business Process	7984381	1234	48555	133	0.10171405081367299	t
5511	119	Project Planning	7984381	1234	226745	154	0.0964137380609588757	t
5512	119	Strategy	7984381	1234	223349	151	0.094407640105046986	t
5514	119	Requirements Analysis	7984381	1234	57261	118	0.0884660329089268505	t
5515	119	Programme Delivery	7984381	1234	6364	109	0.0875471064961560186	t
5516	119	Outsourcing	7984381	1234	64839	114	0.0842747910543142076	t
5517	119	Team Management	7984381	1234	150662	126	0.083250245159540659	t
5518	119	Investment Banking	7984381	1234	44007	106	0.0804003040035495137	t
5519	119	Analysis	7984381	1234	128547	115	0.0771049775659093523	t
5520	119	User Acceptance Testing	7984381	1234	19596	98	0.076974136393727105	t
5539	120	Pensions	7984381	567	21667	203	0.355336251973038975	t
5546	120	Financial Modeling	7984381	567	47994	101	0.17213174946863799	t
5583	120	Retirement Planning	7984381	567	11670	16	0.0267589915405691998	t
5589	121	Financial Services	7984381	844	73327	34	0.0311038428324171001	t
5538	120	Actuarial Science	7984381	567	3563	259	0.456376286160480316	t
5540	120	Defined Benefit	7984381	567	2595	144	0.253661257838334098	t
5541	120	Financial Risk	7984381	567	46720	136	0.234024101255811134	t
5542	120	Actuarial Consulting	7984381	567	632	129	0.227450225043480586	t
5543	120	Risk Management	7984381	567	130308	131	0.21473545005134459	t
5544	120	Pension Funds	7984381	567	2648	110	0.193685634159489556	t
5545	120	Retirement	7984381	567	9007	108	0.189361560300687876	t
5547	120	Microsoft Excel	7984381	567	428419	125	0.16681326596328791	t
5548	120	Insurance	7984381	567	48752	98	0.166745426325788954	t
5549	120	Solvency Ii	7984381	567	3649	93	0.163575762863271301	t
5550	120	Employee Benefits	7984381	567	16398	86	0.149632351238417366	t
5551	120	ALM	7984381	567	1922	83	0.146154138680308909	t
5552	120	Valuation	7984381	567	31348	82	0.140704637889650791	t
5553	120	Investments	7984381	567	60931	76	0.126416503893442445	t
5554	120	Actuaries	7984381	567	703	71	0.125141298392996564	t
5555	120	Data Analysis	7984381	567	113349	72	0.112795795442335048	t
5588	121	Accounting	7984381	844	101909	42	0.0370034004461528426	t
5590	121	Outlook	7984381	844	88197	28	0.0221315035835768642	t
5591	121	Financial Analysis	7984381	844	97681	29	0.0221285183229851454	t
5592	121	Banking	7984381	844	78690	26	0.020952410391771932	t
5593	121	Investments	7984381	844	60931	20	0.0160671067513343362	t
5616	122	Time Management	7984381	457	218895	48	0.0776218654383795947	t
5636	122	Employee Engagement	7984381	457	51884	20	0.0372676223286449032	t
5644	122	Interviews	7984381	457	57940	17	0.0299441708967561997	t
4398	97	Accounting	7984381	17806	101909	4890	0.262448273101813956	t
4399	97	Financial Reporting	7984381	17806	76474	3282	0.175132506123849258	t
4400	97	Financial Accounting	7984381	17806	52966	3164	0.171441543500296251	t
4401	97	Microsoft Excel	7984381	17806	428419	3364	0.135570283417766418	t
4402	97	Account Reconciliation	7984381	17806	29394	2451	0.134268224817977899	t
4403	97	Bookkeeping	7984381	17806	20608	2364	0.130474168582959876	t
4404	97	Auditing	7984381	17806	53141	2048	0.108603988786915628	t
4405	97	Accounts Payable	7984381	17806	22451	1945	0.106658838349352414	t
4406	97	Tax	7984381	17806	27555	1944	0.105961875152364993	t
4407	97	Financial Analysis	7984381	17806	97681	1954	0.0977222107809633533	t
4408	97	IFRS	7984381	17806	20168	655	0.0343359945247819487	t
4410	97	Payroll	7984381	17806	31714	1507	0.0808426756325558854	t
4412	97	Management Accounting	7984381	17806	27852	1397	0.0751359504822358554	t
4413	97	General Ledger	7984381	17806	12071	1354	0.0746965380641359394	t
4414	97	Finance	7984381	17806	102182	1546	0.0741923866012675209	t
4415	97	Income Tax	7984381	17806	13691	1224	0.0671759604589275833	t
4416	97	Bank Reconciliation	7984381	17806	10490	1206	0.0665646096012852684	t
4417	97	Microsoft Word	7984381	17806	319543	1877	0.0655390533086383509	t
4418	97	Sage	7984381	17806	13935	1177	0.0644998731430001387	t
4419	97	Corporate Tax	7984381	17806	15335	1100	0.0599900884814501545	t
4420	97	Internal Controls	7984381	17806	28669	964	0.0506613991737547564	t
5597	122	Payroll	7984381	457	31714	207	0.449007743039945117	t
5598	122	Accounting	7984381	457	101909	99	0.203878322043946014	t
5599	122	Microsoft Excel	7984381	457	428419	108	0.182677173204061238	t
4479	98	Team Leadership	7984381	9558	284785	876	0.0560503082648789591	t
4480	98	Funding	7984381	9558	11583	533	0.0543791936623320704	t
4481	98	Team Management	7984381	9558	150662	687	0.0530709016858245605	t
4482	98	Commercial Lending	7984381	9558	3367	491	0.0510099446558582859	t
4483	98	Sales Process	7984381	9558	48637	543	0.0507803188770219946	t
4484	98	Leadership	7984381	9558	330397	873	0.0500165589043731831	t
4485	98	Trade Finance	7984381	9558	4605	476	0.0492834592050860609	t
4486	98	Business Analysis	7984381	9558	148418	626	0.0469625498657611357	t
4487	98	Project Management	7984381	9558	479558	1020	0.0467107896908671438	t
4488	98	Wealth Management	7984381	9558	21921	461	0.0455408788516432766	t
4489	98	Direct Sales	7984381	9558	49654	485	0.0445773045392320669	t
4490	98	Key Account Management	7984381	9558	74920	493	0.0422470820967266042	t
4491	98	Private Banking	7984381	9558	7972	392	0.0400622728616263288	t
4492	98	Marketing	7984381	9558	249999	676	0.0394623273454551213	t
4493	98	Mortgage Lending	7984381	9558	14555	392	0.0392367999953319932	t
4494	98	Event Management	7984381	9558	237669	653	0.0385991979252316292	t
4495	98	Marketing Communications	7984381	9558	160246	557	0.0382516464316504518	t
4496	98	Asset Based Lending	7984381	9558	2551	357	0.0370757944083789162	t
4497	98	Solution Selling	7984381	9558	39947	375	0.0342720330030637649	t
4507	99	Managerial Finance	7984381	10390	32966	1086	0.100525582374517072	t
4508	99	Forecasting	7984381	10390	72454	1201	0.106656239303541817	t
4509	99	Internal Controls	7984381	10390	28669	1069	0.0994261387567611371	t
4510	99	Management	7984381	10390	738887	2168	0.116271927925864701	t
4511	99	Account Reconciliation	7984381	10390	29394	1046	0.097118666797584588	t
4512	99	Financial Modeling	7984381	10390	47994	961	0.0865944804064830292	t
4513	99	VAT	7984381	10390	17993	570	0.0526754640947208336	t
4514	99	Cash Flow	7984381	10390	20454	792	0.0737613749670328195	t
4515	99	Financial Audits	7984381	10390	19326	777	0.0724572578937150297	t
4516	99	Analysis	7984381	10390	128547	1156	0.0952850133494685253	t
4517	99	Banking	7984381	10390	78690	923	0.0790828368090914086	t
4518	99	Corporate Finance	7984381	10390	49388	742	0.0653142381837991254	t
4519	99	Risk Management	7984381	10390	130308	982	0.0782954774263963094	t
4520	99	Tax	7984381	10390	27555	667	0.0608243799650086403	t
4521	99	Financial Services	7984381	10390	73327	843	0.0720456545127433345	t
4522	99	IFRS	7984381	10390	20168	793	0.0738936133723314265	t
4523	99	Accounts Receivable	7984381	10390	22858	578	0.0528363299434086303	t
4524	99	Variance Analysis	7984381	10390	12155	553	0.0517692737675693113	t
4525	99	Accounts Payable	7984381	10390	22451	548	0.0499962169295910114	t
4526	99	Business Planning	7984381	10390	140725	691	0.0489449118904812935	t
4527	99	Payroll	7984381	10390	31714	513	0.0454615523081120035	t
4528	99	Microsoft Office	7984381	10390	601080	1586	0.0774656023535643529	t
4529	99	Business Strategy	7984381	10390	247930	802	0.046197847310311714	t
4530	99	Bookkeeping	7984381	10390	20608	478	0.0434813174571205691	t
4562	100	Investment Banking	7984381	6656	44007	700	0.0997397792790599425	t
4563	100	Financial Analysis	7984381	6656	97681	740	0.0990264253961209706	t
4564	100	Wealth Management	7984381	6656	21921	642	0.093787025154715653	t
4565	100	Bloomberg	7984381	6656	19492	633	0.0927382063183679467	t
4567	100	Capital Markets	7984381	6656	31475	593	0.0852215196822366239	t
4568	100	Corporate Finance	7984381	6656	49388	593	0.0829761427107315874	t
4569	100	Mutual Funds	7984381	6656	8527	540	0.0801286450801594885	t
4570	100	Financial Services	7984381	6656	73327	579	0.0778702922818209908	t
4571	100	Risk Management	7984381	6656	130308	602	0.0741861917223485545	t
4572	100	Finance	7984381	6656	102182	566	0.0722985918107437175	t
4573	100	Due Diligence	7984381	6656	37983	473	0.0663618602326200568	t
4574	100	Emerging Markets	7984381	6656	15273	448	0.0654493931058521827	t
4644	101	Financial Reporting	7984381	7695	76474	391	0.0412740441078626522	t
4645	101	Personal Financial Planning	7984381	7695	1064	313	0.0405816141079654719	t
4646	101	Personal Finance	7984381	7695	1738	307	0.0397166385771964697	t
4647	101	Financial Modeling	7984381	7695	47994	351	0.039641253910172633	t
4666	102	Finance	7984381	2693	102182	269	0.0871202483170944453	t
4667	102	Equities	7984381	2693	39231	246	0.0864636339268293891	t
4668	102	KYC	7984381	2693	4156	216	0.07971431660915132	t
4669	102	Insurance	7984381	2693	48752	229	0.0789559861472036856	t
4670	102	Anti Money Laundering	7984381	2693	3785	207	0.0764176726520321148	t
4671	102	Financial Regulation	7984381	2693	4052	204	0.0752698459637087397	t
4672	102	Change Management	7984381	2693	341196	314	0.0738905803025159541	t
4673	102	Credit	7984381	2693	26674	200	0.0709497749036739345	t
4674	102	Fixed Income	7984381	2693	34489	201	0.0703421170792584427	t
4675	102	Asset Management	7984381	2693	38451	202	0.0702171892237417605	t
4676	102	Corporate Governance	7984381	2693	17766	185	0.0664939539643749217	t
4678	102	Business Analysis	7984381	2693	148418	223	0.0642404035525770134	t
4679	102	Due Diligence	7984381	2693	37983	180	0.0621037392411504796	t
4680	102	Internal Audit	7984381	2693	21877	174	0.0618928579077106453	t
4681	102	Capital Markets	7984381	2693	31475	175	0.0610618137519827811	t
4682	102	Auditing	7984381	2693	53141	179	0.0598331838354822926	t
4683	102	Wealth Management	7984381	2693	21921	167	0.0592871366814114661	t
4684	102	Pensions	7984381	2693	21667	166	0.0589475011513385314	t
4685	102	Enterprise Risk Management	7984381	2693	6297	158	0.0579014920016380913	t
4686	102	Security	7984381	2693	58305	175	0.0577003694058745367	t
4687	102	Analysis	7984381	2693	128547	192	0.0552147676372843829	t
4688	102	AML	7984381	2693	6101	354	0.130731889232440418	t
4689	102	Financial Markets	7984381	2693	27599	155	0.0541182578656670618	t
4690	102	Hedge Funds	7984381	2693	21026	144	0.0508557257819368391	t
4691	102	Internal Controls	7984381	2693	28669	143	0.0495267005388107182	t
4692	102	Risk Assessment	7984381	2693	63657	148	0.0470004584924896829	t
4693	102	Mortgage Lending	7984381	2693	14555	121	0.0431229139757868252	t
4695	102	Market Risk	7984381	2693	6726	116	0.0422464923249049676	t
4696	102	Team Management	7984381	2693	150662	160	0.0405573825437782476	t
4697	102	Process Improvement	7984381	2693	108186	145	0.040307188283948539	t
4782	104	Uk Corporation Tax	7984381	3097	1188	112	0.0360292143055374811	t
4783	104	Management Accounting	7984381	3097	27852	118	0.0346265089598814801	t
4784	104	Tax Research	7984381	3097	559	100	0.0322318026940721369	t
4785	104	Tax Compliance	7984381	3097	749	95	0.0305929049231536063	t
4786	104	Corporate Finance	7984381	3097	49388	110	0.0293440489333157868	t
4787	104	Business Advisory	7984381	3097	3156	91	0.0289992507134632649	t
4789	104	Personal Income Tax Returns	7984381	3097	775	87	0.0280054999779507582	t
4790	104	Sage	7984381	3097	13935	88	0.0266796608913242861	t
4791	104	Paye	7984381	3097	2087	83	0.0265490417382321583	t
4792	104	Account Reconciliation	7984381	3097	29394	92	0.0260348281608180424	t
4793	104	Corporate Tax Planning	7984381	3097	534	79	0.0254515482966588269	t
4794	104	External Audit	7984381	3097	12659	83	0.0252244428391076581	t
4795	104	Cash Flow	7984381	3097	20454	72	0.0206945803727840646	t
4796	104	Assurance	7984381	3097	8941	66	0.0201989696078994571	t
4797	104	Capital Allowances	7984381	3097	269	61	0.0196704194953276276	t
4813	105	Finance	7984381	13821	102182	1089	0.066109841330269481	t
4814	105	PowerPoint	7984381	13821	268322	1256	0.0573696487605173458	t
4815	105	Business Analysis	7984381	13821	148418	1001	0.0539308310886064818	t
4816	105	Derivatives	7984381	13821	38143	782	0.0518931912673571069	t
4856	106	Finance	7984381	1586	102182	270	0.157473140609972612	t
4857	106	Corporate Finance	7984381	1586	49388	240	0.145167344909544582	t
4858	106	Microsoft Excel	7984381	1586	428419	300	0.135524893710033262	t
4860	106	Fixed Income	7984381	1586	34489	204	0.124330611250960302	t
4861	106	Analysis	7984381	1586	128547	222	0.123899582599095781	t
4862	106	Derivatives	7984381	1586	38143	199	0.120719665369048074	t
4863	106	Investment Banking	7984381	1586	44007	189	0.113678662629681765	t
4865	106	Bloomberg	7984381	1586	19492	155	0.0953078041805397874	t
4866	106	Microsoft Office	7984381	1586	601080	265	0.0918232722704499654	t
4867	106	Equities	7984381	1586	39231	136	0.0808529077715353095	t
4868	106	Data Analysis	7984381	1586	113349	147	0.078505255052040368	t
4869	106	Valuation	7984381	1586	31348	130	0.0780565527508088886	t
4870	106	Business Analysis	7984381	1586	148418	151	0.0766347513732060504	t
4871	106	Financial Markets	7984381	1586	27599	126	0.0760036185861310137	t
4872	106	Investments	7984381	1586	60931	132	0.0756119924548924738	t
4873	106	Financial Services	7984381	1586	73327	128	0.0715365837058115073	t
4874	106	Economics	7984381	1586	30444	112	0.0668182350145975629	t
4876	106	VBA	7984381	1586	13934	102	0.0625800099990736075	t
4877	106	Asset Management	7984381	1586	38451	106	0.0620313491083855501	t
4878	106	Loans	7984381	1586	15537	100	0.061117918552085447	t
4879	106	Commercial Banking	7984381	1586	13155	94	0.0576324565205940109	t
4880	106	Retail Banking	7984381	1586	25392	91	0.0542076079006758166	t
4881	106	Accounting	7984381	1586	101909	105	0.053451360752642986	t
4882	106	Hedge Funds	7984381	1586	21026	88	0.0528626072538046637	t
4883	106	Market Risk	7984381	1586	6726	82	0.0508701060211311784	t
4884	106	Relationship Management	7984381	1586	42975	86	0.0488517844414237956	t
4885	106	PowerPoint	7984381	1586	268322	125	0.0452177487064359951	t
4886	106	Financial Reporting	7984381	1586	76474	82	0.0421328153854578363	t
4887	106	Bonds	7984381	1586	8967	68	0.0417603851717395433	t
4930	107	Credit Risk	7984381	2375	25070	121	0.0478217130406883434	t
4931	107	Certified Mortgage Planning	7984381	2375	464	105	0.0441655501531556666	t
4932	107	Management	7984381	2375	738887	323	0.0434713800014683155	t
4933	107	Wealth	7984381	2375	8111	99	0.0406804528243045402	t
4934	107	Negotiation	7984381	2375	275641	178	0.0404368706840176131	t
5018	109	GAAP	7984381	5582	3373	263	0.0467259461557414033	t
5024	109	Corporate Finance	7984381	5582	49388	339	0.0545835043949663007	t
5028	109	Financial Statements	7984381	5582	7841	299	0.052619775411010497	t
4964	108	Fixed Income	7984381	2911	34489	284	0.0932754242013062729	t
4965	108	Mergers & Acquisitions	7984381	2911	36659	282	0.0923162447554359139	t
4966	108	Financial Markets	7984381	2911	27599	278	0.0920767745897067835	t
4967	108	Banking	7984381	2911	78690	260	0.0794898754663023455	t
4968	108	Asset Management	7984381	2911	38451	242	0.0783457306224980277	t
4970	108	Emerging Markets	7984381	2911	15273	201	0.0671600630170900853	t
4971	108	Analysis	7984381	2911	128547	240	0.0663702847495158677	t
4972	108	Teamwork	7984381	2911	285884	296	0.0659018917356058442	t
4973	108	Due Diligence	7984381	2911	37983	193	0.0615655236794337563	t
4974	108	Research	7984381	2911	383551	300	0.0550397728456848076	t
4975	108	Microsoft Office	7984381	2911	601080	375	0.0535592590986760514	t
4976	108	PowerPoint	7984381	2911	268322	250	0.0522943450866661386	t
5004	109	Financial Analysis	7984381	5582	97681	1212	0.20503581118659131	t
5005	109	US GAAP	7984381	5582	4434	233	0.0412147910132076509	t
5006	109	Internal Audit	7984381	5582	21877	1020	0.180116151661818685	t
5007	109	Microsoft Excel	7984381	5582	428419	1168	0.155695713918969553	t
5008	109	Assurance	7984381	5582	8941	819	0.145703657470822756	t
5009	109	Finance	7984381	5582	102182	853	0.140112830959895351	t
5010	109	Financial Audits	7984381	5582	19326	788	0.138844632809162594	t
5011	109	Tax	7984381	5582	27555	718	0.125264193197442725	t
5012	109	Microsoft Office	7984381	5582	601080	990	0.102145219051523184	t
5013	109	Teamwork	7984381	5582	285884	765	0.101313077077436767	t
5014	109	Management Accounting	7984381	5582	27852	534	0.09224081277065109	t
5015	109	Economics	7984381	5582	30444	186	0.0295290901135092619	t
5016	109	Corporate Tax	7984381	5582	15335	487	0.0853837834542323509	t
5017	109	Risk Management	7984381	5582	130308	556	0.0833437794413745547	t
5019	109	Account Reconciliation	7984381	5582	29394	429	0.0732239285265028211	t
5020	109	Microsoft Word	7984381	5582	319543	603	0.0680523626069377552	t
5021	109	Income Tax	7984381	5582	13691	339	0.0590574860054818643	t
5022	109	PowerPoint	7984381	5582	268322	517	0.0590545576070958464	t
5023	109	Big 4	7984381	5582	5201	312	0.0552811959615687534	t
5025	109	Financial Risk	7984381	5582	46720	342	0.0554557083336805479	t
5026	109	Bookkeeping	7984381	5582	20608	316	0.0540672939551823037	t
5027	109	Sarbanes Oxley Act	7984381	5582	8769	299	0.0525034671796588831	t
5029	109	Analysis	7984381	5582	128547	367	0.0496819696147844936	t
5030	109	Managerial Finance	7984381	5582	32966	271	0.044451172693055041	t
5031	109	Time Management	7984381	5582	218895	423	0.0483977260080512769	t
5032	109	Cash Flow	7984381	5582	20454	263	0.0445851477724258163	t
5034	109	UK GAAP	7984381	5582	6183	522	0.0928053639448268991	t
5079	110	Strategic Financial Planning	7984381	1876	21890	84	0.0420443954641964365	t
5081	110	Operational Risk	7984381	1876	11219	78	0.0401821479884002589	t
5082	110	Underwriting	7984381	1876	14917	76	0.0386525362609713222	t
5083	110	Financial Advisory	7984381	1876	13434	75	0.0383051432269387593	t
5084	110	Corporate Finance	7984381	1876	49388	75	0.03380104332346235	t
5085	110	Leadership	7984381	1876	330397	141	0.0337874382777510404	t
5086	110	Sales Management	7984381	1876	180284	105	0.0333984126873276901	t
5087	110	Funding	7984381	1876	11583	63	0.0321389335504574103	t
5088	110	Performance Management	7984381	1876	139406	92	0.0315880954742860653	t
5089	110	Pensions	7984381	1876	21667	63	0.0308756709530647357	t
5090	110	Trade Finance	7984381	1876	4605	55	0.0287477007170247323	t
5091	110	Branch Management	7984381	1876	945	54	0.0286730290906204825	t
5092	110	Stakeholder Management	7984381	1876	146503	87	0.0280331546185458823	t
5117	111	Financial Analysis	7984381	2300	97681	238	0.0912705421054985505	t
5118	111	Process Improvement	7984381	2300	108186	239	0.0903893771561576492	t
5119	111	Management	7984381	2300	738887	417	0.0887883736083359687	t
5120	111	Financial Risk	7984381	2300	46720	209	0.0850426386302018111	t
5121	111	Data Analysis	7984381	2300	113349	228	0.0849585665692943887	t
5122	111	SQL	7984381	2300	74090	216	0.0846580634799371234	t
5123	111	SDLC	7984381	2300	25307	194	0.0812016540548761712	t
5124	111	Business Process Mapping	7984381	2300	7443	187	0.0803953116987913413	t
5125	111	Finance	7984381	2300	102182	211	0.0789641410554465795	t
5126	111	PRINCE2	7984381	2300	53617	189	0.0754804204567706138	t
5127	111	Business Transformation	7984381	2300	54432	180	0.0714641457534695573	t
5128	111	Microsoft Excel	7984381	2300	428419	268	0.0628827194311859239	t
5129	111	Testing	7984381	2300	52574	157	0.0616940356781646299	t
5130	111	Visio	7984381	2300	12345	139	0.0589056074474814256	t
5131	111	Retail Banking	7984381	2300	25392	140	0.0577059791801160654	t
5132	111	Trading Systems	7984381	2300	13324	130	0.0548687867236626603	t
5133	111	Middle Office	7984381	2300	5812	127	0.0545051710199382852	t
5134	111	Back Office	7984381	2300	7043	124	0.0530462269175168699	t
5152	112	Tax	7984381	1440	27555	243	0.165328704515040281	t
5153	112	Financial Accounting	7984381	1440	52966	237	0.15797812354911972	t
5155	112	Time Management	7984381	1440	218895	243	0.141360094450153156	t
5156	112	Financial Reporting	7984381	1440	76474	200	0.129334264847448532	t
5157	112	Auditing	7984381	1440	53141	192	0.126700564783496866	t
5158	112	Microsoft Word	7984381	1440	319543	240	0.126668500577251736	t
5159	112	Finance	7984381	1440	102182	192	0.120557340124815324	t
5160	112	Corporate Tax	7984381	1440	15335	175	0.119628728292130823	t
5161	112	IFRS	7984381	1440	20168	79	0.052344620008395959	t
5162	112	Research	7984381	1440	383551	223	0.106842717889865962	t
5227	113	Data Analysis	7984381	144	113349	15	0.0899719477473760743	t
5228	113	Mathematical Modeling	7984381	144	8955	13	0.0891578210430265389	t
5229	113	Monte Carlo Simulation	7984381	144	1532	12	0.0831429582229752523	t
5230	113	Numerical Analysis	7984381	144	6823	12	0.0824802774934327854	t
5232	113	Mathematics	7984381	144	13271	12	0.0816726862358085476	t
5234	113	Trading	7984381	144	23464	12	0.0803960457753612884	t
5235	113	C#	7984381	144	29764	12	0.079606991041640332	t
5236	113	Asset Management	7984381	144	38451	12	0.0785189722365873255	t
5237	113	Machine Learning	7984381	144	5786	11	0.0756655887163113494	t
5238	113	Commodity	7984381	144	9015	11	0.0752611668535835832	t
5239	113	Trading Systems	7984381	144	13324	11	0.0747214784650750696	t
5240	113	Java	7984381	144	56026	11	0.0693731903318445531	t
5241	113	Programming	7984381	144	26495	10	0.0661272833932381732	t
5242	113	Time Series Analysis	7984381	144	1621	9	0.0622981021855939371	t
5259	114	Investment Banking	7984381	2840	44007	169	0.0540146191738175921	t
5260	114	Credit Analysis	7984381	2840	11704	146	0.0499603594145859239	t
5261	114	Financial Analysis	7984381	2840	97681	163	0.0451764248247087871	t
5262	114	Equities	7984381	2840	39231	118	0.0366488636400513212	t
5264	114	Fixed Income	7984381	2840	34489	110	0.0344250807785077828	t
5265	114	Wealth Management Services	7984381	2840	4029	98	0.0340145308450099174	t
5266	114	Asset Management	7984381	2840	38451	108	0.0332242094779498162	t
5267	114	Investment Advisory	7984381	2840	8330	96	0.0327711865433109317	t
5268	114	Corporate Finance	7984381	2840	49388	104	0.0304449708519434481	t
5269	114	Financial Markets	7984381	2840	27599	94	0.0296525151587842158	t
5270	114	Wealth	7984381	2840	8111	80	0.0271628174114585674	t
5271	114	Credit Cards	7984381	2840	9868	79	0.0265904465170957657	t
5272	114	Cross Selling	7984381	2840	4344	77	0.0265780675139525406	t
5273	114	Strategic Financial Planning	7984381	2840	21890	83	0.0264931729507823822	t
5274	114	Pensions	7984381	2840	21667	81	0.0258166364873191542	t
5275	114	High Net Worth Individuals	7984381	2840	5273	75	0.0257571980200632343	t
5276	114	Derivatives	7984381	2840	38143	79	0.0230478975281223318	t
5277	114	Financial Planning	7984381	2840	14327	68	0.0221571648530415194	t
5279	114	Structured Products	7984381	2840	10212	63	0.0209115396281862077	t
5280	114	Retirement Planning	7984381	2840	11670	60	0.0196721542411174496	t
5281	114	Branch Banking	7984381	2840	2506	53	0.0183546376958859392	t
5282	114	Operational Risk	7984381	2840	11219	54	0.0176152318293450495	t
5283	114	Trade Finance	7984381	2840	4605	50	0.0170349420028248974	t
5284	114	Financial Modeling	7984381	2840	47994	64	0.0165301052360761341	t
5285	114	Commercial Lending	7984381	2840	3367	47	0.0161333359994616163	t
5286	114	Hedge Funds	7984381	2840	21026	53	0.0160342837692444527	t
5287	114	Inheritance Tax Planning	7984381	2840	10247	46	0.0149191091026050597	t
5299	115	Investment Banking	7984381	1240	44007	202	0.15741603724245154	t
5300	115	Hedge Funds	7984381	1240	21026	180	0.142550037433523569	t
5301	115	Fixed Income	7984381	1240	34489	181	0.141670185372221369	t
5302	115	Investments	7984381	1240	60931	172	0.131098763369358717	t
5375	116	Cash Management	7984381	1454	9500	24	0.0153191565437898261	t
5376	116	Retail Sales	7984381	1454	28815	27	0.0149632674756361057	t
5377	116	Customer Retention	7984381	1454	32444	27	0.0145086723127340767	t
5378	116	Operational Risk	7984381	1454	11219	22	0.0137280556398372798	t
5379	116	Investments	7984381	1454	60931	29	0.0123159480608258723	t
5380	116	Internet Banking	7984381	1454	1690	18	0.0121701953798381054	t
5381	116	Call Centers	7984381	1454	26223	19	0.00978489499852979588	t
5382	116	Payments	7984381	1454	9917	16	0.00976385465219682669	t
5384	116	Residential Mortgages	7984381	1454	5590	14	0.00893012006262996691	t
5385	116	KYC	7984381	1454	4156	12	0.0077339870695702518	t
5386	116	Personal Banking	7984381	1454	197	11	0.00754203727685091516	t
5387	116	Savings	7984381	1454	4606	11	0.00698973359174894643	t
5403	117	Lotus Notes	7984381	2198	8136	141	0.0631476208685116808	t
5404	117	Financial Services	7984381	2198	73327	141	0.0549805567959390507	t
5405	117	Teamwork	7984381	2198	285884	197	0.0538363484691220529	t
5406	117	Administration	7984381	2198	46008	129	0.0529420421329374544	t
5407	117	Expenses	7984381	2198	3543	104	0.0468849070609219515	t
5408	117	Management	7984381	2198	738887	306	0.046688772451180624	t
5409	117	Spreadsheets	7984381	2198	8817	98	0.043493679555347213	t
5410	117	Confidentiality	7984381	2198	5776	92	0.0411441470347158333	t
5411	117	Investment Banking	7984381	2198	44007	92	0.0363546051261928113	t
5412	117	Human Resources	7984381	2198	106742	108	0.0357765756302954319	t
5413	117	Calendars	7984381	2198	2057	77	0.0347837946899590619	t
5414	117	Executive Support	7984381	2198	2277	75	0.0338460646419203662	t
5416	117	Executive Administrative Assistance	7984381	2198	1894	64	0.0288881188438548271	t
5417	117	Invoicing	7984381	2198	20378	67	0.027937714583775284	t
5418	117	Accounting	7984381	2198	101909	85	0.0259151094433510559	t
5447	118	Asset Management	7984381	1454	38451	160	0.105244653905888982	t
5448	118	Fixed Income	7984381	1454	34489	143	0.0940469490903443478	t
5450	118	Wealth Management	7984381	1454	21921	135	0.0901182435587080388	t
5451	118	Accounting	7984381	1454	101909	142	0.0849135421103051208	t
5452	118	Derivatives	7984381	1454	38143	126	0.0818952082426526173	t
5453	118	CRM	7984381	1454	102251	127	0.0745524530330588797	t
5455	118	Pensions	7984381	1454	21667	106	0.070201449342079919	t
5456	118	Financial Risk	7984381	1454	46720	107	0.0677510099459716353	t
5458	118	Microsoft Excel	7984381	1454	428419	171	0.0639611163027491297	t
5459	118	Hedge Funds	7984381	1454	21026	95	0.0627150307624812775	t
5460	118	Financial Reporting	7984381	1454	76474	103	0.0612722729198439675	t
5461	118	Business Analysis	7984381	1454	148418	114	0.0598267546296704089	t
5462	118	Tax	7984381	1454	27555	91	0.0591456276185248764	t
5463	118	Financial Markets	7984381	1454	27599	91	0.0591401158557341086	t
5464	118	Investment Banking	7984381	1454	44007	91	0.0570847294041230691	t
5466	118	Credit	7984381	1454	26674	82	0.0530650395527073604	t
5467	118	Financial Accounting	7984381	1454	52966	86	0.0525230434567609053	t
5468	118	Insurance	7984381	1454	48752	82	0.0502993873051044427	t
5521	119	Integration	7984381	1234	67927	105	0.0765934938622003375	t
5522	119	Resource Management	7984381	1234	14910	92	0.0726981347421368079	t
5523	119	SDLC	7984381	1234	25307	89	0.068964272033803356	t
5524	119	IT Strategy	7984381	1234	47381	86	0.0637677029516551669	t
5525	119	Service Delivery	7984381	1234	48591	84	0.0619951375812614128	t
5526	119	Derivatives	7984381	1234	38143	81	0.0608724005355269354	t
5527	119	Finance	7984381	1234	102182	90	0.060145108984379525	t
5528	119	Project Governance	7984381	1234	2743	71	0.0572017616765890247	t
5529	119	Vendor Management	7984381	1234	28713	74	0.0563801527144145928	t
5530	119	Equities	7984381	1234	39231	75	0.0558731252175491827	t
5531	119	Credit Risk	7984381	1234	25070	72	0.0552154929732169564	t
5532	119	Microsoft Project	7984381	1234	39932	74	0.0549748171994854581	t
5533	119	Financial Analysis	7984381	1234	97681	82	0.0542249374435259252	t
5534	119	Business Process Mapping	7984381	1234	7443	66	0.0525605312448549286	t
5535	119	Credit Cards	7984381	1234	9868	66	0.0522567663260829207	t
5536	119	ITIL	7984381	1234	61484	69	0.0482226397940829568	t
5537	119	Leadership	7984381	1234	330397	110	0.0477679723977210632	t
5556	120	Financial Analysis	7984381	567	97681	68	0.107703091275896612	t
5594	121	Relationship Management	7984381	844	42975	17	0.0147613570335295447	t
5595	121	Administrative Assistants	7984381	844	23875	14	0.0135989021986820183	t
5596	121	Bookkeeping	7984381	844	20608	13	0.0128231599353704831	t
5600	122	Human Resources	7984381	457	106742	77	0.155130181309406923	t
5601	122	Customer Service	7984381	457	670741	102	0.139196078030837972	t
5602	122	Tax	7984381	457	27555	53	0.112529069725789022	t
5603	122	Employee Benefits	7984381	457	16398	52	0.11173819380855457	t
5604	122	Performance Management	7984381	457	139406	58	0.109461087876657065	t
5605	122	Management	7984381	457	738887	91	0.106589276490275692	t
5606	122	Microsoft Office	7984381	457	601080	82	0.104155055053589712	t
5607	122	Account Reconciliation	7984381	457	29394	47	0.0991688775070528328	t
5608	122	Microsoft Word	7984381	457	319543	60	0.0912752417229687751	t
5609	122	Accounts Payable	7984381	457	22451	41	0.0869086456586808803	t
5610	122	Financial Reporting	7984381	457	76474	44	0.0867071006101421682	t
5611	122	Employee Relations	7984381	457	51342	42	0.085478308047329643	t
5612	122	Bookkeeping	7984381	457	20608	40	0.0849511754702584609	t
5613	122	Recruiting	7984381	457	160827	47	0.0827066717044925848	t
5614	122	Sage	7984381	457	13935	37	0.0792220528421008624	t
5615	122	Payroll Taxes	7984381	457	1343	36	0.0786109131047198206	t
5617	122	HR Policies	7984381	457	31524	35	0.0726423826907742209	t
5618	122	HRMS	7984381	457	11695	31	0.066372762280244163	t
5619	122	ADP Payroll	7984381	457	958	34	0.0742825168883655129	t
5620	122	VAT	7984381	457	17993	31	0.0655839271159815856	t
5621	122	Auditing	7984381	457	53141	31	0.0611815806006590426	t
5622	122	Financial Accounting	7984381	457	52966	30	0.0590151905878495142	t
5623	122	Outlook	7984381	457	88197	32	0.0589790663002511401	t
5624	122	Paye	7984381	457	2087	27	0.0588229443127233353	t
5625	122	Benefits Administration	7984381	457	2539	26	0.0565780214882287344	t
5626	122	Income Tax	7984381	457	13691	26	0.055181214604796483	t
5627	122	Finance	7984381	457	102182	30	0.0528508032514971166	t
5628	122	Accounts Receivable	7984381	457	22858	24	0.0496564142142541312	t
5629	122	Change Management	7984381	457	341196	42	0.0491736037440321655	t
4421	97	Budgets	7984381	17806	165031	1194	0.0464904980825358444	t
4422	97	Cash Flow	7984381	17806	20454	869	0.0463453775209353921	t
4423	97	Invoicing	7984381	17806	20378	866	0.0461860582723096907	t
4424	97	Tax Returns	7984381	17806	8095	815	0.0448572703511459503	t
4425	97	Quickbooks	7984381	17806	6075	767	0.0424090840364593075	t
4427	97	Financial Statements	7984381	17806	7841	743	0.0408365349868410749	t
4428	97	Journal Entries	7984381	17806	4188	701	0.0389310483249212247	t
4429	97	Customer Service	7984381	17806	670741	2130	0.0356955664906701553	t
4430	97	PowerPoint	7984381	17806	268322	1191	0.0333560923004876941	t
4431	97	VAT	7984381	17806	17993	1772	0.0974808845210212854	t
4432	97	Time Management	7984381	17806	218895	1029	0.0304419978334807204	t
4433	97	Accruals	7984381	17806	6763	550	0.0301085811119652276	t
4434	97	Managerial Finance	7984381	17806	32966	560	0.0273823274597245828	t
4435	97	Fixed Assets	7984381	17806	5034	489	0.0268921443818213382	t
4436	97	Tax Preparation	7984381	17806	4739	484	0.026647742251018517	t
4437	97	Sage Line50	7984381	17806	4596	478	0.0263279740336552735	t
4438	97	External Audit	7984381	17806	12659	430	0.0226141246203346476	t
4439	97	Year End Accounts	7984381	17806	3615	408	0.0225110676877278287	t
4440	97	Outlook	7984381	17806	88197	555	0.0201680543366823048	t
4441	97	Sage Accounts	7984381	17806	5086	363	0.0197935346014511716	t
4442	97	Internal Audit	7984381	17806	21877	392	0.0193181581504873502	t
4443	97	Analysis	7984381	17806	128547	629	0.0192683338165048554	t
4444	97	Forecasting	7984381	17806	72454	500	0.0190484355598295914	t
4445	97	Financial Audits	7984381	17806	19326	354	0.0174994890135591503	t
4446	97	Purchase Ledger	7984381	17806	3875	292	0.0159492125114881721	t
4447	97	Variance Analysis	7984381	17806	12155	307	0.015754165545332887	t
4531	99	Strategic Financial Planning	7984381	10390	21890	477	0.0432241729665253996	t
4532	99	General Ledger	7984381	10390	12071	459	0.0427208589589351331	t
4533	99	Business Analysis	7984381	10390	148418	888	0.0669653946299251651	t
4534	99	External Audit	7984381	10390	12659	438	0.0406233114538256807	t
4535	99	Sage	7984381	10390	13935	435	0.0401741758125744586	t
4536	99	Internal Audit	7984381	10390	21877	431	0.0387927005369161429	t
4537	99	Financial Risk	7984381	10390	46720	504	0.0427123379331083991	t
4538	99	Process Improvement	7984381	10390	108186	564	0.04078633516013426	t
4539	99	Investments	7984381	10390	60931	487	0.0392918483046408862	t
4540	99	Customer Service	7984381	10390	670741	1331	0.0441547668265492022	t
4541	99	Change Management	7984381	10390	341196	927	0.0465480460643842645	t
4542	99	Teamwork	7984381	10390	285884	841	0.0451966229917131548	t
4543	99	Equities	7984381	10390	39231	412	0.0347853108596009528	t
4544	99	Data Analysis	7984381	10390	113349	543	0.0381150473535872975	t
4545	99	Portfolio Management	7984381	10390	52908	432	0.0349975454951943071	t
4547	99	Business Process Improvement	7984381	10390	81006	466	0.0347504806346980444	t
4575	100	Trading	7984381	6656	23464	404	0.0578065670139959395	t
4576	100	Investment Advisory	7984381	6656	8330	354	0.052185312380903362	t
4577	100	Banking	7984381	6656	78690	410	0.0517862365105171488	t
4578	100	Bonds	7984381	6656	8967	346	0.0509025391869356442	t
4579	100	Strategy	7984381	6656	223349	505	0.0479381175134093312	t
4580	100	Pensions	7984381	6656	21667	334	0.0475062178461687912	t
4581	100	Financial Risk	7984381	6656	46720	350	0.0467717006194772605	t
4582	100	Equity Research	7984381	6656	5054	312	0.0462805949534485089	t
4583	100	Business Strategy	7984381	6656	247930	514	0.0462102048880934646	t
4584	100	Mergers & Acquisitions	7984381	6656	36659	281	0.0376576014756050334	t
4585	100	Real Estate	7984381	6656	34511	253	0.0337166106259628659	t
4586	100	Venture Capital	7984381	6656	9820	231	0.0335035571060901052	t
4587	100	Structured Products	7984381	6656	10212	225	0.0325522258889655927	t
4588	100	Funding	7984381	6656	11583	220	0.031628543716193433	t
4589	100	Financial Advisory	7984381	6656	13434	221	0.0315468884162621518	t
4590	100	Economics	7984381	6656	30444	231	0.0309183589449602107	t
4591	100	Analysis	7984381	6656	128547	307	0.0300490399221859834	t
4592	100	Business Planning	7984381	6656	140725	312	0.0292743682409458833	t
4593	100	Fund Of Funds	7984381	6656	2322	184	0.0273762345673060348	t
4594	100	Relationship Management	7984381	6656	42975	216	0.0270921243874470696	t
4595	100	Management	7984381	6656	738887	793	0.0266212664109285596	t
4596	100	Investment Properties	7984381	6656	18031	189	0.0261589555011285044	t
4597	100	Security	7984381	6656	58305	222	0.0260727183329809917	t
4634	101	Trusts	7984381	7695	7284	469	0.0600943031334980893	t
5693	124	Customer Service	7984381	2100	670741	517	0.16222650649309267	t
5694	124	Banking	7984381	2100	78690	296	0.131131378659928438	t
5695	124	Retail Banking	7984381	2100	25392	180	0.0825557900411817425	t
5696	124	Financial Services	7984381	2100	73327	174	0.0736927198056366445	t
5697	124	Teamwork	7984381	2100	285884	226	0.0718325349668370583	t
5698	124	Microsoft Office	7984381	2100	601080	295	0.065211363292081076	t
5699	124	Time Management	7984381	2100	218895	184	0.0602194860150399441	t
5700	124	Microsoft Word	7984381	2100	319543	193	0.0518974006003928914	t
5701	124	Customer Experience	7984381	2100	42804	110	0.0470323559083401024	t
5702	124	Microsoft Excel	7984381	2100	428419	209	0.0458787424057764751	t
5703	124	Credit	7984381	2100	26674	103	0.0457188712874236833	t
5704	124	Sales	7984381	2100	353906	173	0.0380661756899288439	t
5705	124	Loans	7984381	2100	15537	75	0.0337772454121465088	t
5706	124	Relationship Management	7984381	2100	42975	82	0.0336740923576916915	t
5707	124	PowerPoint	7984381	2100	268322	140	0.0330695031491207436	t
5708	124	Risk Management	7984381	2100	130308	101	0.0317832340452679149	t
5709	124	Team Leadership	7984381	2100	284785	141	0.031483375849226912	t
5710	124	Call Centers	7984381	2100	26223	71	0.0305332673109114452	t
5711	124	Financial Risk	7984381	2100	46720	75	0.0298707179421163274	t
5712	124	Finance	7984381	2100	102182	89	0.0295909992334748607	t
5713	124	Credit Cards	7984381	2100	9868	63	0.0287716543679682538	t
5714	124	Customer Satisfaction	7984381	2100	79371	76	0.026256598893999155	t
5715	124	Insurance	7984381	2100	48752	61	0.0229477335637579827	t
5716	124	Team Management	7984381	2100	150662	87	0.022564915789287366	t
5717	124	Communication	7984381	2100	89342	69	0.0216732469256415705	t
5718	124	Commercial Banking	7984381	2100	13155	48	0.0212151310061443783	t
5719	124	Complaint Management	7984381	2100	4699	45	0.0208455300648309125	t
5720	124	Outlook	7984381	2100	88197	64	0.0194351108649866086	t
5721	124	Complaint Investigations	7984381	2100	1671	41	0.0193196072412790028	t
5722	124	Mortgage Lending	7984381	2100	14555	44	0.0191344795279635438	t
5723	124	Credit Risk	7984381	2100	25070	46	0.0187698183967596188	t
5724	124	Analysis	7984381	2100	128547	73	0.0186670065742814521	t
5725	124	Financial Analysis	7984381	2100	97681	59	0.0158654005337691383	t
5726	124	Leadership	7984381	2100	330397	120	0.0157665888806899704	t
5727	124	Payments	7984381	2100	9917	29	0.0125707801471546202	t
5728	124	Administration	7984381	2100	46008	38	0.0123362326179816562	t
5729	124	Data Entry	7984381	2100	27582	33	0.0122630165845720417	t
5730	124	Customer Retention	7984381	2100	32444	32	0.0111776017525865232	t
5731	124	Office Administration	7984381	2100	55039	37	0.0107285359971189993	t
5732	124	Telephone Skills	7984381	2100	15359	26	0.0104600728729520986	t
5733	124	Cross Selling	7984381	2100	4344	23	0.0104110569874641574	t
5734	124	Branch Banking	7984381	2100	2506	20	0.00921236972358199617	t
5735	124	Complaints	7984381	2100	1062	19	0.00891695464229430405	t
5736	124	Problem Solving	7984381	2100	62532	35	0.00883720037751949128	t
5737	124	Pensions	7984381	2100	21667	24	0.00871719105997753943	t
5738	124	Quality Assurance	7984381	2100	35754	27	0.00838135454550612002	t
5739	124	Operational Risk	7984381	2100	11219	18	0.00716819558576946032	t
5740	124	Anti Money Laundering	7984381	2100	3785	16	0.00714687681974852159	t
5741	124	Compliance	7984381	2100	11410	18	0.00714426758824594516	t
5742	124	KYC	7984381	2100	4156	16	0.00710039887691488788	t
4817	105	Fixed Income	7984381	13821	34489	764	0.0510470040402759284	t
4818	105	Capital Markets	7984381	13821	31475	725	0.0485984596711455663	t
4819	105	Portfolio Management	7984381	13821	52908	748	0.0475764589828329629	t
4820	105	Asset Management	7984381	13821	38451	665	0.0433744912738250124	t
4821	105	Financial Markets	7984381	13821	27599	638	0.0427790652188142911	t
4822	105	Banking	7984381	13821	78690	697	0.0406453700108403843	t
4823	105	Microsoft Word	7984381	13821	319543	1078	0.0380420905719822677	t
4824	105	Market Research	7984381	13821	77513	646	0.0370966029836045097	t
4825	105	Risk Management	7984381	13821	130308	733	0.0367785365799858793	t
4826	105	VBA	7984381	13821	13934	525	0.0363033580517916551	t
4827	105	SQL	7984381	13821	74090	611	0.0349892889550353081	t
4829	105	Hedge Funds	7984381	13821	21026	485	0.0325144186256244236	t
4830	105	English	7984381	13821	149229	702	0.032157822853436005	t
4831	105	Private Equity	7984381	13821	24099	481	0.0318389583187873651	t
4832	105	Business Strategy	7984381	13821	247930	822	0.0284721228647143235	t
4833	105	Equity Research	7984381	13821	5054	374	0.0264731098511402675	t
4834	105	Matlab	7984381	13821	43522	424	0.0252708055325966963	t
4835	105	Emerging Markets	7984381	13821	15273	360	0.0241763089787522499	t
4836	105	Econometrics	7984381	13821	6860	335	0.0234198400925767873	t
4837	105	Strategy	7984381	13821	223349	697	0.0224962060876028672	t
4838	105	Mergers & Acquisitions	7984381	13821	36659	367	0.0220005389677003921	t
4839	105	Due Diligence	7984381	13821	37983	369	0.0219793859309792075	t
4840	105	Time Management	7984381	13821	218895	676	0.0215329508405271916	t
4841	105	Public Speaking	7984381	13821	243457	714	0.021205567392061829	t
4842	105	Accounting	7984381	13821	101909	458	0.02040976360803139	t
4843	105	Trading	7984381	13821	23464	321	0.0203219662717384758	t
4844	105	Management Consulting	7984381	13821	71135	399	0.0199944534763553915	t
4845	105	Analytics	7984381	13821	20051	310	0.0199528966600708291	t
4846	105	Financial Services	7984381	13821	73327	401	0.0198643996848566241	t
4847	105	Project Management	7984381	13821	479558	1091	0.0189085654414525711	t
4888	106	SQL	7984381	1586	74090	78	0.0399088884795157639	t
4889	106	Trading	7984381	1586	23464	67	0.0393137122775615092	t
4890	106	SAS	7984381	1586	5139	61	0.0378254204101542077	t
4891	106	Operational Risk	7984381	1586	11219	57	0.0345412132389666948	t
4892	106	Accounts Receivable	7984381	1586	22858	58	0.0337138448982138503	t
4893	106	Customer Service	7984381	1586	670741	184	0.0320148543104903371	t
4894	106	Trade Finance	7984381	1586	4605	51	0.0315858913400979754	t
4895	106	Credit Cards	7984381	1586	9868	52	0.0315572407416897724	t
4896	106	Credit Derivatives	7984381	1586	6124	50	0.0307649648167086197	t
4897	106	Forecasting	7984381	1586	72454	63	0.0306541948297102511	t
4935	107	Sales Management	7984381	2375	180284	144	0.0380633172848239415	t
4936	107	Real Estate	7984381	2375	34511	100	0.0377941914799230574	t
4937	107	Term Life Insurance	7984381	2375	1493	84	0.0351918990104281501	t
4938	107	Investment Properties	7984381	2375	18031	87	0.0343835225064186151	t
4940	107	Cross Selling	7984381	2375	4344	80	0.0331500089734730538	t
4941	107	Mortgage	7984381	2375	1111	75	0.0314491554339123569	t
4942	107	Inheritance Tax Planning	7984381	2375	10247	77	0.0311469368266046077	t
4943	107	Cemap Qualified	7984381	2375	607	72	0.030248763715998734	t
4944	107	Funding	7984381	2375	11583	74	0.029716026614968985	t
4945	107	Mortgage Servicing	7984381	2375	561	63	0.0264639254580206623	t
4946	107	Property	7984381	2375	25357	70	0.0263056835851196193	t
4947	107	Customer Experience	7984381	2375	42804	73	0.0253834259339398086	t
4977	108	Risk Management	7984381	2911	130308	191	0.0493108059429978665	t
4978	108	Data Analysis	7984381	2911	113349	177	0.046624504572095396	t
4979	108	Business Strategy	7984381	2911	247930	216	0.0431651679399592397	t
4980	108	Equity Valuation	7984381	2911	1529	125	0.0427646628051520095	t
4981	108	Trading	7984381	2911	23464	126	0.0403600720450433478	t
4982	108	English	7984381	2911	149229	152	0.0335378457676536942	t
4983	108	Business Analysis	7984381	2911	148418	147	0.0319212068615903344	t
4984	108	Mergers	7984381	2911	15944	95	0.0306491089563666608	t
4985	108	Market Research	7984381	2911	77513	117	0.0304954131697685593	t
4986	108	Microsoft Word	7984381	2911	319543	205	0.0304126122271556609	t
4987	108	Strategy	7984381	2911	223349	168	0.0297497335245014774	t
4988	108	VBA	7984381	2911	13934	89	0.0288390431520107043	t
4989	108	Venture Capital	7984381	2911	9820	85	0.0279798876400984935	t
4990	108	Equity Derivatives	7984381	2911	10334	85	0.0279154884755335696	t
4991	108	Alternative Investments	7984381	2911	11093	83	0.0271330935067081516	t
4992	108	Accounting	7984381	2911	101909	114	0.026407883810171083	t
4993	108	Bloomberg Terminal	7984381	2911	2775	76	0.025769708453402377	t
4994	108	Investment Management	7984381	2911	10236	78	0.0255222179500027499	t
4995	108	Financial Services	7984381	2911	73327	98	0.0244905307693593192	t
4996	108	LBO	7984381	2911	2262	72	0.0244593829189253958	t
4997	108	Financial Risk	7984381	2911	46720	87	0.0240439788378140722	t
5033	109	Consolidation	7984381	5582	6985	253	0.0444805205329923611	t
5035	109	Sage	7984381	5582	13935	265	0.0457607332136272943	t
5036	109	Budgets	7984381	5582	165031	350	0.042061717555205172	t
5037	109	Banking	7984381	5582	78690	297	0.0433815730270836752	t
5038	109	IFRS	7984381	5582	20168	1161	0.205607779657264872	t
5039	109	Forecasting	7984381	5582	72454	223	0.0308969725403567333	t
5040	109	Enterprise Risk Management	7984381	5582	6297	196	0.0343482113513502371	t
5041	109	Payroll	7984381	5582	31714	209	0.0334931878857100754	t
5042	109	Financial Modeling	7984381	5582	47994	207	0.0310942353688371878	t
5043	109	Governance	7984381	5582	96897	248	0.0323152936790908965	t
5044	109	VAT	7984381	5582	17993	424	0.0737564773654092593	t
5045	109	Accounts Payable	7984381	5582	22451	184	0.0301723247729269381	t
5046	109	General Ledger	7984381	5582	12071	177	0.0302183643085318539	t
5047	109	Data Analysis	7984381	5582	113349	246	0.0298947840331312865	t
5093	110	Financial Planning	7984381	1876	14327	53	0.0264634386636642752	t
5094	110	Mortgage Underwriting	7984381	1876	577	49	0.0260532583349929771	t
5095	110	Cash Management	7984381	1876	9500	50	0.0254686131178750511	t
5096	110	Change Management	7984381	1876	341196	127	0.0249701643974564527	t
5097	110	Income Protection	7984381	1876	9494	47	0.023869841818215335	t
5135	111	Accounting	7984381	2300	101909	150	0.0524689614149493055	t
5136	111	Portfolio Management	7984381	2300	52908	135	0.0520842183886633114	t
5137	111	Governance	7984381	2300	96897	146	0.0513572362896342477	t
5138	111	PMO	7984381	2300	25055	125	0.0512245804070392136	t
5139	111	Credit Risk	7984381	2300	25070	125	0.0512227011978455202	t
5140	111	Financial Reporting	7984381	2300	76474	134	0.0486969475754505665	t
5141	111	Business Intelligence	7984381	2300	44693	122	0.0474595960627310076	t
5142	111	Agile Methodologies	7984381	2300	46119	119	0.0459762222407915921	t
5143	111	Capital Markets	7984381	2300	31475	114	0.0456362920897445123	t
5144	111	FX Options	7984381	2300	13675	108	0.0452568396637418185	t
5145	111	Relationship Management	7984381	2300	42975	113	0.0437606571519381926	t
5146	111	Financial Markets	7984381	2300	27599	104	0.0417728008523090694	t
5147	111	Business Process Design	7984381	2300	8283	96	0.0407134580568651247	t
5163	112	Customer Service	7984381	1440	670741	257	0.094482624904642154	t
5164	112	Income Tax	7984381	1440	13691	135	0.0920518789691668754	t
5165	112	Tax Advisory	7984381	1440	8167	112	0.0767687511546322476	t
5166	112	Economics	7984381	1440	30444	111	0.0732836058895253439	t
5168	112	Data Analysis	7984381	1440	113349	120	0.0691494630028373358	t
5169	112	Corporate Recovery	7984381	1440	1643	92	0.063694599591247833	t
5170	112	Tax Returns	7984381	1440	8095	91	0.0621918064442387522	t
5171	112	Analysis	7984381	1440	128547	112	0.0616890956742773278	t
5172	112	Restructuring	7984381	1440	24781	88	0.0580178902041796896	t
5173	112	Bankruptcy	7984381	1440	2469	83	0.0573400015489974879	t
5174	112	Corporate Finance	7984381	1440	49388	91	0.057019151403947213	t
5175	112	Assurance	7984381	1440	8941	80	0.054445563636537235	t
5176	112	VAT	7984381	1440	17993	81	0.0540062154098345445	t
5177	112	Leadership	7984381	1440	330397	136	0.0530736012927789103	t
5178	112	Tax Accounting	7984381	1440	5246	77	0.052824716497201829	t
5179	112	Team Leadership	7984381	1440	284785	127	0.0525361576050452847	t
5180	112	PowerPoint	7984381	1440	268322	213	0.114331425337687781	t
5181	112	Public Speaking	7984381	1440	243457	118	0.0514620695903649783	t
5182	112	External Audit	7984381	1440	12659	73	0.0491178325165847751	t
5183	112	International Tax	7984381	1440	4823	69	0.0473211467949802844	t
5184	112	English	7984381	1440	149229	92	0.0452069269402787174	t
5185	112	Big 4	7984381	1440	5201	63	0.043106377555590096	t
5186	112	Social Media	7984381	1440	321965	115	0.0395438896760535244	t
5188	112	Internal Controls	7984381	1440	28669	60	0.0380828997316486062	t
5189	112	Receiverships	7984381	1440	950	53	0.0366931909520842314	t
5190	112	Bookkeeping	7984381	1440	20608	55	0.0356198293996883852	t
5191	112	Banking	7984381	1440	78690	65	0.0352897618566334823	t
5192	112	Management Accounting	7984381	1440	27852	54	0.0340178246964370629	t
5194	112	Cash Flow	7984381	1440	20454	48	0.0307771325546979911	t
5195	112	Insolvency	7984381	1440	1241	43	0.0297110411055830741	t
5196	112	Creditors	7984381	1440	339	39	0.0270457531983930924	t
5197	112	Administration	7984381	1440	46008	43	0.0241032081026835154	t
5288	114	Business Analysis	7984381	2840	148418	94	0.0145152127255824062	t
5289	114	Investment Management	7984381	2840	10236	43	0.0138637733871473379	t
5290	114	Cash Management	7984381	2840	9500	40	0.0128992722611504743	t
5291	114	FX Options	7984381	2840	13675	41	0.0127284282800900969	t
5292	114	Funding	7984381	2840	11583	40	0.0126382950889477631	t
5303	115	Equity Derivatives	7984381	1240	10334	144	0.114852592320450989	t
5304	115	Portfolio Management	7984381	1240	52908	137	0.103873565575415786	t
5305	115	Options	7984381	1240	9365	106	0.0843240517938102646	t
5306	115	Electronic Trading	7984381	1240	8414	105	0.0836366009601742511	t
5307	115	Asset Management	7984381	1240	38451	104	0.0790674699708200923	t
5308	115	Equity Trading	7984381	1240	3204	97	0.0778366112714200531	t
5309	115	Structured Products	7984381	1240	10212	94	0.0745390306817183684	t
5310	115	Trading Systems	7984381	1240	13324	90	0.070922901674109029	t
5311	115	Valuation	7984381	1240	31348	84	0.0638256824701762399	t
5312	115	ETFs	7984381	1240	1412	28	0.022407279815494726	t
5313	115	Financial Analysis	7984381	1240	97681	91	0.0611625851439968546	t
5314	115	Emerging Markets	7984381	1240	15273	77	0.0601932627811857593	t
5315	115	Equity Research	7984381	1240	5054	73	0.0582470278666407798	t
5316	115	Banking	7984381	1240	78690	76	0.0514428202003164164	t
5317	115	Bonds	7984381	1240	8967	65	0.0513042549049868499	t
5318	115	Financial Modeling	7984381	1240	47994	71	0.0512550388900001666	t
5320	115	Finance	7984381	1240	102182	70	0.0436606575637172103	t
5321	115	Swaps	7984381	1240	4718	53	0.0421575790256798824	t
5322	115	Security	7984381	1240	58305	57	0.0386713657346877196	t
5323	115	Risk Management	7984381	1240	130308	67	0.037717752282894583	t
5324	115	Commodity	7984381	1240	9015	44	0.034360127819524959	t
5325	115	Economics	7984381	1240	30444	44	0.0316758460311912723	t
5326	115	Alternative Investments	7984381	1240	11093	38	0.0292603680115868028	t
5327	115	FX Trading	7984381	1240	3531	36	0.0285944604607909804	t
5328	115	Proprietary Trading	7984381	1240	2134	35	0.0279628773614214593	t
5329	115	Hedging	7984381	1240	4433	34	0.0268683185987134143	t
5330	115	Interest Rate Derivatives	7984381	1240	5872	33	0.0258814868572367351	t
5331	115	Financial Risk	7984381	1240	46720	39	0.0256041651379915434	t
5332	115	FX Options	7984381	1240	13675	78	0.0612000114951924204	t
5333	115	Financial Services	7984381	1240	73327	38	0.0214646895937810819	t
5334	115	Trading Strategies	7984381	1240	1860	24	0.019124854045746268	t
5335	115	Wealth Management	7984381	1240	21921	26	0.0182250871333201614	t
5336	115	Private Equity	7984381	1240	24099	25	0.0171456853119714113	t
5337	115	Credit Derivatives	7984381	1240	6124	22	0.0169775746890409619	t
5339	115	Technical Analysis	7984381	1240	3155	21	0.0165429065633641327	t
5340	115	Market Making	7984381	1240	716	20	0.0160418485292540131	t
5341	115	Bloomberg Terminal	7984381	1240	2775	20	0.0157839299981896129	t
5342	115	Credit	7984381	1240	26674	23	0.0152099768144053852	t
5419	117	Risk Management	7984381	2198	130308	88	0.0237225637790967406	t
5420	117	Recruiting	7984381	2198	160827	96	0.023539848272846723	t
5421	117	Relationship Management	7984381	2198	42975	62	0.0228313630856814415	t
5422	117	Audio Typing	7984381	2198	3098	43	0.0191805119267422254	t
5423	117	Budgets	7984381	2198	165031	86	0.0184623319793442535	t
5424	117	Investments	7984381	2198	60931	57	0.0183064314823707733	t
5425	117	Travel Management	7984381	2198	12036	42	0.0176056837846134545	t
5426	117	Equities	7984381	2198	39231	49	0.017384311381619548	t
5427	117	Data Entry	7984381	2198	27582	45	0.0170233492618476305	t
5428	117	Meeting Scheduling	7984381	2198	1732	36	0.0161660527282807449	t
5429	117	Secretarial Skills	7984381	2198	4430	36	0.0158280499538517444	t
5430	117	Finance	7984381	2198	102182	59	0.0140487156229428013	t
5431	117	System Administration	7984381	2198	32282	39	0.013704031909172177	t
5432	117	Access	7984381	2198	21525	36	0.0136864052433759258	t
5433	117	Retail Banking	7984381	2198	25392	37	0.0136570356365931494	t
5434	117	Expense Management	7984381	2198	777	29	0.0131001038558791871	t
5435	117	Bloomberg	7984381	2198	19492	34	0.0130309288094174851	t
5436	117	Asset Management	7984381	2198	38451	39	0.0129311856840229923	t
5437	117	Corporate Finance	7984381	2198	49388	42	0.0129262621276557028	t
5469	118	Sales	7984381	1454	353906	133	0.0471556006125947655	t
5470	118	Income Tax	7984381	1454	13691	71	0.0471246704359185378	t
5471	118	Business Development	7984381	1454	206995	106	0.0469859044673741899	t
5472	118	VAT	7984381	1454	17993	71	0.046585770355785025	t
5473	118	Corporate Tax	7984381	1454	15335	69	0.0455429645821775198	t
5474	118	Investment Management	7984381	1454	10236	67	0.0448059363761213747	t
5475	118	Credit Risk	7984381	1454	25070	68	0.0436356038881684713	t
5476	118	Microsoft Office	7984381	1454	601080	172	0.0430202159516553106	t
5477	118	Retail Banking	7984381	1454	25392	66	0.0422195014528227372	t
5478	118	Retirement Planning	7984381	1454	11670	61	0.0404990039567642082	t
5479	118	Bloomberg	7984381	1454	19492	60	0.0388312796768173138	t
5480	118	Team Management	7984381	1454	150662	83	0.0382212762542259374	t
5481	118	Financial Planning	7984381	1454	14327	58	0.03810251911494731	t
5482	118	Strategic Financial Planning	7984381	1454	21890	57	0.0364672390750642519	t
5483	118	Trading	7984381	1454	23464	57	0.0362700682879582223	t
5484	118	Auditing	7984381	1454	53141	62	0.0359919254356833584	t
5485	118	FX Options	7984381	1454	13675	54	0.035432660711911132	t
5486	118	Alternative Investments	7984381	1454	11093	53	0.0350682177973080586	t
5487	118	Financial Advisory	7984381	1454	13434	53	0.0347749669633720809	t
5557	120	Analysis	7984381	567	128547	65	0.0985456381943992099	t
5558	120	Financial Services	7984381	567	73327	60	0.0966431635717017318	t
5559	120	Statistics	7984381	567	36968	54	0.090614490529869321	t
5560	120	Economic Capital	7984381	567	892	49	0.0863141644542196468	t
5561	120	Defined Contribution	7984381	567	1133	49	0.0862839783802454852	t
5562	120	Life Insurance	7984381	567	6444	48	0.0838549637882888832	t
5563	120	Pension Administration	7984381	567	2175	47	0.0826258769501602153	t
5564	120	Reinsurance	7984381	567	9264	47	0.0817379554630113386	t
5565	120	VBA	7984381	567	13934	45	0.0776254346288668129	t
5566	120	Enterprise Risk Management	7984381	567	6297	42	0.0732906139383544819	t
5567	120	General Insurance	7984381	567	22948	43	0.0729688129426733778	t
5568	120	Financial Reporting	7984381	567	76474	36	0.0539179426520739816	t
5569	120	Mathematics	7984381	567	13271	30	0.0512515723893393754	t
5570	120	Finance	7984381	567	102182	33	0.0454065467056751632	t
5571	120	Investment Strategies	7984381	567	9606	26	0.0446554514348845855	t
5572	120	Economics	7984381	567	30444	27	0.0438092143739344381	t
5573	120	Microsoft Word	7984381	567	319543	47	0.0428744498753310735	t
5574	120	Microsoft Office	7984381	567	601080	66	0.0411230580473000151	t
5575	120	Prophet	7984381	567	354	22	0.0387591213322707878	t
5576	120	Actuarial Exams	7984381	567	162	20	0.035255582621206788	t
5577	120	Embedded Value	7984381	567	182	20	0.0352530775528271875	t
5578	120	Teamwork	7984381	567	285884	40	0.034743798918498707	t
5579	120	Funding	7984381	567	11583	20	0.0338250633230367595	t
5580	120	R	7984381	567	14529	18	0.0299284793832136735	t
5581	120	Pension Schemes	7984381	567	876	17	0.0298747706287928703	t
5582	120	Mergers & Acquisitions	7984381	567	36659	18	0.027156621221187352	t
5584	120	Consulting	7984381	567	41734	16	0.0229933727523559464	t
5585	120	Health Insurance	7984381	567	3250	13	0.0225222442771181586	t
5586	120	Statistical Modeling	7984381	567	4097	13	0.0224161546312421391	t
5587	120	Matlab	7984381	567	43522	15	0.021005625955465717	t
5630	122	General Ledger	7984381	457	12071	23	0.0488191951705069516	t
5631	122	Payroll Services	7984381	457	1025	22	0.0480144163153186782	t
5632	122	Administration	7984381	457	46008	24	0.046756837514876734	t
5633	122	Bank Reconciliation	7984381	457	10490	20	0.0424522909201795889	t
5634	122	Peoplesoft	7984381	457	3132	19	0.0411855838201833704	t
5635	122	Teamwork	7984381	457	285884	34	0.0385950529295402481	t
5637	122	Budgets	7984381	457	165031	26	0.0362256233441582282	t
5638	122	Invoicing	7984381	457	20378	17	0.0346488749996509693	t
5639	122	Office Administration	7984381	457	55039	18	0.0324958351180877417	t
5640	122	Deferred Compensation	7984381	457	4107	15	0.0323102271827052645	t
5641	122	Corporate Tax	7984381	457	15335	15	0.0309039011705839056	t
5642	122	Process Improvement	7984381	457	108186	20	0.0302157014937271332	t
5643	122	Year End Accounts	7984381	457	3615	14	0.0301835419566647625	t
5645	122	Tax Returns	7984381	457	8095	14	0.0296224143707809265	t
5646	122	Management Accounting	7984381	457	27852	15	0.0293361257258276664	t
5743	125	Biotechnology	7985312	235	17771	20	0.0828833612094906219	t
5744	125	Molecular Biology	7985312	235	22160	16	0.0653119333753796744	t
5745	125	Lifesciences	7985312	235	17496	14	0.0573851341563289957	t
5746	125	Biochemistry	7985312	235	16725	12	0.0489708005027324617	t
5747	125	PCR	7985312	235	12066	11	0.0452988194981873843	t
5748	125	Cell Culture	7985312	235	14013	11	0.0450549896641106451	t
5749	126	Molecular Biology	7985312	23	22160	12	0.518965530130523045	t
5750	126	Biotechnology	7985312	23	17771	9	0.389080007542347728	t
5751	126	Dna Sequencing	7985312	23	1956	7	0.304103752265708516	t
5752	126	PCR	7985312	23	12066	7	0.302837674106232968	t
5753	126	Life Sciences	7985312	23	14634	7	0.302516082739909264	t
5754	128	Molecular Biology	7985312	126	22160	46	0.362309986883290469	t
5755	128	Cell Culture	7985312	126	14013	43	0.339520351652442265	t
5756	128	Biochemistry	7985312	126	16725	41	0.323307456407799954	t
5757	128	Biotechnology	7985312	126	17771	35	0.275556664831880238	t
5758	128	PCR	7985312	126	12066	31	0.244524580137300968	t
5759	128	Life Sciences	7985312	126	14634	30	0.236266351454400919	t
5760	128	Cell Biology	7985312	126	11317	27	0.212871846155403971	t
5761	128	ELISA	7985312	126	5154	26	0.205707017175403739	t
5762	128	Assay Development	7985312	126	2286	24	0.190192915922535732	t
5763	128	Western Blotting	7985312	126	8371	21	0.165620980316968591	t
5764	128	Lifesciences	7985312	126	17496	20	0.156541606077784695	t
5765	128	Protein Chemistry	7985312	126	3680	16	0.126525277309241513	t
5766	128	Protein Purification	7985312	126	3963	16	0.126489836682060125	t
5767	128	Qpcr	7985312	126	3397	15	0.118624084768016794	t
5768	128	Protein Expression	7985312	126	3605	15	0.118598036533197962	t
5769	128	Cell	7985312	126	4448	14	0.110555832874636717	t
5770	128	Drug Discovery	7985312	126	6181	14	0.11033880599511256	t
5771	128	Microbiology	7985312	126	8840	12	0.0941325480410731413	t
5772	128	GMP	7985312	126	13131	12	0.0935951779660366967	t
5773	128	Science	7985312	126	39887	12	0.0902444732986689008	t
5774	128	Dna	7985312	126	2752	11	0.0869583266687103673	t
5775	128	Genetics	7985312	126	7834	11	0.0863218981622234788	t
5776	128	Hplc	7985312	126	8183	11	0.0862781922297630455	t
5777	128	Laboratory	7985312	126	9728	11	0.086084708947094371	t
5778	128	Purification	7985312	126	1642	10	0.0791607009072701068	t
5779	128	Dna Sequencing	7985312	126	1956	10	0.079121378091245545	t
5780	128	Biopharmaceuticals	7985312	126	3300	10	0.0789530664201085058	t
5781	128	Immunoassays	7985312	126	1222	9	0.0712766651360943332	t
5782	128	Sds Page	7985312	126	2290	9	0.0711429174688515131	t
5783	128	Chromatography	7985312	126	4463	9	0.0708707885541336874	t
5784	129	Molecular Biology	7985312	91	22160	34	0.370855504792561741	t
5785	129	Biochemistry	7985312	91	16725	30	0.327579592294369726	t
5786	129	Biotechnology	7985312	91	17771	30	0.327448600303039794	t
5787	129	Cell Culture	7985312	91	14013	27	0.294951811052492574	t
5788	129	Life Sciences	7985312	91	14634	22	0.23992836128279843	t
5789	129	Protein Purification	7985312	91	3963	20	0.219286432570072437	t
5790	129	PCR	7985312	91	12066	20	0.218271682946987483	t
5791	129	Protein Chemistry	7985312	91	3680	17	0.186354464380833335	t
5792	129	Science	7985312	91	39887	17	0.181820212918037266	t
5793	129	Cell Biology	7985312	91	11317	16	0.174408936346145099	t
5794	129	ELISA	7985312	91	5154	14	0.15320246471093768	t
5795	129	Western Blotting	7985312	91	8371	14	0.152799595460355903	t
5796	129	Microbiology	7985312	91	8840	14	0.152740861957551155	t
5797	129	Lifesciences	7985312	91	17496	14	0.151656859398323296	t
5798	129	Sds Page	7985312	91	2290	13	0.142571991074869064	t
5799	129	Protein Expression	7985312	91	3605	12	0.131418175630226869	t
5800	129	Genetics	7985312	91	7834	11	0.119899436033829812	t
5801	129	Research	7985312	91	383919	15	0.116758348927377187	t
5802	129	Microscopy	7985312	91	7431	10	0.108960768047222892	t
5803	129	Chemistry	7985312	91	17386	10	0.107714089965301296	t
5804	129	Qpcr	7985312	91	3397	9	0.0984768150897929878	t
5805	130	Laboratory	7985312	29	9728	9	0.309127713552803218	t
5806	130	Biotechnology	7985312	29	17771	8	0.273637601780071238	t
5807	131	Healthcare	7985312	281	101839	31	0.0975704281221242836	t
5808	131	Hospitals	7985312	281	52229	26	0.0859890827102866295	t
5809	131	Clinical Research	7985312	281	55917	23	0.074850686218007681	t
5810	131	Healthcare Management	7985312	281	40006	14	0.0448136927682118782	t
5811	133	Engineering	7985312	1481	144748	476	0.303333933662981114	t
5812	133	Mechanical Engineering	7985312	1481	30124	403	0.268390787928145247	t
5813	133	Solidworks	7985312	1481	22023	338	0.225508058249042936	t
5814	133	AutoCAD	7985312	1481	71006	275	0.176826067024282302	t
5815	133	CAD	7985312	1481	35654	260	0.171123845971507843	t
5816	133	Manufacturing	7985312	1481	84795	213	0.133227579940244756	t
5817	133	Microsoft Office	7985312	1481	601313	284	0.116481545894763922	t
5818	133	Project Engineering	7985312	1481	44782	178	0.114602269840788612	t
5819	133	Matlab	7985312	1481	43788	168	0.107973324479429034	t
5820	133	Finite Element Analysis	7985312	1481	11592	154	0.102551149177539463	t
5821	133	ANSYS	7985312	1481	6605	109	0.0727852751716919211	t
5822	133	Engineering Design	7985312	1481	7583	96	0.0638832964956243116	t
5823	133	Project Management	7985312	1481	482308	184	0.0638528273343023506	t
5824	133	Commissioning	7985312	1481	40009	88	0.0544190801840988003	t
5825	133	Pro Engineer	7985312	1481	5077	75	0.0500149422063125154	t
5826	133	Design for Manufacturing	7985312	1481	7305	72	0.0477098440846214777	t
5827	133	Microsoft Excel	7985312	1481	428582	149	0.0469451137120261708	t
5828	133	Product Development	7985312	1481	108810	89	0.0464768827537339682	t
5829	133	Lean Manufacturing	7985312	1481	42471	73	0.04398053643110688	t
5830	133	Hvac	7985312	1481	13811	67	0.0435182235785430763	t
5831	133	Engineering Management	7985312	1481	26944	67	0.0418732739296840267	t
5832	133	Product Design	7985312	1481	19582	65	0.0414446982378055551	t
5833	133	Continuous Improvement	7985312	1481	68369	69	0.0380353514955375366	t
5834	133	Design Engineering	7985312	1481	3934	55	0.0366512125699189478	t
5835	133	Project Planning	7985312	1481	227093	96	0.036388977039212983	t
5836	133	Microsoft Word	7985312	1481	319615	113	0.0362811647752333197	t
5837	133	CATIA	7985312	1481	9722	54	0.035250902625065049	t
5838	133	Inventor	7985312	1481	2814	49	0.032739427903635647	t
5839	133	Autodesk Inventor	7985312	1481	1913	46	0.030826246895420583	t
5840	133	PowerPoint	7985312	1481	268398	93	0.0291893614859781159	t
5841	133	Pumps	7985312	1481	10765	45	0.0290421612919887391	t
5842	133	Construction	7985312	1481	122317	65	0.0285768156385872128	t
5843	133	Building Services	7985312	1481	26300	47	0.0284470429703040442	t
5844	133	CFD	7985312	1481	4630	42	0.0277845552827935757	t
5845	133	PTC Creo	7985312	1481	1576	41	0.0274917337103764113	t
5846	133	Renewable Energy	7985312	1481	32734	45	0.0262904747896066104	t
5847	133	Piping	7985312	1481	14814	41	0.025833632480528234	t
5848	133	Teamwork	7985312	1481	286068	91	0.0256254488862918545	t
5849	133	Solid Edge	7985312	1481	1827	38	0.0254342610707377903	t
5850	133	Sheet Metal	7985312	1481	2328	37	0.0246961645419744823	t
5851	133	Thermodynamics	7985312	1481	2398	37	0.0246873968213150649	t
5852	133	Inspection	7985312	1481	41132	43	0.0238879094178363685	t
5853	133	Factory	7985312	1481	13994	37	0.0232349612675063731	t
5854	133	Heat Transfer	7985312	1481	1789	34	0.022737641892635007	t
5855	133	Energy	7985312	1481	53046	43	0.0223956433616034657	t
5856	133	Cam	7985312	1481	2493	32	0.0212987742744870576	t
5857	133	Fluid Mechanics	7985312	1481	2830	32	0.0212565639621695758	t
5858	133	Machining	7985312	1481	4283	31	0.0203992264324381854	t
5859	133	Simulations	7985312	1481	12741	32	0.0200151799699482963	t
5860	133	Stress Analysis	7985312	1481	2486	30	0.0199489616476083327	t
5861	134	Engineering	7985312	492	144748	187	0.36197682256553354	t
5862	134	Mechanical Engineering	7985312	492	30124	109	0.217785707730011213	t
5863	134	Manufacturing	7985312	492	84795	104	0.200775612985803181	t
5864	134	Commissioning	7985312	492	40009	94	0.186058050231615313	t
5865	134	Project Engineering	7985312	492	44782	71	0.138709443038083469	t
5866	134	Automation	7985312	492	11981	52	0.104197097121870058	t
5867	134	Continuous Improvement	7985312	492	68369	55	0.103233133855230141	t
5868	134	Electrical Engineering	7985312	492	25677	52	0.102481842426084796	t
5869	134	Preventive Maintenance	7985312	492	10027	44	0.088180646964607215	t
5870	134	Product Development	7985312	492	108810	50	0.088005170705723057	t
5871	134	Electricians	7985312	492	26464	43	0.0840894703390740877	t
5872	134	Electronics	7985312	492	24798	42	0.0822654706818383014	t
5873	134	Troubleshooting	7985312	492	38538	41	0.078512059967120934	t
5874	134	PLC	7985312	492	7880	39	0.0782863043600842412	t
5875	134	Lean Manufacturing	7985312	492	42471	39	0.0739542092095360759	t
5876	134	Pumps	7985312	492	10765	37	0.073859702647562378	t
5877	134	Instrumentation	7985312	492	12159	36	0.0716524758167647463	t
5878	134	Hydraulics	7985312	492	10192	35	0.0698661726886930512	t
5879	134	AutoCAD	7985312	492	71006	38	0.0683479076344110925	t
5880	134	Project Management	7985312	492	482308	59	0.0595229732971158318	t
5881	134	Hvac	7985312	492	13811	29	0.0572170642982050351	t
5882	134	Maintenance & Repair	7985312	492	11715	26	0.0513816256998060328	t
5883	134	Inspection	7985312	492	41132	27	0.0497301556532789291	t
5884	134	Pneumatics	7985312	492	2898	23	0.0463879092692204564	t
5885	134	Maintenance	7985312	492	5570	23	0.0460532742993651559	t
5886	134	Solidworks	7985312	492	22023	24	0.0460253849973006751	t
5887	134	Field Service	7985312	492	1418	21	0.0425079698483970952	t
5888	134	Maintenance Management	7985312	492	14316	20	0.0388600092252284479	t
5889	134	Building Services	7985312	492	26300	20	0.0373591613664163505	t
5890	134	Control Systems Design	7985312	492	5830	18	0.0358574846991678853	t
5891	134	Engineering Management	7985312	492	26944	19	0.0352458627644329087	t
5892	134	Project Planning	7985312	492	227093	31	0.0345714214266285708	t
5893	134	CAD	7985312	492	35654	18	0.0321223973709626187	t
5894	134	Process Control	7985312	492	7526	16	0.0315797905387260949	t
5895	134	Manufacturing Engineering	7985312	492	8613	16	0.031443657225764754	t
5896	134	Machining	7985312	492	4283	15	0.0299532906372769157	t
5897	134	Energy	7985312	492	53046	18	0.0299442643635811113	t
5898	134	Gas	7985312	492	58103	18	0.0293109376260967357	t
5899	134	Power Generation	7985312	492	15084	15	0.0286005989047143777	t
5900	134	Air Conditioning	7985312	492	4737	14	0.0278637871865930614	t
5901	134	Cnc	7985312	492	2123	13	0.0261585128105783979	t
5902	134	Hvac Controls	7985312	492	2674	13	0.0260895068718095847	t
5903	134	Air Compressors	7985312	492	3156	13	0.0260291423300916744	t
5904	134	Testing	7985312	492	52639	16	0.0259299449567342681	t
5905	134	Building Management Systems	7985312	492	4117	13	0.0259087889595711121	t
5906	134	Fault Finding	7985312	492	5368	13	0.0257521166739090694	t
5907	134	Factory	7985312	492	13994	13	0.0246718168049076397	t
5908	134	Machine Tools	7985312	492	2785	12	0.0240429599311034158	t
5909	134	Refrigeration	7985312	492	2881	12	0.0240309371178152008	t
5910	134	Energy Management	7985312	492	13241	12	0.0227334751837953986	t
5911	135	Electrical Engineering	7985312	583	25677	19	0.0293766675096917042	t
5912	135	Electronics	7985312	583	24798	18	0.0277713615431859906	t
5913	135	Manufacturing	7985312	583	84795	20	0.0236881755276383658	t
\.


--
-- Name: career_skill_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geektalent
--

SELECT pg_catalog.setval('career_skill_id_seq', 5913, true);


--
-- Data for Name: career_subject; Type: TABLE DATA; Schema: public; Owner: geektalent
--

COPY career_subject (id, career_id, subject_name, count, visible) FROM stdin;
1	1	Computer Science	177	t
2	1	Information Technology	101	t
3	1	Project Management	56	t
4	1	Computing	45	t
5	1	Business Studies	39	t
6	1	Mathematics	34	t
7	1	Business	32	t
8	1	Business Management	30	t
9	1	 Business Administration and Management	29	t
10	1	Electrical and Electronics Engineering	29	t
11	1	Marketing	23	t
12	1	Economics	22	t
13	1	Business Administration	20	t
14	1	Mechanical Engineering	20	t
15	1	Business Information Technology	19	t
16	1	Business Information Systems	17	t
17	1	Law	17	t
18	1	Computer Studies	16	t
19	1	Information Systems	16	t
20	1	History	16	t
21	1	Physics	16	t
22	1	Business and Finance	15	t
23	1	Civil Engineering	14	t
24	1	English	12	t
25	1	Management	12	t
26	1	Psychology	12	t
27	1	Software Engineering	11	t
28	1	International Business	11	t
29	1	 Management Information Systems	9	t
30	1	Engineering	9	t
31	1	Chemistry	9	t
32	1	Electronics and Communications Engineering	9	t
33	1	Computer Software Engineering	8	t
34	1	Accounting and Finance	8	t
35	1	Information Technology Project Management	8	t
36	1	Geography	8	t
37	1	Biology	7	t
38	1	Mathematics and Computer Science	7	t
39	1	 English Language and Literature	7	t
40	1	Business Computing	7	t
41	1	Electronics	7	t
42	1	Graphic Design	7	t
43	1	French	6	t
44	1	Management Science	6	t
45	1	Business IT	6	t
46	1	Computer Information Systems	6	t
47	1	Applied Computing	6	t
48	1	English Literature	6	t
49	1	Public Administration	5	t
50	1	Accounting	5	t
51	2	Computer Science	215	t
52	2	Information Technology	67	t
53	2	Computing	36	t
54	2	Mathematics	36	t
55	2	Physics	28	t
56	2	Business	27	t
57	2	Electrical and Electronics Engineering	25	t
58	2	Business Studies	24	t
59	2	 Business Administration and Management	22	t
60	2	Mechanical Engineering	21	t
61	2	Psychology	20	t
62	2	Economics	20	t
63	2	Business Management	17	t
64	2	Business Administration	16	t
65	2	Information Systems	16	t
66	2	Law	16	t
67	2	Marketing	15	t
68	2	International Business	15	t
69	2	English	14	t
70	2	History	14	t
71	2	Computer Software Engineering	13	t
72	2	Management	12	t
73	2	Electronic Engineering	12	t
74	2	Geography	12	t
75	2	Software Engineering	12	t
76	2	Accounting and Finance	11	t
77	2	Computer Engineering	11	t
78	2	Finance	11	t
79	2	Business and Finance	11	t
80	2	Computer Studies	11	t
81	2	Accounting	10	t
82	2	Electronics and Communication	10	t
83	2	Computer Information Systems	10	t
84	2	Computer Science and Engineering	9	t
85	2	Electronics	9	t
86	2	Mathematics and Computer Science	8	t
87	2	Business Information Systems	8	t
88	2	Artificial Intelligence	8	t
89	2	Project Management	7	t
90	2	Mechanical	7	t
91	2	Chemistry	7	t
92	2	Business Computing	6	t
93	2	 English Language and Literature	6	t
94	2	Engineering	6	t
95	2	Information Systems Management	6	t
96	2	 Management Information Systems	5	t
97	2	 MSc	5	t
98	2	Human Resource Management	5	t
99	2	Civil Engineering	5	t
100	2	Informatics	5	t
101	3	Computer Science	1575	t
102	3	Information Technology	1325	t
103	3	Electrical and Electronics Engineering	583	t
104	3	Computing	553	t
105	3	Mechanical Engineering	394	t
106	3	Mathematics	266	t
107	3	Engineering	219	t
108	3	Computer Systems Networking and Telecommunications	212	t
109	3	Business	201	t
110	3	 Business Administration and Management	185	t
111	3	Physics	164	t
112	3	Computer Networking	158	t
113	3	Business Information Technology	155	t
114	3	Electronic Engineering	142	t
115	3	Computer Engineering	136	t
116	3	Business Studies	135	t
117	3	Business Management	131	t
118	3	Business Information Systems	126	t
119	3	Computer Studies	120	t
120	3	Economics	106	t
121	3	Computer Software Engineering	105	t
122	3	Information Systems	104	t
123	3	English	102	t
124	3	Chemistry	100	t
125	3	Psychology	99	t
126	3	Law	95	t
127	3	Electrical Engineering	94	t
128	3	Business Administration	89	t
129	3	Chemical Engineering	88	t
130	3	Electronics	88	t
131	3	Accounting	86	t
132	3	Management	85	t
133	3	Accounting and Finance	84	t
134	3	Computer Technology/Computer Systems Technology	83	t
135	3	 Aerospace	80	t
136	3	Software Engineering	79	t
137	3	Telecommunications Engineering	79	t
138	3	Civil Engineering	75	t
139	3	Project Management	74	t
140	3	Systems Engineering	73	t
141	3	Computer and Information Sciences and Support Services	71	t
142	3	History	70	t
143	3	International Business	67	t
144	3	Marketing	65	t
145	3	Geography	61	t
146	3	Computer Information Systems	60	t
147	3	 Management Information Systems	56	t
148	3	Electronics and Communications Engineering	55	t
149	3	ICT	54	t
150	3	Telecommunications	52	t
151	4	Computer Science	1320	t
152	4	Information Technology	594	t
153	4	Computing	316	t
154	4	Electrical and Electronics Engineering	205	t
155	4	Mechanical Engineering	202	t
156	4	Mathematics	198	t
157	4	Physics	121	t
158	4	 Business Administration and Management	120	t
159	4	Software Engineering	116	t
160	4	Economics	114	t
161	4	Business	107	t
162	4	Computer Engineering	105	t
163	4	Business Studies	98	t
164	4	Accounting	97	t
165	4	Computer Software Engineering	95	t
166	4	Information Systems	91	t
167	4	Business Information Systems	85	t
168	4	Business Information Technology	84	t
169	4	Chemistry	74	t
170	4	Computer Studies	72	t
171	4	Management	69	t
172	4	Psychology	69	t
173	4	Engineering	67	t
174	4	Marketing	67	t
175	4	Computer Science and Engineering	64	t
176	4	Finance	63	t
177	4	Business Administration	63	t
178	4	Accounting and Finance	63	t
179	4	Electronics	63	t
180	4	Law	61	t
181	4	Business Management	60	t
182	4	International Business	60	t
183	4	Electronic Engineering	55	t
184	4	Electronics and Communications Engineering	54	t
185	4	Computer Applications	51	t
186	4	Civil Engineering	51	t
187	4	Electronics and Communication	50	t
188	4	 Management Information Systems	49	t
189	4	Geography	49	t
190	4	Project Management	47	t
191	4	Chemical Engineering	46	t
192	4	Electrical Engineering	43	t
193	4	Human Resource Management	43	t
194	4	Computer Systems Networking and Telecommunications	40	t
195	4	English	39	t
196	4	Mathematics and Computer Science	39	t
197	4	Computer Information Systems	33	t
198	4	Business Computing	32	t
199	4	Biochemistry	32	t
200	4	Computer Programming	30	t
201	5	Computer Science	78	t
202	5	Information Technology	36	t
203	5	Computing	33	t
204	5	Business Information Systems	21	t
205	5	Mathematics	19	t
206	5	Business	18	t
207	5	Business Information Technology	16	t
208	5	Electrical and Electronics Engineering	13	t
209	5	 Business Administration and Management	10	t
210	5	Economics	10	t
211	5	Computer Software Engineering	9	t
212	5	Business Studies	9	t
213	5	International Business	9	t
214	5	Finance	9	t
215	5	Information Systems	9	t
216	5	Project Management	8	t
217	5	Physics	8	t
218	5	 Management Information Systems	7	t
219	5	Accounting and Finance	7	t
220	5	Business Administration	7	t
221	5	Geography	7	t
222	5	Business Management	7	t
223	5	Software Engineering	7	t
224	5	Marketing	7	t
225	5	Accounting	6	t
226	5	Chemistry	6	t
227	5	Computer Engineering	6	t
228	5	Sociology	6	t
229	5	Management	6	t
230	5	Mechanical Engineering	6	t
231	5	Computer Studies	5	t
232	5	Computer Technology/Computer Systems Technology	5	t
233	5	Psychology	5	t
234	6	Computer Science	97	t
235	6	Information Technology	91	t
236	6	Computing	29	t
237	6	Mathematics	19	t
238	6	Business Information Technology	16	t
239	6	Business	14	t
240	6	Psychology	13	t
241	6	Computer Software Engineering	12	t
242	6	Electrical and Electronics Engineering	12	t
243	6	Business Studies	11	t
244	6	Business Information Systems	10	t
245	6	Computer Networking	9	t
246	6	 English Language and Literature	9	t
247	6	Economics	9	t
248	6	Law	9	t
249	6	Business and Finance	8	t
250	6	Computer Systems Networking and Telecommunications	8	t
251	6	Chemistry	8	t
252	6	Geography	8	t
253	6	Computer Studies	7	t
254	6	English	7	t
255	6	History	7	t
256	6	Computing and IT	7	t
257	6	Business Administration	7	t
258	6	Business Management	6	t
259	6	International Business	6	t
260	6	Physics	6	t
261	6	Information Systems	5	t
262	6	Graphic Design	5	t
263	6	Network and System Administration/Administrator	5	t
264	6	ICT	5	t
265	6	Mechanical Engineering	5	t
266	6	Social Sciences	5	t
267	7	Computer Science	115	t
268	7	Information Technology	74	t
269	7	Computer Networking	38	t
270	7	Computer Systems Networking and Telecommunications	37	t
271	7	Electrical and Electronics Engineering	26	t
272	7	 Business Administration and Management	21	t
273	7	Computing	20	t
274	7	Computer Networks and Security	17	t
275	7	Telecommunications Engineering	15	t
276	7	Economics	14	t
277	7	Business Information Technology	12	t
278	7	Business Studies	12	t
279	7	Computer Engineering	12	t
280	7	Electronic Engineering	12	t
281	7	Business	12	t
282	7	Business Management	11	t
283	7	Geography	11	t
284	7	Telecommunications	11	t
285	7	Management	10	t
286	7	Mathematics	10	t
287	7	Network Security	9	t
288	7	Marketing	9	t
289	7	Business Information Systems	9	t
290	7	Network and System Administration/Administrator	9	t
291	7	 System	9	t
292	7	Computer Systems and Networks	9	t
293	7	Civil Engineering	8	t
294	7	Information Security	8	t
295	7	Electronics	8	t
296	7	Software Engineering	8	t
297	7	English	7	t
298	7	Computer Systems	7	t
299	7	Sports Science	7	t
300	7	Networking	7	t
301	7	 Logistics	7	t
302	7	Chemistry	7	t
303	7	Computer Software Engineering	6	t
304	7	ICT	6	t
305	7	Project Management	6	t
306	7	Engineering	6	t
307	7	Business Administration	6	t
308	7	Computer Network Technology	6	t
309	7	Mechanical Engineering	6	t
310	7	Data Networks and Security	6	t
311	7	Network Computing	6	t
312	7	International Business	6	t
313	7	Advanced Networking	6	t
314	7	Electrical Engineering	5	t
315	7	Physics	5	t
316	7	Law	5	t
317	8	Computer Science	3839	t
318	8	Information Technology	718	t
319	8	Computing	604	t
320	8	Computer Software Engineering	560	t
321	8	Software Engineering	452	t
322	8	Mathematics	333	t
323	8	Electrical and Electronics Engineering	290	t
324	8	Computer Engineering	239	t
325	8	Physics	220	t
326	8	Mechanical Engineering	123	t
327	8	Electronic Engineering	117	t
328	8	Computer Science and Engineering	117	t
329	8	Mathematics and Computer Science	113	t
330	8	Electronics and Communications Engineering	93	t
331	8	Electronics	87	t
332	8	Engineering	86	t
333	8	Computer Studies	78	t
334	8	Electronics and Communication	74	t
335	8	Software Development	72	t
336	8	Chemistry	70	t
337	8	Computer Programming	70	t
338	8	Artificial Intelligence	69	t
339	8	Informatics	67	t
340	8	Computer Systems Engineering	66	t
341	8	Information Systems	66	t
342	8	Computer Applications	64	t
343	8	Economics	60	t
344	8	 Business Administration and Management	57	t
345	8	Advanced Computer Science	51	t
346	8	Business Information Technology	50	t
347	8	Computer Games Programming	50	t
348	8	Telecommunications Engineering	44	t
349	8	Computer Information Systems	42	t
350	8	Advanced Software Engineering	42	t
351	8	Business Information Systems	42	t
352	8	Computer Games and Programming Skills	41	t
353	8	Business	40	t
354	8	Computer Games Development	40	t
355	8	Electrical Engineering	40	t
356	8	Computer Technology/Computer Systems Technology	39	t
357	8	Psychology	39	t
358	8	Applied Computing	36	t
359	8	Embedded Systems	35	t
360	8	Management	35	t
361	8	Law	34	t
362	8	Applied Mathematics	34	t
363	8	Finance	33	t
364	8	Electronics and Telecommunications	33	t
365	8	Civil Engineering	33	t
366	8	Computer Science and Software Engineering	32	t
367	9	Economics	435	t
368	9	Finance	292	t
369	9	Mathematics	177	t
370	9	Accounting and Finance	128	t
371	9	Computer Science	125	t
372	9	Management	85	t
373	9	Law	65	t
374	9	Chemistry	64	t
375	9	Physics	50	t
376	9	History	46	t
377	9	 Business Administration and Management	46	t
378	9	Business	44	t
379	9	International Business	44	t
380	9	Business Management	43	t
381	9	Information Technology	40	t
382	9	Geography	38	t
383	9	Mechanical Engineering	35	t
384	9	Politics	33	t
385	9	Economics and Finance	32	t
386	9	Computing	30	t
387	9	Psychology	30	t
388	9	International Relations	27	t
389	9	Business Administration	27	t
390	9	Financial Economics	25	t
391	9	Accounting	25	t
392	9	Finance and Investment	25	t
393	9	Banking and Finance	25	t
394	9	Biology	23	t
395	9	Marketing	23	t
396	9	Finance and Economics	23	t
397	9	Statistics	23	t
398	9	Chemical Engineering	23	t
399	9	Philosophy	22	t
400	9	Corporate Finance	21	t
401	9	Engineering	21	t
402	9	Financial Mathematics	20	t
403	9	Natural Sciences	20	t
404	9	Business Economics	19	t
405	9	 Banking	19	t
406	9	Mathematics and Economics	19	t
407	9	Business Studies	19	t
408	9	Mathematics and Statistics	18	t
409	9	International Finance	18	t
410	9	English Literature	16	t
411	9	Biochemistry	16	t
412	9	Electrical and Electronics Engineering	16	t
413	9	Economics and Management	15	t
414	9	Computer Software Engineering	14	t
415	9	International Management	14	t
416	9	Financial Engineering	14	t
417	10	Computer Science	582	t
418	10	Information Technology	245	t
419	10	Electrical and Electronics Engineering	193	t
420	10	Mechanical Engineering	125	t
421	10	Computing	114	t
422	10	Mathematics	58	t
423	10	Physics	50	t
424	10	Electronic Engineering	50	t
425	10	Software Engineering	46	t
426	10	Computer Software Engineering	45	t
427	10	Engineering	45	t
428	10	Information Systems	42	t
429	10	Electronics	40	t
430	10	Electronics and Communication	38	t
431	10	Computer Science and Engineering	36	t
432	10	Electronics and Communications Engineering	36	t
433	10	Computer Engineering	35	t
434	10	Business Information Systems	33	t
435	10	Computer Applications	32	t
436	10	 Business Administration and Management	32	t
437	10	Business	28	t
438	10	Computer Studies	26	t
439	10	Business Information Technology	23	t
440	10	Chemistry	22	t
441	10	Electrical and Electronics	22	t
442	10	English	21	t
443	10	History	20	t
444	10	Psychology	19	t
445	10	Telecommunications Engineering	19	t
446	10	Electrical Engineering	18	t
447	10	Software Testing	18	t
448	10	Business Administration	18	t
449	10	Mechanical	17	t
450	10	Automotive Engineering	16	t
451	10	Management	16	t
452	10	Electronics and Telecommunications	16	t
453	10	Mathematics and Computer Science	16	t
454	10	Business Management	15	t
455	10	Project Management	15	t
456	10	Computer Games Design	15	t
457	10	Accounting and Finance	15	t
458	10	Business Studies	14	t
459	10	Finance	13	t
460	10	Biotechnology	13	t
461	10	Chemical Engineering	13	t
462	10	Informatics	13	t
463	10	Computer Networking	13	t
464	10	Telecommunications	13	t
465	10	Computer Information Systems	12	t
466	10	Computer Technology/Computer Systems Technology	12	t
467	11	Computer Science	294	t
468	11	Information Technology	67	t
469	11	Computing	64	t
470	11	Computer Software Engineering	44	t
471	11	Web Development	37	t
472	11	Software Engineering	26	t
473	11	Graphic Design	20	t
474	11	Computer Engineering	18	t
475	11	Computer Programming	18	t
476	11	Web Technologies	16	t
477	11	Mathematics	16	t
478	11	Multimedia Computing	14	t
479	11	Web Design	14	t
480	11	Multimedia	13	t
481	11	Multimedia Technology	13	t
482	11	Web Design and Development	12	t
483	11	Physics	12	t
484	11	 Web Page	9	t
485	11	Mathematics and Computer Science	9	t
486	11	Informatics	9	t
487	11	Computer Systems Engineering	8	t
488	11	Information Systems	8	t
489	11	Accounting	7	t
490	11	Business Information Systems	7	t
491	11	Computer Networking	7	t
492	11	Multimedia Design	7	t
493	11	History	7	t
494	11	Psychology	7	t
495	11	Digital Media	7	t
496	11	Software Development	6	t
497	11	Architecture	6	t
498	11	Engineering	6	t
499	11	Digital Media Design	6	t
500	11	Computer Games and Programming Skills	6	t
501	11	Computer Information Systems	6	t
502	11	Internet Computing	6	t
503	11	Philosophy	6	t
504	11	Music Technology	6	t
505	11	Information and Communication Technology	6	t
506	11	ICT	5	t
507	11	Business Management	5	t
508	11	Interactive Media Production	5	t
509	11	Music	5	t
510	11	New Media	5	t
511	11	Business Computing	5	t
512	11	Business Information Technology	5	t
513	11	Business	5	t
514	11	Chemistry	5	t
515	11	Applied Computing	5	t
516	11	Advanced Computer Science	5	t
517	12	Computer Science	12	t
518	12	Information Technology	8	t
519	12	Graphic Design	7	t
520	12	Web Design	6	t
521	12	Web Development	6	t
522	12	Computing	5	t
523	12	Multimedia Computing	5	t
524	13	Computer Science	161	t
525	13	Information Technology	59	t
526	13	Computing	38	t
527	13	Mathematics	23	t
528	13	Mechanical Engineering	15	t
529	13	Information Systems	13	t
530	13	Electronics and Communications Engineering	13	t
531	13	Computer Science and Engineering	12	t
532	13	Software Engineering	11	t
533	13	Computer Applications	11	t
534	13	Electrical and Electronics Engineering	11	t
535	13	Computer Information Systems	10	t
536	13	Physics	10	t
537	13	Business Information Technology	8	t
538	13	Economics	7	t
539	13	Engineering	6	t
540	13	Computer Studies	6	t
541	13	International Business	6	t
542	13	Mathematics and Computer Science	6	t
543	13	Electrical and Electronics	6	t
544	13	Computer Programming	6	t
545	13	Computer Software Engineering	5	t
546	13	Electronic Engineering	5	t
547	13	Electronics	5	t
548	13	Electronics and Communication	5	t
549	13	Business Information Systems	5	t
550	14	Marketing	28	t
551	14	Information Technology	18	t
552	14	Computer Science	17	t
553	14	English	15	t
554	14	Business	14	t
555	14	Journalism	12	t
556	14	Digital Marketing	9	t
557	14	Business Management	8	t
558	14	Graphic Design	8	t
559	14	Business Information Technology	7	t
560	14	Project Management	7	t
561	14	Law	6	t
562	14	International Business	5	t
563	14	 Business Administration and Management	5	t
564	14	Business Studies	5	t
565	14	Psychology	5	t
566	15	Animation	64	t
567	15	Computer Animation	28	t
568	15	Computer Games Design	11	t
569	15	3D Computer Animation	11	t
570	15	3D Animation	11	t
571	15	Architecture	7	t
572	15	Computer Games Art	7	t
573	15	3D Digital Animation	6	t
574	15	Game and Interactive Media Design	6	t
575	15	Computer Graphics	6	t
576	15	3D Modelling and Animation	6	t
577	15	Games Design	6	t
578	15	Computer Games and Programming Skills	6	t
579	15	Fine Art	6	t
580	15	Digital Effects	5	t
581	15	Computer Games Modelling and Animation	5	t
582	15	3D Modelling	5	t
583	16	Computer Science	37	t
584	16	Information Security	21	t
1130	83	Surgery	13	t
585	16	Computer Networks and Security	19	t
586	16	Information Technology	14	t
587	16	Computer Systems Networking and Telecommunications	11	t
588	16	Computing	10	t
589	16	Network Security	8	t
590	16	Electrical and Electronics Engineering	8	t
591	16	Computer Networking	7	t
592	16	Computer and Information Systems Security/Information Assurance	6	t
593	16	Cyber Security	6	t
594	16	Business Information Technology	6	t
595	16	Computer Security	6	t
596	16	Physics	6	t
597	16	Business Management	6	t
598	16	Mathematics	5	t
599	18	Data Science	10	t
600	18	Computer Science	9	t
601	18	Data Science and Analytics	8	t
602	18	Mathematics	6	t
603	18	Physics	6	t
604	18	Machine Learning	5	t
605	18	Statistics	5	t
606	19	Computer Science	20	t
607	19	Computer Games Development	12	t
608	19	Computer Games Programming	7	t
609	19	Computer Games Technology	7	t
610	19	Games Design	5	t
611	20	Games Design	11	t
612	20	Animation	9	t
613	20	Game Art	7	t
614	20	Computer Games Design	5	t
678	41	Business	12	t
679	42	Business	12	t
680	42	 Business Administration and Management	10	t
681	42	Business Studies	10	t
682	42	Business Management	8	t
683	42	History	6	t
684	42	Law	6	t
685	43	Automotive Engineering Technology/Technician	8	t
686	43	Vehicle Maintenance and Repair Technologies	7	t
687	43	Mechanical Engineering	5	t
688	44	Business	19	t
689	44	Business Studies	15	t
690	44	Accounting and Finance	13	t
691	44	Marketing	12	t
692	44	 Business Administration and Management	8	t
693	44	Business Management	7	t
694	44	Mechanical Engineering	7	t
695	44	Economics	6	t
696	44	English	5	t
697	44	Accounting	5	t
698	45	Business Studies	8	t
699	45	Business	7	t
700	45	 Business Administration and Management	5	t
701	46	Strategic Automotive Dealership Management	7	t
702	46	Business Studies	6	t
703	46	Business	6	t
704	47	Mechanical Engineering	72	t
705	47	Automotive Engineering	41	t
706	47	Automotive Engineering Technology/Technician	21	t
707	47	Electrical and Electronics Engineering	15	t
708	47	Engineering	15	t
709	47	Motorsport Engineering	15	t
710	47	Automotive and Motorsport Engineering	5	t
711	48	Mechanical Engineering	10	t
712	48	Electrical and Electronics Engineering	5	t
713	48	Engineering	5	t
714	49	Mechanical Engineering	12	t
715	50	Business Studies	5	t
716	50	Business	5	t
717	53	Business	5	t
718	54	Mechanical Engineering	46	t
719	54	Automotive Engineering	11	t
720	54	Engineering	9	t
721	54	Automotive Engineering Technology/Technician	8	t
722	54	Electrical and Electronics Engineering	8	t
723	56	Business	5	t
724	57	 Business Administration and Management	5	t
725	57	Business	5	t
726	58	Engineering	7	t
943	78	Registered Nursing/Registered Nurse	824	t
944	78	Adult Health Nurse/Nursing	342	t
945	78	Nursing	320	t
946	78	Adult Nursing	140	t
947	78	Public Health	122	t
948	78	Psychiatric/Mental Health Nurse/Nursing	110	t
949	78	Dietetics/Dietitian	81	t
950	78	Mental Health Nursing	77	t
951	78	Nursing Science	59	t
952	78	Health/Health Care Administration/Management	55	t
953	78	Nursing Education	53	t
954	78	Nutrition and Dietetics	46	t
955	78	Health and Social Care	44	t
956	78	General Nursing	43	t
957	78	Specialist Community Public Health Nursing	42	t
958	78	Nursing Studies	40	t
959	78	Critical Care Nursing	39	t
960	78	Veterinary Nursing	38	t
961	78	Operating Department Practice	34	t
962	78	Nursing Practice	32	t
963	78	Advanced Practice	31	t
964	78	Advanced Nursing Practice	30	t
965	78	Health Studies	30	t
966	78	Pediatric Nurse/Nursing	29	t
967	78	Non Medical Prescribing	26	t
968	78	Psychology	26	t
969	78	Mental Health	26	t
970	78	 Health Services/Allied Health/Health Sciences	24	t
971	78	Paediatric Nursing	23	t
972	78	Health Visiting	21	t
973	78	Children's Nursing	20	t
974	78	Midwifery	20	t
975	78	Nurse Midwife/Nursing Midwifery	19	t
976	78	Mental and Social Health Services and Allied Professions	18	t
977	78	Healthcare	18	t
978	78	Learning Disability Nursing	18	t
979	78	Medicine	17	t
980	78	Education	15	t
981	78	Advanced Clinical Practice	15	t
982	78	Mentorship	15	t
983	78	Nurse Practitioner	15	t
984	78	Enfermería	15	t
985	78	Human Nutrition and Dietetics	14	t
986	78	Dietetics and Clinical Nutrition Services	14	t
987	78	District Nursing	13	t
988	78	Advanced Nursing	13	t
989	78	Occupational Health	12	t
990	78	Clinical Research	12	t
991	78	Perioperative/Operating Room and Surgical Nurse/Nursing	11	t
992	78	Advanced Nurse Practitioner	11	t
993	79	Psychology	130	t
994	79	Biomedical Sciences	96	t
995	79	Health and Social Care	78	t
996	79	Adult Health Nurse/Nursing	58	t
997	79	Registered Nursing/Registered Nurse	47	t
998	79	Health/Health Care Administration/Management	42	t
999	79	Nursing	33	t
1000	79	Adult Nursing	27	t
1001	79	Business	24	t
1002	79	 English Language and Literature	23	t
1003	79	Biology	23	t
1004	79	Social Work	20	t
1005	79	Occupational Therapy/Therapist	20	t
1006	79	Biochemistry	17	t
1007	79	Public Health	17	t
1008	79	Business Management	17	t
1009	79	History	16	t
1010	79	Law	16	t
1011	79	Medicine	16	t
1012	79	Marketing	14	t
1013	79	 Health Services/Allied Health/Health Sciences	14	t
1014	79	Accounting	14	t
1015	79	 Business Administration and Management	14	t
1016	79	Sociology	14	t
1017	79	Accounting and Finance	13	t
1018	79	Mathematics	12	t
1019	79	Social Sciences	11	t
1020	79	English	11	t
1021	79	Information Technology	11	t
1022	79	Psychiatric/Mental Health Nurse/Nursing	11	t
1023	79	Biological and Biomedical Sciences	11	t
1024	79	Forensic Psychology	10	t
1025	79	Health Care	10	t
1026	79	Microbiology	10	t
1027	79	Mental Health Nursing	9	t
1028	79	Human Resource Management	9	t
1029	79	Operating Department Practice	9	t
1030	79	Mental and Social Health Services and Allied Professions	8	t
1521	101	English	11	t
1031	79	 Bachelor of Surgery (MBBS)	8	t
1032	79	Business Studies	8	t
1033	79	Nursing Science	8	t
1034	79	English Literature	8	t
1035	79	Social Care	7	t
1036	79	Pre-Nursing Studies	7	t
1037	79	Geology	7	t
1038	79	Business Administration	7	t
1039	79	Pharmaceutical Sciences	7	t
1040	79	Forensic Science	7	t
1041	79	Healthcare	7	t
1042	79	Early Childhood Education and Teaching	7	t
1043	80	Social Work	99	t
1044	80	Psychology	88	t
1045	80	Health and Social Care	36	t
1046	80	Social Sciences	15	t
1047	80	Occupational Therapy/Therapist	14	t
1048	80	Adult Health Nurse/Nursing	11	t
1049	80	Mental Health Nursing	10	t
1050	80	Law	10	t
1051	80	Mental and Social Health Services and Allied Professions	9	t
1052	80	Psychiatric/Mental Health Nurse/Nursing	9	t
1053	80	Health/Health Care Administration/Management	9	t
1054	80	Sociology	9	t
1055	80	Business Administration	9	t
1056	80	Criminology	8	t
1057	80	Registered Nursing/Registered Nurse	8	t
1058	80	 Business Administration and Management	8	t
1059	80	Social Care	7	t
1060	80	Mental Health Practice	7	t
1061	80	Counseling Psychology	7	t
1062	80	English	6	t
1063	80	Biomedical Sciences	6	t
1064	80	Business	6	t
1065	80	Education	5	t
1066	80	Business Studies	5	t
1067	80	Public Health	5	t
1068	81	Medicine	1297	t
1069	81	 Bachelor of Surgery (MBBS)	536	t
1070	81	Audiology/Audiologist	83	t
1071	81	Biomedical Sciences	79	t
1072	81	Public Health	76	t
1073	81	Registered Nursing/Registered Nurse	60	t
1074	81	Medicine and Surgery	57	t
1075	81	Biochemistry	54	t
1076	81	Neuroscience	53	t
1077	81	Physiotherapy	50	t
1078	81	Dentistry	50	t
1079	81	Biology	48	t
1080	81	Pharmacology	45	t
1081	81	Paediatrics	45	t
1082	81	Psychology	44	t
1083	81	Clinical Research	40	t
1084	81	Ophthalmology	39	t
1085	81	 Business Administration and Management	34	t
1086	81	Surgery	32	t
1087	81	Medical Education	32	t
1088	81	Clinical Psychology	32	t
1089	81	Medical Sciences	31	t
1090	81	Chemistry	30	t
1091	81	Health/Health Care Administration/Management	29	t
1092	81	Nursing	27	t
1093	81	Clinical Physiology	26	t
1094	81	Cardiology	25	t
1095	81	General Medicine	24	t
1096	81	Medical Physics	23	t
1097	81	Management	23	t
1098	81	Physiology	23	t
1099	81	Pharmaceutical Medicine	23	t
1100	81	Obstetrics and Gynaecology	22	t
1101	81	Immunology	22	t
1102	81	Business	21	t
1103	81	Cardiovascular Science	21	t
1104	81	MBBS	21	t
1105	81	Pharmacy	21	t
1106	81	Psychiatry	20	t
1107	81	Molecular Biology	19	t
1108	81	Clinical Sciences	18	t
1109	81	Law	18	t
1110	81	Microbiology	18	t
1111	81	General Surgery	18	t
1112	81	Anaesthesia	17	t
1113	81	Internal Medicine	17	t
1114	81	Clinical Biochemistry	17	t
1115	81	Biological Sciences	16	t
1116	81	Epidemiology	15	t
1117	81	Biotechnology	15	t
1118	82	Medicine	290	t
1119	82	 Bachelor of Surgery (MBBS)	138	t
1120	82	General Practice	36	t
1121	82	Dermatology	7	t
1122	82	Family Medicine	7	t
1123	82	Health/Health Care Administration/Management	6	t
1124	82	Dentistry	6	t
1125	82	Family Medicine Residency Program	5	t
1126	83	Medicine	194	t
1127	83	 Bachelor of Surgery (MBBS)	68	t
1128	83	Orthopaedic Surgery	15	t
1129	83	Orthopaedics	14	t
1131	83	General Surgery	11	t
1132	83	Trauma & Orthopaedics	11	t
1133	83	Trauma and Orthopaedic Surgery	9	t
1134	83	FRCS	8	t
1135	83	Medicine and Surgery	6	t
1136	83	Orthopedic Surgery Residency Program	6	t
1137	83	Medical Education	6	t
1138	83	Veterinary Medicine	5	t
1139	83	 PhD	5	t
1140	83	Neurosurgery	5	t
1141	83	Ophthalmology	5	t
1142	83	 MD	5	t
1143	83	Plastic Surgery	5	t
1144	83	Neuroscience	5	t
1145	84	Dentistry	428	t
1146	84	Dental Hygiene/Hygienist	60	t
1147	84	Dental Assisting/Assistant	38	t
1148	84	Dental Nursing	36	t
1149	84	Dental Hygiene and Therapy	26	t
1150	84	Orthodontics	14	t
1151	84	Restorative Dentistry	13	t
1152	84	Advanced General Dentistry	12	t
1153	84	Dental Implantology	11	t
1154	84	Dental Surgery	10	t
1155	84	Dental Laboratory Technology/Technician	10	t
1156	84	Oral Health Science	10	t
1157	84	Implantology	8	t
1158	84	Dental Hygiene and Dental Therapy	8	t
1159	84	Implant Dentistry	8	t
1160	84	Biology	7	t
1161	84	Endodontics/Endodontology	7	t
1162	84	Advanced	6	t
1163	84	Aesthetic Dentistry	6	t
1164	84	Law	5	t
1165	84	Health and Social Care	5	t
1166	84	Orthodontic therapy	5	t
1167	84	Fixed and Removable Prosthodontics	5	t
1168	85	Physiotherapy	357	t
1169	85	Podiatric Medicine/Podiatry	98	t
1170	85	Podiatry	60	t
1171	85	Physical Therapy/Therapist	51	t
1172	85	Osteopathic Medicine/Osteopathy	13	t
1173	85	Osteopathy	11	t
1174	85	Sports Physiotherapy	6	t
1175	85	Sports and Exercise	6	t
1176	85	Sports Therapy	6	t
1177	85	Veterinary Physiotherapy	5	t
1178	86	Occupational Therapy/Therapist	238	t
1179	86	Occupational Therapist	5	t
1180	87	Speech and Language Therapy	72	t
1181	87	Speech-Language Pathology/Pathologist	27	t
1182	87	Speech and Language Sciences	9	t
1183	87	Speech Sciences	6	t
1184	87	Speech Pathology and Therapy	6	t
1185	88	Registered Nursing/Registered Nurse	29	t
1186	88	Social Work	27	t
1187	88	Health and Social Care	24	t
1188	88	Health/Health Care Administration/Management	16	t
1189	88	Psychology	12	t
1190	88	Social Care	8	t
1191	88	Nursing	8	t
1192	88	 Business Administration and Management	8	t
1193	88	Adult Health Nurse/Nursing	6	t
1194	88	History	6	t
1195	88	Accounting and Finance	6	t
1196	88	Law	5	t
1197	88	General Nursing	5	t
1198	88	Business	5	t
1199	88	Management	5	t
1200	89	Paramedic Science	37	t
1201	89	Emergency Medical Technology/Technician (EMT Paramedic)	11	t
1202	89	Paramedic Practice	8	t
1203	89	Psychology	6	t
1204	89	Medicine	5	t
1205	90	Psychology	34	t
1206	90	 Business Administration and Management	24	t
1207	90	Law	16	t
1208	90	Business Administration	15	t
1209	90	Biomedical Sciences	14	t
1210	90	Business	13	t
1211	90	English	12	t
1212	90	 English Language and Literature	12	t
1213	90	Medical Administrative/Executive Assistant and Medical Secretary	12	t
1214	90	Health and Social Care	9	t
1215	90	 Bachelor of Surgery (MBBS)	9	t
1216	90	Accounting and Finance	9	t
1217	90	Social Sciences	8	t
1218	90	Business Studies	8	t
1219	90	Biochemistry	7	t
1220	90	Business Management	7	t
1221	90	English Literature	7	t
1222	90	Business and Finance	7	t
1223	90	Management	7	t
1224	90	Humanities/Humanistic Studies	6	t
1225	90	Computer Science	6	t
1226	90	Accounting	6	t
1227	90	Medicine	6	t
1228	90	Beauty Therapy	6	t
1229	90	Secretarial	5	t
1230	90	Dentistry	5	t
1231	90	Criminology	5	t
1232	90	Medical Secretary	5	t
1233	90	Project Management	5	t
1234	90	Human Resource Management	5	t
1235	91	 Business Administration and Management	23	t
1236	91	Registered Nursing/Registered Nurse	13	t
1237	91	Management	12	t
1238	91	Law	11	t
1239	91	Health and Social Care	10	t
1240	91	Health/Health Care Administration/Management	9	t
1241	91	Business	8	t
1242	91	Business Studies	7	t
1243	91	Nursing	7	t
1244	91	Pharmacy	7	t
1245	91	Public Health	7	t
1246	91	International Business	6	t
1247	91	Leadership and Management	6	t
1248	91	Business Administration	6	t
1249	91	Electrical and Electronics Engineering	5	t
1250	91	Business Management	5	t
1251	91	Practice Management	5	t
1252	91	Occupational Therapy/Therapist	5	t
1253	91	Social Work	5	t
1254	91	Psychology	5	t
1255	91	Business and Finance	5	t
1256	92	Biomedical Sciences	124	t
1257	92	Applied Biomedical Science	13	t
1258	92	Haematology	11	t
1259	92	Biological and Biomedical Sciences	10	t
1260	92	Medical Microbiology	8	t
1261	92	Biomedical/Medical Engineering	6	t
1262	92	Cellular Pathology	5	t
1263	93	Diagnostic Radiography	56	t
1264	93	Medicine	43	t
1265	93	Radiologic Technology/Science - Radiographer	38	t
1266	93	Radiography	24	t
1267	93	Radiology	19	t
1268	93	Diagnostic Medical Sonography/Sonographer and Ultrasound Technician	17	t
1269	93	 Bachelor of Surgery (MBBS)	14	t
1270	93	Medical Imaging	11	t
1271	93	Radiotherapy and Oncology	11	t
1272	93	 Allied Health Diagnostic	10	t
1273	93	MRI	8	t
1274	93	Magnetic Resonance Imaging (MRI) Technology/Technician	7	t
1275	93	Radiotherapy	7	t
1276	93	Diagnostic Radiology	6	t
1277	93	Medical Ultrasound	6	t
1278	93	Diagnostic Imaging	5	t
1279	93	Diagnostic Radiology Residency Program	5	t
1280	94	Optometry	303	t
1281	94	Ophthalmic Optics	11	t
1282	94	Optometry and Visual Science	9	t
1283	94	Opticianry/Ophthalmic Dispensing Optician	6	t
1284	94	Optics/Optical Sciences	5	t
1285	95	Pharmacy	233	t
1286	95	Clinical Pharmacy	19	t
1287	95	Pharmaceutical Sciences	13	t
1288	95	 Clinical	11	t
1289	95	Pharmacology	5	t
1290	95	Business	5	t
1291	95	Psychiatric Therapeutics	5	t
1292	95	Psychology	5	t
1293	96	Direct Entry Midwifery	73	t
1294	96	Midwifery	51	t
1295	96	Nurse Midwife/Nursing Midwifery	32	t
1296	96	Registered Nursing/Registered Nurse	7	t
1297	97	Accounting and Finance	960	t
1298	97	Accounting	924	t
1299	97	Economics	130	t
1300	97	Mathematics	110	t
1301	97	Accounting and Business/Management	96	t
1302	97	ACCA	81	t
1303	97	AAT	67	t
1304	97	Business	61	t
1305	97	Finance	55	t
1306	97	 Business Administration and Management	50	t
1307	97	Business Studies	47	t
1308	97	Business Management	47	t
1309	97	Accounting Technology/Technician and Bookkeeping	38	t
1310	97	Management Accounting	32	t
1311	97	Accounting and Financial Management	30	t
1312	97	Geography	27	t
1313	97	Law	27	t
1314	97	International Business	25	t
1315	97	Business and Finance	24	t
1316	97	Business Administration	22	t
1317	97	Psychology	21	t
1318	97	Management	21	t
1319	97	Applied Accounting	20	t
1320	97	Chartered Accountant	20	t
1321	97	Taxation	20	t
1322	97	Economics and Accounting	16	t
1323	97	Chemistry	16	t
1324	97	Marketing	16	t
1325	97	ACA	15	t
1326	97	Physics	15	t
1327	97	Bookkeeping	14	t
1329	97	Finance and Financial Management Services	13	t
1330	97	History	13	t
1331	97	CIMA	12	t
1332	97	Financial Management	12	t
1333	97	Association of Chartered Certified Accountants	12	t
1334	97	AAT Level 3	11	t
1335	97	Finance and Accounting	11	t
1336	97	Business Economics	11	t
1337	97	Mathematics and Economics	11	t
1338	97	Accounting and Related Services	10	t
1339	97	AAT Level 4	10	t
1340	97	Accounting Technician	10	t
1341	97	 Banking	10	t
1342	97	Computer Science	9	t
1343	97	International Accounting and Finance	9	t
1346	97	International Accounting	9	t
1347	98	Economics	99	t
1348	98	Business	89	t
1349	98	Law	71	t
1350	98	Business Studies	70	t
1351	98	Accounting	61	t
1352	98	Accounting and Finance	58	t
1353	98	Business Management	52	t
1354	98	Marketing	52	t
1355	98	 Business Administration and Management	50	t
1356	98	 Banking	45	t
1357	98	Finance	41	t
1358	98	History	39	t
1359	98	Geography	35	t
1360	98	Business Administration	34	t
1361	98	Mathematics	33	t
1362	98	Management	32	t
1363	98	International Business	32	t
1364	98	Psychology	30	t
1365	98	English	24	t
1366	98	Business and Finance	23	t
1367	98	Computer Science	21	t
1368	98	Human Resource Management	21	t
1369	98	English Literature	21	t
1370	98	Public Relations	16	t
1371	98	Politics	15	t
1372	98	Engineering	13	t
1373	98	Biology	13	t
1374	98	Chemistry	13	t
1376	98	Information Technology	11	t
1378	98	Physics	11	t
1379	98	Chartered Accountant	10	t
1380	98	Financial Services	10	t
1381	98	Banking and Financial Support Services	10	t
1382	98	Accounting and Business/Management	10	t
1383	98	Banking and Finance	10	t
1384	98	Business Information Technology	10	t
1385	98	Mechanical Engineering	10	t
1386	98	Quantity Surveying	9	t
1387	98	Business and Marketing	9	t
1388	98	International Business Management	9	t
1389	98	Financial Planning and Services	9	t
1390	98	Communication and Media Studies	9	t
1391	98	Graphic Design	9	t
1392	98	Finance and Financial Management Services	9	t
1394	98	Sport and Exercise Science	8	t
1396	98	Biochemistry	8	t
1407	99	Chartered Accountant	33	t
1408	99	ACCA	27	t
1415	99	Accounting and Financial Management	21	t
1418	99	AAT	18	t
1422	99	CGMA	15	t
1395	98	Business Economics	8	t
1328	97	English Language and Literature	13	t
1375	98	Management Accounting	8	t
1377	98	Social Sciences	8	t
1397	99	Accounting and Finance	464	t
1398	99	Accounting	424	t
1399	99	Economics	216	t
1400	99	Mathematics	128	t
1423	99	Economics and Accounting	14	t
1426	99	First time passes	12	t
1427	99	Finance and Management	12	t
1429	99	Accounting and Economics	11	t
1447	100	Economics	200	t
1448	100	Finance	182	t
1449	100	Mathematics	60	t
1450	100	Accounting and Finance	52	t
1451	100	Law	46	t
1452	100	Investment Management	43	t
1453	100	Business Studies	38	t
1454	100	Business	37	t
1455	100	History	36	t
1456	100	Real Estate	33	t
1457	100	Accounting	32	t
1458	100	 Business Administration and Management	31	t
1459	100	Geography	23	t
1460	100	Chemistry	23	t
1461	100	Physics	21	t
1462	100	Business Management	19	t
1463	100	Investments and Securities	19	t
1464	100	International Business	19	t
1465	100	Politics	18	t
1466	100	Engineering	18	t
1467	100	Banking and Finance	18	t
1468	100	Management	17	t
1469	100	Financial Economics	17	t
1470	100	Economics and Finance	16	t
1471	100	Business Administration	15	t
1472	100	 Banking	15	t
1473	100	Finance and Investment	15	t
1474	100	Business Economics	14	t
1475	100	Finance and Financial Management Services	13	t
1476	100	Economics and Management	12	t
1477	100	Marketing	12	t
1478	100	Business and Finance	11	t
1479	100	Land Management	11	t
1481	100	Mathematics and Statistics	10	t
1482	100	Computer Science	10	t
1483	100	Financial Mathematics	10	t
1484	100	English Literature	10	t
1485	100	Philosophy	10	t
1486	100	Actuarial Science	10	t
1487	100	Financial Analysis and Fund Management	9	t
1488	100	Finance and Investment Management	9	t
1489	100	International Relations	9	t
1490	100	Civil Engineering	9	t
1491	100	Natural Sciences	9	t
1492	100	Investment Analysis	9	t
1494	100	Statistics	8	t
1495	100	Chartered Financial Analyst	8	t
1496	100	Mechanical Engineering	8	t
1497	101	Economics	122	t
1498	101	Accounting and Finance	88	t
1499	101	Financial Planning and Services	87	t
1500	101	Finance	85	t
1501	101	Business	58	t
1502	101	Mathematics	54	t
1503	101	Accounting	47	t
1504	101	Law	46	t
1505	101	Business Management	37	t
1506	101	 Business Administration and Management	37	t
1507	101	Financial Services	35	t
1508	101	Business Studies	34	t
1509	101	Financial Planning	28	t
1510	101	History	25	t
1511	101	Psychology	24	t
1512	101	Marketing	23	t
1513	101	Management	19	t
1514	101	Geography	17	t
1515	101	Finance and Financial Management Services	16	t
1516	101	Business and Finance	16	t
1517	101	Business Administration	16	t
1518	101	International Business	16	t
1519	101	Financial Advice	12	t
1520	101	Business Economics	11	t
1424	99	Financial Management	16	t
1425	99	Finance and Financial Management Services	14	t
1480	100	Psychology	8	t
1493	100	English Language and Literature	10	t
1522	101	Management Accounting	10	t
1523	101	Civil Engineering	10	t
1525	101	Sport and Exercise Science	9	t
1527	101	Chemistry	8	t
1528	101	Philosophy	8	t
1529	101	Banking and Financial Support Services	8	t
1530	101	 Banking	8	t
1531	101	Politics	7	t
1532	101	Sports Science	7	t
1533	101	Biology	7	t
1534	101	Electrical and Electronics Engineering	7	t
1535	101	Financial Economics	7	t
1536	101	Economics and Finance	7	t
1537	101	Diploma in Financial Planning	7	t
1538	101	Mechanical Engineering	7	t
1539	101	Wealth Management	7	t
1540	101	Physics	7	t
1544	101	Banking and Finance	6	t
1546	101	Sociology	6	t
1547	102	Law	74	t
1548	102	Economics	40	t
1549	102	Finance	24	t
1550	102	Mathematics	24	t
1551	102	Accounting and Finance	24	t
1552	102	Business Studies	17	t
1553	102	Accounting	17	t
1554	102	Business	17	t
1555	102	 Business Administration and Management	16	t
1556	102	Business Management	12	t
1557	102	Business Administration	11	t
1558	102	History	11	t
1559	102	Risk Management	9	t
1560	102	Geography	8	t
1561	102	Management	8	t
1562	102	Compliance	7	t
1563	102	Psychology	7	t
1564	102	Finance and Investment	7	t
1565	102	Marketing	6	t
1566	102	Banking and Financial Support Services	5	t
1567	102	Anti Money Laundering	5	t
1568	102	Accounting and Business/Management	5	t
1569	102	International Business	5	t
1570	102	Computer Science	5	t
1571	102	Physics	5	t
1572	102	Financial Services	5	t
1573	102	Chemistry	5	t
1613	104	Accounting and Finance	109	t
1614	104	Accounting	81	t
1615	104	Economics	76	t
1616	104	Law	56	t
1617	104	Mathematics	52	t
1618	104	Taxation	43	t
1619	104	History	16	t
1620	104	Business	14	t
1621	104	Finance	13	t
1622	104	Chemistry	13	t
1543	101	Languages	6	t
1524	101	Education	6	t
1526	101	Engineering	6	t
1541	101	Chartered Financial Planner	6	t
1542	101	English Language and Literature	9	t
1545	101	Computer Science	6	t
1623	104	Business Studies	11	t
1624	104	Tax Law/Taxation	10	t
1625	104	Psychology	9	t
1626	104	 Business Administration and Management	9	t
1627	104	Accounting and Business/Management	9	t
1628	104	Natural Sciences	8	t
1629	104	Philosophy	8	t
1630	104	Tax	7	t
1631	104	Geography	6	t
1632	104	Mathematics and Statistics	6	t
1633	104	Physics	6	t
1634	104	Economics and Politics	5	t
1635	104	Accounting and Financial Management	5	t
1636	104	Business and Finance	5	t
1637	104	Management	5	t
1638	105	Economics	626	t
1639	105	Finance	471	t
1640	105	Mathematics	226	t
1641	105	Accounting and Finance	180	t
1642	105	Computer Science	113	t
1643	105	Management	111	t
1644	105	Law	75	t
1645	105	Chemistry	73	t
1646	105	International Business	66	t
1647	105	Business	66	t
1648	105	Physics	59	t
1649	105	 Business Administration and Management	53	t
1650	105	Business Management	52	t
1651	105	History	52	t
1652	105	Economics and Finance	51	t
1653	105	Geography	41	t
1654	105	Financial Economics	41	t
1655	105	Finance and Investment	40	t
1656	105	Accounting	40	t
1657	105	Mechanical Engineering	39	t
1658	105	Business Administration	36	t
1659	105	Information Technology	35	t
1660	105	Finance and Economics	35	t
1661	105	Politics	34	t
1662	105	Marketing	34	t
1663	105	Financial Mathematics	34	t
1664	105	Chemical Engineering	33	t
1665	105	Philosophy	33	t
1666	105	Corporate Finance	32	t
1667	105	International Finance	32	t
1668	105	Psychology	31	t
1669	105	Computing	31	t
1670	105	Mathematics and Economics	31	t
1671	105	Business Economics	29	t
1672	105	Banking and Finance	29	t
1673	105	International Relations	28	t
1674	105	Engineering	26	t
1675	105	 Banking	26	t
1676	105	Biology	26	t
1677	105	Investment Management	25	t
1678	105	Statistics	25	t
1679	105	Business Studies	23	t
1680	105	Mathematics and Statistics	23	t
1681	105	Natural Sciences	23	t
1682	105	Economics and Management	23	t
1683	105	Civil Engineering	21	t
1684	105	Electrical and Electronics Engineering	21	t
1685	105	International Management	21	t
1686	105	Actuarial Science	21	t
1688	106	Finance	82	t
1689	106	Economics	54	t
1690	106	Mathematics	41	t
1691	106	Accounting and Finance	31	t
1692	106	Financial Mathematics	13	t
1693	106	Accounting	13	t
1694	106	Business Administration	13	t
1695	106	Business	12	t
1696	106	Banking and Finance	10	t
1697	106	International Management	9	t
1698	106	Finance and Economics	8	t
1699	106	Financial Economics	8	t
1700	106	Mechanical Engineering	8	t
1701	106	International Business	8	t
1702	106	Quantitative Finance	7	t
1703	106	Business Studies	7	t
1704	106	Credit Management	7	t
1705	106	Business and Finance	7	t
1706	106	Physics	7	t
1707	106	Mathematics and Statistics	6	t
1708	106	Computer Science	6	t
1709	106	Finance and Investment	6	t
1710	106	Management	6	t
1711	106	Business Management	5	t
1712	106	Electrical and Electronics Engineering	5	t
1713	106	History	5	t
1714	106	Economics and Finance	5	t
1715	106	Business Economics	5	t
1716	106	Investment Management	5	t
1717	106	 Business Administration and Management	5	t
1718	106	Financial Risk Management	5	t
1719	107	Business	25	t
1720	107	Financial Planning and Services	19	t
1721	107	Finance	15	t
1722	107	Mortgages	13	t
1723	107	Economics	12	t
1724	107	Psychology	10	t
1725	107	Certificate in Mortgage Advice and Practice	9	t
1726	107	 Business Administration and Management	8	t
1727	107	Accounting and Finance	8	t
1728	107	Mortgage Advice	7	t
1729	107	Law	7	t
1730	107	Business Administration	7	t
1731	107	CeMAP	7	t
1732	107	Business Studies	6	t
1733	107	Mathematics	6	t
1734	107	Business and Finance	6	t
1735	107	2	6	t
1736	107	Marketing	5	t
1737	107	2 & 3	5	t
1738	108	Finance	218	t
1739	108	Economics	159	t
1740	108	Accounting and Finance	59	t
1741	108	Mathematics	38	t
1742	108	Management	30	t
1743	108	Economics and Finance	18	t
1744	108	Financial Economics	16	t
1745	108	Accounting	15	t
1746	108	 Business Administration and Management	15	t
1747	108	Finance and Investment	15	t
1748	108	International Business	14	t
1749	108	Finance and Economics	13	t
1750	108	Corporate Finance	13	t
1751	108	 Banking	13	t
1752	108	Finance and Private Equity	13	t
1753	108	Finance and Accounting	13	t
1754	108	Banking and Finance	12	t
1755	108	International Finance	12	t
1756	108	Business	12	t
1757	108	Physics	12	t
1758	108	Law	11	t
1759	108	Business Administration	11	t
1760	108	Computer Science	10	t
1761	108	Mathematics and Economics	10	t
1762	108	Investment Management	9	t
1763	108	Business Management	9	t
1764	108	Economics and Management	9	t
1765	108	Chemical Engineering	9	t
1766	108	Finance and Management	9	t
1767	108	Philosophy	9	t
1768	108	Finance and Strategy	8	t
1769	108	Chemistry	7	t
1770	108	Financial Mathematics	7	t
1771	108	Mechanical Engineering	7	t
1772	108	International Management	6	t
1773	108	Business Economics	6	t
1774	108	Financial Engineering	6	t
1775	108	Marketing	6	t
1776	108	Investments and Securities	6	t
1777	108	History	6	t
1778	108	Mathematical Finance	6	t
1779	108	Banking and International Finance	6	t
1780	108	Business Studies	5	t
1781	108	Biochemistry	5	t
1782	108	Risk Management and Financial Engineering	5	t
1783	108	Corporate Finance and Banking	5	t
1784	108	Electrical and Electronics Engineering	5	t
1785	108	Real Estate	5	t
1786	108	Economic History	5	t
1787	108	Actuarial Science	5	t
1792	109	Finance	60	t
1793	109	ACA	37	t
1794	109	Management	32	t
1797	109	Accounting and Financial Management	24	t
1799	109	History	23	t
1804	109	International Business	20	t
1805	109	Applied Accounting	18	t
1806	109	ACCA	18	t
1807	109	Auditing	18	t
1808	109	Business Management	16	t
1809	109	Business Studies	14	t
1810	109	Management Accounting	14	t
1811	109	Biochemistry	13	t
1812	109	Economics and Finance	12	t
1813	109	Business Economics	11	t
1814	109	Physics	11	t
1816	109	Business Administration	10	t
1817	109	Philosophy	10	t
1818	109	Internal Audit	10	t
1819	109	Mathematics and Economics	10	t
1820	109	 Banking	9	t
1822	109	Computer Science	9	t
1823	109	Natural Sciences	9	t
1824	109	Psychology	9	t
1825	109	Accounting and Economics	8	t
1826	109	Business Information Systems	8	t
1827	109	Audit Management and Consultancy	8	t
1828	109	Finance and Accounting	8	t
1829	109	Economics and Accounting	7	t
1830	109	Finance and Financial Management Services	7	t
1831	109	Financial Mathematics	7	t
1832	109	Association of Chartered Certified Accountants	7	t
1833	109	Finance and Investment	7	t
1834	109	Engineering	6	t
1835	109	Politics	6	t
1837	109	BSc Accounting	6	t
1838	110	Economics	15	t
1839	110	Business Studies	13	t
1840	110	Business	13	t
1841	110	 Banking	13	t
1842	110	Accounting and Finance	12	t
1843	110	Business Management	10	t
1844	110	 Business Administration and Management	10	t
1845	110	Accounting	9	t
1846	110	Psychology	8	t
1847	110	Law	8	t
1848	110	Finance	7	t
1849	110	Mathematics	5	t
1850	110	Business and Finance	5	t
1851	110	History	5	t
1852	110	Finance and Financial Management Services	5	t
1853	110	Accounting and Business/Management	5	t
1854	111	Economics	54	t
1855	111	Computer Science	34	t
1856	111	Finance	33	t
1857	111	Mathematics	33	t
1858	111	Accounting and Finance	30	t
1859	111	Business Studies	24	t
1860	111	Accounting	24	t
1861	111	Business	21	t
1862	111	 Business Administration and Management	20	t
1863	111	Information Technology	19	t
1864	111	Project Management	12	t
1865	111	Business Management	12	t
1866	111	Physics	9	t
1867	111	Geography	8	t
1868	111	Computing	8	t
1869	111	International Business	8	t
1870	111	Psychology	8	t
1871	111	Business Administration	7	t
1872	111	Business Information Systems	6	t
1873	111	Information Systems	6	t
1874	111	Mechanical Engineering	6	t
1875	111	Business Information Technology	6	t
1876	111	Marketing	6	t
1877	111	Business Analysis	6	t
1878	111	Finance and Investment	6	t
1879	111	Management	6	t
1880	111	Business Computing	5	t
1881	111	Engineering	5	t
1882	111	Law	5	t
1883	111	Economics and Finance	5	t
1884	111	Business and Finance	5	t
1885	111	Chemistry	5	t
1886	112	Accounting and Finance	116	t
1887	112	Economics	72	t
1888	112	Accounting	56	t
1889	112	Law	35	t
1890	112	Mathematics	33	t
1891	112	Finance	20	t
1892	112	Business Management	16	t
1893	112	Taxation	12	t
1894	112	Business	10	t
1895	112	Psychology	10	t
1896	112	Business Studies	9	t
1897	112	Philosophy	9	t
1898	112	Management	9	t
1899	112	Physics	8	t
1900	112	Natural Sciences	7	t
1901	112	 Business Administration and Management	7	t
1902	112	History	7	t
1903	112	Geography	6	t
1904	112	Chemical Engineering	6	t
1905	112	Certificate of Proficiency in Insolvency	6	t
1906	112	Biology	6	t
1907	112	Chemistry	6	t
1908	112	ACA	5	t
1909	112	Management Science	5	t
1910	112	Economics and Finance	5	t
1911	112	Accounting and Business/Management	5	t
1912	112	Pharmacology	5	t
1913	113	Mathematics	14	t
1914	113	Financial Mathematics	9	t
1915	113	Finance	7	t
1916	113	Quantitative Finance	5	t
1917	114	Economics	31	t
1918	114	Finance	25	t
1919	114	Accounting and Finance	23	t
1920	114	Business	15	t
1921	114	 Banking	14	t
1922	114	Law	11	t
1923	114	 Business Administration and Management	11	t
1924	114	Business Studies	9	t
1925	114	Business Management	9	t
1926	114	Accounting	9	t
1927	114	Banking and Financial Support Services	8	t
1928	114	Psychology	7	t
1929	114	International Business	5	t
1930	114	Business and Finance	5	t
1931	114	Chemistry	5	t
1932	114	Management	5	t
1933	115	Economics	54	t
1934	115	Finance	45	t
1935	115	Accounting	7	t
1936	115	Business Management	7	t
1937	115	History	7	t
1938	115	Economics and Finance	7	t
1939	115	Business Studies	6	t
1940	115	Business	5	t
1941	115	Accounting and Finance	5	t
1942	115	Law	5	t
1943	115	Business Administration	5	t
1944	115	Finance and Financial Management Services	5	t
1945	115	Management	5	t
1946	116	 Business Administration and Management	16	t
1947	116	Business	16	t
1948	116	Economics	13	t
1949	116	Accounting and Finance	12	t
1950	116	Accounting	9	t
1951	116	Finance	8	t
1952	116	Accounting and Business/Management	7	t
1953	116	Business Management	7	t
1954	116	Law	6	t
1955	116	Marketing	6	t
1956	116	Social Sciences	5	t
1957	117	Psychology	9	t
1958	117	Law	8	t
1959	117	Business	7	t
1961	117	English Literature	6	t
1962	117	English	6	t
1963	117	Business Management	6	t
1964	117	 Business Administration and Management	5	t
1965	117	Accounting	5	t
1966	117	Executive Assistant/Executive Secretary	5	t
1967	117	Business Studies	5	t
1968	118	Economics	31	t
1969	118	Accounting	27	t
1970	118	Accounting and Finance	21	t
1971	118	Business Management	16	t
1972	118	Law	15	t
1973	118	Business	12	t
1974	118	History	11	t
1975	118	Finance	9	t
1976	118	Business Studies	9	t
1977	118	Psychology	8	t
1978	118	International Business	6	t
1979	118	 Banking	6	t
1980	118	Biology	6	t
1981	118	Mathematics	5	t
1982	118	English Literature	5	t
1983	118	Business Administration	5	t
1984	118	Business and Finance	5	t
1985	118	Marketing	5	t
1986	119	Business	17	t
1987	119	Computer Science	14	t
1988	119	Economics	12	t
1989	119	Law	11	t
1990	119	Business Studies	10	t
1991	119	Information Technology	10	t
1992	119	Project Management	9	t
1993	119	Accounting and Finance	9	t
1994	119	Psychology	8	t
1995	119	Accounting	8	t
1996	119	Geography	8	t
1997	119	Mathematics	7	t
1998	119	Business Management	7	t
1999	119	 Business Administration and Management	7	t
2000	119	History	5	t
2001	119	Financial Services	5	t
2002	119	Marketing	5	t
2003	119	Management	5	t
2004	120	Mathematics	101	t
2005	120	Actuarial Science	60	t
2006	120	Actuarial Finance	11	t
2007	120	Mathematics and Statistics	10	t
2008	120	Physics	6	t
2009	120	Financial Mathematics	5	t
2010	120	Statistics	5	t
2011	121	Accounting and Finance	12	t
2012	121	Accounting	9	t
2013	122	Accounting and Finance	9	t
2014	122	Accounting	8	t
2015	122	Payroll Management	7	t
2016	122	Payroll	6	t
1345	97	English	9	t
1344	97	English Literature	9	t
1445	99	English Literature	10	t
1446	99	Mathematics and Statistics	12	t
1960	117	English Language and Literature	7	t
1788	109	Accounting and Finance	456	t
1789	109	Accounting	391	t
1790	109	Economics	171	t
1791	109	Mathematics	125	t
1795	109	Accounting and Business/Management	26	t
1796	109	Law	24	t
1798	109	Chemistry	22	t
1800	109	Business	21	t
1801	109	 Business Administration and Management	21	t
1802	109	Chartered Accountant	19	t
1803	109	Geography	19	t
1815	109	First time passes	8	t
1821	109	Accounting and Management	8	t
1836	109	Risk Management	6	t
1393	98	English Language and Literature	11	t
1401	99	Finance	106	t
1402	99	Business	80	t
1403	99	Accounting and Business/Management	50	t
1404	99	Management Accounting	46	t
1405	99	Business Studies	62	t
1406	99	Business Management	56	t
1409	99	Law	40	t
1410	99	 Business Administration and Management	45	t
1411	99	Business and Finance	29	t
1412	99	CIMA	24	t
1413	99	International Business	35	t
1414	99	Geography	28	t
1416	99	Physics	32	t
1417	99	Marketing	31	t
1419	99	History	23	t
1420	99	Psychology	25	t
1421	99	Management	23	t
1428	99	Corporate Finance	12	t
1430	99	Business Economics	15	t
1431	99	Business Administration	16	t
1432	99	Chemistry	14	t
1433	99	Computer Science	41	t
1434	99	 Banking	12	t
1435	99	Banking and Finance	19	t
1436	99	English	12	t
1437	99	Project Management	14	t
1438	99	Accounting and Management	10	t
1439	99	Information Technology	33	t
1440	99	Biology	13	t
1441	99	Computing	14	t
1442	99	Mechanical Engineering	12	t
1443	99	Mathematics and Economics	12	t
1444	99	Economics and Finance	13	t
2020	124	Accounting and Finance	34	t
2021	124	Law	23	t
2022	124	Business Management	18	t
2023	124	Economics	14	t
2024	124	 Business Administration and Management	12	t
2025	124	Psychology	10	t
2026	124	Business Studies	10	t
2027	124	Business	9	t
2028	124	Finance	8	t
2029	124	English Language and Literature	8	t
2030	124	Mathematics	7	t
2031	124	History	7	t
2032	124	Accounting	7	t
2033	124	Business Economics	6	t
2034	124	Business Administration	6	t
2035	124	Criminology	6	t
2036	124	Accounting and Business/Management	5	t
2037	124	Travel and Tourism	5	t
2038	124	International Business	5	t
2039	124	English Literature	5	t
2040	124	Project Management	5	t
2041	124	Marketing	5	t
1687	105	Financial Engineering	20	t
2042	125	Biotechnology	7	t
2043	125	Biochemistry	3	t
2044	125	Molecular Biology	1	t
2045	125	Quality and Safety Food	1	t
2046	125	Physiology	1	t
2047	125	Forensic Biology	1	t
2048	125	Biotechnology; Biotechnology	1	t
2049	125	Applied Molecular technology	1	t
2050	125	Strategy	1	t
2051	125	Genetic Manipulation and Molecular Cell Biology	1	t
2052	125	 PhD	1	t
2053	125	Medical Microbiology and Bacteriology	1	t
2054	125	Biochemistry and Genetics	1	t
2055	125	Industrial Biotechnology	1	t
2056	125	Neuroscience	1	t
2057	125	Bioinformatics	1	t
2058	125	Education	1	t
2059	125	Invertebrate immunology	1	t
2060	125	Molecular and Cellular Biology	1	t
2061	125	Cell Biology	1	t
2062	125	Biochemical Engineering	1	t
2063	125	10	1	t
2064	125	Electrical Engineering	1	t
2065	125	Microbiology	1	t
2066	126	Forensic Science	2	t
2067	126	Molecular Biology	1	t
2068	126	Chemical Engineering and Analytical Science	1	t
2069	126	Analytical Chemistry	1	t
2070	126	Marine Biology and Biological Oceanography	1	t
2071	126	Bioengineering	1	t
2072	126	 Development of a Resource for the Exploration of Gene Expression in the Mouse Foetus	1	t
2073	126	Biological Sciences	1	t
2074	126	Humanities/Humanistic Studies	1	t
2075	126	Biotechnology	1	t
2076	126	Organic Chemistry	1	t
2077	126	Biomedical Engineering - BioInformatics	1	t
2078	126	Applied chemistry with industry	1	t
2079	127	Microbiology	3	t
2080	127	Yachting	1	t
2081	127	Human Biology and Law	1	t
2082	127	Applied Microbiology	1	t
2083	127	analysis and processes	1	t
2084	127	Biochemistry	1	t
2085	127	Biotechnology	1	t
2086	128	Biochemistry	6	t
2087	128	Molecular Biology	5	t
2088	128	Cell/Cellular and Molecular Biology	4	t
2089	128	Biochemical Engineering	3	t
2090	128	Biotechnology	3	t
2091	128	Molecular Microbiology	2	t
2092	128	Cell Biology	2	t
2093	128	Analytical Chemistry	2	t
2094	128	Biochemistry and Clinical Biochemistry	1	t
2095	128	Agricultural Biotechnology	1	t
2096	128	 Medical Biotechnology and Molecular Medicine	1	t
2097	128	Genetic control of pest insects	1	t
2098	128	Biocatalysis	1	t
2099	128	 Engineer in Biotechnology	1	t
2100	128	Molecular Pharmacology	1	t
2101	128	Biology and Chemistry	1	t
2102	128	Biological Sciences Research	1	t
2103	128	Immunologie	1	t
2104	128	Biomedical Blood Science	1	t
2105	128	Physics	1	t
2106	128	 Biology with Industrial Experience	1	t
2107	128	Virology	1	t
2108	128	Human Molecular Genetics	1	t
2109	128	Molecular Biology and Pathology of Viruses	1	t
2110	128	Plant molecular ecology	1	t
2111	128	Pharmacology	1	t
2112	128	Inorganic Chemistry	1	t
2113	128	Molecular Pathology	1	t
2114	128	Medicinal and Pharmaceutical Chemistry	1	t
2115	128	Plant Molecular Biology	1	t
2116	128	Immunology and Pharmacology	1	t
2117	128	Marine Biotechnology	1	t
2118	128	Medical Sciences	1	t
2119	128	Pharmaceutical Sciences	1	t
2120	128	Upper Second Class	1	t
2121	128	Structural Biology	1	t
2122	128	Biochemistry with a year in industry	1	t
2123	128	BSc Biomedical Sciences	1	t
2124	128	Cell Physiology	1	t
2125	128	Biochemistry and Molecular Biology	1	t
2126	128	Microbial & Cellular Biology	1	t
2127	128	Human Anatomy	1	t
2128	128	Genetics	1	t
2129	128	Applied Biomolecular Technology	1	t
2130	128	Molecular and Cellular Biology	1	t
2131	128	Biochemsitry	1	t
2132	129	Biochemistry and Molecular Biology	5	t
2133	129	Biochemistry	4	t
2134	129	Chemistry	3	t
2135	129	Biotechnology	3	t
2136	129	Materials Science	3	t
2137	129	Biomedical Sciences	2	t
2138	129	Molecular Biophysics	2	t
2139	129	Genetics	2	t
2140	129	Microbiology	2	t
2141	129	Molecular Biology	1	t
2142	129	Biological and Biomedical Sciences	1	t
2143	129	Biotechnology and Enterprise	1	t
2144	129	Molecular Plant Pathology	1	t
2145	129	Biochemistry and Systems Biology	1	t
2146	129	Cancer Research UK Tumour Microcirculation Group	1	t
2147	129	Experimental Nuclear Physics	1	t
2148	129	Microbiología	1	t
2149	129	Electronic and Electrical Engineering	1	t
2150	129	Cancer Immunology and Biotechnology	1	t
2151	129	 Biotecnologie Genomiche	1	t
2152	129	Biochemical Engineering and Biotechnology	1	t
2153	129	Biomedical Engineering	1	t
2154	129	Production and extraction of PUFAs from microalgae	1	t
2155	129	 Micro- and Nano-Materials and Technologies	1	t
2156	129	Enzymology	1	t
2157	129	Pharmacology and Biotechnology	1	t
2158	129	Applied Microbiology and Biotechnology	1	t
2159	129	Genetics of autism	1	t
2160	129	Biological Sciences	1	t
2161	129	Engineering	1	t
2162	129	Organic Chemistry and Chemical Biology	1	t
2163	129	Physical Chemistry	1	t
2164	129	Biology and Biochemistry	1	t
2165	129	Cell and Molecular Biology	1	t
2166	129	 Curriculum Biomolecular Pharmaceutical	1	t
2167	130	Biochemistry	3	t
2168	130	Biology	2	t
2169	130	Biotechnology	2	t
2170	130	Chemistry	1	t
2171	130	Clinical Laboratory Science/Medical Technology/Technologist	1	t
2172	130	Biochemistry and Microbiology	1	t
2173	130	Biomedical Sciences	1	t
2174	130	Industrial and molecular biotechnology	1	t
2175	130	Principles of Biochemistry	1	t
2176	130	Forensic Science	1	t
2177	130	Análises Clínicas e Saúde Pública	1	t
2178	130	Management and Leadership Course	1	t
2179	130	Forensic and Analytical Science	1	t
2180	130	Applied Biomolecular Technology	1	t
2181	130	Biosciences	1	t
2182	130	Microbiology	1	t
2183	131	Biomedical Sciences	11	t
2184	131	Biological and Biomedical Sciences	3	t
2185	131	Biomedical/Medical Engineering	2	t
2186	131	Public Service Management	2	t
2187	131	Chemistry	1	t
2188	131	Certificate in First Line Management	1	t
2189	131	English	1	t
2190	131	Neuroscience	1	t
2191	131	Haematology and Blood Transfusion	1	t
2192	131	Medical Biochemistry	1	t
2193	131	Clinical Biochemistry	1	t
2194	131	Biochemistry	1	t
2195	131	BMS	1	t
2196	131	Anatomy Pathology/ Health	1	t
2197	131	Applied haematology and blood transfusion	1	t
2198	131	Human Biosciences	1	t
2199	131	Fellowship IBMS	1	t
2200	131	C!inical Chemistry	1	t
2201	131	Microbiology	1	t
2202	132	Health and Social Care	1	t
2203	132	Cell Biology	1	t
2204	133	Mechanical Engineering	294	t
2205	133	Engineering	20	t
2206	133	Mechanical and Manufacturing Engineering	8	t
2207	133	Building Services Engineering	6	t
2208	133	Advanced Mechanical Engineering	4	t
2209	133	Building Services	4	t
2210	133	Mechanical Engineering Design	4	t
2211	133	Product Design and Management	3	t
2212	133	Engineering Design	3	t
2213	133	Aerospace Engineering	3	t
2214	133	Automotive Engineering	3	t
2215	133	Mechanical Engineering Related Technologies/Technicians	3	t
2216	133	Mechanical Engineering with Management	3	t
2217	133	Engineering Science	3	t
2218	133	Aeronautical Engineering	2	t
2219	133	Renewable Energy Engineering	2	t
2220	133	Product Design	2	t
2221	133	Mechanical Engineering BEng (Hons)	2	t
2222	133	Electromechanical Engineering	2	t
2223	133	Electrical and Electronics Engineering	2	t
2224	133	Advanced Engineering Design	2	t
2225	133	Mechanical Design Engineering	2	t
2226	133	Renewable Energy	2	t
2227	133	Mechanical and Offshore Engineering	2	t
2228	133	Mathematics	2	t
2229	133	Mechanical	2	t
2230	133	Chemistry	2	t
2231	133	Business Administration	2	t
2232	133	Product Design Engineering	2	t
2233	133	Mechanical & Production Engineering	2	t
2234	133	Environmental Engineering Technology/Environmental Technology	2	t
2235	133	Building Services & Energy Engineering	2	t
2236	133	BEng Mechanical Engineering	2	t
2237	133	 BEng	1	t
2238	133	Electrical Engineering	1	t
2239	133	General Engineering	1	t
2240	133	HND Mechanical Engineering	1	t
2241	133	Vehicle Maintenance and Repair Technologies	1	t
2242	133	Sailing	1	t
2243	133	Telecommunications Engineering	1	t
2244	133	Advanced Certificate	1	t
2245	133	Advanced Product Design Engineering	1	t
2246	133	Industrial Engineering	1	t
2247	133	Engineering Physics	1	t
2248	133	 Innovation and Marketing	1	t
2249	133	IT and Computing	1	t
2250	133	Design and Applied Arts	1	t
2251	133	Mechanical Electronic Systems Engineering	1	t
2252	133	Diploma	1	t
2253	133	Mechanical Engineering and Energy Engineering	1	t
2254	134	Mechanical Engineering	29	t
2255	134	Electrical and Electronics Engineering	9	t
2256	134	Engineering	6	t
2257	134	Building Services Engineering	3	t
2258	134	Electrical and Mechanical Engineering	2	t
2259	134	Building Services Engineering Management	2	t
2260	134	Domestic Gas Engineering	1	t
2261	134	Microprocessor's Control Systems in Electrical Engineering	1	t
2262	134	HV Competent Person	1	t
2263	134	Mechanics and Machine Design	1	t
2264	134	 laundry and catering gas safe coarse	1	t
2265	134	Techical equipment for food industry	1	t
2266	134	Marine Engineering	1	t
2267	134	 GCE History	1	t
2268	134	specialization: machinery construction	1	t
2269	134	 Miljøteknologi / Environmental Engineering	1	t
2270	134	General Engineering	1	t
2271	134	Aeronautical/Aerospace Engineering Technology/Technician	1	t
2272	134	Plant engineering and technologies	1	t
2273	134	Mechatronik	1	t
2274	134	HNC Mechanical Engineering	1	t
2275	134	Electronic Servicing	1	t
2276	134	Risk Assessment	1	t
2277	134	Underwater Inspection	1	t
2278	134	Motor Vehicle	1	t
2279	134	Plant Mechanics	1	t
2280	134	Electro	1	t
2281	134	Industrial Engineering	1	t
2282	134	Mechanical and Marine Engineering	1	t
2283	134	Mechanical Engineering 2:1	1	t
2284	134	Chemistry	1	t
2285	134	City and Guilds level 2 and 3 advanced certificate in plant maintenance and repair	1	t
2286	134	 lithographics and print managment and technology	1	t
2287	134	Bioelectrónica	1	t
2288	134	Maintaining Heating and Ventilating Systems	1	t
2289	134	Advanced Manufacturing	1	t
2290	134	Electrical Engineering	1	t
2291	134	Mechanical and Materials Engineering	1	t
2292	134	Advanced Engineering and Management	1	t
2293	134	Manufacturing Engineering	1	t
2294	134	stairlift technology	1	t
2295	134	Production Management	1	t
2296	134	Technical Authorship	1	t
2297	134	Mecatrónica Industrial	1	t
2298	134	Film Production Technology	1	t
2299	134	Cooling Enginnering	1	t
2300	134	Physics	1	t
2301	134	Building services and management	1	t
2302	134	 level 3 and advanced apprenticeship mechanical engineering/ CAD level 1 - 3 / 3D	1	t
2303	134	 Level 3 and Level 2	1	t
2304	135	Electronic Engineering	5	t
2305	135	Electrical and Electronics Engineering	5	t
2306	135	English	2	t
2307	135	Engineering Management	1	t
2308	135	Manufacturing Operations Management	1	t
2309	135	Manufacturing Management	1	t
2310	135	Photonics	1	t
2311	135	17th Edition	1	t
2312	135	Commerce & project managment	1	t
2313	135	Chemistry	1	t
2314	135	Mechanical Engineering	1	t
2315	135	Computer Science	1	t
2316	135	General Studies	1	t
2317	135	Electronic and Electrical Engineering	1	t
2318	135	Applied Design	1	t
2319	135	Engineerin pharmaceutical petrochemical oil and gas	1	t
2320	135	Thermal Power Engineering	1	t
2321	135	Electronics and Communiations	1	t
2322	135	Engineering	1	t
2323	135	vehicle refinishing. bodywork and welding	1	t
2324	135	Electronic Device Engineering	1	t
2325	135	 2391 testing	1	t
2326	135	HNC Electrical Engineering	1	t
2327	135	Control Systems	1	t
2328	135	Marketing	1	t
2329	135	Electrical and Electronics Engineering Technology	1	t
2330	135	 Electrical and Power Transmission Installation/Installer	1	t
2331	135	Marketing - and advertisement administrator	1	t
2332	135	 Business Administration and Management	1	t
2333	135	 HND in Electronics Eng	1	t
2334	135	Information Technology	1	t
2335	135	Electrical Technolody and Mechanical Technology	1	t
2336	135	Accounting	1	t
2337	135	 UK	1	t
2338	135	RF and Microwaves	1	t
2339	135	Electronics	1	t
2340	135	Electro technics	1	t
2341	135	 BEng.Electronic	1	t
2342	135	•\tMathematics •\tEnglish language and literature •\tScience •\tDesign and technology	1	t
2343	135	Computer Communications	1	t
2344	135	Electronics and Computing	1	t
\.


--
-- Name: career_subject_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geektalent
--

SELECT pg_catalog.setval('career_subject_id_seq', 2344, true);


--
-- Data for Name: entity_description; Type: TABLE DATA; Schema: public; Owner: geektalent
--

COPY entity_description (id, entity_type, linkedin_sector, entity_name, match_count, short_description, description, description_url, description_source, edited) FROM stdin;
\.


--
-- Name: entity_description_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geektalent
--

SELECT pg_catalog.setval('entity_description_id_seq', 1, false);


--
-- Data for Name: next_title; Type: TABLE DATA; Schema: public; Owner: geektalent
--

COPY next_title (id, career_id, next_title, count, visible) FROM stdin;
1	1	Management Consultant	41	t
2	1	IT Consultant	31	t
3	1	Business Analyst	30	t
4	1	Director	25	t
5	1	Software Developer	21	t
6	1	Manager	18	t
7	1	IT Service Manager	14	t
8	1	Account Manager	13	t
9	1	Product Manager	13	t
10	1	Managing Director	11	t
11	1	Test Analyst	11	t
12	1	IT Manager	11	t
13	1	PMO Manager	10	t
14	1	Producer	9	t
15	1	Operations Manager	8	t
16	1	Business Development Manager	8	t
17	1	Implementation Manager	8	t
18	1	Operations	6	t
19	1	Head of Delivery	6	t
20	1	Portfolio Manager	6	t
21	1	Engagement Manager	6	t
22	1	Project Director	6	t
23	1	Programme Director	6	t
24	1	Founder	6	t
25	1	Change Manager	6	t
26	1	PMO Lead	5	t
27	1	Contracts Manager	5	t
28	1	Operations Director	5	t
29	1	Marketing Manager	5	t
30	2	Project Manager	62	t
31	2	Software Developer	58	t
32	2	IT Consultant	51	t
33	2	Director	44	t
34	2	Business Analyst	33	t
35	2	Account Manager	27	t
36	2	IT Manager	22	t
37	2	Manager	21	t
38	2	Managing Director	15	t
39	2	Sales Manager	14	t
40	2	Product Manager	12	t
41	2	Consultant	11	t
42	2	Business Development	9	t
43	2	Founder	9	t
44	2	Test Analyst	8	t
45	2	IT Service Manager	8	t
46	2	Account Director	7	t
47	2	Sales Director	7	t
48	2	Web Developer	6	t
49	2	Co-Founder	6	t
50	2	Key Account Manager	6	t
51	2	Account Executive	6	t
52	2	Data Analyst	6	t
53	2	Sales Executive	6	t
54	2	Business Development Manager	5	t
55	2	General Manager	5	t
56	2	Business Manager	5	t
57	3	IT Consultant	195	t
58	3	Project Manager	162	t
59	3	Software Developer	117	t
60	3	Business Analyst	82	t
61	3	IT Service Manager	76	t
62	3	Network Engineer	64	t
63	3	Test Analyst	49	t
64	3	Director	40	t
65	3	Project Engineer	32	t
66	3	Web Developer	31	t
67	3	Consultant	30	t
68	3	Management Consultant	30	t
69	3	Data Analyst	27	t
70	3	Account Manager	25	t
71	3	Operations Manager	24	t
72	3	Manager	23	t
73	3	Team Leader	19	t
74	3	Managing Director	19	t
75	3	Owner	16	t
76	3	Engineer	16	t
77	3	Project Coordinator	15	t
78	3	Database Administrator	14	t
79	3	Service Desk Manager	11	t
80	3	Desktop Support	11	t
81	3	Server Engineer	11	t
82	3	General Manager	10	t
83	3	DevOps Engineer	10	t
84	3	Technical Manager	10	t
85	3	IT Project Manager	10	t
86	3	Sales Manager	9	t
87	3	Business Development Manager	9	t
88	3	Technical Services Manager	9	t
89	3	Infrastructure Consultant	9	t
90	3	Field Service Engineer	9	t
91	3	Administrator	9	t
92	3	Design Engineer	8	t
93	3	IT Officer	8	t
94	3	Systems Manager	8	t
95	3	Team Manager	8	t
96	3	Infrastructure Manager	8	t
97	3	Vice President	8	t
98	3	Engineering Manager	8	t
99	3	Desktop Engineer	8	t
100	3	Project Support Officer	7	t
101	3	Recruitment Consultant	7	t
102	3	Founder	7	t
103	3	Contracts Manager	7	t
104	3	Office Manager	7	t
105	3	Customer Service Representative	7	t
106	3	Business Manager	7	t
107	4	IT Manager	118	t
108	4	Software Developer	115	t
109	4	Business Analyst	78	t
110	4	Project Manager	71	t
111	4	Management Consultant	58	t
112	4	Test Analyst	47	t
113	4	Director	45	t
114	4	Consultant	36	t
115	4	Manager	36	t
116	4	Data Analyst	19	t
117	4	IT Service Manager	18	t
118	4	Database Administrator	14	t
119	4	Account Manager	13	t
120	4	Recruitment Consultant	12	t
121	4	Architect	12	t
122	4	Managing Director	11	t
123	4	Product Manager	11	t
124	4	Business Development Manager	10	t
125	4	Founder	10	t
126	4	Web Developer	9	t
127	4	Vice President	9	t
128	4	Technical Director	9	t
129	4	Network Engineer	8	t
130	4	Co-Founder	8	t
131	4	Technical Manager	7	t
132	4	Developer	7	t
133	4	Engineer	6	t
134	4	Business Consultant	6	t
135	4	Client Services Manager	6	t
136	4	Operations Manager	6	t
137	4	Principal Consultant	6	t
138	4	Sales Engineer	6	t
139	4	CEO	6	t
140	4	Principal Architect	6	t
141	4	Owner	5	t
142	4	Office Manager	5	t
143	4	Trainer	5	t
144	4	Technical Project Manager	5	t
145	4	Account Director	5	t
146	4	Infrastructure Architect	5	t
147	4	Team Leader	5	t
148	5	Project Manager	43	t
149	5	Management Consultant	28	t
150	5	IT Consultant	15	t
151	5	Test Analyst	12	t
152	5	IT Manager	11	t
153	5	Data Analyst	9	t
154	5	Software Developer	8	t
155	5	Director	6	t
156	5	Product Manager	5	t
157	5	Business Analyst	5	t
158	6	Project Manager	48	t
159	6	IT Manager	37	t
160	6	IT Consultant	21	t
161	6	Management Consultant	12	t
162	6	Business Analyst	9	t
163	6	Operations Manager	7	t
164	6	Director	7	t
165	6	Manager	7	t
166	6	Software Developer	6	t
167	6	Head of Service Delivery	5	t
168	7	IT Manager	43	t
169	7	IT Consultant	15	t
170	7	Software Developer	12	t
171	7	Project Manager	12	t
172	7	Director	9	t
173	7	IT Service Manager	7	t
174	7	Operations Manager	6	t
175	7	Infrastructure Manager	5	t
176	8	IT Consultant	200	t
177	8	Web Developer	102	t
178	8	Project Manager	84	t
179	8	Management Consultant	74	t
180	8	IT Manager	72	t
181	8	Business Analyst	62	t
182	8	Test Analyst	55	t
183	8	Director	49	t
184	8	Consultant	41	t
185	8	Software Developer	41	t
186	8	Data Analyst	31	t
187	8	Engineer	21	t
188	8	Team Leader	18	t
189	8	Manager	16	t
190	8	Vice President	15	t
191	8	Technical Director	15	t
192	8	Database Administrator	15	t
193	8	Co-Founder	13	t
194	8	Development Team Leader	12	t
195	8	Founder	12	t
196	8	Product Manager	11	t
197	8	Managing Director	10	t
198	8	Development Team Lead	10	t
199	8	C Developer	10	t
200	8	Java Consultant	10	t
201	8	Contract Developer	9	t
202	8	Contractor	9	t
203	8	Technical Manager	8	t
204	8	Architect	8	t
205	8	Frontend Developer	8	t
206	8	Owner	8	t
207	8	Head of Technology	7	t
208	8	SharePoint Developer	7	t
209	8	Assistant Vice President	7	t
210	8	Project Leader	7	t
211	8	Mobile Developer	6	t
212	8	Business Development Manager	6	t
213	8	Application Engineer	6	t
214	8	Account Manager	6	t
215	8	Technical Developer	6	t
216	8	Operations Manager	6	t
217	8	Technical Project Manager	6	t
218	8	Database Developer	6	t
219	8	Web Designer	6	t
220	8	Lecturer	5	t
221	8	Technical Delivery Manager	5	t
222	8	System Specialist	5	t
223	8	Designer	5	t
224	8	SharePoint Consultant	5	t
225	8	Recruitment Consultant	5	t
226	9	Consultant	86	t
227	9	Director	70	t
228	9	Vice President	51	t
229	9	Business Analyst	41	t
230	9	Manager	33	t
231	9	Software Developer	25	t
232	9	Project Manager	21	t
233	9	Assistant Vice President	19	t
234	9	Management Consultant	19	t
235	9	IT Consultant	16	t
236	9	Investment Analyst	16	t
237	9	Chief Executive	12	t
238	9	AVP	12	t
239	9	Assistant Manager	12	t
240	9	Summer Analyst	11	t
241	9	IT Manager	11	t
242	9	Research Analyst	11	t
243	9	Financial Analyst	10	t
244	9	Consulting Analyst	8	t
245	9	Executive Director	8	t
246	9	Relationship Manager	8	t
247	9	Managing Director	8	t
248	9	Portfolio Manager	8	t
249	9	Credit Analyst	7	t
250	9	Investment Banking Analyst	7	t
251	9	Team Leader	7	t
252	9	Risk Analyst	6	t
253	9	Investment Manager	6	t
254	9	Summer Intern	6	t
255	9	Product Manager	6	t
256	9	Assistant Director	5	t
257	9	MI Analyst	5	t
258	9	Performance Analyst	5	t
259	9	Research Assistant	5	t
260	9	Fund Manager	5	t
261	9	Partner	5	t
262	9	VP	5	t
263	9	Sales Assistant	5	t
264	9	Recruitment Consultant	5	t
265	10	Software Developer	30	t
266	10	Business Analyst	27	t
267	10	Project Manager	27	t
268	10	Management Consultant	22	t
269	10	IT Manager	16	t
270	10	IT Consultant	13	t
271	10	Director	11	t
272	10	QA Lead	10	t
273	10	QA Consultant	9	t
274	10	Test Specialist	8	t
275	10	test	8	t
276	10	Software Developer in Test	8	t
277	10	Quality Assurance Analyst	7	t
278	10	Test Team Leader	7	t
279	10	QA Manager	7	t
280	10	QA Team Lead	7	t
281	11	Software Developer	155	t
282	11	IT Manager	14	t
283	11	Web Designer	11	t
284	11	Frontend Developer	9	t
285	11	Designer	8	t
286	11	Director	8	t
287	11	Developer	8	t
288	11	Owner	7	t
289	11	UI Developer	7	t
290	11	Project Manager	7	t
291	11	IT Consultant	7	t
292	11	Co-Founder	6	t
293	11	Founder	6	t
294	11	Managing Director	5	t
295	11	User Interface Developer	5	t
296	12	Web Developer	34	t
297	12	Designer	11	t
298	12	Software Developer	9	t
299	12	Digital Designer	8	t
300	13	IT Consultant	10	t
301	13	Software Developer	7	t
302	13	Management Consultant	7	t
303	14	Project Manager	25	t
304	14	Marketing Manager	6	t
305	14	Marketing Intern	5	t
306	14	SEO Executive	5	t
307	14	Producer	5	t
308	14	Digital Producer	5	t
309	15	Character Animator	10	t
310	15	3D Modeler	6	t
311	15	3D Generalist	6	t
312	15	Creative Director	5	t
313	15	Designer	5	t
314	15	Director	5	t
315	19	Software Developer	5	t
527	41	Sales Executive	9	t
528	41	Parts Manager	5	t
529	42	Sales Manager	65	t
530	42	Account Manager	60	t
531	42	Business Development Manager	45	t
532	42	Recruitment Consultant	20	t
533	42	Business Manager	17	t
534	42	Business Development Executive	14	t
535	42	Consultant	13	t
536	42	Account Executive	13	t
537	42	Director	12	t
538	42	Regional Sales Manager	9	t
539	42	Marketing Manager	9	t
540	42	Business Development	9	t
541	42	Sales Consultant	8	t
542	42	Sales & Marketing Manager	7	t
543	42	Sales	7	t
544	42	Sales Director	7	t
545	42	Product Manager	7	t
546	42	National Account Manager	6	t
547	42	Event Coordinator	6	t
548	42	Assistant Sales Manager	6	t
549	42	Team Leader	6	t
550	42	Marketing Assistant	6	t
551	42	General Manager	6	t
552	42	Key Account Manager	6	t
553	42	Marketing Executive	6	t
554	42	Assistant Manager	6	t
555	42	Corporate Account Manager	5	t
556	42	Sales and Events Manager	5	t
557	42	Sales Advisor	5	t
558	42	Area Sales Manager	5	t
559	42	Project Manager	5	t
560	42	Internal Account Manager	5	t
561	42	Sales Representative	5	t
562	42	Managing Director	5	t
563	44	Sales Director	50	t
564	44	Business Development Manager	48	t
565	44	Director	29	t
566	44	Account Manager	29	t
567	44	Sales	22	t
568	44	Managing Director	20	t
569	44	General Manager	20	t
570	44	Sales Executive	20	t
571	44	Operations Manager	15	t
572	44	Business Manager	14	t
573	44	Director of Sales	10	t
574	44	Regional Sales Manager	10	t
575	44	Sales & Marketing Manager	9	t
576	44	Commercial Manager	9	t
577	44	Manager	9	t
578	44	Business Development Director	9	t
579	44	Business Development	8	t
580	44	Branch Manager	8	t
581	44	Account Director	8	t
582	44	Consultant	7	t
583	44	Recruitment Consultant	6	t
584	44	Key Account Manager	6	t
585	44	Project Manager	6	t
586	44	Assistant Manager	6	t
587	44	UK Sales Manager	6	t
588	44	Sales Consultant	6	t
589	44	Commercial Director	6	t
590	44	European Sales Manager	5	t
591	44	Area Sales Manager	5	t
592	44	Marketing Manager	5	t
593	44	Sales & Marketing Director	5	t
594	45	Business Development Manager	16	t
595	45	Director	14	t
596	45	Project Manager	13	t
597	45	Manager	12	t
598	45	Consultant	12	t
599	45	Sales Manager	10	t
600	45	Account Manager	7	t
601	45	Relationship Manager	5	t
602	45	Sales Executive	5	t
603	47	Project Manager	53	t
604	47	Engineer	18	t
605	47	Director	9	t
606	47	Engineering Manager	9	t
607	47	Design Engineer	8	t
608	47	Process Engineer	7	t
609	47	Consultant	6	t
610	47	Principal Engineer	6	t
611	47	IT Manager	6	t
612	47	Structural Engineer	5	t
613	47	IT Consultant	5	t
614	47	Contracts Manager	5	t
615	50	Director	53	t
616	50	Managing Director	27	t
617	50	Operations Manager	20	t
618	50	Manager	12	t
619	50	Assistant Manager	11	t
620	50	Owner	10	t
621	50	Project Manager	9	t
622	50	Sales Manager	8	t
623	50	Assistant General Manager	7	t
624	50	Area Manager	7	t
625	50	Vice President	7	t
626	50	Operations Director	6	t
627	50	Recruitment Consultant	6	t
628	50	Business Development Manager	6	t
629	50	Founder	5	t
630	50	Store Manager	5	t
631	50	Consultant	5	t
632	51	Sales Executive	6	t
633	53	Director	25	t
634	53	Managing Director	23	t
635	53	Sales Manager	14	t
636	53	Business Development Manager	9	t
637	53	General Manager	7	t
638	53	Sales & Marketing Director	7	t
639	53	Commercial Director	7	t
640	53	Sales	6	t
641	53	Owner	6	t
642	54	Mechanical Engineer	12	t
643	54	Project Engineer	7	t
644	54	Design Engineer	6	t
645	57	Procurement Manager	16	t
646	57	Assistant Buyer	13	t
647	57	Category Manager	11	t
648	57	Buying Manager	10	t
649	57	Purchasing Manager	10	t
653	78	Midwife	9	t
654	78	Director	6	t
655	78	Care Manager	5	t
656	78	Doctor	5	t
657	79	Nurse	15	t
658	79	Support Worker	7	t
659	79	Sales Assistant	6	t
660	79	Biomedical Scientist	5	t
661	79	Project Manager	5	t
662	79	Administrative Assistant	5	t
663	79	Sales Advisor	5	t
664	79	Psychological Wellbeing Practitioner	5	t
665	80	Healthcare Assistant	12	t
666	80	Team Leader	5	t
667	81	Director	16	t
668	81	Project Manager	8	t
669	81	General Practitioner (GP)	6	t
670	81	Core Surgical Trainee	6	t
671	81	Consultant	6	t
672	81	Research Fellow	5	t
673	81	Lecturer	5	t
674	90	Administrative Assistant	7	t
675	91	Project Manager	6	t
676	91	General Manager	5	t
677	91	Care Manager	5	t
678	91	Operations Manager	5	t
679	97	Financial Analyst	220	t
681	97	Manager	32	t
682	97	Account Manager	31	t
683	97	Management Accountant	31	t
684	97	Director	29	t
685	97	Finance Manager	22	t
686	97	Business Analyst	22	t
687	97	Financial Accountant	21	t
688	97	Data Analyst	19	t
689	97	Assistant Financial Controller	18	t
690	97	Financial Controller	18	t
691	97	Tax Manager	16	t
693	97	Assistant Manager	13	t
694	97	Assistant Accountant	12	t
695	97	Accounts Assistant	12	t
696	97	Tax Assistant	9	t
697	97	Account Executive	9	t
698	97	Chief Executive	8	t
699	97	Administrator	7	t
700	97	Payroll Manager	7	t
701	97	Vice President	7	t
702	97	Account Director	7	t
703	97	Office Manager	7	t
704	97	Financial Administrator	6	t
705	97	Finance Director	6	t
706	97	Business Development Manager	6	t
707	97	Consultant	6	t
708	97	Account Supervisor	6	t
709	97	Relationship Manager	5	t
710	97	Auditor	5	t
711	97	Legal Cashier	5	t
712	97	Sales Assistant	5	t
713	97	Client Accountant	5	t
714	97	Contract Accountant	5	t
715	97	Tax Accountant	5	t
716	97	Managing Director	5	t
717	97	Group Financial Accountant	5	t
718	98	Director	51	t
719	98	Business Development Manager	34	t
720	98	Manager	32	t
680	97	Audit Manager	110	t
692	97	Customer Advisor	12	t
721	98	Project Manager	19	t
722	98	Account Manager	17	t
723	98	Vice President	15	t
724	98	Portfolio Manager	13	t
725	98	Operations Manager	13	t
726	98	Business Analyst	11	t
727	98	Business Manager	11	t
728	98	Financial Advisor	9	t
729	98	Client Manager	8	t
730	98	Risk Analyst	8	t
731	98	Assistant Director	7	t
732	98	Data Analyst	7	t
734	98	Sales Manager	7	t
735	98	Product Manager	6	t
736	98	Team Leader	6	t
737	98	Managing Director	6	t
738	98	Business Development	6	t
739	98	Customer Service Manager	5	t
740	98	Marketing Manager	5	t
741	98	IT Consultant	5	t
742	98	Key Account Manager	5	t
743	98	Commercial Director	5	t
744	98	Owner	5	t
745	98	Business Support Manager	5	t
746	98	Consultant	5	t
747	98	Internal Communications Manager	5	t
748	99	Accountant	130	t
749	99	Audit Manager	64	t
755	99	Financial Advisor	22	t
756	99	Relationship Manager	22	t
758	99	Finance Manager	17	t
761	99	Management Accountant	14	t
763	99	Financial Controller	12	t
764	99	Portfolio Manager	11	t
766	99	Commercial Manager	9	t
767	99	Client Manager	8	t
769	99	Owner	8	t
770	99	Business Manager	8	t
774	99	Finance Business Partner	7	t
775	99	Commercial Analyst	7	t
777	99	Partner	7	t
778	99	Business Partner	6	t
779	99	CFO	6	t
780	99	Financial Planning & Analysis Manager	6	t
781	99	Finance Analyst	6	t
782	99	Chief Executive	6	t
783	99	Systems Accountant	6	t
785	99	Assistant Vice President	5	t
786	99	Production Controller	5	t
787	99	Commercial Accountant	5	t
789	99	Marketing Manager	5	t
791	99	Account Executive	5	t
792	99	Mortgage Advisor	5	t
793	99	Financial Director	5	t
794	99	Contractor	5	t
796	99	Sales Manager	5	t
797	100	Director	46	t
798	100	Partner	19	t
799	100	Consultant	17	t
800	100	Managing Director	15	t
801	100	Project Manager	15	t
802	100	Vice President	14	t
803	100	Data Analyst	12	t
804	100	Manager	8	t
805	100	Executive Director	7	t
807	100	Business Manager	6	t
808	100	Business Analyst	5	t
809	100	Advisor	5	t
810	100	Non Executive Director	5	t
811	100	Investment Banker	5	t
812	100	Relationship Manager	5	t
813	100	Risk Manager	5	t
814	101	Director	28	t
815	101	Mortgage Advisor	11	t
816	101	Financial Analyst	11	t
817	101	Business Development Manager	10	t
818	101	Relationship Manager	10	t
819	101	Managing Director	10	t
820	101	Manager	7	t
821	101	Owner	7	t
733	98	Financial Analyst	8	t
750	99	Business Analyst	65	t
806	100	Financial Analyst	7	t
822	101	Partner	7	t
823	101	Client Manager	6	t
824	101	Consultant	6	t
825	102	Manager	22	t
826	102	Director	13	t
827	102	Project Manager	9	t
828	102	Vice President	9	t
829	102	Managing Director	8	t
830	102	Risk Analyst	7	t
831	102	Consultant	7	t
832	102	Business Analyst	5	t
833	102	Data Analyst	5	t
834	102	Audit Manager	5	t
854	104	Director	17	t
855	104	Manager	17	t
856	104	Partner	11	t
857	104	Assistant Manager	10	t
858	104	Tax Assistant	5	t
859	105	Consultant	96	t
860	105	Director	87	t
861	105	Vice President	56	t
862	105	Portfolio Manager	50	t
863	105	Business Analyst	47	t
864	105	Manager	38	t
865	105	Software Developer	24	t
867	105	Assistant Vice President	21	t
868	105	Project Manager	21	t
869	105	Risk Analyst	19	t
870	105	Investment Banking Associate	16	t
871	105	IT Consultant	16	t
872	105	Management Consultant	16	t
873	105	Investment Banker	15	t
874	105	Assistant Manager	15	t
875	105	AVP	14	t
876	105	Chief Executive	14	t
877	105	Managing Director	13	t
878	105	Summer Analyst	12	t
879	105	Relationship Manager	11	t
880	105	IT Manager	11	t
881	105	Researcher	10	t
882	105	Executive Director	10	t
884	105	Summer Intern	9	t
885	105	Consulting Analyst	8	t
886	105	Change Analyst	8	t
887	105	Assistant Director	7	t
888	105	Performance Analyst	7	t
889	105	Investment Professional	7	t
890	105	Partner	7	t
891	105	Research Analyst	6	t
892	105	Research Manager	6	t
893	105	Sales Assistant	6	t
894	105	Research Assistant	6	t
895	105	Team Leader	6	t
896	105	MI Analyst	6	t
897	105	Audit Manager	6	t
898	105	Trader	5	t
899	105	Product Manager	5	t
900	105	Investment Executive	5	t
901	105	Founder	5	t
902	105	Mentor	5	t
903	105	VP	5	t
904	105	Accountant	5	t
905	105	Recruitment Consultant	5	t
906	106	Data Analyst	21	t
907	106	Business Analyst	15	t
908	106	Director	15	t
909	106	Risk Manager	13	t
910	106	Manager	13	t
911	106	Relationship Manager	9	t
912	106	Vice President	8	t
913	106	Portfolio Manager	5	t
914	106	Account Manager	5	t
915	106	Credit Risk Manager	5	t
916	107	Financial Advisor	14	t
917	107	Bank Manager	5	t
918	108	Data Analyst	28	t
919	108	Vice President	16	t
920	108	Portfolio Manager	15	t
921	108	Director	14	t
922	108	Investment Professional	6	t
923	108	Business Analyst	6	t
924	108	Partner	6	t
925	108	Private Equity Associate	5	t
866	105	Financial Analyst	29	t
927	109	Manager	59	t
928	109	Assistant Manager	57	t
930	109	Director	31	t
931	109	Audit Supervisor	18	t
932	109	Financial Controller	18	t
933	109	Management Accountant	16	t
934	109	Finance Manager	15	t
935	109	Internal Audit	15	t
936	109	Financial Accountant	14	t
940	109	Chief Executive	10	t
941	109	Vice President	9	t
942	109	Risk Manager	8	t
943	109	Internal Audit Manager	8	t
944	109	Project Manager	8	t
945	109	Data Analyst	7	t
946	109	Finance Director	7	t
947	109	Corporate Finance Executive	7	t
948	109	Tax Manager	6	t
949	109	Group Finance Manager	6	t
950	109	Production Controller	5	t
951	109	Assistant Financial Controller	5	t
952	109	Managing Director	5	t
953	109	Transaction Services	5	t
954	109	Non Executive Director	5	t
955	109	Principal Auditor	5	t
956	109	Group Financial Accountant	5	t
957	110	Relationship Manager	13	t
958	110	Mortgage Advisor	9	t
959	110	Business Manager	8	t
960	110	Financial Advisor	6	t
961	110	Manager	6	t
962	110	Assistant Manager	5	t
963	111	Project Manager	103	t
965	111	Consultant	40	t
966	111	Data Analyst	33	t
967	111	Management Consultant	26	t
968	111	Manager	23	t
969	111	IT Consultant	22	t
970	111	Change Analyst	21	t
971	111	Test Analyst	21	t
972	111	Director	19	t
973	111	Vice President	13	t
974	111	Software Developer	13	t
975	111	IT Manager	13	t
976	111	Business Consultant	11	t
977	111	Management Accountant	10	t
978	111	IT Project Manager	9	t
979	111	Accountant	9	t
980	111	Assistant Vice President	8	t
981	111	Product Manager	8	t
982	111	Business Architect	8	t
983	111	Head of Business Analysis	7	t
984	111	Operations Manager	7	t
985	111	Audit Manager	6	t
986	111	Business Development Manager	6	t
987	111	Project Leader	5	t
988	111	Risk Manager	5	t
990	111	Business Intelligence Manager	5	t
991	111	Agile Business Analyst	5	t
992	111	Team Leader	5	t
993	111	Product Analyst	5	t
994	111	Financial Controller	5	t
995	111	Executive Director	5	t
996	112	Tax Manager	32	t
997	112	Assistant Manager	11	t
998	112	Manager	8	t
999	114	Director	8	t
1000	115	Director	27	t
1001	115	Managing Director	6	t
1002	115	Data Analyst	5	t
1003	116	Relationship Manager	8	t
1004	116	Mortgage Advisor	7	t
1005	116	Recruitment Consultant	6	t
1006	116	Assistant Manager	6	t
1008	116	Accountant	5	t
1009	117	Executive Assistant	28	t
1010	117	Office Manager	19	t
1011	117	Secretary	10	t
1012	117	Project Manager	8	t
1013	117	Administrative Assistant	8	t
1014	117	Legal Secretary	6	t
1015	117	Project Coordinator	6	t
1016	117	Financial Administrator	5	t
1017	117	Administrator	5	t
1018	117	Accountant	5	t
1019	117	Marketing Executive	5	t
1020	117	Data Analyst	5	t
1021	117	PA/Office Manager	5	t
1022	118	Account Manager	16	t
1023	118	Relationship Manager	15	t
1024	118	Director	14	t
1025	118	Manager	12	t
1026	118	Financial Advisor	9	t
964	111	Financial Analyst	44	t
1027	118	Client Director	9	t
1028	118	Account Director	8	t
1029	118	Project Manager	6	t
1030	118	Data Analyst	5	t
1031	119	Project Manager	64	t
1032	119	Business Analyst	28	t
1033	119	Director	11	t
1034	119	PMO Lead	11	t
1035	119	Manager	8	t
1036	119	PMO Manager	7	t
1037	119	Consultant	5	t
1038	120	Consultant	7	t
1039	121	Accountant	7	t
1040	121	Assistant Manager	5	t
1041	122	Accountant	7	t
1042	97	Group Financial Controller	5	t
773	99	Customer Advisor	5	t
926	109	Financial Analyst	154	t
929	109	Accountant	55	t
937	109	Partner	12	t
938	109	Consultant	11	t
939	109	Business Analyst	11	t
1045	109	Group Financial Controller	9	t
751	99	Director	49	t
752	99	Manager	50	t
753	99	Data Analyst	40	t
754	99	Consultant	27	t
757	99	Business Development Manager	21	t
759	99	Project Manager	27	t
760	99	Vice President	17	t
762	99	Managing Director	15	t
765	99	Assistant Manager	12	t
768	99	Risk Analyst	12	t
771	99	Operations Manager	11	t
772	99	Risk Manager	10	t
776	99	Change Analyst	8	t
784	99	Investment Banker	7	t
788	99	Banker	5	t
790	99	IT Manager	8	t
795	99	IT Consultant	8	t
1046	99	Software Developer	5	t
1047	124	Personal Banker	31	t
1048	124	Accountant	28	t
1049	124	Relationship Manager	14	t
1050	124	Team Leader	12	t
1051	124	Business Analyst	9	t
1052	124	Assistant Manager	9	t
1053	124	Bank Manager	9	t
1054	124	Mortgage Advisor	8	t
1055	124	Sales Advisor	7	t
1056	124	Account Manager	5	t
1057	124	Adjudicator	5	t
1058	124	Recruitment Consultant	5	t
1059	124	Quality Assurance	5	t
1060	126	IT Consultant	20	t
1061	126	Software Developer	17	t
1062	126	IT Manager	15	t
1063	126	Account Manager	8	t
1064	126	Project Manager	8	t
1065	126	Director	7	t
1066	126	Radiographer	6	t
1067	126	Consultant	6	t
1068	126	Technical Manager	6	t
1069	126	Business Analyst	6	t
1070	126	Application Engineer	4	t
1071	126	Owner	4	t
1072	126	Product Specialist	4	t
1073	126	Business Development Manager	4	t
1074	126	Product Manager	3	t
1075	126	Developer	3	t
1076	126	Key Account Manager	3	t
1077	126	Regional Sales Manager	3	t
1078	126	Area Sales Manager	3	t
1079	126	Head of Professional Services	2	t
1080	126	Wastewater Technical Specialist	2	t
1081	126	Measurement	2	t
1082	126	Team Leader	2	t
1083	126	Communications Director	2	t
1084	126	Clinical Product Specialist	2	t
1085	126	Project Manager Data Services	2	t
1086	126	Scientific Advisor	2	t
1087	126	Software QA Lead	2	t
1088	126	NPD Technologist	2	t
1089	126	PLM Consultant	2	t
1090	126	Systems Manager	2	t
1091	126	Territory Sales Manager	2	t
1092	126	1st/2nd Line Support Engineer	2	t
1093	126	Database Administrator	2	t
1094	126	Application Manager	2	t
1095	126	Supervisor Applications Support European Team	2	t
1096	126	Technical Director	2	t
1097	126	UK Sales Manager	2	t
1098	126	Contract Developer	2	t
1099	126	System and Application Specialist	2	t
1100	126	Snr Application Specialist	2	t
1101	126	CRO Program Manager	2	t
1102	126	Scientist	2	t
1103	126	Life Science Specialist	2	t
1104	126	Sales and Production	2	t
1105	126	Service Manager	2	t
1106	126	Sr Developer	2	t
1107	126	Liquid Logic Applications Trainer	2	t
1108	126	Application Support Manager	2	t
1109	126	Global Head of Application Support	2	t
1110	127	Scientist	12	t
1111	127	Laboratory Technician	12	t
1112	127	Research Scientist	11	t
1113	127	QC Microbiologist	9	t
1114	127	PhD student	7	t
1115	127	Research Technician	7	t
1116	127	Team Leader	7	t
1117	127	Biomedical Scientist	7	t
1118	127	Technical Manager	5	t
1119	127	Research Assistant	5	t
1120	127	Laboratory Manager	5	t
1121	127	Laboratory Supervisor	5	t
1122	127	Research Associate	3	t
1123	127	Consultant	3	t
1124	127	QC Technician	3	t
1125	127	Data Analyst	3	t
1126	127	Site Microbiologist	3	t
1127	127	Research Microbiologist	3	t
1128	127	Quality Compliance Officer	3	t
1129	127	QA Manager	2	t
1130	127	Director & Chief Event Planner	2	t
1131	127	Application Specialist	2	t
1132	127	Company Microbiologist	2	t
1133	127	Paramedic	2	t
1134	127	QA Specialist	2	t
1135	127	Factory Hygienist	2	t
1136	127	Technical Advisor	2	t
1137	127	Microbiology Analyst	2	t
1138	127	QA Compliance Officer	2	t
1139	127	Microbiology Technician	2	t
1140	127	Adminstration Manager	2	t
1141	127	Quality Assurance Laboratory Technician	2	t
1142	127	Medical Records Clerk	2	t
1143	127	Quality Control Manager	2	t
1144	127	Validation Microbiologist	2	t
1145	127	Sole Trader	2	t
1146	127	voluntary assitant	2	t
1147	127	Quality Specialist	2	t
1148	127	Chief Microbiologist & Lab in charge	2	t
1149	127	Quality Technician	2	t
1150	127	Senior Operations Microbiologist	2	t
1151	127	Microbiology Lab Manager/Research Assistant	2	t
1152	127	Professional Work Experince Placement	2	t
1153	127	Cryptosporidium & Microbiology Manager	2	t
1154	127	HACCP SPECIALIST	2	t
1155	127	R&D Scientist	2	t
1156	127	Microbial Analyst	2	t
1157	127	Health and Safety Advisor	2	t
1158	127	Regulatory Advisor	2	t
1159	127	Science Teacher	2	t
1160	128	Principal Scientist	168	t
1161	128	Research Scientist	111	t
1162	128	Project Manager	51	t
1163	128	Team Leader	45	t
1164	128	Research Associate	45	t
1165	128	PhD student	44	t
1166	128	Director	42	t
1167	128	Consultant	42	t
1168	128	Research Fellow	37	t
1169	128	Lecturer	32	t
1170	128	Manager	30	t
1171	128	Group Leader	29	t
1172	128	Investigator	27	t
1173	128	Data Analyst	26	t
1174	128	Researcher	25	t
1175	128	Research Assistant	23	t
1176	128	Scientist II	23	t
1177	128	Software Developer	22	t
1178	128	Formulation Scientist	19	t
1179	128	Analytical Chemist	18	t
1180	128	PhD	17	t
1181	128	Chemist	16	t
1182	128	Project Leader	16	t
1183	128	IT Manager	16	t
1184	128	Scientific Officer	15	t
1185	128	Professor	15	t
1186	128	Scientist 1	15	t
1187	128	IT Consultant	14	t
1188	128	Study Director	13	t
1189	128	Engineer	13	t
1190	128	Technical Manager	12	t
1191	128	Analytical Scientist	12	t
1192	128	Technologist	11	t
1193	128	R&D Scientist	11	t
1194	128	Medicinal Chemist	11	t
1195	128	Medical Writer	11	t
1196	128	Development Scientist	11	t
1197	128	R&D Manager	11	t
1198	128	Owner	10	t
1199	128	Research Chemist	10	t
1200	128	Research Manager	10	t
1201	128	Research Technician	10	t
1202	128	Postdoctoral Research Associate	9	t
1203	128	Laboratory Technician	9	t
1204	128	Principal Consultant	9	t
1205	128	Biomedical Scientist	8	t
1206	128	Product Manager	7	t
1207	128	Laboratory Analyst	7	t
1208	128	Visiting Scientist	7	t
1209	128	Postdoctoral Researcher	7	t
1210	129	Scientist	198	t
1211	129	Research Fellow	72	t
1212	129	Research Associate	71	t
1213	129	PhD student	58	t
1214	129	Lecturer	52	t
1215	129	Project Manager	42	t
1216	129	Principal Scientist	40	t
1217	129	Research Assistant	34	t
1218	129	Director	32	t
1219	129	Software Developer	30	t
1220	129	Consultant	25	t
1221	129	Researcher	24	t
1222	129	Postdoctoral Researcher	23	t
1223	129	Team Leader	23	t
1224	129	Manager	23	t
1225	129	Scientific Officer	18	t
1226	129	PhD Researcher	17	t
1227	129	Postdoctoral Research Fellow	17	t
1228	129	Data Analyst	17	t
1229	129	Research Manager	16	t
1230	129	Postdoctoral Research Associate	15	t
1231	129	Principal Research Scientist	15	t
1232	129	Group Leader	15	t
1233	129	Project Leader	15	t
1234	129	Development Scientist	15	t
1235	129	Research Technician	14	t
1236	129	Product Manager	13	t
1237	129	Medical Writer	13	t
1238	129	Post Doctoral Research Associate	12	t
1239	129	R&D Manager	12	t
1240	129	IT Consultant	11	t
1241	129	Research Engineer	10	t
1242	129	Post Doctoral Research Fellow	10	t
1243	129	Teaching Assistant	10	t
1244	129	Business Development Manager	10	t
1245	129	R&D Scientist	9	t
1246	129	Chemist	9	t
1247	129	Postdoctoral Research Scientist	9	t
1248	129	Visiting Researcher	9	t
1249	129	Professor	9	t
1250	129	Postdoctoral Fellow	9	t
1251	129	IT Manager	9	t
1252	129	PhD	8	t
1253	129	Engineer	8	t
1254	129	Research Scientist II	8	t
1255	129	Post-doctoral researcher	8	t
1256	129	Science Teacher	8	t
1257	129	Technical Manager	7	t
1258	129	Postdoc	7	t
1259	129	Post-doctoral Research Scientist	7	t
1260	130	Research Assistant	57	t
1261	130	Laboratory Manager	41	t
1262	130	Scientist	35	t
1263	130	Microbiologist	33	t
1264	130	Laboratory Analyst	32	t
1265	130	PhD student	31	t
1266	130	Healthcare Assistant	27	t
1267	130	Research Scientist	24	t
1268	130	Research Technician	24	t
1269	130	Laboratory Supervisor	21	t
1270	130	Sales Assistant	20	t
1271	130	Chemist	17	t
1272	130	Analytical Chemist	17	t
1273	130	Data Analyst	16	t
1274	130	IT Manager	16	t
1275	130	Technician	14	t
1276	130	Lab Technician	13	t
1277	130	Laboratory Assistant	12	t
1278	130	Technologist	12	t
1279	130	Biomedical Scientist	12	t
1280	130	Scientific Officer	11	t
1281	130	Science Technician	11	t
1282	130	Technical Assistant	11	t
1283	130	Student	10	t
1284	130	Assistant Manager	9	t
1285	130	Quality Control Technician	9	t
1286	130	Technical Officer	9	t
1287	130	Research Associate	9	t
1288	130	Director	8	t
1289	130	Team Leader	8	t
1290	130	Development Chemist	8	t
1291	130	Laboratory Scientist	8	t
1292	130	Quality Control	8	t
1293	130	Sales Representative	8	t
1294	130	Technical Manager	7	t
1295	130	Quality Technician	7	t
1296	130	Volunteer	7	t
1297	130	Manager	7	t
1298	130	Development Technician	7	t
1299	130	Assistant Scientist	7	t
1300	130	Science Teacher	7	t
1301	130	Development Scientist	7	t
1302	130	Laboratory Technologist	6	t
1303	130	Process Engineer	6	t
1304	130	Medical Laboratory Technician	6	t
1305	130	R&D Chemist	6	t
1306	130	Administrator	6	t
1307	130	Test Analyst	6	t
1308	130	Quality Engineer	6	t
1309	130	Microbiology Technician	6	t
1310	131	Healthcare Assistant	28	t
1311	131	Research Assistant	20	t
1312	131	PhD student	18	t
1313	131	Locum Biomedical Scientist	14	t
1314	131	Laboratory Manager	13	t
1315	131	Product Specialist	10	t
1316	131	Scientist	9	t
1317	131	Advanced Biomedical Scientist	9	t
1318	131	Research Scientist	7	t
1319	131	Doctor	7	t
1320	131	Healthcare Scientist	7	t
1321	131	Training Officer	7	t
1322	131	Quality Manager	7	t
1323	131	Research Technician	6	t
1324	131	Account Manager	6	t
1325	131	Specialist BMS	6	t
1326	131	Application Specialist	5	t
1327	131	Research Associate	5	t
1328	131	Advanced Specialist Biomedical Scientist	5	t
1329	131	Biomedical Scientist 1	5	t
1330	131	Sales Representative	5	t
1331	131	Lab Manager	5	t
1332	131	Laboratory Technician	5	t
1333	131	Director	5	t
1334	131	Medical Laboratory Scientist	4	t
1335	131	Lecturer	4	t
1336	131	Biomedical Scientist in Haematology	4	t
1337	131	Field Support Scientist	4	t
1338	131	Sales Specialist	4	t
1339	131	Medical Scientist	4	t
1340	131	Biomedical Scientist Microbiology	4	t
1341	131	Graduate Assistant	3	t
1342	131	Biomedical Scientist Training Officer	3	t
1343	131	Technician	3	t
1344	131	Locum Associate Practitioner	3	t
1345	131	Biomedical Scientist Specialist	3	t
1346	131	Science Technician	3	t
1347	131	Haemostasis Product Specialist	3	t
1348	131	Student	3	t
1349	131	Support Specialist	3	t
1350	131	Microbiologist	3	t
1351	131	Research Biomedical Scientist	3	t
1352	131	BMS 2	3	t
1353	131	Biomedical Scientist Team Lead	3	t
1354	131	Biomedical Scientist Team Manager	3	t
1355	131	Team Leader	3	t
1356	131	Clinical Research Associate	3	t
1357	131	Scientific Officer	3	t
1358	131	IT Manager	3	t
1359	131	Sales Assistant	3	t
1360	133	Project Engineer	194	t
1361	133	Design Engineer	149	t
1362	133	Engineer	142	t
1363	133	Mechanical/Design Engineer	137	t
1364	133	Project Manager	88	t
1365	133	Director	80	t
1366	133	Principal Mechanical Engineer	74	t
1367	133	Engineering Manager	47	t
1368	133	IT Manager	37	t
1369	133	Mechanical Project Engineer	33	t
1370	133	Principal Engineer	33	t
1371	133	Production Engineer	28	t
1372	133	Consultant	25	t
1373	133	Graduate Engineer	25	t
1374	133	Development Engineer	23	t
1375	133	Software Developer	22	t
1376	133	Maintenance Engineer	22	t
1377	133	Managing Director	22	t
1378	133	Building Services Engineer	21	t
1379	133	Mechanical Fitter	20	t
1380	133	Mechanic	18	t
1381	133	Stress Engineer	16	t
1382	133	Manufacturing Engineer	16	t
1383	133	Owner	13	t
1384	133	Rotating Equipment Engineer	13	t
1385	133	PhD Researcher	12	t
1386	133	Technical Manager	12	t
1387	133	Team Leader	12	t
1388	133	Operations Manager	12	t
1389	133	Commissioning Engineer	12	t
1390	133	Sales Engineer	12	t
1391	133	Researcher	12	t
1392	133	Product Manager	12	t
1393	133	Service Engineer	12	t
1394	133	Graduate Mechanical Engineer	11	t
1395	133	Research Engineer	11	t
1396	133	Research Assistant	11	t
1397	133	Mechanical Technician	11	t
1398	133	Design Manager	11	t
1399	133	Application Engineer	11	t
1400	133	Process Engineer	11	t
1401	133	Mechanical Designer	10	t
1402	133	Reliability Engineer	10	t
1403	133	Supervisor	10	t
1404	133	Contracts Manager	10	t
1405	133	Engineer Surveyor	10	t
1406	133	Technician	9	t
1407	133	Student	9	t
1408	133	Designer	9	t
1409	133	PhD student	9	t
1410	134	Engineer	109	t
1411	134	Service Manager	98	t
1412	134	Field Service Engineer	95	t
1413	134	IT Manager	89	t
1414	134	Director	53	t
1415	134	Owner	48	t
1416	134	Sales Engineer	41	t
1417	134	Project Manager	33	t
1418	134	Service Technician	30	t
1419	134	Project Engineer	29	t
1420	134	Service Supervisor	29	t
1421	134	Maintenance Engineer	28	t
1422	134	Sales Manager	24	t
1423	134	Commissioning Engineer	22	t
1424	134	Managing Director	22	t
1425	134	Technician	19	t
1426	134	Team Leader	18	t
1427	134	Field Engineer	18	t
1428	134	Installation Engineer	18	t
1429	134	Technical Manager	18	t
1430	134	IT Consultant	17	t
1431	134	Operations Manager	16	t
1432	134	Electrical Engineer	15	t
1433	134	Mechanical Technician	14	t
1434	134	Account Manager	13	t
1435	134	Engineering Manager	13	t
1436	134	Area Sales Manager	12	t
1437	134	Electronics Engineer	12	t
1438	134	Mechanic	12	t
1439	134	Electrician	11	t
1440	134	Network Engineer	11	t
1441	134	Refrigeration Engineer	10	t
1442	134	Service/Commissioning Engineer	10	t
1443	134	Software Developer	10	t
1444	134	Application Engineer	10	t
1445	134	Business Development Manager	10	t
1446	134	Mechanical Engineer	10	t
1447	134	Proprietor	10	t
1448	134	Development Engineer	10	t
1449	134	IT Service Manager	9	t
1450	134	Maintenance Manager	9	t
1451	134	Production Engineer	9	t
1452	134	Supervisor	8	t
1453	134	Consultant	8	t
1454	134	Customer Service Engineer	8	t
1455	134	Field Service Technician	8	t
1456	134	Service	8	t
1457	134	Test Analyst	8	t
1458	134	Site Engineer	8	t
1459	134	Sales Representative	7	t
\.


--
-- Name: next_title_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geektalent
--

SELECT pg_catalog.setval('next_title_id_seq', 1459, true);


--
-- Data for Name: previous_title; Type: TABLE DATA; Schema: public; Owner: geektalent
--

COPY previous_title (id, career_id, previous_title, count, visible) FROM stdin;
1	1	Software Developer	58	t
2	1	Business Analyst	56	t
3	1	IT Manager	50	t
4	1	Management Consultant	47	t
5	1	IT Consultant	45	t
6	1	Project Coordinator	35	t
7	1	Director	26	t
8	1	Test Analyst	20	t
9	1	IT Service Manager	20	t
10	1	Manager	13	t
11	1	Web Developer	10	t
12	1	PMO Manager	10	t
13	1	Account Manager	10	t
14	1	Product Manager	10	t
15	1	Managing Director	8	t
16	1	Operations Manager	8	t
17	1	PMO Lead	7	t
18	1	Project Lead	7	t
19	1	Office Manager	7	t
20	1	Project Leader	6	t
21	1	Project Support Officer	6	t
22	1	Network Engineer	6	t
23	1	Data Analyst	6	t
24	1	Transition Manager	6	t
25	1	Service Desk Manager	5	t
26	1	Implementation Manager	5	t
27	1	Project Manager	5	t
28	1	Project Analyst	5	t
29	1	Owner	5	t
30	1	Team Manager	5	t
31	1	Portfolio Manager	5	t
32	2	Software Developer	90	t
33	2	IT Consultant	62	t
34	2	Project Manager	58	t
35	2	Business Analyst	37	t
36	2	Account Manager	34	t
37	2	Director	25	t
38	2	IT Manager	24	t
39	2	Sales Executive	16	t
40	2	Business Development Executive	15	t
41	2	Web Developer	14	t
42	2	Managing Director	12	t
43	2	Test Analyst	12	t
44	2	Manager	11	t
45	2	Recruitment Consultant	11	t
46	2	Sales Manager	10	t
47	2	Data Analyst	10	t
48	2	Database Administrator	10	t
49	2	Operations Manager	9	t
50	2	Team Leader	8	t
51	2	Consultant	7	t
52	2	Vice President	6	t
53	2	Account Executive	6	t
54	2	Marketing Manager	6	t
55	2	Sales Consultant	6	t
56	2	Founder	6	t
57	2	Business Development	5	t
58	3	IT Consultant	136	t
59	3	Software Developer	126	t
60	3	Project Manager	82	t
61	3	IT Service Manager	65	t
62	3	Network Engineer	54	t
63	3	Business Analyst	54	t
64	3	Test Analyst	35	t
65	3	Sales Assistant	34	t
66	3	Director	31	t
67	3	Data Analyst	29	t
68	3	Team Leader	27	t
69	3	Manager	22	t
70	3	Administrator	21	t
71	3	Management Consultant	20	t
72	3	Project Engineer	20	t
73	3	Engineer	19	t
74	3	Customer Service Representative	19	t
75	3	Assistant Manager	18	t
76	3	Customer Service Advisor	17	t
77	3	Field Service Engineer	16	t
78	3	Web Developer	15	t
79	3	Account Manager	15	t
80	3	Administrative Assistant	15	t
81	3	Computer Operator	15	t
82	3	Sales Advisor	14	t
83	3	Helpdesk Analyst	13	t
84	3	IT Assistant	13	t
85	3	Managing Director	12	t
86	3	Customer Service	11	t
87	3	Technical Manager	11	t
88	3	Desktop Support	11	t
89	3	Operations Analyst	10	t
90	3	Owner	10	t
91	3	Research Assistant	10	t
92	3	Work Experience	10	t
93	3	Design Engineer	9	t
94	3	Application Support	9	t
95	3	Team Manager	9	t
96	3	Consultant	9	t
97	3	Sales Executive	9	t
98	3	Operations Manager	9	t
99	3	Operations	9	t
100	3	Executive Assistant	8	t
101	3	Developer	8	t
102	3	Office Administrator	8	t
103	3	Office Manager	8	t
104	3	IT Coordinator	8	t
105	3	Founder	8	t
106	3	Installation Engineer	8	t
107	3	2nd Line Support	7	t
108	4	Software Developer	243	t
109	4	IT Manager	190	t
110	4	Management Consultant	64	t
111	4	Business Analyst	55	t
112	4	Test Analyst	51	t
113	4	Project Manager	50	t
114	4	Director	28	t
115	4	Consultant	26	t
116	4	Network Engineer	24	t
117	4	Data Analyst	23	t
118	4	Account Manager	22	t
119	4	IT Service Manager	21	t
120	4	Developer	20	t
121	4	Recruitment Consultant	18	t
122	4	Database Administrator	15	t
123	4	Manager	14	t
124	4	Customer Service Representative	14	t
125	4	Managing Director	13	t
126	4	Vice President	12	t
127	4	Architect	12	t
128	4	Engineer	11	t
129	4	Business Development Manager	10	t
130	4	Web Developer	10	t
131	4	Project Coordinator	9	t
132	4	Technical Director	9	t
133	4	Project Engineer	8	t
134	4	Programme Manager	7	t
135	4	Operations Manager	7	t
136	4	Research Assistant	7	t
137	4	Designer	7	t
138	4	Application Support	7	t
139	4	Assistant Manager	7	t
140	4	Infrastructure Architect	7	t
141	4	Recruiter	7	t
142	4	Customer Service	6	t
143	4	Technical Manager	6	t
144	4	Co-Founder	6	t
145	4	Development Manager	6	t
146	4	Team Leader	6	t
147	4	Solution Designer	5	t
148	4	Contractor	5	t
149	4	HR Administrator	5	t
150	4	Systems Consultant	5	t
151	4	Project Leader	5	t
152	4	Administrator	5	t
153	4	Student Ambassador	5	t
154	4	Desktop Support Analyst	5	t
155	4	Principal Consultant	5	t
156	4	Owner	5	t
157	4	IT Trainer	5	t
158	5	Software Developer	30	t
159	5	IT Consultant	28	t
160	5	Project Manager	24	t
161	5	Test Analyst	23	t
162	5	Management Consultant	22	t
163	5	IT Manager	15	t
164	5	Data Analyst	13	t
165	5	Business Analyst	7	t
166	5	Director	5	t
167	6	IT Manager	57	t
168	6	Project Manager	38	t
169	6	IT Consultant	20	t
170	6	Management Consultant	15	t
171	6	Manager	11	t
172	6	Account Manager	10	t
173	6	Operations Manager	8	t
174	6	Software Developer	8	t
175	6	Network Engineer	7	t
176	6	Business Analyst	5	t
177	6	Service Desk Team Leader	5	t
178	6	Team Leader	5	t
179	7	IT Manager	65	t
180	7	IT Consultant	12	t
181	7	Project Manager	7	t
182	7	Software Developer	5	t
183	8	Web Developer	151	t
184	8	IT Consultant	112	t
185	8	IT Manager	84	t
186	8	Management Consultant	49	t
187	8	Software Developer	48	t
188	8	Test Analyst	48	t
189	8	Project Manager	41	t
190	8	Data Analyst	34	t
191	8	Director	31	t
192	8	Business Analyst	24	t
193	8	Engineer	16	t
194	8	Consultant	15	t
195	8	Co-Founder	14	t
196	8	Network Engineer	13	t
197	8	Team Leader	13	t
198	8	Student	12	t
199	8	Database Administrator	12	t
200	8	Sales Assistant	11	t
201	8	Web Designer	11	t
202	8	Research Assistant	10	t
203	8	Summer Analyst	10	t
204	8	Managing Director	9	t
205	8	Researcher	9	t
206	8	Teaching Assistant	9	t
207	8	Research Associate	9	t
208	8	Graduate Developer	9	t
209	8	Summer Intern	9	t
210	8	Founder	9	t
211	8	Head of Technology	8	t
212	8	C Developer	8	t
213	8	Internship	8	t
214	8	Work Experience	8	t
215	8	Database Developer	8	t
216	8	Student Ambassador	7	t
217	8	Research Fellow	7	t
218	8	Java Consultant	7	t
219	8	Frontend Developer	7	t
220	8	Contract Developer	7	t
221	8	Technical Developer	6	t
222	8	Programme Manager	6	t
223	8	Manager	6	t
224	8	Volunteer	6	t
225	8	Research Engineer	6	t
226	8	Producer	5	t
227	8	Support Developer	5	t
228	8	Technical Team Leader	5	t
229	8	Administrator	5	t
230	8	Game Developer	5	t
231	8	Graduate Trainee	5	t
232	9	Summer Analyst	101	t
233	9	Summer Intern	42	t
234	9	Software Developer	28	t
235	9	Business Analyst	26	t
236	9	Consultant	25	t
237	9	Research Analyst	21	t
238	9	IT Consultant	18	t
239	9	Researcher	17	t
240	9	Research Assistant	16	t
241	9	Manager	13	t
242	9	Assistant Manager	12	t
243	9	Internship	10	t
244	9	IT Manager	10	t
245	9	Sales Assistant	10	t
246	9	Work Experience	9	t
247	9	Management Consultant	8	t
248	9	Account Executive	8	t
249	9	Director	7	t
250	9	Investment Analyst	7	t
251	9	Graduate	7	t
252	9	Marketing Analyst	7	t
253	9	Investment Banking Summer Analyst	6	t
254	9	Financial Data Analyst	6	t
255	9	Student	5	t
256	9	Administrator	5	t
257	9	Pricing Analyst	5	t
258	9	Sales Analyst	5	t
259	9	Spring Intern	5	t
260	9	Project Manager	5	t
261	10	Software Developer	39	t
262	10	IT Manager	23	t
263	10	IT Consultant	20	t
264	10	Business Analyst	19	t
265	10	Management Consultant	13	t
266	10	Test Team Leader	11	t
267	10	System Tester	10	t
268	10	Director	9	t
269	10	Project Manager	8	t
270	10	QA Consultant	7	t
271	10	Team Leader	7	t
272	10	Consultant	6	t
273	10	System Test Analyst	5	t
274	10	Data Analyst	5	t
275	10	Manager	5	t
276	10	Sales Assistant	5	t
277	11	Software Developer	112	t
278	11	Web Designer	29	t
279	11	IT Manager	19	t
280	11	IT Consultant	10	t
281	11	Director	9	t
282	11	Founder	7	t
283	11	Developer	6	t
284	12	Graphic Designer	15	t
285	12	Web Developer	13	t
286	12	Designer	7	t
287	12	Software Developer	5	t
288	13	Software Developer	21	t
289	13	IT Manager	12	t
290	13	IT Consultant	9	t
291	13	SQL Server DBA	6	t
292	14	Project Manager	23	t
293	14	Marketing Manager	8	t
294	14	Digital Producer	6	t
295	14	Marketing Intern	5	t
296	15	Character Animator	7	t
297	15	Graphic Designer	6	t
298	15	Compositor	5	t
299	16	Network Engineer	8	t
300	19	Software Developer	6	t
527	41	Sales Executive	6	t
528	42	Account Manager	22	t
529	42	Sales Manager	20	t
530	42	Sales Assistant	19	t
531	42	Recruitment Consultant	12	t
532	42	Director	12	t
533	42	Sales	11	t
534	42	Sales Advisor	11	t
535	42	Account Executive	11	t
536	42	Assistant Manager	10	t
537	42	Sales Coordinator	9	t
538	42	Business Development Manager	8	t
539	42	Sales Consultant	8	t
540	42	Business Manager	7	t
541	42	Business Development Executive	7	t
542	42	Parts Advisor	6	t
543	42	Sales Associate	6	t
544	42	Event Coordinator	5	t
545	42	Customer Service Representative	5	t
546	42	Telesales Executive	5	t
547	42	Service Advisor	5	t
548	42	Sales Representative	5	t
549	42	Supervisor	5	t
550	44	Sales Executive	75	t
551	44	Account Manager	52	t
552	44	Business Development Manager	36	t
553	44	Sales	21	t
554	44	Director	15	t
555	44	Sales Director	14	t
556	44	Business Manager	13	t
557	44	Sales Consultant	11	t
558	44	Sales Assistant	11	t
559	44	Consultant	10	t
560	44	Managing Director	10	t
561	44	Sales & Marketing Manager	9	t
562	44	Sales Engineer	9	t
563	44	Account Director	9	t
564	44	Assistant Manager	9	t
565	44	Team Leader	8	t
566	44	General Manager	8	t
567	44	National Account Manager	7	t
568	44	Key Account Manager	7	t
569	44	Manager	7	t
570	44	Marketing Manager	7	t
571	44	Sales Account Manager	7	t
572	44	Project Manager	7	t
573	44	Sales Representative	7	t
574	44	Operations Manager	6	t
575	44	Sales Advisor	6	t
576	44	Regional Sales Manager	6	t
577	44	Business Development	6	t
578	44	UK Sales Manager	6	t
579	44	Area Sales Manager	6	t
580	44	Store Manager	5	t
581	44	Customer Service Manager	5	t
582	44	International Sales Manager	5	t
583	44	Account Executive	5	t
584	44	Business Development Director	5	t
585	45	Sales Executive	16	t
586	45	Manager	11	t
587	45	Project Manager	11	t
588	45	Sales Manager	11	t
589	45	Recruitment Consultant	10	t
590	45	Business Development Manager	10	t
591	45	Consultant	10	t
592	45	Account Manager	10	t
593	45	Director	8	t
594	45	Operations Manager	7	t
595	45	Assistant Manager	6	t
596	45	Branch Manager	6	t
597	45	Product Manager	5	t
598	46	Service Manager	5	t
599	47	Graduate Engineer	20	t
600	47	Design Engineer	18	t
601	47	Project Manager	16	t
602	47	Engineer	16	t
603	47	IT Manager	13	t
604	47	Mechanical/Design Engineer	7	t
605	47	Director	6	t
606	47	Site Engineer	5	t
607	50	Assistant Manager	49	t
608	50	Operations Manager	38	t
609	50	Assistant General Manager	25	t
610	50	Deputy General Manager	23	t
611	50	Sales Manager	22	t
612	50	Manager	21	t
613	50	Director	20	t
614	50	Deputy Manager	12	t
615	50	Store Manager	12	t
616	50	Managing Director	11	t
617	50	Project Manager	10	t
618	50	Business Development Manager	9	t
619	50	Bar Manager	8	t
620	50	Retail Manager	8	t
621	50	Restaurant Manager	8	t
622	50	Sales Executive	8	t
623	50	Operations Director	7	t
624	50	Food and Beverage Manager	7	t
625	50	Account Manager	7	t
626	50	Sales Director	6	t
627	50	Product Manager	6	t
628	50	Bar Supervisor	5	t
629	50	Branch Manager	5	t
630	50	Hotel Manager	5	t
631	53	Sales Manager	48	t
632	53	Director	18	t
633	53	Business Development Manager	16	t
634	53	Managing Director	9	t
635	53	Account Manager	9	t
636	53	Sales Executive	8	t
637	53	National Sales Manager	7	t
638	53	Sales	7	t
639	53	Commercial Director	7	t
640	53	Business Development Director	5	t
641	54	Design Engineer	6	t
642	55	Vehicle Technician	5	t
643	57	Assistant Buyer	56	t
644	57	Project Manager	6	t
645	57	Sales Assistant	6	t
646	57	Merchandiser	5	t
647	57	Buying Assistant	5	t
654	78	Healthcare Assistant	16	t
655	79	Sales Assistant	14	t
656	79	Care Worker	9	t
657	79	Student Ambassador	5	t
658	80	Healthcare Assistant	8	t
659	80	Healthcare Administrator	5	t
660	81	Housing Officer	18	t
661	81	Nurse	13	t
662	81	Research Assistant	12	t
663	81	Research Fellow	8	t
664	81	Lecturer	8	t
665	81	Clinical Research Associate	8	t
666	81	Data Manager	6	t
667	81	Director	6	t
668	81	General Practitioner (GP)	5	t
669	82	Doctor	5	t
670	88	Nurse	7	t
671	90	Administrative Assistant	6	t
672	90	Receptionist	6	t
673	94	Pre-Reg Optometrist	6	t
674	95	Pre-registration Pharmacist	10	t
675	95	Pharmacy Manager	5	t
676	96	Nurse	7	t
677	97	Financial Analyst	100	t
678	97	Audit Manager	45	t
680	97	Sales Assistant	28	t
681	97	Administrative Assistant	19	t
682	97	Manager	18	t
683	97	Account Manager	16	t
684	97	Accounts Assistant	16	t
685	97	Management Accountant	16	t
686	97	Administrator	15	t
687	97	Assistant Accountant	14	t
688	97	Assistant Manager	14	t
689	97	Sales Advisor	11	t
690	97	Receptionist	11	t
691	97	Office Manager	11	t
692	97	Financial Accountant	10	t
693	97	Team Leader	9	t
694	97	Student	9	t
695	97	Business Analyst	8	t
696	97	Director	8	t
697	97	Accounts Junior	8	t
698	97	Financial Administrator	8	t
699	97	Customer Service	8	t
700	97	Work Experience	8	t
701	97	Internship	7	t
702	97	Office Administrator	7	t
703	97	Sales Consultant	7	t
704	97	Purchase Ledger Assistant	7	t
705	97	Sales Associate	6	t
706	97	Data Analyst	6	t
707	97	Office Assistant	6	t
708	97	Owner	6	t
709	97	Operations Manager	6	t
710	97	Assistant Financial Controller	6	t
711	97	Sales Ledger Clerk	5	t
712	97	Finance Manager	5	t
713	97	Waiter	5	t
714	97	Duty Manager	5	t
715	97	Accounts Administrator	5	t
716	97	Account Executive	5	t
717	97	Supervisor	5	t
718	98	Account Manager	50	t
719	98	Director	33	t
721	98	Business Development Manager	27	t
722	98	Data Analyst	18	t
723	98	Sales Manager	16	t
724	98	Consultant	16	t
725	98	Project Manager	15	t
726	98	Personal Banker	14	t
727	98	Manager	14	t
728	98	Team Leader	12	t
729	98	Sales Executive	12	t
730	98	Financial Advisor	11	t
731	98	Risk Analyst	11	t
732	98	Account Executive	10	t
733	98	Accountant	10	t
734	98	Audit Manager	10	t
735	98	Bank Manager	10	t
736	98	Business Manager	10	t
679	97	Customer Advisor	33	t
720	98	Customer Advisor	23	t
738	98	Client Manager	9	t
739	98	Business Analyst	9	t
740	98	Portfolio Manager	9	t
741	98	Operations Manager	9	t
742	98	Commercial Manager	8	t
743	98	Managing Director	8	t
744	98	Assistant Manager	8	t
745	98	Marketing Manager	7	t
746	98	Assistant Director	7	t
747	98	IT Manager	7	t
748	98	Business Development	7	t
749	98	Recruitment Consultant	6	t
750	98	Business Development Executive	5	t
751	98	Business Banking Manager	5	t
752	98	Sales Consultant	5	t
754	99	Audit Manager	155	t
759	99	Director	32	t
760	99	Management Accountant	17	t
762	99	Consultant	15	t
767	99	Chief Executive	10	t
768	99	Managing Director	10	t
769	99	Business Development Manager	10	t
770	99	Relationship Manager	10	t
771	99	Assistant Financial Accountant	9	t
774	99	Group Financial Accountant	8	t
775	99	Audit Supervisor	7	t
777	99	Sales Consultant	7	t
778	99	Student	7	t
779	99	Financial Accountant	7	t
780	99	Supervisor	7	t
781	99	Client Accountant	7	t
783	99	Finance Graduate	6	t
784	99	Business Advisor	6	t
786	99	Audit Assistant Manager	6	t
788	99	Commercial Accountant	5	t
789	99	Finance Manager	5	t
790	99	Financial Controller	5	t
792	99	Sales	5	t
795	99	Financial Reporting Accountant	5	t
798	99	Management Consultant	5	t
800	99	Commercial Manager	5	t
801	100	Data Analyst	58	t
802	100	Director	41	t
803	100	Project Manager	19	t
804	100	Manager	16	t
805	100	Investment Banker	16	t
806	100	Vice President	13	t
807	100	Managing Director	11	t
808	100	Financial Analyst	11	t
809	100	Executive Director	9	t
810	100	Consultant	9	t
811	100	Risk Analyst	8	t
812	100	Non Executive Director	7	t
813	100	Surveyor	7	t
814	100	Partner	6	t
815	100	Asset Manager	6	t
816	100	Client Manager	5	t
817	100	Principal	5	t
818	100	Assistant Director	5	t
819	100	Development Manager	5	t
821	101	Mortgage Advisor	12	t
822	101	Director	12	t
823	101	Accountant	9	t
824	101	Consultant	8	t
825	101	Relationship Manager	8	t
826	101	Broker Consultant	7	t
827	101	Business Analyst	6	t
828	101	Business Development Manager	6	t
829	101	Audit Manager	6	t
830	101	Account Manager	5	t
831	101	Advisor	5	t
832	101	Personal Banker	5	t
833	101	Banker	5	t
834	101	Assistant Manager	5	t
835	101	Partner	5	t
836	101	Risk Manager	5	t
837	102	Risk Analyst	25	t
737	98	Financial Analyst	11	t
753	99	Accountant	283	t
820	101	Financial Analyst	19	t
838	102	Manager	24	t
839	102	Audit Manager	16	t
841	102	Director	13	t
842	102	Data Analyst	11	t
843	102	Consultant	11	t
844	102	Business Analyst	8	t
845	102	Vice President	8	t
846	102	Financial Analyst	7	t
847	102	Operations Manager	7	t
848	102	Project Manager	6	t
849	102	Market Risk Analyst	5	t
850	102	Business Manager	5	t
863	104	Accountant	23	t
864	104	Tax Assistant	18	t
865	104	Assistant Manager	9	t
866	104	Summer Intern	8	t
867	104	Manager	8	t
868	104	Audit Manager	7	t
869	104	Director	6	t
870	105	Summer Analyst	121	t
871	105	Summer Intern	50	t
872	105	Consultant	36	t
873	105	Business Analyst	33	t
874	105	Software Developer	30	t
875	105	Researcher	20	t
876	105	Research Assistant	18	t
877	105	Manager	18	t
878	105	Accountant	17	t
879	105	Research Analyst	16	t
880	105	Internship	16	t
881	105	Investment Banker	16	t
882	105	Assistant Manager	15	t
883	105	Risk Analyst	14	t
884	105	IT Consultant	13	t
886	105	Work Experience	12	t
888	105	Sales Assistant	10	t
889	105	M&A Analyst	10	t
890	105	Marketing Analyst	9	t
891	105	Director	9	t
892	105	Account Executive	9	t
893	105	Spring Intern	9	t
894	105	IT Manager	8	t
895	105	Administrative Assistant	8	t
896	105	Administrator	7	t
897	105	IBD Summer Analyst	7	t
898	105	Graduate	7	t
899	105	Graduate Analyst	6	t
900	105	Student	6	t
901	105	Project Manager	6	t
902	105	Graduate Trainee	6	t
903	105	Statistical Analyst	5	t
904	105	Co-Founder	5	t
905	105	Sales Associate	5	t
906	105	Student Ambassador	5	t
907	105	Private Equity Intern	5	t
908	105	President	5	t
909	105	Marketing Assistant	5	t
910	105	Pricing Analyst	5	t
911	105	Sales Analyst	5	t
912	105	Audit Manager	5	t
913	105	Event Manager	5	t
914	106	Data Analyst	23	t
915	106	Relationship Manager	10	t
918	106	Business Analyst	7	t
919	106	Consultant	7	t
920	106	Accountant	6	t
921	106	Summer Intern	5	t
922	106	Summer Analyst	5	t
923	107	Financial Advisor	12	t
925	107	Personal Banker	8	t
926	107	Customer Account Manager	5	t
927	108	Data Analyst	27	t
928	108	Summer Analyst	18	t
929	108	Summer Intern	9	t
930	108	Director	7	t
931	108	Work Experience	7	t
932	108	Spring Intern	7	t
933	108	IBD Summer Analyst	6	t
934	108	Managing Director	6	t
935	108	M&A Analyst	6	t
936	108	Internship	5	t
940	109	Assistant Manager	25	t
840	102	Compliance Analyst	7	t
924	107	Customer Advisor	12	t
938	109	Accountant	138	t
939	109	Financial Analyst	63	t
887	105	Financial Analyst	14	t
917	106	Financial Analyst	12	t
937	108	Financial Analyst	6	t
941	109	Manager	24	t
942	109	Auditor	16	t
943	109	Audit Supervisor	10	t
944	109	Consultant	10	t
946	109	Tax Assistant	8	t
948	109	Summer Intern	7	t
949	109	Chief Executive	6	t
950	109	Business Analyst	6	t
951	109	Data Analyst	6	t
952	109	Sales Assistant	5	t
953	109	Internal Audit	5	t
954	109	Management Accountant	5	t
956	110	Relationship Manager	9	t
957	110	Personal Banker	7	t
958	110	Assistant Manager	6	t
959	110	Financial Advisor	5	t
960	110	Mortgage Advisor	5	t
961	110	Area Manager	5	t
962	111	Project Manager	58	t
964	111	Data Analyst	52	t
965	111	IT Consultant	46	t
966	111	Software Developer	42	t
967	111	Consultant	37	t
968	111	Test Analyst	23	t
969	111	IT Manager	23	t
970	111	Accountant	22	t
971	111	Change Analyst	21	t
973	111	Director	16	t
975	111	Manager	15	t
976	111	Management Consultant	14	t
977	111	Risk Analyst	11	t
978	111	Management Accountant	10	t
979	111	Production Controller	8	t
980	111	Business Process Analyst	8	t
981	111	Team Leader	7	t
982	111	Business Manager	7	t
983	111	Business Consultant	6	t
984	111	Administrator	6	t
985	111	Vice President	6	t
986	111	Summer Analyst	6	t
987	111	Sales Assistant	6	t
988	111	Product Manager	6	t
989	111	Project Coordinator	6	t
990	111	BA	6	t
991	111	Summer Intern	6	t
992	111	Operations Manager	5	t
993	111	Relationship Manager	5	t
994	111	Business Development Manager	5	t
995	111	Assistant Manager	5	t
996	112	Summer Intern	12	t
997	112	Accountant	12	t
998	112	Tax Manager	11	t
1000	114	Relationship Manager	6	t
1001	114	Financial Advisor	5	t
1002	115	Director	9	t
1003	115	Data Analyst	7	t
1005	117	Secretary	23	t
1006	117	Office Manager	18	t
1007	117	Team Assistant	12	t
1008	117	Receptionist	12	t
1009	117	Administrator	11	t
1010	117	Team Secretary	10	t
1011	117	Administrative Assistant	9	t
1012	117	Executive Assistant	8	t
1013	117	Sales Assistant	8	t
1014	117	Assistant Manager	6	t
1015	117	Production Assistant	5	t
1016	117	Office Administrator	5	t
1017	118	Account Manager	20	t
1018	118	Accountant	12	t
1019	118	Relationship Manager	10	t
1020	118	Project Manager	9	t
1021	118	Manager	8	t
1022	118	Financial Advisor	7	t
1023	118	Director	7	t
1024	118	Business Development Manager	7	t
1025	118	Client Executive	7	t
1027	118	Data Analyst	6	t
1028	118	Consultant	6	t
1030	118	Operations Manager	5	t
1031	118	Assistant Manager	5	t
1032	118	Account Executive	5	t
1033	118	Financial Analyst	5	t
1034	119	Project Manager	82	t
1035	119	Business Analyst	32	t
1036	119	Manager	14	t
1037	119	Director	9	t
1038	119	Data Analyst	8	t
1040	119	Consultant	6	t
1042	119	IT Manager	5	t
1043	119	Project Coordinator	5	t
955	110	Customer Advisor	14	t
1039	119	Financial Analyst	9	t
999	114	Customer Advisor	9	t
1004	116	Customer Advisor	33	t
1029	118	Audit Manager	5	t
963	111	Financial Analyst	60	t
1044	119	Audit Manager	5	t
1045	121	Accountant	7	t
1046	122	Accountant	10	t
761	99	Customer Advisor	13	t
945	109	Director	6	t
947	109	Account Manager	6	t
974	111	Audit Manager	15	t
1048	111	Customer Advisor	12	t
755	99	Manager	56	t
756	99	Business Analyst	44	t
757	99	Assistant Manager	37	t
758	99	Data Analyst	44	t
763	99	Risk Analyst	15	t
764	99	Financial Advisor	12	t
765	99	Account Executive	13	t
766	99	Project Manager	14	t
772	99	Summer Analyst	9	t
773	99	Team Leader	9	t
776	99	Sales Assistant	8	t
782	99	Business Manager	8	t
785	99	Sales Executive	7	t
787	99	Financial Administrator	6	t
791	99	Summer Intern	5	t
793	99	Customer Service	6	t
794	99	Sales Advisor	6	t
796	99	Work Experience	6	t
797	99	Reporting Analyst	6	t
799	99	Computer Operator	6	t
1049	99	IT Manager	5	t
1050	99	Portfolio Manager	5	t
1051	124	Sales Assistant	13	t
1052	124	Administrator	9	t
1053	124	Receptionist	9	t
1054	124	Sales Advisor	8	t
1055	124	Accountant	7	t
1056	124	Customer Service Assistant	7	t
1057	124	Customer Service Representative	6	t
1058	124	Customer Service Advisor	5	t
1059	126	IT Manager	31	t
1060	126	Software Developer	25	t
1061	126	Radiographer	16	t
1062	126	IT Consultant	16	t
1063	126	Research Assistant	7	t
1064	126	Product Specialist	7	t
1065	126	Biomedical Scientist	7	t
1066	126	Project Manager	6	t
1067	126	Scientist	5	t
1068	126	Business Analyst	4	t
1069	126	Postdoctoral Research Fellow	4	t
1070	126	Application Support Specialist	4	t
1071	126	Business Systems Analyst	3	t
1072	126	Database Administrator	3	t
1073	126	Data Analyst	3	t
1074	126	Business Development Manager	3	t
1075	126	Product Manager	3	t
1076	126	Application Support Manager	3	t
1077	126	Systems Support Officer	3	t
1078	126	Account Manager	3	t
1079	126	Life Science Sales Executive	2	t
1080	126	Network Engineer	2	t
1081	126	Service Desk Team Leader	2	t
1082	126	Geologist	2	t
1083	126	Consultant	2	t
1084	126	Medical Physicist	2	t
1085	126	Software Development Specialist	2	t
1086	126	Postdoctoral Research Associate	2	t
1087	126	Systems Manager	2	t
1088	126	Application Support	2	t
1089	126	Lecturer	2	t
1090	126	Technical Assistant	2	t
1091	126	Technician	2	t
1092	126	Graduate Application Specialist	2	t
1093	126	Systems Consultant	2	t
1094	126	Programmer Analyst	2	t
1095	126	Microbiologist	2	t
1096	126	Manager	2	t
1097	126	Clinical Sonographer	2	t
1098	126	Sales Engineer	2	t
1099	126	Data Quality Specialist	2	t
1100	126	Food Technologist	2	t
1101	126	Laboratory analyst/SPE section leader	2	t
1102	126	Director	2	t
1103	126	e-Procurement	2	t
1104	126	Specialist Receptionist	2	t
1105	126	PACS & IT Project Manager	2	t
1106	126	Oncology Application and Product Specialist	2	t
1107	126	Researcher	2	t
1108	126	Change Control Analyst	2	t
1109	127	Laboratory Technician	33	t
1110	127	Research Assistant	12	t
1111	127	Microbiology Technician	8	t
1112	127	Microbiology Analyst	8	t
1113	127	Lab Technician	7	t
1114	127	Student	6	t
1115	127	PhD student	5	t
1116	127	Technical Officer	5	t
1117	127	Scientist	5	t
1118	127	QC Microbiologist	4	t
1119	127	Data Analyst	4	t
1120	127	Research Scientist	3	t
1121	127	Laboratory Assistant	3	t
1122	127	Laboratory Analyst	3	t
1123	127	Biomedical Scientist	3	t
1124	127	Quality Control Technician	3	t
1125	127	Medical Laboratory Scientific Officer	3	t
1126	127	Research Technician	3	t
1127	127	Lab Manager	3	t
1128	127	Quality Assurance Officer	3	t
1129	127	Scientific Officer	3	t
1130	127	Microbiolgist	3	t
1131	127	Quality Control	2	t
1132	127	QA Microbiologist	2	t
1133	127	Care Worker	2	t
1134	127	Science Lab Technician	2	t
1135	127	Science Teacher	2	t
1136	127	E-commerce Entrepeneur	2	t
1137	127	General Assistant	2	t
1138	127	Lecturer	2	t
1139	127	Contract Microbiologist	2	t
1140	127	Demonstrator and Lecturer	2	t
1141	127	Postgraduate Student	2	t
1142	127	Healthcare Assistant	2	t
1143	127	Assistantant Scientific Officer/Scientific Officer	2	t
1144	127	Microbiology Risk Assessment and Training Technical Assistant	2	t
1145	127	Medical Advisor	2	t
1146	127	Supervisor	2	t
1147	127	Placement Year with Dr Darren Flower	2	t
1148	127	Head of Innovation	2	t
1149	127	Medical Biology Student	2	t
1150	127	Assistant Forensic Scientist	2	t
1151	127	Research Microbiologist	2	t
1152	127	QC Specialist Microbiology	2	t
1153	127	Volunteer	2	t
1154	127	Postdoctoral Researcher	2	t
1155	127	Account Manager	2	t
1156	127	Sales Executive	2	t
1157	127	Quality Assurance Technician	2	t
1158	127	Bar Staff	2	t
1159	128	Research Scientist	191	t
1160	128	Research Associate	125	t
1161	128	Research Assistant	88	t
1162	128	PhD student	64	t
1163	128	Research Fellow	61	t
1164	128	Data Analyst	45	t
1165	128	Postdoctoral Fellow	43	t
1166	128	Post-doc	40	t
1167	128	Postdoctoral Research Associate	39	t
1168	128	Postdoc	38	t
1169	128	Chemist	36	t
1170	128	Laboratory Technician	35	t
1171	128	Postdoctoral Researcher	35	t
1172	128	Postdoctoral Research Fellow	34	t
1173	128	Researcher	29	t
1174	128	Industrial Placement Student	25	t
1175	128	Medicinal Chemist	25	t
1176	128	Post Doctoral Research Associate	25	t
1177	128	Analytical Chemist	25	t
1178	128	Post-doctoral researcher	24	t
1179	128	Postdoctoral Scientist	22	t
1180	128	Development Scientist	22	t
1181	128	Scientific Officer	20	t
1182	128	Principal Scientist	19	t
1183	128	Postdoctoral Research Scientist	19	t
1184	128	Formulation Scientist	19	t
1185	128	Research Technician	18	t
1186	128	Lecturer	17	t
1187	128	Technician	17	t
1188	128	Team Leader	16	t
1189	128	Technologist	14	t
1190	128	Industrial Trainee	14	t
1191	128	Analytical Scientist	14	t
1192	128	PhD	14	t
1193	128	Assistant Scientist	13	t
1194	128	IT Consultant	13	t
1195	128	Scientist II	13	t
1196	128	Consultant	13	t
1197	128	Research Chemist	13	t
1198	128	Development Chemist	13	t
1199	128	Project Manager	13	t
1200	128	R&D Scientist	12	t
1201	128	Biotechnologist	12	t
1202	128	Microbiologist	12	t
1203	128	IT Manager	12	t
1204	128	Post Doctoral Fellow	11	t
1205	128	Software Developer	10	t
1206	128	QC Analyst	10	t
1207	128	Post Doctoral Research Fellow	10	t
1208	128	Manager	9	t
1209	129	Research Assistant	133	t
1210	129	Research Associate	112	t
1211	129	Scientist	112	t
1212	129	PhD student	82	t
1213	129	Research Fellow	81	t
1214	129	Researcher	46	t
1215	129	Postdoctoral Researcher	44	t
1216	129	Postdoctoral Research Fellow	34	t
1217	129	Research Technician	31	t
1218	129	Postdoctoral Research Associate	29	t
1219	129	Lecturer	26	t
1220	129	Post-doctoral researcher	25	t
1221	129	Postdoctoral Fellow	25	t
1222	129	Laboratory Technician	24	t
1223	129	Software Developer	17	t
1224	129	Postdoc	17	t
1225	129	Post-doctoral Research Scientist	16	t
1226	129	Postdoctoral Research Scientist	16	t
1227	129	PhD	16	t
1228	129	Post Doctoral Fellow	16	t
1229	129	Post Doctoral Research Fellow	16	t
1230	129	Principal Scientist	13	t
1231	129	Research Chemist	13	t
1232	129	Post-doc	13	t
1233	129	Industrial Placement Student	12	t
1234	129	Research Engineer	12	t
1235	129	Teaching Assistant	12	t
1236	129	Student	11	t
1237	129	Microbiologist	11	t
1238	129	Visiting Researcher	11	t
1239	129	Post Doctoral Research Associate	11	t
1240	129	Engineer	10	t
1241	129	Internship	10	t
1242	129	Chemist	10	t
1243	129	Postdoctoral Scientist	9	t
1244	129	R&D Scientist	9	t
1245	129	Post Doctoral Research Assistant	9	t
1246	129	Post Doctoral Scientist	9	t
1247	129	Higher Scientific Officer	8	t
1248	129	Scientific Officer	8	t
1249	129	Sales Assistant	8	t
1250	129	PhD Researcher	8	t
1251	129	Consultant	8	t
1252	129	Analytical Chemist	8	t
1253	129	Product Manager	7	t
1254	129	Biomedical Scientist	7	t
1255	129	Research Officer	7	t
1256	129	Ph D student	7	t
1257	129	Technician	7	t
1258	129	Team Leader	7	t
1259	130	Laboratory Assistant	48	t
1260	130	Sales Assistant	35	t
1261	130	Research Assistant	34	t
1262	130	Healthcare Assistant	21	t
1263	130	Lab Technician	14	t
1264	130	Volunteer	14	t
1265	130	Technician	12	t
1266	130	Science Technician	12	t
1267	130	Microbiologist	12	t
1268	130	Student	11	t
1269	130	Waitress	9	t
1270	130	Geologist	9	t
1271	130	Microbiology Technician	9	t
1272	130	Scientist	9	t
1273	130	Data Analyst	9	t
1274	130	Analytical Chemist	9	t
1275	130	Pharmacy Assistant	8	t
1276	130	Receptionist	8	t
1277	130	Customer Service Assistant	8	t
1278	130	Warehouse Operative	8	t
1279	130	Laboratory Analyst	7	t
1280	130	Administrative Assistant	7	t
1281	130	Student Ambassador	7	t
1282	130	Engineer	7	t
1283	130	Quality Control Technician	7	t
1284	130	Team Leader	7	t
1285	130	Research Student	6	t
1286	130	QC Analyst	6	t
1287	130	Quality Control	6	t
1288	130	Sales Manager	6	t
1289	130	Bartender	6	t
1290	130	Production Technician	6	t
1291	130	Researcher	6	t
1292	130	Sales Associate	6	t
1293	130	PhD student	5	t
1294	130	Manager	5	t
1295	130	Biomedical Scientist	5	t
1296	130	Research Technician	5	t
1297	130	Sales Advisor	5	t
1298	130	Laboratory Supervisor	5	t
1299	130	Customer Service Advisor	5	t
1300	130	IT Manager	5	t
1301	130	General Assistant	4	t
1302	130	Project Engineer	4	t
1303	130	QC Technician	4	t
1304	130	R&D Technician	4	t
1305	130	Animal Technician	4	t
1306	130	Assistant Scientist	4	t
1307	130	Operations	4	t
1308	130	Support Worker	4	t
1309	131	Healthcare Assistant	89	t
1310	131	Locum Biomedical Scientist	17	t
1311	131	Research Assistant	14	t
1312	131	Medical Laboratory Scientist	12	t
1313	131	Laboratory Technician	12	t
1314	131	Medical Laboratory Technician	9	t
1315	131	Senior Practitioner	9	t
1316	131	Scientist	8	t
1317	131	Laboratory Assistant	7	t
1318	131	Doctor	7	t
1319	131	Microbiologist	7	t
1320	131	Healthcare Scientist	7	t
1321	131	Student Biomedical Scientist	6	t
1322	131	Medical Laboratory Scientific Officer	6	t
1323	131	Medical Technologist	6	t
1324	131	Medical Lab Assistant	6	t
1325	131	Sales Assistant	6	t
1326	131	MLSO	5	t
1327	131	Lecturer	5	t
1328	131	Research Scientist	5	t
1329	131	Student	5	t
1330	131	Biomedical Support Worker	5	t
1331	131	Sales Associate	5	t
1332	131	Medical Scientist	5	t
1333	131	BMS Band 6	4	t
1334	131	Scientific Officer	4	t
1335	131	PhD student	4	t
1336	131	Technical Officer	4	t
1337	131	Director	4	t
1338	131	Customer Service Assistant	4	t
1339	131	Healthcare Administrator	3	t
1340	131	Medical Technical Officer	3	t
1341	131	Laboratory Technologist	3	t
1342	131	First Aider	3	t
1343	131	Customer Service	3	t
1344	131	Assistant Scientific Officer	3	t
1345	131	Biomedical Scientist 1	3	t
1346	131	Deputy Manager	3	t
1347	131	Team Member	3	t
1348	131	BMS1	3	t
1349	131	Laboratory Analyst	3	t
1350	131	Trainee biomedical scientist/biomedical scientist	3	t
1351	131	Assistant Healthcare Scientist	3	t
1352	131	Junior B Medical Laboratory Scientific Officer	3	t
1353	131	Biomedical scientist trainee	3	t
1354	131	Software Developer	2	t
1355	131	Biomedical Assistant	2	t
1356	131	Forensic Scientist	2	t
1357	131	Public Relations Assistant	2	t
1358	131	Event Steward	2	t
1359	133	Design Engineer	177	t
1360	133	Engineer	153	t
1361	133	Project Engineer	148	t
1362	133	Mechanical/Design Engineer	144	t
1363	133	Graduate Mechanical Engineer	70	t
1364	133	Project Manager	50	t
1365	133	Graduate Engineer	45	t
1366	133	IT Manager	35	t
1367	133	Mechanical Designer	34	t
1368	133	Mechanical Technician	34	t
1369	133	Maintenance Engineer	25	t
1370	133	Student	24	t
1371	133	Production Engineer	24	t
1372	133	Director	23	t
1373	133	Mechanical Project Engineer	22	t
1374	133	Internship	21	t
1375	133	Building Services Engineer	20	t
1376	133	Development Engineer	20	t
1377	133	Principal Mechanical Engineer	19	t
1378	133	Sales Assistant	19	t
1379	133	Mechanic	18	t
1380	133	Assistant Engineer	17	t
1381	133	Assistant Mechanical Engineer	16	t
1382	133	Researcher	15	t
1383	133	Mechanical Fitter	15	t
1384	133	Technician	14	t
1385	133	Mechanical Building Services Engineer	14	t
1386	133	Engineering Manager	13	t
1387	133	Research Assistant	12	t
1388	133	Engineering Apprentice	12	t
1389	133	Student Engineer	12	t
1390	133	Summer Intern	12	t
1391	133	Marine Engineer	11	t
1392	133	Manufacturing Engineer	11	t
1393	133	Principal Engineer	11	t
1394	133	Rotating Equipment Engineer	11	t
1395	133	Application Engineer	10	t
1396	133	Intermediate Mechanical Engineer	9	t
1397	133	Commissioning Engineer	9	t
1398	133	Consultant	9	t
1399	133	Designer	9	t
1400	133	Draughtsman	9	t
1401	133	Managing Director	9	t
1402	133	Mechanical Supervisor	9	t
1403	133	Process Engineer	9	t
1404	133	Vehicle Technician	9	t
1405	133	Engineering Technician	8	t
1406	133	Volunteer	7	t
1407	133	Research Engineer	7	t
1408	133	Supervisor	7	t
1409	134	Engineer	125	t
1410	134	IT Manager	65	t
1411	134	Field Service Engineer	58	t
1412	134	Installation Engineer	41	t
1413	134	Maintenance Engineer	40	t
1414	134	Electrician	34	t
1415	134	Service Technician	32	t
1416	134	Technician	22	t
1417	134	Electrical Engineer	19	t
1418	134	Mechanical Engineer	18	t
1419	134	Test Analyst	18	t
1420	134	Service Manager	18	t
1421	134	Marine Engineer	17	t
1422	134	Team Leader	16	t
1423	134	Commissioning Engineer	16	t
1424	134	Mechanical Fitter	15	t
1425	134	Software Developer	15	t
1426	134	Electronics Engineer	15	t
1427	134	Field Engineer	13	t
1428	134	Production Engineer	12	t
1429	134	Project Engineer	12	t
1430	134	Refrigeration Engineer	11	t
1431	134	Project Manager	11	t
1432	134	Mechanical Technician	11	t
1433	134	Owner	11	t
1434	134	Fitter	11	t
1435	134	Maintenance Manager	11	t
1436	134	Maintenance Technician	10	t
1437	134	Installation/Service Engineer	10	t
1438	134	Manager	10	t
1439	134	Technical Manager	9	t
1440	134	Sales Engineer	9	t
1441	134	Electrical Technician	9	t
1442	134	Managing Director	9	t
1443	134	Field Service Technician	9	t
1444	134	Engineering Apprentice	9	t
1445	134	Avionics Technician	9	t
1446	134	Service	9	t
1447	134	Apprenticeship	9	t
1448	134	Director	9	t
1449	134	Aircraft Engineer	8	t
1450	134	Electronic Test Engineer	8	t
1451	134	Security Engineer	8	t
1452	134	Electronics Technician	8	t
1453	134	Installer	8	t
1454	134	Service and Installation Engineer	8	t
1455	134	Design Engineer	7	t
1456	134	Workshop Engineer	7	t
1457	134	Lift Engineer	7	t
1458	134	Vehicle Technician	7	t
\.


--
-- Name: previous_title_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geektalent
--

SELECT pg_catalog.setval('previous_title_id_seq', 1458, true);


--
-- Data for Name: salary_bin; Type: TABLE DATA; Schema: public; Owner: geektalent
--

COPY salary_bin (id, career_id, lower_bound, upper_bound, count) FROM stdin;
141	15	10000	20000	626
142	15	20000	30000	759
143	15	30000	40000	550
144	15	40000	50000	259
145	15	50000	60000	108
146	15	60000	70000	82
147	15	70000	\N	58
148	5	10000	20000	112
149	5	20000	30000	944
150	5	30000	40000	1522
151	5	40000	50000	1824
152	5	50000	60000	1302
153	5	60000	70000	769
154	5	70000	\N	1560
155	16	10000	20000	1
156	16	20000	30000	9
157	16	30000	40000	14
158	16	40000	50000	25
159	16	50000	60000	27
160	16	60000	70000	11
161	16	70000	\N	7
162	9	10000	20000	209
163	9	20000	30000	759
164	9	30000	40000	672
165	9	40000	50000	472
166	9	50000	60000	256
167	9	60000	70000	126
168	9	70000	\N	335
169	13	10000	20000	418
170	13	20000	30000	447
171	13	30000	40000	366
172	13	40000	50000	284
173	13	50000	60000	161
174	13	60000	70000	93
175	13	70000	\N	133
176	18	10000	20000	4
177	18	20000	30000	29
178	18	30000	40000	81
179	18	40000	50000	180
180	18	50000	60000	143
181	18	60000	70000	95
182	18	70000	\N	185
183	14	10000	20000	981
184	14	20000	30000	4282
185	14	30000	40000	2951
186	14	40000	50000	1631
187	14	50000	60000	850
188	14	60000	70000	413
189	14	70000	\N	563
190	20	10000	20000	18
191	20	20000	30000	43
192	20	30000	40000	38
193	20	40000	50000	59
194	20	50000	60000	26
195	20	60000	70000	19
196	20	70000	\N	19
197	19	10000	20000	29
198	19	20000	30000	145
199	19	30000	40000	148
200	19	40000	50000	190
201	19	50000	60000	118
202	19	60000	70000	57
203	19	70000	\N	64
204	4	10000	20000	497
205	4	20000	30000	1781
206	4	30000	40000	1003
207	4	40000	50000	687
208	4	50000	60000	565
209	4	60000	70000	391
210	4	70000	\N	608
211	3	10000	20000	1088
212	3	20000	30000	3262
213	3	30000	40000	2739
214	3	40000	50000	2172
215	3	50000	60000	1822
216	3	60000	70000	1010
217	3	70000	\N	1648
218	6	10000	20000	109
219	6	20000	30000	447
220	6	30000	40000	414
221	6	40000	50000	358
222	6	50000	60000	311
223	6	60000	70000	177
224	6	70000	\N	275
225	17	10000	20000	15
226	17	20000	30000	92
227	17	30000	40000	88
228	17	40000	50000	36
229	17	50000	60000	7
230	17	60000	70000	11
231	17	70000	\N	9
232	2	10000	20000	1878
233	2	20000	30000	3795
234	2	30000	40000	2763
235	2	40000	50000	2477
236	2	50000	60000	2021
237	2	60000	70000	1241
238	2	70000	\N	1889
239	7	10000	20000	87
240	7	20000	30000	615
241	7	30000	40000	668
242	7	40000	50000	635
243	7	50000	60000	384
244	7	60000	70000	184
245	7	70000	\N	279
246	1	10000	20000	2314
247	1	20000	30000	10213
248	1	30000	40000	14540
249	1	40000	50000	14852
250	1	50000	60000	10078
251	1	60000	70000	5630
252	1	70000	\N	7363
253	8	10000	20000	498
254	8	20000	30000	3149
255	8	30000	40000	5107
256	8	40000	50000	5619
257	8	50000	60000	3243
258	8	60000	70000	1611
259	8	70000	\N	2420
260	10	10000	20000	28
261	10	20000	30000	302
262	10	30000	40000	558
263	10	40000	50000	343
264	10	50000	60000	124
265	10	60000	70000	91
266	10	70000	\N	148
267	12	10000	20000	308
268	12	20000	30000	1310
269	12	30000	40000	1043
270	12	40000	50000	599
271	12	50000	60000	307
272	12	60000	70000	140
273	12	70000	\N	245
274	11	10000	20000	417
275	11	20000	30000	2401
276	11	30000	40000	3635
277	11	40000	50000	2716
278	11	50000	60000	1414
279	11	60000	70000	660
280	11	70000	\N	972
281	57	10000	20000	997
282	57	20000	30000	2199
283	57	30000	40000	1841
284	57	40000	50000	1065
285	57	50000	60000	546
286	57	60000	70000	191
287	57	70000	\N	199
288	58	10000	20000	513
289	58	20000	30000	3716
290	58	30000	40000	5068
291	58	40000	50000	1110
292	58	50000	60000	225
293	58	60000	70000	67
294	58	70000	\N	61
295	49	10000	20000	738
296	49	20000	30000	3413
297	49	30000	40000	4894
298	49	40000	50000	2367
299	49	50000	60000	789
300	49	60000	70000	387
301	49	70000	\N	368
302	54	10000	20000	27
303	54	20000	30000	321
304	54	30000	40000	981
305	54	40000	50000	677
306	54	50000	60000	322
307	54	60000	70000	114
308	54	70000	\N	59
309	47	10000	20000	326
310	47	20000	30000	1679
311	47	30000	40000	3367
312	47	40000	50000	3319
313	47	50000	60000	1709
314	47	60000	70000	698
315	47	70000	\N	1004
316	48	10000	20000	186
317	48	20000	30000	1147
318	48	30000	40000	1799
319	48	40000	50000	937
320	48	50000	60000	426
321	48	60000	70000	199
322	48	70000	\N	193
323	43	10000	20000	676
324	43	20000	30000	4803
325	43	30000	40000	1070
326	43	40000	50000	171
327	43	50000	60000	37
328	43	60000	70000	14
329	43	70000	\N	10
330	45	10000	20000	6665
331	45	20000	30000	18058
332	45	30000	40000	16348
333	45	40000	50000	11790
334	45	50000	60000	7483
335	45	60000	70000	3982
336	45	70000	\N	5258
337	52	10000	20000	3
338	52	20000	30000	90
339	52	30000	40000	884
340	52	40000	50000	1
341	52	50000	60000	1
342	52	60000	70000	0
343	52	70000	\N	0
344	56	10000	20000	241
345	56	20000	30000	419
346	56	30000	40000	369
347	56	40000	50000	200
348	56	50000	60000	94
349	56	60000	70000	57
350	56	70000	\N	66
351	50	10000	20000	2758
352	50	20000	30000	6827
353	50	30000	40000	4678
354	50	40000	50000	2124
355	50	50000	60000	1616
356	50	60000	70000	539
357	50	70000	\N	606
358	51	10000	20000	1295
359	51	20000	30000	1388
360	51	30000	40000	352
361	51	40000	50000	150
362	51	50000	60000	56
363	51	60000	70000	33
364	51	70000	\N	45
365	46	10000	20000	1718
366	46	20000	30000	4283
367	46	30000	40000	2692
368	46	40000	50000	1610
369	46	50000	60000	1065
370	46	60000	70000	570
371	46	70000	\N	568
372	53	10000	20000	515
373	53	20000	30000	1841
374	53	30000	40000	1947
375	53	40000	50000	1136
376	53	50000	60000	765
377	53	60000	70000	452
378	53	70000	\N	709
379	42	10000	20000	5838
380	42	20000	30000	11655
381	42	30000	40000	5406
382	42	40000	50000	3145
383	42	50000	60000	1360
384	42	60000	70000	568
385	42	70000	\N	907
386	44	10000	20000	7683
387	44	20000	30000	15956
388	44	30000	40000	11589
389	44	40000	50000	6840
390	44	50000	60000	3137
391	44	60000	70000	1571
392	44	70000	\N	1882
393	41	10000	20000	7035
394	41	20000	30000	4140
395	41	30000	40000	938
396	41	40000	50000	389
397	41	50000	60000	209
398	41	60000	70000	100
399	41	70000	\N	134
400	55	10000	20000	290
401	55	20000	30000	1342
402	55	30000	40000	489
403	55	40000	50000	134
404	55	50000	60000	41
405	55	60000	70000	13
406	55	70000	\N	19
540	97	10000	20000	2023
541	97	20000	30000	6168
542	97	30000	40000	5768
543	97	40000	50000	4411
544	97	50000	60000	2357
545	97	60000	70000	1351
546	97	70000	\N	1583
547	120	10000	20000	50
548	120	20000	30000	285
549	120	30000	40000	254
550	120	40000	50000	206
551	120	50000	60000	203
552	120	60000	70000	128
553	120	70000	\N	311
554	109	10000	20000	377
555	109	20000	30000	1117
556	109	30000	40000	1383
557	109	40000	50000	1260
558	109	50000	60000	798
559	109	60000	70000	490
560	109	70000	\N	481
561	114	10000	20000	136
562	114	20000	30000	77
563	114	30000	40000	48
564	114	40000	50000	77
565	114	50000	60000	56
566	114	60000	70000	48
567	114	70000	\N	77
568	110	10000	20000	602
569	110	20000	30000	1415
570	110	30000	40000	555
571	110	40000	50000	461
572	110	50000	60000	485
573	110	60000	70000	399
574	110	70000	\N	782
575	111	10000	20000	144
576	111	20000	30000	885
577	111	30000	40000	1425
578	111	40000	50000	1558
579	111	50000	60000	1136
580	111	60000	70000	611
581	111	70000	\N	1382
582	119	10000	20000	8
583	119	20000	30000	57
584	119	30000	40000	93
585	119	40000	50000	85
586	119	50000	60000	69
587	119	60000	70000	41
588	119	70000	\N	100
589	118	10000	20000	5163
590	118	20000	30000	12007
591	118	30000	40000	9489
592	118	40000	50000	6902
593	118	50000	60000	4479
594	118	60000	70000	2340
595	118	70000	\N	3040
596	124	10000	20000	7687
597	124	20000	30000	2896
598	124	30000	40000	500
599	124	40000	50000	333
600	124	50000	60000	78
601	124	60000	70000	53
602	124	70000	\N	79
603	105	10000	20000	214
604	105	20000	30000	762
605	105	30000	40000	552
606	105	40000	50000	391
607	105	50000	60000	237
608	105	60000	70000	109
609	105	70000	\N	250
610	121	10000	20000	762
611	121	20000	30000	943
612	121	30000	40000	275
613	121	40000	50000	110
614	121	50000	60000	56
615	121	60000	70000	42
616	121	70000	\N	43
617	101	10000	20000	541
618	101	20000	30000	952
619	101	30000	40000	629
620	101	40000	50000	500
621	101	50000	60000	243
622	101	60000	70000	113
623	101	70000	\N	281
624	99	10000	20000	44
625	99	20000	30000	297
626	99	30000	40000	396
627	99	40000	50000	411
628	99	50000	60000	259
629	99	60000	70000	126
630	99	70000	\N	181
631	108	10000	20000	0
632	108	20000	30000	26
633	108	30000	40000	10
634	108	40000	50000	11
635	108	50000	60000	22
636	108	60000	70000	16
637	108	70000	\N	20
638	107	10000	20000	226
639	107	20000	30000	1016
640	107	30000	40000	333
641	107	40000	50000	188
642	107	50000	60000	87
643	107	60000	70000	58
644	107	70000	\N	28
645	122	10000	20000	579
646	122	20000	30000	1124
647	122	30000	40000	733
648	122	40000	50000	396
649	122	50000	60000	206
650	122	60000	70000	99
651	122	70000	\N	90
652	117	10000	20000	4650
653	117	20000	30000	2018
654	117	30000	40000	651
655	117	40000	50000	225
656	117	50000	60000	86
657	117	60000	70000	70
658	117	70000	\N	42
659	116	10000	20000	38
660	116	20000	30000	6
661	116	30000	40000	2
662	116	40000	50000	2
663	116	50000	60000	0
664	116	60000	70000	2
665	116	70000	\N	2
666	100	10000	20000	681
667	100	20000	30000	2130
668	100	30000	40000	2166
669	100	40000	50000	1904
670	100	50000	60000	1233
671	100	60000	70000	643
672	100	70000	\N	817
673	113	10000	20000	2
674	113	20000	30000	4
675	113	30000	40000	14
676	113	40000	50000	16
677	113	50000	60000	24
678	113	60000	70000	54
679	113	70000	\N	95
680	98	10000	20000	1944
681	98	20000	30000	5446
682	98	30000	40000	4778
683	98	40000	50000	3506
684	98	50000	60000	2355
685	98	60000	70000	1356
686	98	70000	\N	1959
687	106	10000	20000	14
688	106	20000	30000	77
689	106	30000	40000	197
690	106	40000	50000	193
691	106	50000	60000	150
692	106	60000	70000	87
693	106	70000	\N	156
694	102	10000	20000	1035
695	102	20000	30000	2014
696	102	30000	40000	2804
697	102	40000	50000	2979
698	102	50000	60000	2547
699	102	60000	70000	1746
700	102	70000	\N	2729
701	112	10000	20000	189
702	112	20000	30000	428
703	112	30000	40000	384
704	112	40000	50000	219
705	112	50000	60000	108
706	112	60000	70000	36
707	112	70000	\N	51
708	104	10000	20000	153
709	104	20000	30000	533
710	104	30000	40000	720
711	104	40000	50000	639
712	104	50000	60000	490
713	104	60000	70000	283
714	104	70000	\N	327
715	115	10000	20000	699
716	115	20000	30000	1477
717	115	30000	40000	794
718	115	40000	50000	417
719	115	50000	60000	240
720	115	60000	70000	295
721	115	70000	\N	270
722	92	10000	20000	6
723	92	20000	30000	60
724	92	30000	40000	116
725	92	40000	50000	185
726	92	50000	60000	60
727	92	60000	70000	4
728	92	70000	\N	5
729	88	10000	20000	2293
730	88	20000	30000	4091
731	88	30000	40000	3307
732	88	40000	50000	1680
733	88	50000	60000	920
734	88	60000	70000	377
735	88	70000	\N	227
736	80	10000	20000	7429
737	80	20000	30000	1561
738	80	30000	40000	424
739	80	40000	50000	442
740	80	50000	60000	355
741	80	60000	70000	73
742	80	70000	\N	63
743	84	10000	20000	492
744	84	20000	30000	414
745	84	30000	40000	280
746	84	40000	50000	306
747	84	50000	60000	214
748	84	60000	70000	250
749	84	70000	\N	1140
750	81	10000	20000	546
751	81	20000	30000	834
752	81	30000	40000	1621
753	81	40000	50000	946
754	81	50000	60000	1112
755	81	60000	70000	382
756	81	70000	\N	1521
757	82	10000	20000	1
758	82	20000	30000	2
759	82	30000	40000	5
760	82	40000	50000	5
761	82	50000	60000	232
762	82	60000	70000	2
763	82	70000	\N	26
764	90	10000	20000	56
765	90	20000	30000	34
766	90	30000	40000	13
767	90	40000	50000	2
768	90	50000	60000	1
769	90	60000	70000	0
770	90	70000	\N	0
771	79	10000	20000	2781
772	79	20000	30000	1958
773	79	30000	40000	534
774	79	40000	50000	649
775	79	50000	60000	275
776	79	60000	70000	123
777	79	70000	\N	42
778	91	10000	20000	23
779	91	20000	30000	51
780	91	30000	40000	96
781	91	40000	50000	39
782	91	50000	60000	40
783	91	60000	70000	6
784	91	70000	\N	7
785	96	10000	20000	3
786	96	20000	30000	110
787	96	30000	40000	149
788	96	40000	50000	66
789	96	50000	60000	27
790	96	60000	70000	9
791	96	70000	\N	25
792	78	10000	20000	21068
793	78	20000	30000	26979
794	78	30000	40000	20673
795	78	40000	50000	12391
796	78	50000	60000	7134
797	78	60000	70000	2587
798	78	70000	\N	5110
799	86	10000	20000	114
800	86	20000	30000	597
801	86	30000	40000	1045
802	86	40000	50000	660
803	86	50000	60000	236
804	86	60000	70000	43
805	86	70000	\N	15
806	94	10000	20000	367
807	94	20000	30000	737
808	94	30000	40000	305
809	94	40000	50000	627
810	94	50000	60000	150
811	94	60000	70000	33
812	94	70000	\N	13
813	89	10000	20000	32
814	89	20000	30000	141
815	89	30000	40000	455
816	89	40000	50000	65
817	89	50000	60000	34
818	89	60000	70000	21
819	89	70000	\N	19
820	95	10000	20000	71
821	95	20000	30000	236
822	95	30000	40000	403
823	95	40000	50000	305
824	95	50000	60000	200
825	95	60000	70000	45
826	95	70000	\N	102
827	85	10000	20000	124
828	85	20000	30000	652
829	85	30000	40000	1343
830	85	40000	50000	700
831	85	50000	60000	241
832	85	60000	70000	42
833	85	70000	\N	18
834	93	10000	20000	18
835	93	20000	30000	245
836	93	30000	40000	556
837	93	40000	50000	378
838	93	50000	60000	147
839	93	60000	70000	39
840	93	70000	\N	30
841	87	10000	20000	125
842	87	20000	30000	137
843	87	30000	40000	201
844	87	40000	50000	147
845	87	50000	60000	87
846	87	60000	70000	15
847	87	70000	\N	3
848	83	10000	20000	40
849	83	20000	30000	335
850	83	30000	40000	518
851	83	40000	50000	258
852	83	50000	60000	148
853	83	60000	70000	29
854	83	70000	\N	129
\.


--
-- Name: salary_bin_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geektalent
--

SELECT pg_catalog.setval('salary_bin_id_seq', 854, true);


--
-- Data for Name: salary_history_point; Type: TABLE DATA; Schema: public; Owner: geektalent
--

COPY salary_history_point (id, career_id, date, salary) FROM stdin;
181	15	2016-04-01	29793.1699999999983
182	15	2015-07-01	28179.9599999999991
183	15	2015-10-01	29548.1500000000015
184	15	2015-12-01	30160.3899999999994
185	15	2016-02-01	29919.0099999999984
186	15	2015-08-01	28387.9399999999987
187	15	2015-05-01	28257.8100000000013
188	15	2015-11-01	29361.9700000000012
189	15	2016-01-01	30315.2700000000004
190	15	2015-06-01	29115.7400000000016
191	15	2016-03-01	30870.8199999999997
192	15	2015-09-01	29487.8400000000001
193	5	2016-04-01	53683.760000000002
194	5	2016-02-01	52033.9599999999991
195	5	2015-10-01	52725.4499999999971
196	5	2015-12-01	51422.760000000002
197	5	2015-07-01	53855.5299999999988
198	5	2015-08-01	54108.739999999998
199	5	2015-05-01	52953.3000000000029
200	5	2015-11-01	52297.3099999999977
201	5	2016-01-01	50897.9199999999983
202	5	2015-06-01	52257.7300000000032
203	5	2016-03-01	51501.6399999999994
204	5	2015-09-01	52734.6900000000023
205	9	2016-04-01	42151.1699999999983
206	9	2015-07-01	41781.8899999999994
207	9	2015-10-01	42068.7699999999968
208	9	2015-12-01	40431.6800000000003
209	9	2016-02-01	41223.6299999999974
210	9	2015-08-01	41983.5800000000017
211	9	2015-05-01	42382.4499999999971
212	9	2015-11-01	40779.0500000000029
213	9	2016-01-01	42245.0199999999968
214	9	2015-06-01	41166.5500000000029
215	9	2016-03-01	41920.5199999999968
216	9	2015-09-01	41992.989999999998
217	13	2016-04-01	37639.4400000000023
218	13	2016-02-01	36806.7300000000032
219	13	2015-10-01	36795.9499999999971
220	13	2015-12-01	37569.6200000000026
221	13	2015-07-01	35271.6299999999974
222	13	2015-06-01	35700.4400000000023
223	13	2015-05-01	35664.4000000000015
224	13	2015-11-01	36797.4599999999991
225	13	2016-01-01	37032.760000000002
226	13	2015-08-01	35716.1800000000003
227	13	2016-03-01	37056.1399999999994
228	13	2015-09-01	36039.4000000000015
229	18	2016-04-01	57546.7099999999991
230	18	2016-02-01	56358.7099999999991
231	18	2015-10-01	57433.8499999999985
232	18	2015-12-01	57879.739999999998
233	18	2015-07-01	50600.2900000000009
234	18	2015-06-01	53552.4100000000035
235	18	2015-05-01	53507.8899999999994
236	18	2015-11-01	54092.6299999999974
237	18	2016-01-01	56852.6699999999983
238	18	2015-08-01	53694.239999999998
239	18	2016-03-01	57591.0999999999985
240	18	2015-09-01	58247.0899999999965
241	4	2016-04-01	37135.989999999998
242	4	2016-02-01	37977.3899999999994
243	4	2015-10-01	37351.9499999999971
244	4	2015-12-01	37466.7300000000032
245	4	2015-07-01	37288.6900000000023
246	4	2015-06-01	37419.0899999999965
247	4	2015-05-01	37531.9199999999983
248	4	2015-11-01	37283.489999999998
249	4	2016-01-01	37443.0800000000017
250	4	2015-08-01	37168.8899999999994
251	4	2016-03-01	37598.8700000000026
252	4	2015-09-01	36986.3300000000017
253	3	2016-04-01	35547.3499999999985
254	3	2015-07-01	35751.8399999999965
255	3	2015-10-01	35726.1299999999974
256	3	2015-12-01	36192.4800000000032
257	3	2016-02-01	36423.6100000000006
258	3	2015-06-01	35902.8099999999977
259	3	2015-05-01	36026.5
260	3	2015-11-01	36116.1299999999974
261	3	2016-01-01	36286.3199999999997
262	3	2015-08-01	35771.6999999999971
263	3	2016-03-01	36148.9000000000015
264	3	2015-09-01	35812.6800000000003
265	2	2016-04-01	41527.4800000000032
266	2	2016-02-01	43106.5500000000029
267	2	2015-10-01	43353.8300000000017
268	2	2015-12-01	43015.3700000000026
269	2	2015-07-01	42873.3899999999994
270	2	2015-08-01	42756.4700000000012
271	2	2015-05-01	42569.6299999999974
272	2	2015-11-01	43290.6600000000035
273	2	2016-01-01	43272.8799999999974
274	2	2015-06-01	42861.4000000000015
275	2	2016-03-01	42851.3000000000029
276	2	2015-09-01	42450
277	7	2016-04-01	42394.8000000000029
278	7	2016-02-01	43042.0699999999997
279	7	2015-10-01	40007.0500000000029
280	7	2015-12-01	44207.8799999999974
281	7	2015-07-01	39659.9199999999983
282	7	2015-06-01	41120.6800000000003
283	7	2015-05-01	39731.3499999999985
284	7	2015-11-01	39692.6600000000035
285	7	2016-01-01	44057.8700000000026
286	7	2015-08-01	39141.4800000000032
287	7	2016-03-01	42677.8899999999994
288	7	2015-09-01	40183.989999999998
289	1	2016-04-01	46443.0400000000009
290	1	2016-02-01	46262.5899999999965
291	1	2015-10-01	45627.0599999999977
292	1	2015-12-01	46056.5899999999965
293	1	2015-07-01	45323.4300000000003
294	1	2015-08-01	45676.0999999999985
295	1	2015-05-01	45404.7900000000009
296	1	2015-11-01	46054.0199999999968
297	1	2016-01-01	46033.5400000000009
298	1	2015-06-01	45183.6200000000026
299	1	2016-03-01	46823.739999999998
300	1	2015-09-01	45650.1299999999974
301	8	2016-04-01	45162.760000000002
302	8	2016-02-01	44995.6299999999974
303	8	2015-10-01	44962.8399999999965
304	8	2015-12-01	45317.9100000000035
305	8	2015-07-01	44326.8300000000017
306	8	2015-06-01	43951.9599999999991
307	8	2015-05-01	44203.4199999999983
308	8	2015-11-01	45390.6200000000026
309	8	2016-01-01	45147.0199999999968
310	8	2015-08-01	44461.5999999999985
311	8	2016-03-01	45187
312	8	2015-09-01	44856.7699999999968
313	10	2016-04-01	43927.2200000000012
314	10	2015-07-01	42713.3099999999977
315	10	2015-10-01	42015.1399999999994
316	10	2015-12-01	42255.8700000000026
317	10	2016-02-01	42064.6399999999994
318	10	2015-08-01	43876.8000000000029
319	10	2015-05-01	41324.2200000000012
320	10	2015-11-01	44420.6200000000026
321	10	2016-01-01	41109.6399999999994
322	10	2015-06-01	43055.8199999999997
323	10	2016-03-01	42252.7900000000009
324	10	2015-09-01	43130.4300000000003
325	12	2016-04-01	35877.6600000000035
326	12	2016-02-01	36392.6600000000035
327	12	2015-10-01	34874.7699999999968
328	12	2015-12-01	35093.0699999999997
329	12	2015-07-01	33645.8300000000017
330	12	2015-06-01	33367.7900000000009
331	12	2015-05-01	33132.0199999999968
332	12	2015-11-01	35053.1800000000003
333	12	2016-01-01	34942.4199999999983
334	12	2015-08-01	34874.1600000000035
335	12	2016-03-01	35507.8099999999977
336	12	2015-09-01	35333.6399999999994
337	11	2016-04-01	40442.239999999998
338	11	2015-07-01	39257.1800000000003
339	11	2015-10-01	40803.3199999999997
340	11	2015-12-01	40365.6299999999974
341	11	2016-02-01	39973.5199999999968
342	11	2015-06-01	40012.6900000000023
343	11	2015-05-01	39320.4700000000012
344	11	2015-11-01	40182.9199999999983
345	11	2016-01-01	39693.5199999999968
346	11	2015-08-01	39875.9400000000023
347	11	2016-03-01	39995.9800000000032
348	11	2015-09-01	40531.8700000000026
349	57	2015-11-01	32682.3199999999997
350	57	2015-07-01	33221.0599999999977
351	57	2015-06-01	33555.1999999999971
352	57	2015-09-01	33021.0999999999985
353	57	2016-01-01	34520.010000000002
354	57	2015-05-01	33719.1699999999983
355	57	2016-03-01	33972.8499999999985
356	57	2016-02-01	33753.8600000000006
357	57	2016-04-01	32839.0999999999985
358	57	2015-12-01	34023.0999999999985
359	57	2015-08-01	32981.1500000000015
360	57	2015-10-01	32811.5899999999965
361	58	2015-10-01	32456.7599999999984
362	58	2015-12-01	32826.5400000000009
363	58	2015-07-01	32563.7200000000012
364	58	2015-06-01	32303.0099999999984
365	58	2015-09-01	32702.619999999999
366	58	2016-01-01	32931.6999999999971
367	58	2015-05-01	32326.0200000000004
368	58	2016-03-01	32390.7299999999996
369	58	2016-02-01	33693.739999999998
370	58	2016-04-01	31983.0900000000001
371	58	2015-08-01	32602.6699999999983
372	58	2015-11-01	33686.0199999999968
373	49	2015-11-01	36464.0999999999985
374	49	2015-07-01	35995.3899999999994
375	49	2015-06-01	35956.5
376	49	2015-09-01	36412.739999999998
377	49	2016-01-01	36542.9300000000003
378	49	2015-05-01	35905.7099999999991
379	49	2016-03-01	36087.0500000000029
380	49	2016-02-01	36297.6500000000015
381	49	2016-04-01	36181.6500000000015
382	49	2015-12-01	36768.6600000000035
383	49	2015-08-01	36607.6800000000003
384	49	2015-10-01	36031.1399999999994
385	47	2016-01-01	44149.489999999998
386	47	2015-12-01	44316.2099999999991
387	47	2015-07-01	42238.25
388	47	2015-06-01	42526.3199999999997
389	47	2015-09-01	42402.7200000000012
390	47	2015-10-01	43201.2300000000032
391	47	2015-05-01	42851.2099999999991
392	47	2016-03-01	44328.9100000000035
393	47	2016-02-01	44366.4499999999971
394	47	2016-04-01	44218.6600000000035
395	47	2015-08-01	43044.5800000000017
396	47	2015-11-01	42422.9300000000003
397	48	2015-11-01	36486.4800000000032
398	48	2015-07-01	35950.2200000000012
399	48	2015-06-01	36488.3600000000006
400	48	2015-09-01	36515.3099999999977
401	48	2016-01-01	38047.9300000000003
402	48	2015-05-01	37161.4400000000023
403	48	2016-03-01	38604.7300000000032
404	48	2016-02-01	39595.8000000000029
405	48	2016-04-01	38065.7799999999988
406	48	2015-12-01	38195.4400000000023
407	48	2015-08-01	36615.2699999999968
408	48	2015-10-01	37215.510000000002
409	45	2015-12-01	39664.9300000000003
410	45	2015-07-01	39126.8899999999994
411	45	2015-06-01	39353.0800000000017
412	45	2015-11-01	39547.7699999999968
413	45	2015-09-01	38915.4800000000032
414	45	2016-01-01	39593.8199999999997
415	45	2015-05-01	39304.9800000000032
416	45	2016-03-01	39613.0299999999988
417	45	2016-02-01	39821.5400000000009
418	45	2016-04-01	39398.1699999999983
419	45	2015-08-01	38945.3899999999994
420	45	2015-10-01	39291.1600000000035
421	52	2015-12-01	28365.5400000000009
422	52	2015-07-01	28845.6599999999999
423	52	2015-06-01	31522.5299999999988
424	52	2015-11-01	27884.1800000000003
425	52	2015-09-01	28174.8499999999985
426	52	2016-01-01	27874.6500000000015
427	52	2015-05-01	28861.9500000000007
428	52	2016-03-01	30735.9500000000007
429	52	2016-02-01	27998.9099999999999
430	52	2016-04-01	30192.1800000000003
431	52	2015-08-01	29470.1800000000003
432	52	2015-10-01	28255.9199999999983
433	50	2015-10-01	32086.9099999999999
434	50	2015-12-01	32992.6299999999974
435	50	2015-07-01	31863.2900000000009
436	50	2015-06-01	32356.3199999999997
437	50	2015-09-01	32180.3100000000013
438	50	2016-01-01	33237.3600000000006
439	50	2015-05-01	32190.9399999999987
440	50	2016-03-01	33658.5500000000029
441	50	2016-02-01	33541.7099999999991
442	50	2016-04-01	33696.760000000002
443	50	2015-08-01	32274.9599999999991
444	50	2015-11-01	32398.2799999999988
445	51	2015-11-01	23580.5999999999985
446	51	2015-07-01	23918.3100000000013
447	51	2015-06-01	23568.7000000000007
448	51	2015-09-01	23077.8499999999985
449	51	2016-01-01	24846.4900000000016
450	51	2015-05-01	23609.9300000000003
451	51	2016-03-01	23807.5800000000017
452	51	2016-02-01	24423.4199999999983
453	51	2016-04-01	24063.7999999999993
454	51	2015-12-01	24719.9399999999987
455	51	2015-08-01	23510.2599999999984
456	51	2015-10-01	22812.0200000000004
457	53	2015-11-01	41409.3700000000026
458	53	2015-07-01	42580.0699999999997
459	53	2015-06-01	42794.4599999999991
460	53	2015-09-01	40449
461	53	2016-01-01	40465.3799999999974
462	53	2015-05-01	43372.8899999999994
463	53	2016-03-01	41166.2099999999991
464	53	2016-02-01	40671.0199999999968
465	53	2016-04-01	42372.1500000000015
466	53	2015-12-01	40744.6100000000006
467	53	2015-08-01	40818.9800000000032
468	53	2015-10-01	41060.9000000000015
469	42	2015-10-01	30137.8499999999985
470	42	2015-11-01	30677.0699999999997
471	42	2015-07-01	30548.8300000000017
472	42	2015-06-01	29897.6699999999983
473	42	2015-09-01	29645.1599999999999
474	42	2016-01-01	30380.869999999999
475	42	2015-05-01	29976.7999999999993
476	42	2016-03-01	30054.369999999999
477	42	2016-02-01	29949.369999999999
478	42	2016-04-01	30500.3600000000006
479	42	2015-08-01	29732.5400000000009
480	42	2015-12-01	29668.9900000000016
481	44	2015-10-01	33422.9400000000023
482	44	2015-12-01	33731.3300000000017
483	44	2015-07-01	34086.4700000000012
484	44	2015-06-01	33937.25
485	44	2015-09-01	33458.6100000000006
486	44	2016-01-01	33617.8300000000017
487	44	2015-05-01	33921.1399999999994
488	44	2016-03-01	33626.3600000000006
489	44	2016-02-01	33522.1600000000035
490	44	2016-04-01	33770.3700000000026
491	44	2015-08-01	33728.0500000000029
492	44	2015-11-01	33970.6200000000026
493	41	2015-10-01	22027.1699999999983
494	41	2015-11-01	21032.7000000000007
495	41	2015-07-01	21911.7700000000004
496	41	2015-06-01	21824.0499999999993
497	41	2015-09-01	21249.5800000000017
498	41	2016-01-01	22487.3100000000013
499	41	2015-05-01	21781.0800000000017
500	41	2016-03-01	22677.380000000001
501	41	2016-02-01	22532.7700000000004
502	41	2016-04-01	22322.4700000000012
503	41	2015-08-01	21496.6599999999999
504	41	2015-12-01	22013.4300000000003
505	55	2015-12-01	26605.5499999999993
506	55	2015-07-01	25306.0999999999985
507	55	2015-06-01	25217.1399999999994
508	55	2015-11-01	26351.2000000000007
509	55	2015-09-01	25132.25
510	55	2016-01-01	26658.4199999999983
511	55	2015-05-01	25353.25
512	55	2016-03-01	27216.0900000000001
513	55	2016-02-01	26982.9199999999983
514	55	2016-04-01	28397.3300000000017
515	55	2015-08-01	25446.5800000000017
516	55	2015-10-01	25553.880000000001
709	97	2015-08-01	37741.5500000000029
710	97	2015-11-01	38242.4000000000015
711	97	2016-04-01	38315.0800000000017
712	97	2015-07-01	37400.7900000000009
713	97	2016-06-01	38455.8899999999994
714	97	2015-12-01	38396.1800000000003
715	97	2015-09-01	38082.010000000002
716	97	2016-02-01	38776.7799999999988
717	97	2016-01-01	38650.7099999999991
718	97	2016-03-01	38399.739999999998
719	97	2015-10-01	38013.7699999999968
720	97	2016-05-01	38399.8600000000006
721	120	2016-04-01	48399.1100000000006
722	120	2015-11-01	47948.5199999999968
723	120	2015-07-01	48394.3399999999965
724	120	2015-08-01	49455.25
725	120	2015-12-01	50719.8799999999974
726	120	2015-09-01	47635.3499999999985
727	120	2016-02-01	48426.3700000000026
728	120	2016-01-01	49476.5299999999988
729	120	2016-06-01	49237.6399999999994
730	120	2015-10-01	50455.2799999999988
731	120	2016-03-01	48645.1200000000026
732	120	2016-05-01	46223.9400000000023
733	109	2016-04-01	41987.8099999999977
734	109	2015-11-01	42087.1699999999983
735	109	2015-07-01	41222.3899999999994
736	109	2015-08-01	41796.5199999999968
737	109	2015-12-01	42679.5
738	109	2015-09-01	41177.4700000000012
739	109	2016-02-01	42912.9300000000003
740	109	2016-01-01	42934.1999999999971
741	109	2016-06-01	42157.9100000000035
742	109	2015-10-01	41477.5299999999988
743	109	2016-03-01	42972.4499999999971
744	109	2016-05-01	42078.7099999999991
745	114	2016-04-01	43547.1500000000015
746	114	2015-11-01	43857.25
747	114	2015-07-01	44471.3099999999977
748	114	2015-08-01	43417.510000000002
749	114	2015-12-01	45305.8300000000017
750	114	2015-09-01	43158.2699999999968
751	114	2016-02-01	42098.2799999999988
752	114	2016-01-01	44111.5299999999988
753	114	2016-03-01	41008.0299999999988
754	114	2015-10-01	46901.2699999999968
755	114	2016-05-01	41203.5299999999988
756	114	2016-06-01	40152.3799999999974
757	110	2016-04-01	46025.25
758	110	2015-11-01	49340.1999999999971
759	110	2015-07-01	49805.0800000000017
760	110	2015-08-01	50570.5999999999985
761	110	2015-12-01	46708.7699999999968
762	110	2015-09-01	49234.3899999999994
763	110	2016-02-01	47362.0500000000029
764	110	2016-01-01	45612.4000000000015
765	110	2016-06-01	43736.4400000000023
766	110	2015-10-01	48464.25
767	110	2016-03-01	46514.4800000000032
768	110	2016-05-01	44904.7900000000009
769	111	2015-08-01	54108.739999999998
770	111	2015-11-01	52297.3099999999977
771	111	2016-04-01	53683.760000000002
772	111	2016-01-01	50897.9199999999983
773	111	2016-06-01	53018.9700000000012
774	111	2015-12-01	51422.760000000002
775	111	2015-09-01	52734.6900000000023
776	111	2016-02-01	52033.9599999999991
777	111	2015-07-01	53855.5299999999988
778	111	2016-03-01	51501.6399999999994
779	111	2015-10-01	52725.4499999999971
780	111	2016-05-01	52723.3899999999994
781	119	2016-04-01	53725.0899999999965
782	119	2015-11-01	54323.0599999999977
783	119	2015-07-01	58798.4599999999991
784	119	2015-08-01	61266.1299999999974
785	119	2016-06-01	51920.5199999999968
786	119	2015-12-01	53136.4100000000035
787	119	2015-09-01	56152.0299999999988
788	119	2016-02-01	52554.1699999999983
789	119	2016-01-01	52425.4400000000023
790	119	2015-10-01	54567.3700000000026
791	119	2016-03-01	53025.5199999999968
792	119	2016-05-01	54456.7099999999991
793	118	2015-08-01	38174.5500000000029
794	118	2015-11-01	38659.2099999999991
795	118	2016-04-01	37929.2699999999968
796	118	2016-01-01	38319.8000000000029
797	118	2016-06-01	37415.760000000002
798	118	2015-12-01	38484.1200000000026
799	118	2015-09-01	38148.8499999999985
800	118	2016-02-01	38371.6299999999974
801	118	2015-07-01	38101.739999999998
802	118	2016-03-01	38232.2200000000012
803	118	2015-10-01	38647.1900000000023
804	118	2016-05-01	37637.5500000000029
805	124	2015-08-01	19623.5699999999997
806	124	2015-11-01	19219.5800000000017
807	124	2016-04-01	20537.5900000000001
808	124	2016-01-01	20409.119999999999
809	124	2016-06-01	20089.0999999999985
810	124	2015-12-01	20126.380000000001
811	124	2015-09-01	19543.1699999999983
812	124	2016-02-01	20590.130000000001
813	124	2015-07-01	20026.4199999999983
814	124	2015-10-01	20043.5099999999984
815	124	2016-03-01	21096.8100000000013
816	124	2016-05-01	20229.7599999999984
817	105	2016-06-01	41445.7699999999968
818	105	2015-11-01	40779.0500000000029
819	105	2016-01-01	42245.0199999999968
820	105	2015-08-01	41983.5800000000017
821	105	2015-10-01	42068.7699999999968
822	105	2016-04-01	42151.1699999999983
823	105	2015-12-01	40431.6800000000003
824	105	2015-09-01	41992.989999999998
825	105	2016-02-01	41223.6299999999974
826	105	2015-07-01	41781.8899999999994
827	105	2016-05-01	41028.3899999999994
828	105	2016-03-01	41920.5199999999968
829	121	2016-06-01	25791.3199999999997
830	121	2015-11-01	25802.4799999999996
831	121	2016-01-01	26645.7299999999996
832	121	2015-08-01	25353.1800000000003
833	121	2015-10-01	25742.3100000000013
834	121	2016-04-01	26115.2700000000004
835	121	2015-12-01	26597.380000000001
836	121	2015-09-01	25723.75
837	121	2016-02-01	26504.6699999999983
838	121	2015-07-01	25723.9300000000003
839	121	2016-05-01	25575.4300000000003
840	121	2016-03-01	26342.1899999999987
841	101	2016-04-01	36836.8099999999977
842	101	2015-11-01	37059.5299999999988
843	101	2015-07-01	37565.760000000002
844	101	2015-08-01	35820.1100000000006
845	101	2016-06-01	35514.4400000000023
846	101	2015-12-01	37189.6399999999994
847	101	2015-09-01	36539.8700000000026
848	101	2016-02-01	36685.1900000000023
849	101	2016-01-01	37630.1299999999974
850	101	2015-10-01	37006.3099999999977
851	101	2016-03-01	35723.9499999999971
852	101	2016-05-01	35609.2799999999988
853	99	2016-04-01	43558.2799999999988
854	99	2015-11-01	44063.3499999999985
855	99	2016-01-01	42857.9700000000012
856	99	2015-08-01	46022.8000000000029
857	99	2015-12-01	43344.6999999999971
858	99	2015-09-01	44916.4499999999971
859	99	2016-02-01	43961.3600000000006
860	99	2015-07-01	44792.5199999999968
861	99	2016-06-01	44555.0199999999968
862	99	2015-10-01	43394.9800000000032
863	99	2016-03-01	44355.5
864	99	2016-05-01	44194.6999999999971
865	108	2016-04-01	62002.3799999999974
866	108	2015-11-01	49198.5800000000017
867	108	2016-01-01	53631.5599999999977
868	108	2015-08-01	49080.1500000000015
869	108	2016-06-01	49873.6600000000035
870	108	2015-12-01	53774.2200000000012
871	108	2015-09-01	52584.0299999999988
872	108	2016-02-01	48936.2200000000012
873	108	2015-07-01	56484.6800000000003
874	108	2015-10-01	52150.4000000000015
875	108	2016-03-01	52849.5500000000029
876	108	2016-05-01	55126.3399999999965
877	107	2015-08-01	29664.4099999999999
878	107	2015-11-01	28141.3899999999994
879	107	2016-01-01	29887.5400000000009
880	107	2016-04-01	30136.6699999999983
881	107	2015-12-01	27798.9199999999983
882	107	2015-09-01	29290.6399999999994
883	107	2016-02-01	29141.130000000001
884	107	2015-07-01	32444.130000000001
885	107	2016-06-01	29118.9099999999999
886	107	2015-10-01	29883.9700000000012
887	107	2016-03-01	27992.5999999999985
888	107	2016-05-01	29102.5499999999993
889	122	2016-06-01	32278.2299999999996
890	122	2015-11-01	30973.1599999999999
891	122	2016-01-01	32339.7299999999996
892	122	2015-08-01	31856.8199999999997
893	122	2016-04-01	31518.2999999999993
894	122	2015-12-01	32237.0499999999993
895	122	2015-09-01	31143.1599999999999
896	122	2016-02-01	31945.5200000000004
897	122	2015-07-01	31211.5499999999993
898	122	2016-03-01	31450.8100000000013
899	122	2015-10-01	30955.0999999999985
900	122	2016-05-01	31612.4599999999991
901	117	2016-06-01	20591.0499999999993
902	117	2015-11-01	20662.6399999999994
903	117	2015-07-01	19804.5099999999984
904	117	2015-08-01	19995.7200000000012
905	117	2016-04-01	21306.2400000000016
906	117	2015-12-01	20464.2599999999984
907	117	2015-09-01	20696.9900000000016
908	117	2016-02-01	21703.2400000000016
909	117	2016-01-01	21223.8600000000006
910	117	2015-10-01	20610.0699999999997
911	117	2016-03-01	22001.2400000000016
912	117	2016-05-01	20914.4099999999999
913	116	2015-08-01	22716.1899999999987
914	116	2015-11-01	18843.6699999999983
915	116	2016-04-01	21220.630000000001
916	116	2015-07-01	22518.5900000000001
917	116	2016-06-01	18813.8600000000006
918	116	2015-12-01	21366.9399999999987
919	116	2015-09-01	22534.619999999999
920	116	2016-02-01	20666.5
921	116	2016-01-01	21155.7700000000004
922	116	2016-03-01	19496.7299999999996
923	116	2015-10-01	20734.8400000000001
924	116	2016-05-01	18494.4799999999996
925	100	2015-08-01	41969.3199999999997
926	100	2015-11-01	41818.5899999999965
927	100	2015-07-01	41585.9000000000015
928	100	2016-04-01	41367.2099999999991
929	100	2015-12-01	41822.0299999999988
930	100	2015-09-01	41424.3700000000026
931	100	2016-02-01	41785.739999999998
932	100	2016-01-01	41402.8899999999994
933	100	2016-06-01	40942.3399999999965
934	100	2015-10-01	41521.0800000000017
935	100	2016-05-01	40709.010000000002
936	100	2016-03-01	41630.4100000000035
937	113	2016-06-01	76934.7799999999988
938	113	2015-11-01	79222.6000000000058
939	113	2015-07-01	67480.2299999999959
940	113	2015-08-01	75261.7200000000012
941	113	2016-04-01	76417.679999999993
942	113	2015-12-01	78710.9600000000064
943	113	2015-09-01	78698.9700000000012
944	113	2016-02-01	70078.8300000000017
945	113	2016-01-01	77171.9100000000035
946	113	2015-10-01	73808.3600000000006
947	113	2016-03-01	76917.4100000000035
948	113	2016-05-01	71647.6100000000006
949	98	2016-06-01	40616.1100000000006
950	98	2015-11-01	40875.6999999999971
951	98	2016-04-01	40709.6299999999974
952	98	2015-07-01	40082.3799999999974
953	98	2015-08-01	40034.1800000000003
954	98	2015-12-01	40983.8099999999977
955	98	2015-09-01	40382.4000000000015
956	98	2016-02-01	40084.8600000000006
957	98	2016-01-01	40766.3199999999997
958	98	2015-10-01	40227.9499999999971
959	98	2016-03-01	40594.8499999999985
960	98	2016-05-01	40392.1800000000003
961	106	2016-04-01	54811.0299999999988
962	106	2015-11-01	54527.8499999999985
963	106	2015-07-01	52504.0400000000009
964	106	2015-08-01	54852.5199999999968
965	106	2016-06-01	56271.9700000000012
966	106	2015-12-01	53721.8000000000029
967	106	2015-09-01	54295.0699999999997
968	106	2016-02-01	52867.510000000002
969	106	2016-01-01	52654.5400000000009
970	106	2015-10-01	53531.6600000000035
971	106	2016-03-01	53799.9100000000035
972	106	2016-05-01	56866.2699999999968
973	104	2016-06-01	43935.9800000000032
974	104	2015-11-01	46866.0299999999988
975	104	2015-07-01	47557.8799999999974
976	104	2015-08-01	47201.5699999999997
977	104	2016-04-01	43285.7900000000009
978	104	2015-12-01	45333.4000000000015
979	104	2015-09-01	46926.3099999999977
980	104	2016-02-01	44681.3700000000026
981	104	2016-01-01	43508.9300000000003
982	104	2015-10-01	46570.0899999999965
983	104	2016-03-01	44084.9100000000035
984	104	2016-05-01	43054.2200000000012
985	115	2016-04-01	37070.1399999999994
986	115	2015-11-01	39431.7300000000032
987	115	2015-07-01	36455.1800000000003
988	115	2015-08-01	37884.9499999999971
989	115	2015-12-01	38796.7300000000032
990	115	2015-09-01	37971.6999999999971
991	115	2016-02-01	37371.8099999999977
992	115	2016-01-01	37586.510000000002
993	115	2016-06-01	35718.8300000000017
994	115	2015-10-01	36254.3600000000006
995	115	2016-03-01	36588.739999999998
996	115	2016-05-01	36756.2200000000012
997	92	2016-06-01	37177.8899999999994
998	92	2015-11-01	38242.6399999999994
999	92	2016-01-01	39882.6999999999971
1000	92	2015-08-01	40049.3300000000017
1001	92	2016-04-01	39373.7900000000009
1002	92	2015-12-01	38353.0599999999977
1003	92	2015-09-01	42682.1100000000006
1004	92	2016-02-01	40436.6100000000006
1005	92	2015-07-01	38560.3099999999977
1006	92	2015-10-01	40291.5599999999977
1007	92	2016-03-01	39547.6399999999994
1008	92	2016-05-01	37605.5
1009	88	2015-08-01	33234.3899999999994
1010	88	2015-11-01	32656.2400000000016
1011	88	2016-01-01	33203.9400000000023
1012	88	2016-04-01	32890.3899999999994
1013	88	2015-12-01	32707.5600000000013
1014	88	2015-09-01	33174.1900000000023
1015	88	2016-02-01	33588.7300000000032
1016	88	2015-07-01	32992.4100000000035
1017	88	2016-06-01	32615.9099999999999
1018	88	2015-10-01	33011.5699999999997
1019	88	2016-03-01	32946.3300000000017
1020	88	2016-05-01	32896.2200000000012
1021	80	2015-08-01	21321.5400000000009
1022	80	2015-11-01	20087.9000000000015
1023	80	2015-07-01	21375.6399999999994
1024	80	2016-04-01	19958.9799999999996
1025	80	2015-12-01	20700.4300000000003
1026	80	2015-09-01	21131.9900000000016
1027	80	2016-02-01	20815.0600000000013
1028	80	2016-01-01	20445.2299999999996
1029	80	2016-03-01	20438.2299999999996
1030	80	2015-10-01	20643.9399999999987
1031	80	2016-05-01	19966.2799999999988
1032	80	2016-06-01	20220.0800000000017
1033	84	2015-08-01	58533.1399999999994
1034	84	2015-11-01	52550.6200000000026
1035	84	2016-04-01	53970.0500000000029
1036	84	2015-07-01	58560.4100000000035
1037	84	2016-06-01	50663.7099999999991
1038	84	2015-12-01	49894.4599999999991
1039	84	2015-09-01	51183.1500000000015
1040	84	2016-02-01	51090.489999999998
1041	84	2016-01-01	49660.9800000000032
1042	84	2016-03-01	51649.3799999999974
1043	84	2015-10-01	48276.739999999998
1044	84	2016-05-01	53221.2300000000032
1045	81	2016-06-01	49197.3300000000017
1046	81	2015-11-01	46405.4100000000035
1047	81	2015-07-01	53042.6999999999971
1048	81	2015-08-01	51619.2799999999988
1049	81	2016-04-01	49677.6900000000023
1050	81	2015-12-01	50464.4599999999991
1051	81	2015-09-01	48380.1100000000006
1052	81	2016-02-01	52304.9499999999971
1053	81	2016-01-01	49503.5299999999988
1054	81	2016-03-01	51622.5599999999977
1055	81	2015-10-01	46249.0500000000029
1056	81	2016-05-01	49340.5299999999988
1057	79	2016-06-01	26331.1500000000015
1058	79	2015-11-01	25774.2099999999991
1059	79	2015-07-01	26568.619999999999
1060	79	2015-08-01	25685.6699999999983
1061	79	2016-04-01	27077.7700000000004
1062	79	2015-12-01	26460.8600000000006
1063	79	2015-09-01	25730.8600000000006
1064	79	2016-02-01	27863.619999999999
1065	79	2016-01-01	26429.2799999999988
1066	79	2015-10-01	25869.2799999999988
1067	79	2016-03-01	28383.0299999999988
1068	79	2016-05-01	26926.7700000000004
1069	91	2015-08-01	35355.4800000000032
1070	91	2015-11-01	37639.8199999999997
1071	91	2016-04-01	34688.7200000000012
1072	91	2015-07-01	35802.1100000000006
1073	91	2016-06-01	35156.7200000000012
1074	91	2015-12-01	34173.4400000000023
1075	91	2015-09-01	34272.6200000000026
1076	91	2016-02-01	37189.4499999999971
1077	91	2016-01-01	34911.6299999999974
1078	91	2016-03-01	38770.4800000000032
1079	91	2015-10-01	35626.0999999999985
1080	91	2016-05-01	37813.4700000000012
1081	96	2015-08-01	45794.5599999999977
1082	96	2015-11-01	40134.2300000000032
1083	96	2016-04-01	36616.8099999999977
1084	96	2015-07-01	41745.7099999999991
1085	96	2016-06-01	33679.8099999999977
1086	96	2015-12-01	37631.760000000002
1087	96	2015-09-01	45868.3600000000006
1088	96	2016-02-01	38117.0199999999968
1089	96	2016-01-01	36781.489999999998
1090	96	2015-10-01	37953.2099999999991
1091	96	2016-03-01	37884.3399999999965
1092	96	2016-05-01	34405.5999999999985
1093	78	2016-04-01	34246.5500000000029
1094	78	2015-11-01	33356.1100000000006
1095	78	2015-07-01	34225.9199999999983
1096	78	2015-08-01	33927.5999999999985
1097	78	2016-06-01	33368.25
1098	78	2015-12-01	33602.8600000000006
1099	78	2015-09-01	33298.8600000000006
1100	78	2016-02-01	34866.1699999999983
1101	78	2016-01-01	34101.1900000000023
1102	78	2015-10-01	32964.9599999999991
1103	78	2016-03-01	34484.3099999999977
1104	78	2016-05-01	33471.239999999998
1105	86	2016-06-01	35862.0500000000029
1106	86	2015-11-01	36332.1399999999994
1107	86	2016-04-01	36761.4100000000035
1108	86	2016-01-01	37346.9700000000012
1109	86	2015-08-01	36460.0800000000017
1110	86	2015-12-01	36407.5599999999977
1111	86	2015-09-01	37515.8499999999985
1112	86	2016-02-01	38200.7099999999991
1113	86	2015-07-01	36329.5400000000009
1114	86	2015-10-01	36529.489999999998
1115	86	2016-03-01	37391.1699999999983
1116	86	2016-05-01	36543.9800000000032
1117	94	2015-08-01	31792.7599999999984
1118	94	2015-11-01	33126.8399999999965
1119	94	2015-07-01	32214.369999999999
1120	94	2016-04-01	30084.0499999999993
1121	94	2015-12-01	31399.4500000000007
1122	94	2015-09-01	31470.0299999999988
1123	94	2016-02-01	31578.9700000000012
1124	94	2016-01-01	31574.5200000000004
1125	94	2016-03-01	32133.2000000000007
1126	94	2015-10-01	31703.8600000000006
1127	94	2016-05-01	30694.2700000000004
1128	94	2016-06-01	30342.5099999999984
1129	89	2016-04-01	33185.7799999999988
1130	89	2015-11-01	34132.0899999999965
1131	89	2015-07-01	34288.2200000000012
1132	89	2015-08-01	33719.5699999999997
1133	89	2015-12-01	33933.760000000002
1134	89	2015-09-01	33671.6600000000035
1135	89	2016-02-01	33129.8199999999997
1136	89	2016-01-01	33825.7099999999991
1137	89	2016-06-01	34569.2799999999988
1138	89	2015-10-01	33636.8399999999965
1139	89	2016-03-01	33948.2300000000032
1140	89	2016-05-01	33184
1141	95	2015-08-01	39533.8099999999977
1142	95	2015-11-01	40246.5
1143	95	2016-04-01	41311.3399999999965
1144	95	2015-07-01	40677.7300000000032
1145	95	2016-06-01	40889.6100000000006
1146	95	2015-12-01	39719.3799999999974
1147	95	2015-09-01	39564.3399999999965
1148	95	2016-02-01	39556.8199999999997
1149	95	2016-01-01	40750.9400000000023
1150	95	2015-10-01	39205.8000000000029
1151	95	2016-03-01	39531.1399999999994
1152	95	2016-05-01	41211.239999999998
1153	85	2016-06-01	35450.6100000000006
1154	85	2015-11-01	36477.3700000000026
1155	85	2016-04-01	37423.7900000000009
1156	85	2016-01-01	38507.1299999999974
1157	85	2015-08-01	37013.489999999998
1158	85	2015-12-01	37454.5500000000029
1159	85	2015-09-01	36736.1800000000003
1160	85	2016-02-01	38036.0599999999977
1161	85	2015-07-01	36917.0199999999968
1162	85	2015-10-01	37748.9499999999971
1163	85	2016-03-01	36841.5
1164	85	2016-05-01	36770.4700000000012
1165	93	2016-06-01	37210.4300000000003
1166	93	2015-11-01	40710.5400000000009
1167	93	2016-04-01	41792.3300000000017
1168	93	2016-01-01	41141.7099999999991
1169	93	2015-08-01	40937.3099999999977
1170	93	2015-12-01	42521.989999999998
1171	93	2015-09-01	40991.2699999999968
1172	93	2016-02-01	40566.5500000000029
1173	93	2015-07-01	39342.2699999999968
1174	93	2015-10-01	40804.6699999999983
1175	93	2016-03-01	40534.8000000000029
1176	93	2016-05-01	38096.7200000000012
1177	83	2015-08-01	34994.739999999998
1178	83	2015-11-01	37544.4100000000035
1179	83	2015-07-01	36357.3499999999985
1180	83	2016-04-01	36898.6299999999974
1181	83	2015-12-01	36586.510000000002
1182	83	2015-09-01	35584.0500000000029
1183	83	2016-02-01	37774.1200000000026
1184	83	2016-01-01	37312.5899999999965
1185	83	2016-06-01	39669.1399999999994
1186	83	2015-10-01	37508.260000000002
1187	83	2016-03-01	37275.0199999999968
1188	83	2016-05-01	38380.8899999999994
\.


--
-- Name: salary_history_point_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geektalent
--

SELECT pg_catalog.setval('salary_history_point_id_seq', 1188, true);


--
-- Data for Name: sector; Type: TABLE DATA; Schema: public; Owner: geektalent
--

COPY sector (id, name, count, total_count, education_subjects_total, education_institutes_total, visible) FROM stdin;
1	Digital Tech	191031	2404377	37474	54609	t
2	Automotive	37729	2404377	3969	5067	t
8	Healthcare	131062	2404377	16084	23215	t
9	Financial Services	204323	2404377	44764	69311	t
10	Biosciences	7728	2411262	2727	3936	t
5	Automotive Sales and Service	0	2411262	\N	\N	t
6	Automotive Engineering and Manufacturing	0	2411262	\N	\N	t
11	Mechanical Engineering	34783	2411262	8592	14539	t
12	Electrical Engineering	27806	2411262	5805	10417	t
\.


--
-- Data for Name: sector_company; Type: TABLE DATA; Schema: public; Owner: geektalent
--

COPY sector_company (id, sector_id, company_name, total_count, sector_count, company_count, count, relevance_score, visible) FROM stdin;
22	1	Amazon	2404377	191031	585	255	0.0011857663487713499	t
27	1	HCL Technologies	2404377	191031	215	190	0.000983307854116387096	t
30	1	Tech Mahindra	2404377	191031	204	164	0.00084042722012412697	t
34	1	Home Page Pays Smart Media Technologies	2404377	191031	158	143	0.000741792534236979974	t
35	1	Steria	2404377	191031	170	142	0.000730684321399523965	t
36	1	NHS Connecting for Health	2404377	191031	272	149	0.00072440614761039399	t
49	1	none none none	2404377	191031	119	114	0.000594502758902699046	t
1	1	IBM	2404377	191031	2328	1968	0.0101393431986839238	t
2	1	Hewlett-Packard	2404377	191031	1635	1406	0.00725659871615665086	t
3	1	Fujitsu	2404377	191031	1042	899	0.00464143441079158461	t
4	1	Capgemini	2404377	191031	990	759	0.00386881025572026428	t
5	1	Microsoft	2404377	191031	814	630	0.00321476200471466737	t
6	1	Tata Consultancy Services	2404377	191031	659	570	0.00294359829734314789	t
7	1	CSC	2404377	191031	633	535	0.00275631571893804458	t
8	1	Computacenter	2404377	191031	502	448	0.00232077165794121552	t
9	1	Google	2404377	191031	610	454	0.00230609609917434939	t
10	1	Oracle	2404377	191031	519	437	0.00225053885070716688	t
11	1	Accenture	2404377	191031	1498	513	0.00224040044589871642	t
12	1	Cognizant Technology Solutions	2404377	191031	504	411	0.00210946543528805304	t
13	1	Atos	2404377	191031	479	398	0.00204683530883601351	t
14	1	CGI	2404377	191031	423	359	0.00185036064125744699	t
15	1	Thomson Reuters	2404377	191031	735	346	0.00163547235001779579	t
16	1	Wipro Technologies	2404377	191031	329	292	0.00151183095081932868	t
17	1	BT	2404377	191031	3185	504	0.00142702699861194408	t
18	1	Infosys	2404377	191031	298	251	0.0012926880529225632	t
19	1	Dell	2404377	191031	277	241	0.00124531037925142466	t
20	1	Capita	2404377	191031	1464	327	0.00119806217981950386	t
21	1	TCS	2404377	191031	294	233	0.00119213724337142372	t
23	1	Primary School	2404377	191031	616	256	0.00117744696194747867	t
24	1	Cisco	2404377	191031	267	213	0.00109060482637984564	t
25	1	Xerox	2404377	191031	369	210	0.00102746108141055681	t
26	1	SAP	2404377	191031	223	191	0.000985379974088109638	t
28	1	Sage	2404377	191031	242	191	0.000976795685865662578	t
29	1	Logica	2404377	191031	190	165	0.000852439042248156337	t
31	1	Ricoh UK	2404377	191031	211	154	0.000780399016440961094	t
32	1	SCC	2404377	191031	209	150	0.00075855639725547078	t
33	1	Cisco Systems	2404377	191031	198	149	0.000757839691213608329	t
37	1	EDS	2404377	191031	201	142	0.000716678377457636868	t
38	1	Krajowy Fundusz Kapitałowy SA	2404377	191031	168	139	0.000714528259332049514	t
39	1	BAE Systems Applied Intelligence	2404377	191031	190	139	0.000704588557179742581	t
40	1	EMC	2404377	191031	145	135	0.000702173537655579618	t
41	1	NCR Corporation	2404377	191031	156	130	0.000668770900989346562	t
42	1	Sony Computer Entertainment Europe	2404377	191031	161	129	0.00066082532065489725	t
43	1	Civica	2404377	191031	142	124	0.000640976823287264558	t
44	1	Wipro	2404377	191031	151	124	0.000636910581497684395	t
45	1	Symantec	2404377	191031	129	118	0.000612730940941895929	t
46	1	ASOS.com	2404377	191031	318	133	0.00061263822013095208	t
47	1	Insight	2404377	191031	146	119	0.000610736819124038308	t
48	1	Rackspace	2404377	191031	136	118	0.000609568308438889232	t
50	1	IT	2404377	191031	177	116	0.000579671203828103511	t
55	2	Mercedes-Benz UK Ltd	2404377	37729	251	167	0.00439081013636925029	t
57	2	BMW Group	2404377	37729	186	155	0.00409514695172190964	t
51	2	Jaguar Land Rover	2404377	37729	1847	1475	0.0389374113307586062	t
52	2	Ford Motor Company	2404377	37729	777	693	0.0183323405241346271	t
53	2	Bentley Motors Ltd	2404377	37729	246	208	0.00549694414493993692	t
54	2	Enterprise Rent-A-Car	2404377	37729	337	208	0.00545849313743903327	t
56	2	Euro Car Parts Ltd.	2404377	37729	207	157	0.00414012834063281262	t
58	2	Sytner Group	2404377	37729	166	146	0.00386125158009738246	t
59	2	Vauxhall Motors Ltd	2404377	37729	162	140	0.00370137763927068245	t
60	2	BMW	2404377	37729	162	132	0.00348595884593392918	t
61	2	Aston Martin Lagonda Ltd	2404377	37729	148	123	0.00324952824304560644	t
62	2	RAC	2404377	37729	172	118	0.00310475057215495263	t
63	2	Toyota	2404377	37729	133	117	0.0030943022262025317	t
64	2	Arnold Clark	2404377	37729	147	117	0.00308838668658700799	t
65	2	Nissan Motor Manufacturing Ltd.	2404377	37729	146	115	0.00303495452679678574	t
66	2	Cummins Inc.	2404377	37729	205	114	0.00298309740353569887	t
67	2	Lookers PLC	2404377	37729	127	110	0.00290834601329666891	t
68	2	McLaren Automotive Ltd	2404377	37729	122	96	0.00253347581767718148	t
69	2	Volkswagen Group UK Ltd	2404377	37729	122	96	0.00253347581767718148	t
70	2	Kwik-Fit	2404377	37729	113	94	0.00248342396623868738	t
71	2	Audi UK	2404377	37729	107	92	0.00243210449916829528	t
72	2	The AA	2404377	37729	264	92	0.00236576594776563608	t
73	2	Delphi Diesel Systems	2404377	37729	110	89	0.00235005483603511513	t
74	2	TRW	2404377	37729	99	85	0.00224699336335036463	t
75	2	Rolls-Royce Motor Cars	2404377	37729	94	82	0.00216832400856891263	t
76	2	Inchcape	2404377	37729	98	81	0.00213970650522595429	t
77	2	Evans Halshaw	2404377	37729	93	77	0.0020341098012774078	t
78	2	Ricardo	2404377	37729	94	74	0.00195290521523215936	t
79	2	BMW (UK) Manufacturing Ltd	2404377	37729	89	71	0.00187423586045070735	t
80	2	Honda of the UK Manufacturing Ltd.	2404377	37729	76	69	0.00182587416318807688	t
81	2	Lear Corporation	2404377	37729	82	67	0.00176948423359009279	t
82	2	Marshall Motor Group	2404377	37729	76	65	0.00171816476651970068	t
83	2	General Motors	2404377	37729	73	62	0.00163865033465031631	t
84	2	Pendragon PLC	2404377	37729	76	62	0.00163738271901841832	t
85	2	Jaguar Cars	2404377	37729	65	60	0.00158817594466785592	t
86	2	ATS Euromaster	2404377	37729	73	59	0.00155786828714903416	t
87	2	Andrew Page Ltd	2404377	37729	61	57	0.00150908405134243763	t
88	2	Renault	2404377	37729	67	57	0.00150654882007864163	t
89	2	Honda UK	2404377	37729	66	56	0.00148004400945551365	t
90	2	Michelin	2404377	37729	70	56	0.0014783538552796498	t
91	2	Toyota Motor Manufacturing UK	2404377	37729	60	55	0.00145565189155221538	t
92	2	IAC Group	2404377	37729	64	54	0.00142703438820925748	t
93	2	Land Rover	2404377	37729	63	53	0.00140052957758612928	t
94	2	PSA Peugeot Citroën	2404377	37729	65	53	0.00139968450049819735	t
95	2	The Automobile Association	2404377	37729	71	53	0.00139714926923440157	t
96	2	JCT600 Ltd	2404377	37729	55	52	0.00137698253677076316	t
97	2	Dava Projects Limited	2404377	37729	51	51	0.00135174534177953296	t
98	2	Bristol Street Motors	2404377	37729	57	51	0.00134921011051573718	t
99	2	Delphi	2404377	37729	59	50	0.0013214376842607112	t
100	2	Jaguar Land Rover North America	2404377	37729	46	46	0.00121922128866389242	t
151	8	National Health Service (NHS)	2404377	131062	41422	36036	0.272584611323438142	t
152	8	Bupa	2404377	131062	925	655	0.00487886542097522389	t
153	8	Care UK	2404377	131062	650	476	0.00355532867977866084	t
154	8	BMI Healthcare	2404377	131062	425	373	0.00282310720653556778	t
155	8	Barchester Healthcare	2404377	131062	340	307	0.00232788658614857449	t
156	8	NHS Direct	2404377	131062	324	303	0.0023026453144844917	t
157	8	NHS Professionals	2404377	131062	326	270	0.00203546006636994188	t
158	8	Nottingham University Hospital	2404377	131062	279	257	0.00195122650223458847	t
159	8	Spire Healthcare	2404377	131062	241	211	0.0015967284862667666	t
160	8	Priory Group	2404377	131062	277	206	0.00154054326694331501	t
161	8	Public Health England	2404377	131062	353	198	0.00144255300911012093	t
162	8	Nuffield Health	2404377	131062	490	192	0.00133386941610187052	t
163	8	Southend University Hospital	2404377	131062	169	162	0.0012329770139500552	t
164	8	Care Quality Commission	2404377	131062	228	163	0.00121509358836814456	t
165	8	University Hospital Birmingham	2404377	131062	175	158	0.00119805824488680018	t
166	8	Kings College Hospital	2404377	131062	194	156	0.00117356068042850188	t
167	8	Salford Royal Foundation Trust	2404377	131062	164	154	0.00117061754199563293	t
168	8	University College London Hospitals	2404377	131062	158	146	0.00110869795628662743	t
169	8	Four Seasons Healthcare	2404377	131062	151	138	0.00104721825682303911	t
170	8	NHS Blood and Transplant	2404377	131062	166	138	0.00104061996314178508	t
171	8	GE Healthcare	2404377	131062	282	143	0.00102994247316186261	t
172	8	London Ambulance Service	2404377	131062	164	135	0.00101729014693955396	t
173	8	Moorfields Eye Hospital, London	2404377	131062	151	133	0.00100686894233459725	t
174	8	East of England Ambulance Trust	2404377	131062	144	132	0.00100187828315482738	t
175	8	Central Manchester & Manchester Children's Foundation Trust	2404377	131062	141	129	0.000978988353198013018	t
176	8	Litfield House	2404377	131062	124	121	0.000921907516188593952	t
177	8	Four Seasons Health Care	2404377	131062	140	121	0.000914869336261923049	t
178	8	HCA	2404377	131062	152	121	0.000909590701316919737	t
179	8	Ramsay Health Care	2404377	131062	136	120	0.000908559018345902244	t
180	8	Nottinghamshire Healthcare	2404377	131062	127	115	0.000872168680066212859	t
181	8	Sunrise Senior Living	2404377	131062	131	110	0.000830059820596103183	t
182	8	Brighton & Sussex University Hospitals NHS Trust	2404377	131062	116	109	0.000828588251379668928	t
183	8	HC-One	2404377	131062	140	107	0.00080189125569428562	t
184	8	St John Ambulance	2404377	131062	196	109	0.000793397351746314089	t
185	8	Solent NHS Trust	2404377	131062	125	105	0.00079234982358016297	t
186	8	Bluebird Care	2404377	131062	124	104	0.000784719846927891445	t
187	8	North East London NHS Foundation Trust	2404377	131062	133	103	0.000772691007821450673	t
188	8	Yorkshire Ambulance Service NHS Trust	2404377	131062	120	102	0.000770339666114182461	t
189	8	UHSM - University Hospital of South Manchester NHS FT	2404377	131062	118	101	0.000763149575707327914	t
190	8	The Ipswich Hospital NHS Trust	2404377	131062	105	100	0.000760798234000059702	t
191	8	Pennine Care NHS Foundation Trust	2404377	131062	120	99	0.000746130077421117274	t
192	8	Salisbury NHS Foundation Trust	2404377	131062	111	98	0.000742019190732181363	t
193	8	Northampton General Hospital	2404377	131062	103	97	0.000737468417797828364	t
194	8	Private	2404377	131062	1393	167	0.000734905564048168739	t
195	8	HCA International Ltd	2404377	131062	126	97	0.000727351034153238935	t
196	8	York Teaching Hospital NHS Foundation Trust	2404377	131062	111	96	0.000725879464936804572	t
197	8	Oxford Health NHS Foundation Trust	2404377	131062	125	95	0.000711651194603279123	t
198	8	West Midlands Ambulance Service NHS Trust	2404377	131062	105	93	0.000704309193716241041	t
199	8	GP Surgery	2404377	131062	116	93	0.000699470445016654708	t
200	8	Wrightington, Wigan & Leigh NHS Foundation Trust	2404377	131062	99	92	0.000698878648291054302	t
209	9	EY	2404377	204323	1496	1075	0.00506991854774449958	t
201	9	Royal Bank of Scotland	2404377	204323	4175	3591	0.0173096658828633676	t
202	9	Post Office	2404377	204323	639	255	0.00107348279170698031	t
203	9	HSBC	2404377	204323	4278	3820	0.0184877116644315796	t
204	9	Barclays	2404377	204323	6016	5315	0.0256941061958706786	t
205	9	PwC	2404377	204323	2439	1880	0.00894703316546594657	t
206	9	KPMG	2404377	204323	1941	1427	0.00675040934685410161	t
231	9	JPMorgan Chase	2404377	204323	477	409	0.00197082421866200987	t
241	9	Standard Life	2404377	204323	365	317	0.0015296474359530899	t
207	9	Deutsche Bank	2404377	204323	1498	1246	0.00598364503039440759	t
208	9	Lloyds	2404377	204323	4630	3711	0.0177447022870128278	t
210	9	Citi	2404377	204323	1226	1041	0.00501078544708266106	t
211	9	J.P. Morgan	2404377	204323	1173	1034	0.00499743454346975556	t
212	9	Nationwide Building Society	2404377	204323	1153	977	0.00470164671234381357	t
213	9	Goldman Sachs	2404377	204323	1131	965	0.00464746151593069604	t
214	9	Deloitte	2404377	204323	2168	1041	0.00458261413856023321	t
215	9	Credit Suisse	2404377	204323	1107	941	0.00453000043714857185	t
216	9	Morgan Stanley	2404377	204323	937	797	0.00383705185619848252	t
217	9	Aviva	2404377	204323	1266	798	0.00369285881813780558	t
218	9	BNP Paribas	2404377	204323	730	632	0.0030485973800787468	t
219	9	NatWest	2404377	204323	891	855	0.00416818769689257865	t
220	9	Citigroup	2404377	204323	235	209	0.00101107233598500914	t
221	9	Ernst & Young	2404377	204323	715	543	0.00257937700822490849	t
222	9	Grant Thornton UK LLP	2404377	204323	574	516	0.00249905020454359262	t
223	9	Bank of America Merrill Lynch	2404377	204323	915	783	0.00377216916795793285	t
224	9	Santander	2404377	204323	1524	1367	0.00661902539421142973	t
225	9	American Express	2404377	204323	626	493	0.00235239326504280187	t
226	9	Barclaycard	2404377	204323	560	457	0.00218983767580345099	t
227	9	UBS	2404377	204323	1010	840	0.00403386692674928722	t
228	9	Lloyds TSB	2404377	204323	620	581	0.00282581011123660825	t
229	9	Financial Ombudsman Service	2404377	204323	321	228	0.00107360855873529239	t
230	9	Bank of America	2404377	204323	480	411	0.00198015810759605889	t
232	9	RSM UK	2404377	204323	262	226	0.00108972859047773559	t
233	9	St. James's Place Wealth Management	2404377	204323	375	347	0.00168556447038663553	t
234	9	BDO LLP	2404377	204323	427	378	0.00182773981022652811	t
235	9	BNY Mellon	2404377	204323	400	365	0.001770478539388667	t
236	9	BlackRock	2404377	204323	422	364	0.0017551300389234718	t
237	9	Legal & General	2404377	204323	478	367	0.0017457223559881282	t
238	9	Standard Chartered Bank	2404377	204323	401	358	0.00173258278369485801	t
239	9	Schroders	2404377	204323	238	214	0.00103645246266020744	t
240	9	Halifax	2404377	204323	340	326	0.00158914950662139977	t
242	9	Bank of England	2404377	204323	387	281	0.00132709282850782158	t
243	9	Nomura	2404377	204323	443	379	0.00182581600737553233	t
244	9	Financial Conduct Authority	2404377	204323	320	230	0.00108476058486051954	t
245	9	State Street	2404377	204323	244	227	0.00110325895375175311	t
246	9	European Bank for Reconstruction and Development (EBRD)	2404377	204323	282	209	0.000989709223988667315	t
247	9	TSB Bank	2404377	204323	300	259	0.00124896490231418428	t
248	9	Bloomberg LP	2404377	204323	378	262	0.00122955746482736154	t
249	9	PricewaterhouseCoopers	2404377	204323	322	246	0.00116943145088439218	t
250	9	Coutts	2404377	204323	247	237	0.00115538280999553326	t
251	10	Imperial College London	2411262	7728	1986	79	0.00942915225808258275	t
252	10	University of Cambridge	2411262	7728	1754	75	0.00900641423257875912	t
253	10	Thermo Fisher Scientific	2411262	7728	284	64	0.00819004161300022036	t
254	10	MedImmune	2411262	7728	102	58	0.00748686960624393629	t
255	10	University College London	2411262	7728	1999	64	0.00747650895650357836	t
256	10	Amgen	2411262	7728	110	47	0.00605556913459423703	t
257	10	University of Oxford	2411262	7728	1740	49	0.00563703235029896794	t
258	10	Life Technologies	2411262	7728	47	43	0.00556251797850852974	t
259	10	University of Manchester	2411262	7728	2332	50	0.00552054400619725154	t
260	10	Fujifilm Diosynth Biotechnologies	2411262	7728	44	40	0.00517431922074455472	t
261	10	Illumina	2411262	7728	60	39	0.00503784671636233004	t
262	10	University of Edinburgh	2411262	7728	1427	42	0.00485854778114588534	t
263	10	University of Leeds	2411262	7728	1618	42	0.00477908146196754247	t
264	10	University of Sheffield	2411262	7728	1375	41	0.00475036695060725937	t
265	10	King's College London	2411262	7728	1561	39	0.00441334962166760152	t
266	10	Lonza	2411262	7728	66	34	0.00438627219245747626	t
267	10	University of Glasgow	2411262	7728	1121	37	0.00433678211369989582	t
268	10	Roche	2411262	7728	188	34	0.00433551360114984349	t
269	10	Abcam	2411262	7728	52	33	0.00426228130888860364	t
270	10	Agilent Technologies	2411262	7728	77	30	0.00386243303836549933	t
271	10	Sigma Aldrich	2411262	7728	42	29	0.00374717928936597368	t
272	10	BioReliance	2411262	7728	36	28	0.00361985997358020735	t
273	10	LGC	2411262	7728	94	26	0.00333609756011085277	t
274	10	Pall Corporation	2411262	7728	71	24	0.00308603552283754886	t
275	10	University of Bristol	2411262	7728	1106	27	0.00304486652462220399	t
276	10	Gilead Sciences	2411262	7728	89	23	0.00294873091040110096	t
277	10	University of Birmingham	2411262	7728	1364	26	0.00280770894567893697	t
278	10	QIAGEN	2411262	7728	36	20	0.00258133485399271315	t
279	10	The University of Nottingham	2411262	7728	1671	25	0.002550164719407195	t
280	10	SIZAM TRADING INNOVATIONS LLC	2411262	7728	19	19	0.002458592132505176	t
281	10	Bio-Rad Laboratories	2411262	7728	29	17	0.00219480031233718498	t
282	10	Pall Life Sciences	2411262	7728	21	16	0.0020683131046056423	t
283	10	Lonza: A Global Leader In Life Sciences	2411262	7728	27	16	0.0020658167804429718	t
284	10	Thermofisher Scientific	2411262	7728	29	16	0.00206498467238874816	t
285	10	GE Healthcare	2411262	7728	283	16	0.00195930694950236526	t
286	10	PerkinElmer	2411262	7728	39	15	0.00193100849216919397	t
287	10	University of Southampton	2411262	7728	1307	19	0.00192271454558524892	t
288	10	University of Leicester	2411262	7728	821	17	0.00186528552286468335	t
289	10	Wellcome Trust Centre for Human Genetics, University of Oxford	2411262	7728	21	13	0.00167886618476033181	t
290	10	John Innes Centre	2411262	7728	65	13	0.0016605598075674151	t
291	10	University of York	2411262	7728	690	15	0.001660157320519448	t
292	10	Wellcome Trust Sanger Institute	2411262	7728	93	13	0.00164891029480828625	t
293	10	University of Bath	2411262	7728	721	15	0.00164725964567898411	t
294	10	University of Exeter	2411262	7728	1057	16	0.00163728113251787469	t
295	10	Aston University	2411262	7728	469	14	0.00162228962056270697	t
296	10	GSK	2411262	7728	1197	16	0.00157903356872223042	t
297	10	Oxford Nanopore Technologies	2411262	7728	23	12	0.00154821843675767134	t
298	10	Alere Toxicology Plc	2411262	7728	24	12	0.00154780238273055952	t
299	10	bioMerieux	2411262	7728	13	11	0.00142256333708035208	t
300	10	The Binding Site	2411262	7728	15	11	0.00142173122902612844	t
301	11	Babcock International Group	2411262	34783	963	443	0.0125172956121159546	t
302	11	Caterpillar Inc.	2411262	34783	267	182	0.00519667393490628061	t
303	11	JCB	2411262	34783	182	122	0.00348221310568235963	t
304	11	Siemens	2411262	34783	617	101	0.00268658938885564655	t
305	11	Johnson Controls	2411262	34783	237	90	0.00252561467425542214	t
306	11	Parker Hannifin	2411262	34783	128	87	0.00248396944707324945	t
307	11	Finning (UK)	2411262	34783	102	76	0.00217403486369236332	t
308	11	KONE	2411262	34783	105	73	0.00208526109045529184	t
309	11	3M	2411262	34783	178	71	0.00199620244308982338	t
310	11	ERIKS	2411262	34783	91	67	0.00191612935577666716	t
311	11	Rolls-Royce	2411262	34783	1329	78	0.00171606574434918398	t
312	11	Crown House Technologies	2411262	34783	94	55	0.0015648213781363652	t
313	11	Jaguar Land Rover	2411262	34783	1848	79	0.00152684589541141535	t
314	11	Emerson Process Management	2411262	34783	89	51	0.00145024346246158654	t
315	11	Rockwell Automation	2411262	34783	68	45	0.00128405726191139309	t
316	11	Honeywell Process Solutions	2411262	34783	57	43	0.00123034502408709873	t
317	11	Stork	2411262	34783	135	44	0.00122669382524049448	t
318	11	Spirax Sarco	2411262	34783	50	41	0.00117494962390370106	t
319	11	Exova Group Limited	2411262	34783	81	41	0.00116190511562064866	t
320	11	Loughborough University	2411262	34783	745	50	0.001145034368412693	t
321	11	Stork Technical Services	2411262	34783	125	41	0.00114339032967050985	t
322	11	SSE Contracting	2411262	34783	63	38	0.00108196794476887108	t
323	11	Nuvia Limited	2411262	34783	62	37	0.00105321826820273245	t
324	11	The University of Nottingham	2411262	34783	1671	60	0.00104708695383937079	t
325	11	Gardner Denver	2411262	34783	40	36	0.00103330519402188709	t
326	11	Terex Corporation	2411262	34783	51	36	0.00102867649753435233	t
327	11	Konecranes	2411262	34783	40	35	0.00100413472686597264	t
328	11	Renishaw	2411262	34783	119	36	0.00100006273742959235	t
329	11	Cavendish Nuclear	2411262	34783	74	35	0.000989827846813592536	t
330	11	Imperial College London	2411262	34783	1986	62	0.000972878852371796888	t
331	11	Brammer Group	2411262	34783	49	34	0.000971177144402075084	t
332	11	Linde Material Handling	2411262	34783	51	34	0.00097033556322252332	t
333	11	Aker Solutions	2411262	34783	352	38	0.000960359464323640882	t
334	11	ABB	2411262	34783	256	36	0.000942414426630296446	t
335	11	Cummins Inc.	2411262	34783	206	35	0.0009342834889631761	t
336	11	Tyco International	2411262	34783	40	32	0.000916623325398229177	t
337	11	The Royal Mint	2411262	34783	48	30	0.000854916066368193004	t
338	11	Frazer-Nash Consultancy	2411262	34783	54	30	0.000852391322829537711	t
339	11	Flowserve	2411262	34783	33	29	0.000832057458058916731	t
340	11	NSK	2411262	34783	35	29	0.000831215876879364966	t
341	11	Emerson	2411262	34783	42	29	0.000828270342750933738	t
342	11	AGCO Corporation	2411262	34783	45	29	0.000827007970981606146	t
343	11	TR Fastenings	2411262	34783	29	28	0.000804570153262105701	t
344	11	Howden	2411262	34783	45	28	0.000797837503825691587	t
345	11	Bilfinger	2411262	34783	69	28	0.000787738529671070417	t
346	11	Norgren	2411262	34783	30	27	0.000774978895516415314	t
347	11	Ishida Europe Ltd	2411262	34783	32	27	0.00077413731433686355	t
348	11	University of Bristol	2411262	34783	1106	41	0.000730594761100368919	t
349	11	Siemens Industry	2411262	34783	31	25	0.000716217170614810478	t
350	11	Space Engineering Services Ltd	2411262	34783	33	25	0.000715375589435258714	t
351	12	Apple	2411262	27806	709	280	0.0098897783784384543	t
352	12	Schneider Electric	2411262	27806	276	183	0.00654229441482837622	t
353	12	Siemens	2411262	27806	617	147	0.00508943613716749451	t
354	12	ABB	2411262	27806	256	133	0.00473153459388833599	t
355	12	Samsung Electronics	2411262	27806	224	128	0.0045630453765594459	t
356	12	ARM	2411262	27806	195	109	0.00388393520346801222	t
357	12	RS Components	2411262	27806	198	105	0.00373714444719549111	t
358	12	Sony	2411262	27806	164	100	0.00356949434751760875	t
359	12	Dyson	2411262	27806	255	99	0.00349493147444776033	t
360	12	Silverfishtm.com	2411262	27806	115	90	0.0032262225304772723	t
361	12	Honeywell	2411262	27806	182	84	0.00297981396947450327	t
362	12	GE	2411262	27806	226	72	0.00252475714176430806	t
363	12	Intel Corporation	2411262	27806	134	67	0.00238144145396564609	t
364	12	AJP ELECTRICAL LTD	2411262	27806	71	63	0.00226234158017637674	t
365	12	TE Connectivity	2411262	27806	90	61	0.00218160392259379981	t
366	12	Canon Europe Ltd.	2411262	27806	133	61	0.00216356289309713613	t
367	12	Alstom Grid	2411262	27806	80	60	0.00214941649089983545	t
368	12	Renishaw	2411262	27806	119	58	0.00206028765680718248	t
369	12	Self employed electrical engineer	2411262	27806	65	56	0.00201017779348638308	t
370	12	Eaton	2411262	27806	97	49	0.00174207077142724486	t
371	12	e2v	2411262	27806	58	47	0.00168566752572388875	t
372	12	Imagination Technologies	2411262	27806	85	47	0.00167433943743528608	t
373	12	Sony Electronics	2411262	27806	55	45	0.0016141601623023956	t
374	12	GE Power Conversion	2411262	27806	67	44	0.00157274243644734747	t
375	12	Samsung	2411262	27806	87	41	0.00145520220009026451	t
376	12	Future Electronics	2411262	27806	47	39	0.00139921851321241205	t
377	12	Philips	2411262	27806	114	39	0.00137110807190365708	t
378	12	TT Electronics	2411262	27806	47	38	0.00136283549326340989	t
379	12	City Electrical Factors	2411262	27806	102	38	0.00133975975786070046	t
380	12	LG Electronics	2411262	27806	49	37	0.00132561335566339978	t
381	12	SBE Ltd	2411262	27806	43	36	0.00129174768866742039	t
382	12	Oxford Instruments	2411262	27806	64	36	0.00128293695333184048	t
383	12	Jabil	2411262	27806	40	35	0.00125662334519492918	t
384	12	NXP Semiconductors	2411262	27806	38	33	0.00118469642294793216	t
385	12	Landis+Gyr	2411262	27806	48	33	0.00118050083469289414	t
386	12	Emerson Network Power	2411262	27806	52	33	0.00117882259939087889	t
387	12	Panasonic	2411262	27806	64	33	0.00117378789348483335	t
388	12	Eaton Corporation	2411262	27806	52	32	0.00114243957944187673	t
389	12	Philips Lighting	2411262	27806	43	31	0.0011098325889224085	t
390	12	Retired	2411262	27806	3052	65	0.001084402761247535	t
391	12	Flextronics	2411262	27806	38	29	0.00103916434315192308	t
392	12	Edwards	2411262	27806	59	29	0.00103035360781634296	t
393	12	Premier Farnell	2411262	27806	47	28	0.000999005293773386335	t
394	12	CSR	2411262	27806	50	28	0.000997746617296874951	t
395	12	University of Manchester	2411262	27806	2332	53	0.000949888876222247506	t
396	12	Edmundson Electrical	2411262	27806	95	27	0.000942483450200201373	t
397	12	Arrow Electronics	2411262	27806	56	26	0.000922463224445847535	t
398	12	Pace	2411262	27806	57	26	0.000922043665620343668	t
399	12	International Rectifier	2411262	27806	27	25	0.00089824741043645546	t
400	12	Broadcom	2411262	27806	36	25	0.000894471381006921198	t
\.


--
-- Name: sector_company_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geektalent
--

SELECT pg_catalog.setval('sector_company_id_seq', 400, true);


--
-- Name: sector_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geektalent
--

SELECT pg_catalog.setval('sector_id_seq', 12, true);


--
-- Data for Name: sector_institute; Type: TABLE DATA; Schema: public; Owner: geektalent
--

COPY sector_institute (id, sector_id, institute_name, count, visible) FROM stdin;
1	1	The Open University	1195	t
2	1	The University of Manchester	802	t
3	1	Sheffield Hallam University	765	t
4	1	Kingston University	761	t
5	1	University of Greenwich	750	t
6	1	University of Portsmouth	733	t
7	1	University of Westminster	702	t
8	1	Middlesex University	693	t
9	1	University of Hertfordshire	666	t
10	1	Staffordshire University	599	t
11	1	Bournemouth University	592	t
12	1	Imperial College London	584	t
13	1	De Montfort University	568	t
14	1	University of Leeds	551	t
15	1	Coventry University	528	t
16	1	University of Southampton	528	t
17	1	The University of Birmingham	511	t
18	1	University of the West of England	509	t
19	1	University of Cambridge	488	t
20	1	The Manchester Metropolitan University	469	t
21	1	University of Nottingham	466	t
22	1	University of East London	462	t
23	1	University of Teesside	462	t
24	1	City University London	460	t
25	1	University of Oxford	455	t
26	1	London Metropolitan University	448	t
27	1	Nottingham Trent University	443	t
28	1	The University of Sheffield	440	t
29	1	Northumbria University	424	t
30	1	The University of Salford	419	t
31	1	University of Bristol	409	t
32	1	The University of Edinburgh	401	t
33	1	University of Central Lancashire	399	t
34	1	University of Ulster	396	t
35	1	University of Warwick	394	t
36	1	Birmingham City University	394	t
37	1	Loughborough University	385	t
38	1	University of Kent	376	t
39	1	University of Plymouth	374	t
40	1	Queen Mary, U. of London	365	t
41	1	The University of Glasgow	357	t
42	1	University of Surrey	356	t
43	1	University of Sunderland	356	t
44	1	Queen's University Belfast	350	t
45	1	Liverpool John Moores University	348	t
46	1	University of Reading	348	t
47	1	The University of Huddersfield	343	t
48	1	Lancaster University	342	t
49	1	Brunel University	340	t
50	1	University of Liverpool	339	t
51	2	Coventry University	383	t
52	2	Loughborough University	219	t
53	2	University of Hertfordshire	145	t
54	2	The Open University	125	t
55	2	Oxford Brookes University	117	t
56	2	University of Warwick	99	t
57	2	Sheffield Hallam University	86	t
58	2	The University of Birmingham	82	t
59	2	Birmingham City University	73	t
60	2	Kingston University	70	t
61	2	Staffordshire University	66	t
62	2	The University of Huddersfield	66	t
63	2	Cranfield University	66	t
64	2	University of Bath	61	t
65	2	Brunel University	60	t
66	2	The University of Wolverhampton	59	t
67	2	Nottingham Trent University	59	t
68	2	The Manchester Metropolitan University	58	t
69	2	De Montfort University	57	t
70	2	The University of Manchester	56	t
71	2	The University of Sheffield	56	t
72	2	University of Leeds	56	t
73	2	Aston University	54	t
74	2	Northumbria University	53	t
75	2	University of Southampton	50	t
76	2	University of Bradford	49	t
77	2	University of Portsmouth	47	t
78	2	Imperial College London	46	t
79	2	University of Derby	44	t
80	2	The University of Salford	44	t
81	2	University of the West of England	43	t
82	2	University of Liverpool	41	t
83	2	Anglia Ruskin University	41	t
84	2	University of Leicester	41	t
85	2	University of Nottingham	41	t
86	2	Bournemouth University	40	t
87	2	Brunel University London	39	t
88	2	Liverpool John Moores University	38	t
89	2	University of Cambridge	38	t
90	2	University of Teesside	38	t
91	2	University of Sunderland	37	t
92	2	The University of Hull	37	t
93	2	University of Central Lancashire	35	t
94	2	The University of Northampton	35	t
95	2	Middlesex University	34	t
96	2	University of Greenwich	33	t
97	2	Southampton Solent University	32	t
98	2	Cardiff University / Prifysgol Caerdydd	32	t
99	2	University of Strathclyde	32	t
100	2	Leeds Metropolitan University	31	t
151	8	The University of Manchester	557	t
152	8	King's College London	553	t
153	8	The University of Birmingham	460	t
154	8	The Open University	444	t
155	8	University of Nottingham	410	t
156	8	University of Leeds	366	t
157	8	University of Southampton	326	t
158	8	Imperial College London	318	t
159	8	University of Hertfordshire	318	t
160	8	The University of Sheffield	298	t
161	8	Sheffield Hallam University	297	t
162	8	UCL	292	t
163	8	Middlesex University	283	t
164	8	University of Liverpool	283	t
165	8	Anglia Ruskin University	281	t
166	8	London South Bank University	281	t
167	8	Cardiff University / Prifysgol Caerdydd	271	t
168	8	City University London	269	t
169	8	University of the West of England	259	t
170	8	Coventry University	257	t
171	8	University of Cambridge	249	t
172	8	The University of Salford	246	t
173	8	The University of Glasgow	237	t
174	8	Glasgow Caledonian University	229	t
175	8	University of Brighton	225	t
176	8	Oxford Brookes University	220	t
177	8	Kingston University	218	t
178	8	The Manchester Metropolitan University	218	t
179	8	The University of Edinburgh	216	t
180	8	University of Oxford	216	t
181	8	University of Surrey	213	t
182	8	University of Greenwich	208	t
183	8	University of Bradford	202	t
184	8	University of Bristol	201	t
185	8	De Montfort University	199	t
186	8	Northumbria University	197	t
187	8	University of Central Lancashire	196	t
188	8	The University of Wolverhampton	189	t
189	8	University of Plymouth	185	t
190	8	Birmingham City University	185	t
191	8	University of Westminster	177	t
192	8	University of Leicester	173	t
193	8	The University of Dundee	173	t
194	8	University of East Anglia	172	t
195	8	St. George's, U. of London	170	t
196	8	Liverpool John Moores University	167	t
197	8	University of Teesside	165	t
198	8	Aston University	162	t
199	8	University of Portsmouth	161	t
200	8	The University of Huddersfield	160	t
201	9	The London School of Economics and Political Science (LSE)	1530	t
202	9	The University of Manchester	1152	t
203	9	University of Oxford	1084	t
204	9	University of Cambridge	1036	t
205	9	Institute of Chartered Accountants in England and Wales	980	t
206	9	Cass Business School	914	t
207	9	Imperial College London	890	t
208	9	University of Exeter	863	t
209	9	The University of Birmingham	855	t
210	9	University of Leeds	854	t
211	9	University of Warwick	828	t
212	9	University of Nottingham	808	t
213	9	Durham University	743	t
214	9	University of Bristol	741	t
215	9	University of Westminster	662	t
216	9	The University of Edinburgh	648	t
217	9	London Business School	625	t
218	9	University of Southampton	613	t
219	9	Queen Mary, U. of London	580	t
220	9	Loughborough University	568	t
221	9	The Open University	568	t
222	9	London Metropolitan University	565	t
223	9	ACCA	557	t
224	9	Kingston University	532	t
225	9	The University of Glasgow	530	t
226	9	The Chartered Institute of Management Accountants	520	t
227	9	Middlesex University	517	t
228	9	University of Bath	516	t
229	9	The Manchester Metropolitan University	515	t
230	9	The University of Sheffield	513	t
231	9	University of Greenwich	501	t
232	9	University of Reading	482	t
233	9	University of Hertfordshire	480	t
234	9	Lancaster University	478	t
235	9	Oxford Brookes University	472	t
236	9	University of Kent	464	t
237	9	University of Strathclyde	462	t
238	9	University of Leicester	447	t
239	9	Cardiff University / Prifysgol Caerdydd	444	t
240	9	Sheffield Hallam University	443	t
241	9	University of the West of England	443	t
242	9	University of Portsmouth	431	t
243	9	University of Liverpool	427	t
244	9	Nottingham Trent University	418	t
245	9	Coventry University	405	t
246	9	Bournemouth University	399	t
247	9	De Montfort University	396	t
248	9	University College London, U. of London	394	t
249	9	UCL	391	t
250	9	King's College London	390	t
251	10	University of Cambridge	146	t
252	10	Imperial College London	125	t
253	10	The University of Manchester	100	t
254	10	The University of Glasgow	85	t
255	10	The University of Sheffield	81	t
256	10	University of Oxford	79	t
257	10	University of Nottingham	76	t
258	10	UCL	75	t
259	10	University of Leeds	75	t
260	10	The University of Edinburgh	67	t
261	10	The University of Birmingham	60	t
262	10	University College London, U. of London	56	t
263	10	University of Bristol	49	t
264	10	University of Strathclyde	49	t
265	10	University of Southampton	42	t
266	10	University of Bath	39	t
267	10	University of Leicester	36	t
268	10	King's College London	35	t
269	10	The Open University	35	t
270	10	University of Liverpool	34	t
271	10	University of East Anglia	34	t
272	10	Nottingham Trent University	32	t
273	10	Cardiff University / Prifysgol Caerdydd	32	t
274	10	University of York	31	t
275	10	Lancaster University	31	t
276	10	University of Warwick	30	t
277	10	University of Hertfordshire	30	t
278	10	Newcastle University	30	t
279	10	Queen Mary, U. of London	28	t
280	10	University of Surrey	28	t
281	10	University of Reading	28	t
282	10	Sheffield Hallam University	25	t
283	10	The University of Salford	24	t
284	10	University of Teesside	24	t
285	10	Glasgow Caledonian University	24	t
286	10	University of Ulster	23	t
287	10	Northumbria University	22	t
288	10	The University of Wolverhampton	22	t
289	10	University of the West of England	22	t
290	10	Kingston University	22	t
291	10	University of Exeter	22	t
292	10	University of Westminster	21	t
293	10	University of Aberdeen	21	t
294	10	Heriot-Watt University	21	t
295	10	The Manchester Metropolitan University	21	t
296	10	University of Kent	20	t
297	10	The University of Dundee	20	t
298	10	University of East London	19	t
299	10	Anglia Ruskin University	19	t
300	10	Aston University	19	t
301	11	Loughborough University	198	t
302	11	Sheffield Hallam University	167	t
303	11	The University of Manchester	163	t
304	11	The Open University	161	t
305	11	Imperial College London	150	t
306	11	University of Nottingham	148	t
307	11	The University of Sheffield	137	t
308	11	Coventry University	137	t
309	11	University of Leeds	131	t
310	11	University of Bath	120	t
311	11	University of Strathclyde	114	t
312	11	University of Bristol	107	t
313	11	The University of Huddersfield	107	t
314	11	University of Portsmouth	105	t
315	11	Cranfield University	104	t
316	11	The University of Birmingham	104	t
317	11	University of Cambridge	91	t
318	11	University of Southampton	87	t
319	11	University of Warwick	86	t
320	11	University of Liverpool	85	t
321	11	Kingston University	84	t
322	11	Northumbria University	84	t
323	11	The Manchester Metropolitan University	83	t
324	11	University of Teesside	81	t
325	11	Glasgow Caledonian University	75	t
326	11	Brunel University	74	t
327	11	Brunel University London	74	t
328	11	Staffordshire University	73	t
329	11	De Montfort University	69	t
330	11	Heriot-Watt University	67	t
331	11	University of Hertfordshire	67	t
332	11	University of the West of England	67	t
333	11	The University of Glasgow	65	t
334	11	University of Plymouth	65	t
335	11	University of Bradford	65	t
336	11	University of Central Lancashire	62	t
337	11	Cardiff University / Prifysgol Caerdydd	61	t
338	11	Birmingham City University	60	t
339	11	University of Leicester	59	t
340	11	The University of Salford	59	t
341	11	Queen's University Belfast	58	t
342	11	University of Ulster	57	t
343	11	Aston University	55	t
344	11	Swansea University	55	t
345	11	London South Bank University	54	t
346	11	University of Derby	54	t
347	11	University of Surrey	52	t
348	11	Nottingham Trent University	51	t
349	11	Lancaster University	49	t
350	11	Liverpool John Moores University	48	t
351	12	The University of Manchester	163	t
352	12	The Open University	126	t
353	12	University of Southampton	126	t
354	12	Imperial College London	107	t
355	12	University of Strathclyde	100	t
356	12	University of Nottingham	98	t
357	12	The University of Birmingham	88	t
358	12	The University of Sheffield	86	t
359	12	University of Leeds	85	t
360	12	Loughborough University	81	t
361	12	Staffordshire University	75	t
362	12	Sheffield Hallam University	73	t
363	12	University of Hertfordshire	73	t
364	12	University of Cambridge	72	t
365	12	University of Portsmouth	71	t
366	12	Coventry University	69	t
367	12	The University of Edinburgh	66	t
368	12	University of Surrey	62	t
369	12	De Montfort University	62	t
370	12	University of the West of England	60	t
371	12	University of Bath	59	t
372	12	University of Westminster	57	t
373	12	The University of Huddersfield	55	t
374	12	University of Bristol	53	t
375	12	University of Greenwich	53	t
376	12	University of Liverpool	52	t
377	12	University of Warwick	52	t
378	12	Brunel University London	51	t
379	12	Glasgow Caledonian University	51	t
380	12	The University of Glasgow	50	t
381	12	London South Bank University	49	t
382	12	Northumbria University	49	t
383	12	The Manchester Metropolitan University	48	t
384	12	Liverpool John Moores University	47	t
385	12	Queen's University Belfast	47	t
386	12	The University of Salford	46	t
387	12	University of Plymouth	46	t
388	12	Kingston University	45	t
389	12	University of Bradford	44	t
390	12	University of Teesside	44	t
391	12	Aston University	43	t
392	12	Lancaster University	43	t
393	12	University of Ulster	43	t
394	12	University of Leicester	42	t
395	12	Nottingham Trent University	42	t
396	12	Brunel University	41	t
397	12	Bournemouth University	41	t
398	12	University of Reading	40	t
399	12	University of Brighton	40	t
400	12	Cardiff University / Prifysgol Caerdydd	40	t
\.


--
-- Name: sector_institute_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geektalent
--

SELECT pg_catalog.setval('sector_institute_id_seq', 400, true);


--
-- Data for Name: sector_skill; Type: TABLE DATA; Schema: public; Owner: geektalent
--

COPY sector_skill (id, sector_id, skill_name, total_count, sector_count, skill_count, count, relevance_score, visible) FROM stdin;
1	1	SQL	2404377	191031	25889	16965	0.0847756710970910959	t
46	1	Program Management	2404377	191031	45059	9132	0.0315717741798667989	t
2	1	Business Analysis	2404377	191031	54180	17852	0.0770376420975477372	t
3	1	ITIL	2404377	191031	23433	14048	0.0692976161877507657	t
4	1	Cloud Computing	2404377	191031	17567	13046	0.0662499719930184916	t
5	1	Requirements Analysis	2404377	191031	20932	12462	0.0614087000114375212	t
6	1	Integration	2404377	191031	24997	12647	0.0606241272033101047	t
7	1	IT Service Management	2404377	191031	18845	12003	0.0597414865848075113	t
8	1	Software Development	2404377	191031	16846	11742	0.0591604526589354293	t
9	1	Agile Methodologies	2404377	191031	16266	11415	0.0575629951744505083	t
10	1	Java	2404377	191031	17689	11397	0.0568177191389292735	t
11	1	Javascript	2404377	191031	14420	10998	0.0560257322277450814	t
12	1	Microsoft SQL Server	2404377	191031	15612	10692	0.0537470946148344841	t
13	1	HTML	2404377	191031	24008	11304	0.0534339157860252573	t
14	1	Project Management	2404377	191031	172911	22950	0.0523844931831220634	t
15	1	IT Strategy	2404377	191031	18341	10446	0.0511152266922732246	t
16	1	Project Delivery	2404377	191031	36251	10793	0.0449966408509603066	t
17	1	Windows Server	2404377	191031	12924	8895	0.0447428023549144849	t
18	1	CSS	2404377	191031	13009	8646	0.0432884462378491583	t
19	1	XML	2404377	191031	10791	8360	0.0426641936009064596	t
20	1	Data Center	2404377	191031	12148	8335	0.0419089307720160384	t
21	1	Active Directory	2404377	191031	12656	8359	0.0418158913840587926	t
22	1	Service Delivery	2404377	191031	18949	8788	0.0414122177674845424	t
23	1	Solution Selling	2404377	191031	15920	8504	0.0411657518104833753	t
24	1	CRM	2404377	191031	35579	9902	0.040233531179096782	t
25	1	Business Intelligence	2404377	191031	15875	8321	0.0401454430668343604	t
26	1	Solution Architecture	2404377	191031	11236	7945	0.0401032193306672877	t
27	1	Virtualization	2404377	191031	9930	7833	0.0400563817975819053	t
28	1	Linux	2404377	191031	11640	7838	0.0393122286431517656	t
29	1	Enterprise Software	2404377	191031	9864	7656	0.0390796802941500154	t
30	1	Software Project Management	2404377	191031	11519	7611	0.0380760485391998457	t
31	1	C#	2404377	191031	9935	7469	0.0379842159834076834	t
32	1	SAAS	2404377	191031	9495	7284	0.0371309969596208753	t
33	1	Databases	2404377	191031	14094	7562	0.036634010283953862	t
34	1	Pre Sales	2404377	191031	10510	7254	0.0365018185331444228	t
35	1	MySQL	2404377	191031	9182	7099	0.0362203987461366603	t
36	1	Networking	2404377	191031	19000	7834	0.0359642002400897415	t
37	1	Outsourcing	2404377	191031	24418	8231	0.0357738858586148234	t
38	1	Managed Services	2404377	191031	14112	7374	0.0355568050621877102	t
39	1	Web Development	2404377	191031	10684	6962	0.03476272984675189	t
40	1	VMware	2404377	191031	9140	6697	0.0339533785797123122	t
41	1	Business Process	2404377	191031	17606	7334	0.0337507373538234179	t
42	1	PHP	2404377	191031	8971	6617	0.0335748089949864867	t
43	1	Windows	2404377	191031	27867	7880	0.0322196300954954787	t
44	1	PRINCE2	2404377	191031	19835	7193	0.0319418602502971605	t
45	1	Management	2404377	191031	263974	26578	0.0318726361756688642	t
47	1	IT Management	2404377	191031	11502	6352	0.0309243538065536797	t
48	1	Servers	2404377	191031	8125	6032	0.0306303998091677111	t
49	1	Technical Support	2404377	191031	10614	5951	0.0290452469254678727	t
50	1	Disaster Recovery	2404377	191031	9138	5797	0.0288363807827845611	t
66	2	B2B	2404377	37729	38539	2883	0.0613473347028272997	t
51	2	Automotive	2404377	37729	14744	9893	0.260162357017827306	t
52	2	Vehicles	2404377	37729	8177	6337	0.167183513997865352	t
53	2	Customer Satisfaction	2404377	37729	28395	4925	0.120619212692024302	t
54	2	Automobile	2404377	37729	5320	4397	0.116151649233813645	t
55	2	Continuous Improvement	2404377	37729	26817	4082	0.0985862231665423222	t
56	2	Sales Management	2404377	37729	69672	4637	0.0954230126526174477	t
57	2	Negotiation	2404377	37729	102316	4979	0.0908388178385381578	t
58	2	Manufacturing	2404377	37729	32778	3321	0.0755757581898025277	t
59	2	New Business Development	2404377	37729	111991	4563	0.0755489801721561383	t
60	2	Automotive Aftermarket	2404377	37729	3293	2849	0.0753245983517710632	t
61	2	Sales Process	2404377	37729	18779	2951	0.0715277560749574826	t
62	2	Customer Retention	2404377	37729	11959	2813	0.0706934947597464836	t
63	2	Automotive Engineering	2404377	37729	3343	2668	0.0704296212253287257	t
64	2	Sales	2404377	37729	125324	4566	0.0699960558129590071	t
65	2	Account Management	2404377	37729	93243	3748	0.061524943223248682	t
67	2	Lean Manufacturing	2404377	37729	16718	2463	0.059258061620529448	t
68	2	Profit	2404377	37729	9119	2337	0.0590760860210730807	t
69	2	Engineering	2404377	37729	53130	2882	0.0551551474586525897	t
70	2	Product Development	2404377	37729	41543	2677	0.0545309949883321099	t
71	2	Parts	2404377	37729	2379	2014	0.053226462026432407	t
72	2	TS 16949	2404377	37729	1141	787	0.0207097073158378532	t
73	2	Customer Service	2404377	37729	235567	5424	0.0465178046958841379	t
74	2	Business Planning	2404377	37729	51071	2426	0.0437462831004836461	t
92	2	Key Account Management	2404377	37729	30238	1385	0.024517658103981977	t
93	2	Business Strategy	2404377	37729	90963	2304	0.0236052389062072696	t
94	2	APQP	2404377	37729	1672	1200	0.0316063345550017735	t
95	2	Management	2404377	37729	263974	4979	0.0225320818980856707	t
96	2	DFMEA	2404377	37729	1044	842	0.0222316977587927317	t
97	2	Root Cause Analysis	2404377	37729	5531	887	0.0215474980245366071	t
98	2	Automotive Repair	2404377	37729	883	740	0.019553136849327659	t
99	2	Motorsports	2404377	37729	1245	716	0.0187539215164017128	t
100	2	CATIA	2404377	37729	2535	887	0.0228134235022586854	t
101	5	Automotive Sales	7984381	1748	104	9	0.00513684058353863163	t
102	5	Product Knowledge	7984381	1748	1747	10	0.00550322642192184724	t
103	5	Automotive Sales Training	7984381	1748	179	10	0.00569965283912028317	t
104	5	Vehicle Leasing	7984381	1929	517	27	0.0139355049328696266	t
105	5	Cold Calling	7984381	1748	14306	30	0.015374089041337087	t
106	5	Call Centers	7984381	630	26223	14	0.0189394294597725922	t
107	5	Customer Experience	7984381	630	42804	16	0.0200374398147850769	t
108	5	Sales Presentations	7984381	1748	16560	39	0.020241594932926335	t
109	5	Vehicle Dynamics	7984381	438	1298	9	0.0203864961570581378	t
110	5	Courses	7984381	438	7504	10	0.0218924162726322098	t
111	5	Trainers	7984381	438	1140	10	0.022689516151727037	t
112	5	Road Safety	7984381	438	2023	11	0.024862149443985862	t
113	5	FMCG	7984381	1857	39801	58	0.0262544207007067466	t
75	2	Fleet Management	2404377	37729	3466	1594	0.0414576759789618693	t
76	2	Team Building	2404377	37729	55448	2409	0.0414390669577039406	t
77	2	Purchasing	2404377	37729	19180	1740	0.0387492982774761893	t
78	2	Operations Management	2404377	37729	52902	2263	0.0385834571122455963	t
79	2	Process Improvement	2404377	37729	40529	2064	0.0384529840324849548	t
80	2	Kaizen	2404377	37729	5005	1452	0.0369837055780708676	t
81	2	Six Sigma	2404377	37729	11649	1412	0.0330992655252771301	t
82	2	5S	2404377	37729	6520	1325	0.0329237863397414607	t
84	2	FMEA	2404377	37729	4649	2020	0.0524288636266321967	t
83	2	Dealers	2404377	37729	1374	1218	0.0322169433261113303	t
85	2	Dealer Management	2404377	37729	1337	1194	0.0315863208722278119	t
86	2	Sales Operations	2404377	37729	16868	1417	0.0310286736101541491	t
87	2	Powertrain	2404377	37729	1290	1118	0.0295597016470950623	t
114	5	CRM	7984381	4860	102251	191	0.02651017010338063	t
115	5	Logistics	7984381	4242	69734	155	0.0278203471628783068	t
116	5	Staff Development	7984381	438	67376	16	0.0280927463841799535	t
88	2	PPAP	2404377	37729	1547	1092	0.0287509981629513606	t
89	2	Warranty	2404377	37729	1228	1045	0.0276202025476230857	t
90	2	Pricing	2404377	37729	8718	1114	0.0263133759458473865	t
91	2	Manufacturing Engineering	2404377	37729	3764	1015	0.0257408243251125365	t
117	5	Powerpoint	7984381	630	268322	41	0.0314759874189145042	t
118	5	Inventory Management	7984381	4047	40826	158	0.0339452378255349838	t
119	5	Contract Negotiation	7984381	3112	143599	166	0.035370699989783691	t
120	5	Personal Development	7984381	438	43723	18	0.0356217781834542724	t
121	5	Instructor-led Training	7984381	438	3516	16	0.0360913004820736863	t
122	5	Fleet	7984381	619	493	23	0.0370978348715259518	t
123	5	Marketing	7984381	4819	249999	332	0.0376056525958561663	t
124	5	Six Sigma	7984381	1074	31465	45	0.0379637289849877116	t
125	5	Motorsports	7984381	1246	3552	48	0.0380843491689127414	t
126	5	Budgets	7984381	3879	165031	229	0.0383852533501946314	t
127	5	Supply Chain	7984381	456	54836	21	0.0391869608718703327	t
128	5	Stock Control	7984381	265	11135	11	0.0401161676319653424	t
129	5	Leadership	7984381	630	330397	52	0.041162515340956024	t
130	5	Microsoft Word	7984381	630	319543	52	0.0425220266784213305	t
131	5	Project Management	7984381	618	479558	64	0.0435012240196974223	t
132	5	Motors	7984381	203	1495	9	0.044148857274395617	t
133	5	Process Improvement	7984381	4690	108186	273	0.0446854992404346202	t
134	5	Selling	7984381	5456	33136	274	0.046101341412265337	t
135	5	Automotive Parts	7984381	3417	886	162	0.047319292921246231	t
136	5	Coaching	7984381	3699	219497	283	0.0490390855557440858	t
137	5	Chassis	7984381	203	1194	10	0.0491127904567939047	t
138	5	Lean Manufacturing	7984381	1670	42373	92	0.0497932488060835315	t
139	5	Manufacturing	7984381	4335	84658	262	0.0498624140783333406	t
140	5	Team Management	7984381	5146	150662	354	0.0499538993961831795	t
141	5	Driver Training	7984381	438	773	22	0.0501342467044829446	t
142	5	Strategic Planning	7984381	3527	267451	296	0.0504495269254376377	t
143	5	Tires	7984381	1011	447	53	0.0523739906328301724	t
144	5	Teaching	7984381	438	185728	34	0.0543671381947605711	t
145	5	Forecasting	7984381	6264	72454	398	0.0545059705063022926	t
146	5	Marketing Strategy	7984381	6264	206871	511	0.0557115143892600029	t
147	5	Suspension	7984381	1011	653	58	0.0572944117128485822	t
148	5	Team Leadership	7984381	7332	284785	705	0.0605416792986594871	t
149	5	Defensive Driving	7984381	438	1819	27	0.0614193851162281174	t
150	5	International Sales	7984381	456	33024	30	0.0616569198338173877	t
151	5	Microsoft Excel	7984381	630	428419	73	0.0622207914987837687	t
152	5	Spare Parts	7984381	1073	517	67	0.0623853844859041176	t
153	5	Direct Sales	7984381	4860	49654	335	0.0627493443410136881	t
154	5	Time Management	7984381	630	218895	57	0.0630657664787486749	t
155	5	Powertrain	7984381	1011	3475	67	0.0658441314011075224	t
156	5	Aftersales	7984381	6288	1894	431	0.0683598798420375076	t
157	5	Vehicle Maintenance	7984381	203	1018	14	0.0688397685418888905	t
158	5	Automotive Repair	7984381	4250	2315	305	0.0715128303179041885	t
159	5	Contract Hire	7984381	181	369	13	0.0717786163584681891	t
160	5	Supply Chain Management	7984381	456	55114	36	0.0720487565227695137	t
161	5	Product Development	7984381	4335	108713	387	0.0756987479342148412	t
162	5	Automotive Engineering	7984381	3311	9172	255	0.0758987385114161112	t
163	5	Business Development	7984381	5456	206995	557	0.0762165338707486012	t
164	5	Operations Management	7984381	6894	139638	652	0.0771527142779188102	t
165	5	Training Delivery	7984381	438	66235	38	0.0784667242590883357	t
166	5	Continuous Improvement	7984381	7800	68212	679	0.0785848726961962118	t
167	5	Pricing	7984381	6894	23421	563	0.0787999027800372204	t
168	5	Purchasing	7984381	7159	49234	631	0.0820480792838092776	t
169	5	Retail	7984381	6894	167010	727	0.0846099852730950175	t
170	5	Teamwork	7984381	630	285884	76	0.0848362089767038391	t
171	5	Business Strategy	7984381	4516	247930	539	0.0883515071830336951	t
172	5	Brake	7984381	203	351	18	0.0886282432519338859	t
173	5	Team Building	7984381	7535	154308	813	0.0886539152771042976	t
174	5	Warranty	7984381	7362	3034	686	0.0928868552162934596	t
175	5	Automotive Electronics	7984381	203	1261	19	0.0934405014591499911	t
176	5	Fleet Management	7984381	7800	8847	806	0.102325257316804447	t
177	5	Dealers	7984381	7362	3397	829	0.112283345537841847	t
178	5	Key Account Management	7984381	6264	74920	768	0.113310940250352057	t
179	5	Business Planning	7984381	6264	140725	823	0.113849979279632682	t
180	5	Management	7984381	6894	738887	1444	0.117016985112815747	t
181	5	Dealer Management	7984381	7362	3247	893	0.121003462468820835	t
182	5	Sales Operations	7984381	6894	45024	893	0.124000984605150674	t
183	5	Parts	7984381	7362	6008	1029	0.13914763314039158	t
184	5	Training	7984381	438	286184	77	0.139963785829614995	t
185	5	Customer Service	7984381	7800	670741	1991	0.17141723154061711	t
186	5	Profit	7984381	7362	23219	1489	0.199530746812567633	t
187	5	B2B	7984381	6894	101291	1466	0.200135340911208409	t
188	5	Automotive Aftermarket	7984381	7362	8117	1500	0.202919473390062943	t
189	5	Customer Retention	7984381	7362	32444	1660	0.221623120216227321	t
190	5	Account Management	7984381	6894	240929	1776	0.227636829454394174	t
191	5	Negotiation	7984381	7362	275641	2011	0.238857179927052993	t
192	5	New Business Development	7984381	6264	289997	1755	0.244043337220273021	t
193	5	Sales Process	7984381	7159	48637	1853	0.252970334563686838	t
194	5	Automobile	7984381	7800	13346	1991	0.253832868014439661	t
195	5	Sales	7984381	7159	353906	2275	0.273702433087641639	t
196	5	Sales Management	7984381	7159	180284	2244	0.291133052903919665	t
197	5	Vehicles	7984381	7800	20721	2327	0.296027332805036791	t
198	5	Customer Satisfaction	7984381	7800	79371	2437	0.302790912949436386	t
199	5	Automotive	7984381	7800	37962	2799	0.354437874158402944	t
200	6	Dealer Management	7984381	1536	3247	11	0.00675608906961845408	t
201	6	Automotive Parts	7984381	1536	886	11	0.00705184828829300003	t
202	6	Tires	7984381	1536	447	12	0.00775800814903709109	t
203	6	Dealers	7984381	1536	3397	13	0.00803963264676210883	t
204	6	Welding	7984381	1536	7563	14	0.00816893049903678892	t
205	6	Brake	7984381	1536	351	16	0.0103747016779940811	t
206	6	Fleet Management	7984381	1536	8847	21	0.0125662541342560202	t
207	6	Troubleshooting	7984381	1536	38514	28	0.0134080784456126444	t
208	6	Vehicle Maintenance	7984381	1536	1018	21	0.0135469821829654717	t
209	6	Suspension	7984381	1536	653	26	0.0168485399067730031	t
210	6	Maintenance & Repair	7984381	1630	11706	31	0.0175558765139418767	t
211	6	Mechanics	7984381	1536	2847	31	0.0198295352245711487	t
212	6	Chassis	7984381	3071	1194	70	0.0226530492037861943	t
213	6	Motorsports	7984381	1920	3552	47	0.0240400790218914528	t
214	6	Warranty	7984381	1536	3034	38	0.0243642785391152313	t
215	6	Automotive Electronics	7984381	2687	1261	72	0.0266467170465974693	t
216	6	Electronics	7984381	3165	24782	95	0.026922660101019881	t
217	6	Systems Engineering	7984381	1151	19629	36	0.0288228805410927387	t
218	6	Industrial Engineering	7984381	373	2839	11	0.0291364085600681437	t
219	6	CATIA V5	7984381	384	505	12	0.031188251479803912	t
220	6	Machine Tools	7984381	373	2780	12	0.0318248887300512651	t
221	6	PDCA	7984381	373	656	12	0.0320909205276145928	t
222	6	Geometric Dimensioning	7984381	384	277	13	0.0338211005219774818	t
223	6	Simulations	7984381	1151	12224	41	0.0340951249247372981	t
224	6	SMED	7984381	373	2349	13	0.0345599620397206223	t
225	6	CFD	7984381	384	4629	14	0.0358803020540129636	t
226	6	Project Engineering	7984381	1151	44758	48	0.0361023770448916509	t
227	6	ANSYS	7984381	1535	6586	59	0.0376188538854242763	t
228	6	Injection Molding	7984381	1908	3434	77	0.0399358477654626759	t
229	6	Problem Solving	7984381	344	62532	17	0.0415886058673395204	t
230	6	QS 9000	7984381	344	204	15	0.0435809789278048115	t
231	6	Simulink	7984381	1151	4716	51	0.0437249463205489491	t
232	6	Components	7984381	384	1123	17	0.0441323062271733527	t
233	6	Composition	7984381	384	26177	19	0.0462028628303801508	t
234	6	Pricing	7984381	281	23421	14	0.0468903622996969804	t
235	6	Logistics Management	7984381	281	21257	14	0.0471614009890921546	t
236	6	Vehicle Dynamics	7984381	1535	1298	75	0.0487067313468011256	t
237	6	NX Unigraphics	7984381	384	742	19	0.0493886105204156059	t
238	6	Low Cost Country Sourcing	7984381	281	550	14	0.0497549306292519727	t
239	6	Parts	7984381	1817	6008	93	0.0504422791372530627	t
240	6	Manufacturing Operations Management	7984381	717	4312	37	0.0510684367338635481	t
241	6	Forecasting	7984381	281	72454	17	0.0514255637349695163	t
242	6	Automotive Aftermarket	7984381	1817	8117	96	0.0518295273282295965	t
243	6	Spend Analysis	7984381	281	3965	15	0.0528860496357506996	t
244	6	AutoCAD	7984381	1535	70871	95	0.0530232398703656474	t
245	6	ISO 14001	7984381	344	8838	19	0.054127979090114145	t
246	6	Sheet Metal	7984381	384	2326	21	0.0543987974867099766	t
247	6	ISO 9000	7984381	344	5149	19	0.054590026047060862	t
248	6	CAE	7984381	1535	1985	85	0.0551365824801752918	t
249	6	Process Capability	7984381	344	423	19	0.0551819571716285484	t
250	6	TPM	7984381	811	4981	46	0.0561019541293535789	t
251	6	Testing	7984381	1908	52574	120	0.0563219352002850698	t
252	6	Teamcenter	7984381	1535	1610	87	0.0564867403411850599	t
253	6	Automotive Repair	7984381	1536	2315	88	0.0570126934434611529	t
254	6	Operations Management	7984381	654	139638	50	0.0589685346151223033	t
255	6	Automobile	7984381	3685	13346	228	0.0602287396149051441	t
256	6	8D Problem Solving	7984381	717	844	44	0.0612666015188510077	t
257	6	Customer Satisfaction	7984381	1536	79371	110	0.061685667013399767	t
258	6	Sales Management	7984381	281	180284	24	0.0628318801411399536	t
259	6	Project Management	7984381	1805	479558	222	0.0629439056769799804	t
260	6	Automotive Design	7984381	1535	1550	97	0.0630101671241458522	t
261	6	Quality Auditing	7984381	344	7455	22	0.0630225057125687743	t
262	6	TQM	7984381	344	1831	22	0.0637269112657995601	t
263	6	Purchase Management	7984381	281	1861	18	0.0638261057196373577	t
264	6	5 Why	7984381	717	1451	46	0.0639802220555573953	t
265	6	PTC Creo	7984381	384	1577	25	0.0649097778160696581	t
266	6	Toyota Production System	7984381	717	1903	47	0.0653184318417259629	t
267	6	DMAIC	7984381	717	3917	48	0.0664609921115822261	t
268	6	JIT	7984381	998	2003	67	0.0668917648265544285	t
269	6	Engineering Management	7984381	1908	26924	136	0.0679229737430027541	t
270	6	Design for Manufacturing	7984381	1535	7274	107	0.0688090402829981546	t
271	6	Process Engineering	7984381	373	24975	27	0.0692613126132436419	t
272	6	Inventory Management	7984381	281	40826	21	0.0696223134048316039	t
273	6	PFMEA	7984381	344	570	24	0.0696990554038392218	t
274	6	Mechanical Engineering	7984381	3538	30057	261	0.070037051614065593	t
275	6	Geometric Dimensioning & Tolerancing	7984381	384	594	27	0.0702414829392470907	t
276	6	Pro Engineer	7984381	1535	4965	109	0.0704014676303540143	t
277	6	Kanban	7984381	998	4574	71	0.070578237973854055	t
278	6	GD&T	7984381	2252	2099	160	0.0708050397235654022	t
279	6	Powertrain	7984381	3788	3475	284	0.0745737558708468445	t
280	6	Matlab	7984381	1908	43522	153	0.0747556511598763962	t
281	6	Quality Management	7984381	1868	23788	148	0.0762676486449829216	t
282	6	New Business Development	7984381	281	289997	32	0.0775611969180204641	t
283	6	Finite Element Analysis	7984381	1535	11586	126	0.0806491123151077266	t
284	6	Contract Negotiation	7984381	281	143599	29	0.0852208577715469207	t
285	6	Unigraphics	7984381	384	1638	33	0.0857364728703555318	t
286	6	SPC	7984381	1868	5436	165	0.0876694460805369502	t
287	6	Poka Yoke	7984381	717	1433	63	0.0876945083785776736	t
288	6	Supplier Quality	7984381	2149	3695	191	0.088439573198542093	t
289	6	Solidworks	7984381	1908	18639	177	0.0904544785043353144	t
290	6	Quality Control	7984381	344	10786	32	0.0916763181682486855	t
291	6	Product Design	7984381	1535	19493	151	0.0959483901042106069	t
292	6	Pneumatics	7984381	94	2893	10	0.106021894508871381	t
293	6	Process Improvement	7984381	1092	108186	136	0.111007602617639534	t
294	6	Sourcing	7984381	281	47464	33	0.111497040314243775	t
295	6	TS 16949	7984381	2149	2584	242	0.112317114874257648	t
296	6	Materials Management	7984381	281	7721	32	0.112915964518626677	t
297	6	Six Sigma	7984381	2627	31465	308	0.113340476596527406	t
298	6	Supplier Evaluation	7984381	281	3117	32	0.113492610602718799	t
299	6	Automation	7984381	94	11971	11	0.115523334450127926	t
300	6	Design Engineering	7984381	384	3932	45	0.116700651119671012	t
301	6	CAD	7984381	1908	35636	232	0.11715807439855401	t
302	6	Root Cause Analysis	7984381	1962	14649	234	0.117460211478902704	t
303	6	Supplier Development	7984381	625	4462	74	0.117850384004721587	t
304	6	ISO	7984381	344	8211	41	0.118162754660650765	t
305	6	Value Stream Mapping	7984381	998	8075	120	0.119244036221642688	t
306	6	Quality Assurance	7984381	344	35754	44	0.123434302080979955	t
307	6	Product Development	7984381	2533	108713	352	0.12538972459303685	t
308	6	5S	7984381	2627	16523	340	0.127397700628891691	t
309	6	DFMEA	7984381	2252	2798	289	0.128016045834174669	t
310	6	Manufacturing Engineering	7984381	2346	8612	303	0.128115047618514222	t
311	6	Management	7984381	281	738887	63	0.131662371133446227	t
312	6	Lean Manufacturing	7984381	4163	42373	591	0.136729232568950893	t
313	6	Preventive Maintenance	7984381	94	10012	13	0.137045537598450451	t
314	6	PPAP	7984381	2533	3965	350	0.137723173163366019	t
315	6	Kaizen	7984381	2627	12685	369	0.138921388828907644	t
316	6	MRP	7984381	281	5777	40	0.141630201324063981	t
317	6	Vehicles	7984381	4069	20721	590	0.14247618811990187	t
318	6	APQP	7984381	2533	4233	373	0.146772620641177604	t
319	6	PLC	7984381	94	7875	14	0.14795161141621968	t
320	6	CATIA	7984381	2252	8001	339	0.149572965396440855	t
321	6	Logistics	7984381	281	69734	48	0.16209040824510601	t
322	6	Manufacturing	7984381	4163	84658	719	0.162193602213298343	t
323	6	Automotive Engineering	7984381	3882	9172	641	0.164052090838310988	t
324	6	Quality System	7984381	344	14495	58	0.166796418059662527	t
325	6	Supply Management	7984381	625	17740	107	0.168991390418244236	t
326	6	Continuous Improvement	7984381	4163	68212	743	0.170022528871249801	t
327	6	Supplier Negotiation	7984381	281	7987	49	0.173382998175065112	t
328	6	Engineering	7984381	4163	143574	827	0.180767209659121075	t
329	6	Global Sourcing	7984381	281	8722	61	0.215997069531565861	t
330	6	FMEA	7984381	2627	12047	623	0.235721381247169487	t
331	6	Procurement	7984381	281	112661	71	0.23856726186355881	t
332	6	Strategic Sourcing	7984381	281	14173	70	0.247343934593135528	t
333	6	Supply Chain	7984381	281	54836	77	0.267162846031933299	t
334	6	Negotiation	7984381	281	275641	86	0.271536852537122175	t
335	6	Automotive	7984381	4163	37962	1193	0.281964665280769189	t
336	6	Supply Chain Management	7984381	281	55114	98	0.341863753141753546	t
337	6	Purchasing	7984381	281	49234	107	0.374629813854680305	t
388	8	Healthcare	2404377	131062	38129	23107	0.169697899325383067	t
389	8	Hospitals	2404377	131062	19975	15851	0.11912866903905521	t
390	8	Healthcare Management	2404377	131062	15487	12740	0.0959975350337778782	t
391	8	Clinical Research	2404377	131062	20207	12599	0.0927834212868358793	t
392	8	Medicine	2404377	131062	10734	8223	0.0616367436493861637	t
393	8	Patient Safety	2404377	131062	8554	7555	0.0572050272487392431	t
394	8	Nursing	2404377	131062	8084	6407	0.048147571177538942	t
395	8	Healthcare Information Technology	2404377	131062	7689	6198	0.0466347248988617652	t
396	8	Medical Education	2404377	131062	7438	6003	0.0451715130814121721	t
397	8	Public Health	2404377	131062	9728	6069	0.0446967845306548289	t
398	8	Treatment	2404377	131062	11568	5932	0.0427818226221043652	t
399	8	Surgery	2404377	131062	5981	4535	0.0339658686071781166	t
400	8	Pediatrics	2404377	131062	4148	3451	0.0260244487139331473	t
401	8	Mental Health	2404377	131062	11705	3451	0.0227002283573173695	t
402	8	Critical Care	2404377	131062	3340	2963	0.0224417837061581041	t
403	8	Emergency Medicine	2404377	131062	3212	2799	0.0211746316303505801	t
404	8	Inpatient	2404377	131062	2613	2322	0.0175887988891579652	t
405	8	Acute Care	2404377	131062	2263	2037	0.015442848149212705	t
406	8	Internal Medicine	2404377	131062	2401	1958	0.0147446246784277857	t
407	8	BLS	2404377	131062	2148	1910	0.014468562479429228	t
408	8	Rehabilitation	2404377	131062	4405	2030	0.0144441227712458105	t
409	8	Clinical Trials	2404377	131062	6655	1848	0.0119856636716784218	t
410	8	Public Sector	2404377	131062	30543	3058	0.0112421951473616142	t
411	8	Policy	2404377	131062	38590	3372	0.0102363674803656862	t
412	8	Orthopedic	2404377	131062	2137	1352	0.00997041773121869895	t
413	8	Medical Devices	2404377	131062	6807	1567	0.00965116948812461302	t
414	8	Health Promotion	2404377	131062	2712	1310	0.00937854889840104844	t
415	8	Home Care	2404377	131062	1823	1251	0.00929348585961308968	t
416	8	Informatics	2404377	131062	1790	1249	0.00929186237991647297	t
417	8	CPR Certified	2404377	131062	1857	1174	0.008657150284146908	t
418	8	Cancer	2404377	131062	2065	1185	0.00865442243697475862	t
419	8	Dentistry	2404377	131062	1719	1160	0.00860487650544680856	t
420	8	ICU	2404377	131062	1193	1064	0.00806154983235803091	t
421	8	Nursing Education	2404377	131062	1281	1063	0.00801476997986365174	t
422	8	Performance Improvement	2404377	131062	6829	1337	0.00778542352425711306	t
423	8	Medical Research	2404377	131062	1296	982	0.00735451279146964038	t
424	8	Quality Improvement	2404377	131062	1335	983	0.00734542709079606844	t
425	8	Health Education	2404377	131062	2040	993	0.00711600591675401288	t
426	8	Epidemiology	2404377	131062	1998	976	0.00699729346980082142	t
427	8	Medical Terminology	2404377	131062	1184	900	0.00674205129334588989	t
428	8	Family Medicine	2404377	131062	987	887	0.00672380066602307723	t
429	8	Wound Care	2404377	131062	1147	887	0.00665341886675636755	t
430	8	General Surgery	2404377	131062	1018	878	0.00663753542633595695	t
431	8	Psychology	2404377	131062	8581	1256	0.00636108392757388317	t
432	8	Clinical Supervision	2404377	131062	2555	893	0.00608247821059545394	t
433	8	ACLS	2404377	131062	941	797	0.00601774777252030244	t
434	8	Case Management	2404377	131062	3226	909	0.00591643234628370408	t
435	8	Patient Education	2404377	131062	966	778	0.005853423221328799	t
436	8	Cosmetic Dentistry	2404377	131062	1020	761	0.00569248169481558278	t
437	8	Social Services	2404377	131062	4987	962	0.0055694954016819653	t
444	9	Investments	2404377	204323	21112	15269	0.0720738732614974037	t
438	9	Banking	2404377	204323	28021	22084	0.105385199200012117	t
439	9	Financial Services	2404377	204323	26971	20303	0.0963363437403675221	t
440	9	Risk Management	2404377	204323	46661	20557	0.0887451448788776076	t
441	9	Accounting	2404377	204323	35474	19450	0.0879089583418207615	t
442	9	Financial Analysis	2404377	204323	33653	18905	0.0858215987751291404	t
443	9	Finance	2404377	204323	34228	18179	0.081677052020539237	t
455	9	Business Analysis	2404377	204323	54180	13412	0.0471107119402573021	t
463	9	Credit	2404377	204323	9568	7975	0.0383072645005900977	t
464	9	Retail Banking	2404377	204323	9141	7709	0.0370785842326998016	t
445	9	Portfolio Management	2404377	204323	18727	14791	0.0706012370149808888	t
446	9	Financial Reporting	2404377	204323	27520	14264	0.0637857278379452552	t
447	9	Investment Banking	2404377	204323	15690	12807	0.0613697457845695585	t
448	9	Equities	2404377	204323	14210	12098	0.0582501956924805289	t
449	9	Financial Risk	2404377	204323	16810	11983	0.0564533007381374241	t
450	9	Derivatives	2404377	204323	13619	11114	0.0532556594833801869	t
451	9	Financial Accounting	2404377	204323	18605	11505	0.0530807111268398676	t
452	9	Fixed Income	2404377	204323	12600	10842	0.0522639710443019434	t
453	9	Corporate Finance	2404377	204323	16631	11098	0.0518010222438036669	t
454	9	Relationship Management	2404377	204323	15935	10726	0.0501276446351661617	t
456	9	Auditing	2404377	204323	18416	10144	0.0458869749205550667	t
457	9	Financial Modeling	2404377	204323	16431	9729	0.0445694959474848759	t
458	9	Capital Markets	2404377	204323	11229	9033	0.0432112562086653176	t
459	9	Microsoft Excel	2404377	204323	136193	19459	0.0421768571154790897	t
460	9	Asset Management	2404377	204323	13695	8860	0.0411650415872311382	t
461	9	Tax	2404377	204323	9939	8054	0.0385611832032919308	t
462	9	Financial Markets	2404377	204323	9848	8040	0.0385276633815991934	t
465	9	Credit Risk	2404377	204323	9164	7703	0.037036037468368227	t
466	9	Wealth Management	2404377	204323	7657	6964	0.0337682974249081599	t
467	9	Stakeholder Management	2404377	204323	56122	10897	0.0327759103609437386	t
468	9	Hedge Funds	2404377	204323	7689	6573	0.0316623926751156484	t
469	9	Analysis	2404377	204323	40996	8983	0.0294136964705303677	t
470	9	Valuation	2404377	204323	10570	6363	0.0292296427212892264	t
471	9	Pensions	2404377	204323	7624	6035	0.0288143121028928868	t
472	9	Bloomberg	2404377	204323	6692	5788	0.0279167978277494247	t
473	9	Internal Controls	2404377	204323	10231	6061	0.0277684085822992276	t
474	9	Due Diligence	2404377	204323	13529	6223	0.0271358513061949885	t
475	9	Trading	2404377	204323	8158	5575	0.0261111676675610943	t
476	9	Strategic Financial Planning	2404377	204323	8355	5501	0.0256258172132805655	t
477	9	Private Equity	2404377	204323	8530	5387	0.0249365166770028589	t
478	9	Account Reconciliation	2404377	204323	10121	5390	0.0242293988469529445	t
479	9	Corporate Tax	2404377	204323	5714	4932	0.0237828058688512554	t
480	9	Management	2404377	204323	263974	26834	0.0235430111226570954	t
481	9	Loans	2404377	204323	5513	4853	0.0234516163355243598	t
482	9	VAT	2404377	204323	6388	4796	0.0227490203078723335	t
483	9	IFRS	2404377	204323	7006	4828	0.0226392779810742489	t
484	9	Income Tax	2404377	204323	5135	4646	0.0225162398959513968	t
485	9	Bookkeeping	2404377	204323	7022	4757	0.0222522444724356748	t
486	9	Business Strategy	2404377	204323	90963	11762	0.0215661461068499122	t
487	9	Management Accounting	2404377	204323	9541	4758	0.0211126213222050246	t
488	10	Biotechnology	2411262	7728	6314	1499	0.191966679155523179	t
489	10	Molecular Biology	2411262	7728	7223	1295	0.165106095495397509	t
490	10	Biochemistry	2411262	7728	5453	1010	0.128845053738080834	t
491	10	Lifesciences	2411262	7728	6055	923	0.117300628538245549	t
492	10	Life Sciences	2411262	7728	5500	918	0.116882460323550388	t
493	10	Cell Culture	2411262	7728	4526	865	0.110407468028690073	t
494	10	PCR	2411262	7728	3805	747	0.0953891974683220983	t
495	10	Cell Biology	2411262	7728	3638	598	0.0761161481385326799	t
496	10	Science	2411262	7728	13334	628	0.0759765574901102997	t
497	10	Pharmaceutical Industry	2411262	7728	11886	601	0.0730739814427603107	t
498	10	Microbiology	2411262	7728	2833	555	0.0708689991125748542	t
499	10	Research	2411262	7728	122165	925	0.0692522267301977634	t
500	10	Genetics	2411262	7728	2497	433	0.0551712851919751029	t
501	10	Western Blotting	2411262	7728	2587	424	0.0539654995699991175	t
502	10	R&D	2411262	7728	6689	434	0.0535570023502711101	t
503	10	GMP	2411262	7728	4913	382	0.0475455010251028543	t
504	10	Protein Purification	2411262	7728	1196	365	0.0468851079647537791	t
505	10	ELISA	2411262	7728	1606	366	0.0468443414535864022	t
506	10	Immunology	2411262	7728	2265	364	0.0463105305698228928	t
507	10	Biopharmaceuticals	2411262	7728	1209	354	0.0454517272229685299	t
508	10	Technology Transfer	2411262	7728	2230	356	0.0452865673411843098	t
509	10	Drug Discovery	2411262	7728	2212	350	0.0445151624739816981	t
510	10	Genomics	2411262	7728	1092	337	0.0432935396650171792	t
511	10	Bioinformatics	2411262	7728	1641	326	0.0416371539647000244	t
512	10	Chemistry	2411262	7728	5852	338	0.0414429381359137025	t
513	10	Laboratory	2411262	7728	3082	328	0.0412972513915288719	t
514	10	Medical Devices	2411262	7728	6832	322	0.038958154950169209	t
515	10	Validation	2411262	7728	3487	304	0.038013174151786136	t
516	10	Protein Chemistry	2411262	7728	1122	296	0.0379586168063179158	t
517	10	Cell	2411262	7728	1385	285	0.0364212225577547205	t
518	10	Data Analysis	2411262	7728	37049	386	0.0346944513696335749	t
519	10	Microscopy	2411262	7728	2314	271	0.0342172894072897971	t
520	10	Hplc	2411262	7728	2752	267	0.0335157951836211054	t
521	10	Chromatography	2411262	7728	1579	257	0.0327056701579388071	t
522	10	Dna	2411262	7728	844	252	0.0323623916681237619	t
523	10	Nanotechnology	2411262	7728	1560	252	0.0320644969847117475	t
524	10	Qpcr	2411262	7728	1040	240	0.0307230573994286167	t
525	10	Protein Expression	2411262	7728	1092	225	0.0287541879907922543	t
526	10	Sds Page	2411262	7728	681	222	0.0285357392760898707	t
527	10	Sop	2411262	7728	3627	216	0.0265311502725280521	t
528	10	Assay Development	2411262	7728	719	204	0.0261832477039877637	t
529	10	Dna Sequencing	2411262	7728	611	200	0.0257089189791220862	t
530	10	Glp	2411262	7728	2070	203	0.0254913430734113565	t
531	10	Matlab	2411262	7728	12797	220	0.0232351974037071016	t
532	10	Molecular Cloning	2411262	7728	1073	182	0.0231800204995245944	t
533	10	Materials Science	2411262	7728	2622	185	0.0229249997313738137	t
534	10	Gel Electrophoresis	2411262	7728	637	175	0.0224527105757062577	t
535	10	Oncology	2411262	7728	4287	186	0.022362085416181194	t
536	10	Commercials	2411262	7728	6261	190	0.0220600573264563594	t
537	10	Dna Extraction	2411262	7728	756	172	0.022013753226634649	t
538	11	Engineering	2411262	34783	53650	9196	0.245676200824313767	t
539	11	Manufacturing	2411262	34783	32892	6563	0.177605131865358618	t
540	11	Mechanical Engineering	2411262	34783	10488	3966	0.111276821034787504	t
541	11	Product Development	2411262	34783	41647	4030	0.100032316945939295	t
542	11	Continuous Improvement	2411262	34783	26922	3748	0.0980023866424212797	t
543	11	Lean Manufacturing	2411262	34783	16778	3037	0.0815306842372526264	t
544	11	Project Engineering	2411262	34783	16947	2844	0.0758296704664889881	t
545	11	Project Management	2411262	34783	174539	5039	0.0735456152497604293	t
546	11	Solidworks	2411262	34783	7087	2514	0.0703524115202274064	t
547	11	AutoCAD	2411262	34783	23848	2471	0.0620452103572895139	t
548	11	New Business Development	2411262	34783	112537	3620	0.0582425805028020244	t
549	11	CAD	2411262	34783	12089	2087	0.0557918275145929399	t
550	11	Negotiation	2411262	34783	102727	3372	0.0551362603338366314	t
551	11	Sales Management	2411262	34783	69921	2773	0.051467606595631446	t
552	11	Commissioning	2411262	34783	15324	1940	0.050142511284748531	t
553	11	Procurement	2411262	34783	43170	2241	0.0472054871357795724	t
554	11	Project Planning	2411262	34783	82300	2758	0.0458210828774570783	t
555	11	Key Account Management	2411262	34783	30337	1964	0.0445252733721851549	t
556	11	Operations Management	2411262	34783	53109	2279	0.0441317272159218246	t
557	11	Microsoft Office	2411262	34783	194275	4244	0.0420503707809915805	t
558	11	Contract Negotiation	2411262	34783	56640	2213	0.0407206648111328312	t
559	11	Automation	2411262	34783	4370	1385	0.0385622421336209997	t
560	11	Six Sigma	2411262	34783	11702	1441	0.0371105516901154356	t
561	11	Matlab	2411262	34783	12797	1413	0.0358330129139452364	t
562	11	Engineering Management	2411262	34783	9955	1325	0.0344618986603678207	t
563	11	Process Engineering	2411262	34783	9175	1241	0.0323397960792961847	t
564	11	International Sales	2411262	34783	12333	1286	0.0323236104188001014	t
565	11	Contract Management	2411262	34783	52114	1853	0.0321237948443292426	t
566	11	Process Improvement	2411262	34783	40734	1632	0.030465718514521678	t
567	11	Hvac	2411262	34783	5327	1119	0.0304002012757322096	t
568	11	Purchasing	2411262	34783	19215	1260	0.0286692974339087039	t
569	11	Manufacturing Engineering	2411262	34783	3771	999	0.0275544953747137444	t
570	11	Electrical Engineering	2411262	34783	9295	1070	0.0273011513248616992	t
571	11	Electricians	2411262	34783	9927	1073	0.027122723073591086	t
572	11	5S	2411262	34783	6550	1019	0.0269685276688448605	t
573	11	Finite Element Analysis	2411262	34783	3556	963	0.0265948285339026383	t
574	11	Supply Chain Management	2411262	34783	21148	1203	0.0261931925959847899	t
575	11	Business Strategy	2411262	34783	91680	2192	0.0253635827351116824	t
576	11	Energy	2411262	34783	19717	1122	0.0244325360903250091	t
577	11	Inspection	2411262	34783	15060	1049	0.0242627137645295282	t
578	11	Automotive	2411262	34783	14786	1032	0.0238821124444775768	t
579	11	Pumps	2411262	34783	4048	835	0.0226539797677758475	t
580	11	PLC	2411262	34783	2867	808	0.0223633308410914715	t
581	11	Instrumentation	2411262	34783	4498	825	0.0221729193308175532	t
582	11	Microsoft Excel	2411262	34783	136762	2707	0.0214162919521313153	t
583	11	Machining	2411262	34783	1555	734	0.0207567935253397534	t
584	11	Root Cause Analysis	2411262	34783	5539	755	0.0196929436259468404	t
585	11	Gas	2411262	34783	27441	1067	0.0195779738813207892	t
586	11	Kaizen	2411262	34783	5014	737	0.0193887902767727188	t
587	11	FMEA	2411262	34783	4655	731	0.0193648312955667749	t
588	12	Electronics	2411262	27806	8997	3500	0.123565799068450416	t
589	12	Manufacturing	2411262	27806	32892	3411	0.110302352157575764	t
590	12	Engineering	2411262	27806	53650	3402	0.101265702878226727	t
591	12	Product Development	2411262	27806	41647	3045	0.0933129293389550751	t
592	12	Electrical Engineering	2411262	27806	9295	2286	0.0792717843203614575	t
593	12	Product Management	2411262	27806	22113	2015	0.064034080888874037	t
594	12	New Business Development	2411262	27806	112537	2865	0.0570214606081698369	t
595	12	Sales Management	2411262	27806	69921	2323	0.0551817827034807862	t
596	12	Key Account Management	2411262	27806	30337	1829	0.0538163873974163015	t
597	12	Electricians	2411262	27806	9927	1566	0.0528108487793613676	t
598	12	Product Marketing	2411262	27806	12506	1579	0.0522017858277240773	t
599	12	Testing	2411262	27806	17853	1443	0.0450103140746909089	t
600	12	Semiconductors	2411262	27806	1882	1140	0.0406870330322644941	t
601	12	International Sales	2411262	27806	12333	1248	0.0402315899014164674	t
602	12	Lean Manufacturing	2411262	27806	16778	1251	0.0384757999818990531	t
603	12	Continuous Improvement	2411262	27806	26922	1359	0.0381491614104806989	t
604	12	Embedded Systems	2411262	27806	3612	1064	0.0371960867480187335	t
605	12	Account Management	2411262	27806	93644	2038	0.0348594280005883259	t
606	12	Project Management	2411262	27806	174539	2946	0.0339549989251520384	t
607	12	Cross Functional Team Leadership	2411262	27806	14122	1046	0.0321316291328916856	t
608	12	Engineering Management	2411262	27806	9955	956	0.0306054589633558381	t
609	12	Six Sigma	2411262	27806	11702	944	0.0294358934558126631	t
610	12	Consumer Electronics	2411262	27806	1535	824	0.0293355856408295777	t
611	12	Pcb Design	2411262	27806	1526	816	0.0290482975106670961	t
612	12	Automation	2411262	27806	4370	837	0.0286191156298633183	t
613	12	Negotiation	2411262	27806	102727	1969	0.0285381468120560824	t
614	12	Business Development	2411262	27806	75434	1649	0.0283465994528507258	t
615	12	Matlab	2411262	27806	12797	895	0.0271937085643848761	t
616	12	C	2411262	27806	9505	851	0.026974043340187305	t
617	12	Supply Chain Management	2411262	27806	21148	939	0.0252908256903586967	t
618	12	B2B	2411262	27806	38704	1132	0.0249469737999713226	t
619	12	Process Improvement	2411262	27806	40734	1061	0.0215120749678194313	t
620	12	Sales	2411262	27806	125824	2031	0.0211033438562328243	t
621	12	Commissioning	2411262	27806	15324	755	0.0210398606194764359	t
622	12	Power Distribution	2411262	27806	2270	587	0.0204044341761707264	t
623	12	Purchasing	2411262	27806	19215	749	0.0191890591097471086	t
624	12	Business Strategy	2411262	27806	91680	1583	0.019129167457081736	t
625	12	Project Engineering	2411262	27806	16947	714	0.0188672128277746591	t
626	12	Ic	2411262	27806	681	510	0.0182696206138230968	t
627	12	PLC	2411262	27806	2867	532	0.0181528914601498288	t
628	12	Contract Negotiation	2411262	27806	56640	1150	0.0180766610648170969	t
629	12	Electricity	2411262	27806	3348	534	0.0180238497049805026	t
630	12	C++	2411262	27806	12747	633	0.0176823352790214591	t
631	12	Sales Operations	2411262	27806	16925	643	0.0162932487055565782	t
632	12	Lighting Control	2411262	27806	1120	457	0.0161571342321298016	t
633	12	Supply Chain	2411262	27806	21196	678	0.0157747186600449077	t
634	12	Troubleshooting	2411262	27806	13703	591	0.0157531502039817209	t
635	12	Procurement	2411262	27806	43170	930	0.0157238540555728508	t
636	12	Switchgear	2411262	27806	1142	434	0.0153110944791416664	t
637	12	Instrumentation	2411262	27806	4498	470	0.0152128437789149761	t
\.


--
-- Name: sector_skill_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geektalent
--

SELECT pg_catalog.setval('sector_skill_id_seq', 637, true);


--
-- Data for Name: sector_subject; Type: TABLE DATA; Schema: public; Owner: geektalent
--

COPY sector_subject (id, sector_id, subject_name, count, visible) FROM stdin;
1	1	Computer Science	6018	t
2	1	Information Technology	2369	t
3	1	Computing	1340	t
4	1	Mathematics	793	t
5	1	Computer Software Engineering	617	t
6	1	Business	557	t
7	1	Electrical and Electronics Engineering	494	t
8	1	Software Engineering	472	t
9	1	Business Studies	455	t
10	1	Marketing	451	t
11	1	 Business Administration and Management	432	t
12	1	Physics	426	t
13	1	Economics	419	t
14	1	Business Management	336	t
15	1	Animation	325	t
16	1	Mechanical Engineering	321	t
17	1	Law	319	t
18	1	Business Information Technology	317	t
19	1	Computer Engineering	316	t
20	1	Psychology	313	t
21	1	English	284	t
22	1	Information Systems	261	t
23	1	Business Information Systems	257	t
24	1	Business Administration	257	t
25	1	Computer Studies	250	t
26	1	Accounting	237	t
27	1	History	227	t
28	1	Engineering	219	t
29	1	Accounting and Finance	213	t
30	1	International Business	209	t
31	1	Management	205	t
32	1	Computer Systems Networking and Telecommunications	199	t
33	1	Geography	195	t
34	1	Project Management	193	t
35	1	Chemistry	186	t
36	1	Computer Networking	180	t
37	1	Electronics	175	t
38	1	Electronic Engineering	175	t
39	1	Mathematics and Computer Science	175	t
40	1	Graphic Design	156	t
41	1	 English Language and Literature	147	t
42	1	Journalism	145	t
43	1	Finance	137	t
44	1	Computer Science and Engineering	136	t
45	1	English Literature	134	t
46	1	Computer Information Systems	129	t
47	1	Computer Programming	126	t
48	1	Computer Technology/Computer Systems Technology	124	t
49	1	 Management Information Systems	120	t
50	1	Business and Finance	118	t
51	2	Mechanical Engineering	510	t
52	2	Automotive Engineering	181	t
53	2	Business	165	t
54	2	Engineering	158	t
55	2	Business Studies	131	t
56	2	Automotive Engineering Technology/Technician	127	t
57	2	 Business Administration and Management	123	t
58	2	Electrical and Electronics Engineering	103	t
59	2	Motorsport Engineering	92	t
60	2	Marketing	87	t
61	2	Business Management	82	t
62	2	Mathematics	77	t
63	2	Accounting and Finance	70	t
64	2	Economics	59	t
65	2	Accounting	58	t
66	2	Law	49	t
67	2	Information Technology	47	t
68	2	Business Administration	45	t
69	2	Computer Science	44	t
70	2	Manufacturing Engineering	44	t
71	2	Human Resource Management	43	t
72	2	English	39	t
73	2	Psychology	38	t
74	2	International Business	36	t
75	2	 English Language and Literature	33	t
76	2	History	33	t
77	2	Physics	32	t
78	2	Geography	30	t
79	2	Automotive	29	t
80	2	Management	28	t
81	2	Business and Finance	28	t
82	2	Engineering Management	24	t
83	2	Vehicle Maintenance and Repair Technologies	24	t
84	2	Chemistry	24	t
85	2	Project Management	22	t
86	2	Aeronautical Engineering	22	t
87	2	Automotive Design	21	t
88	2	Industrial and Product Design	20	t
89	2	Engineering Business Management	20	t
90	2	Manufacturing Systems Engineering	20	t
91	2	Motor Vehicle Engineering	20	t
92	2	Mechanical	19	t
93	2	Automobile/Automotive Mechanics Technology/Technician	18	t
94	2	Finance	18	t
95	2	Electronic Engineering	18	t
96	2	 Aerospace	18	t
97	2	Computing	18	t
98	2	Education	18	t
99	2	GCSE's	17	t
100	2	Motorsport Technology	16	t
151	8	Medicine	1318	t
152	8	 Bachelor of Surgery (MBBS)	1098	t
153	8	Registered Nursing/Registered Nurse	660	t
154	8	Dentistry	492	t
155	8	Physiotherapy	438	t
156	8	Occupational Therapy/Therapist	365	t
157	8	Psychology	363	t
158	8	Biomedical Sciences	362	t
159	8	Adult Health Nurse/Nursing	299	t
160	8	Pharmacy	283	t
161	8	Nursing	271	t
162	8	 Business Administration and Management	246	t
163	8	Public Health	245	t
164	8	Health/Health Care Administration/Management	208	t
165	8	Health and Social Care	196	t
166	8	Social Work	182	t
167	8	Business	163	t
168	8	Optometry	153	t
169	8	Adult Nursing	128	t
170	8	Clinical Psychology	121	t
171	8	Law	117	t
172	8	Human Resource Management	103	t
173	8	Biology	92	t
174	8	Speech and Language Therapy	91	t
175	8	Management	88	t
176	8	Accounting	86	t
177	8	 Health Services/Allied Health/Health Sciences	85	t
178	8	Psychiatric/Mental Health Nurse/Nursing	81	t
179	8	Business Studies	78	t
180	8	Direct Entry Midwifery	78	t
181	8	Accounting and Finance	78	t
182	8	Business Administration	77	t
183	8	Physical Therapy/Therapist	70	t
184	8	Education	70	t
185	8	Midwifery	70	t
186	8	Dietetics/Dietitian	69	t
187	8	English	69	t
188	8	Business Management	69	t
189	8	Computer Science	67	t
190	8	Marketing	66	t
191	8	Information Technology	66	t
192	8	Mathematics	63	t
193	8	Mental Health Nursing	62	t
194	8	Diagnostic Radiography	62	t
195	8	Social Sciences	60	t
196	8	 English Language and Literature	60	t
197	8	Nurse Midwife/Nursing Midwifery	59	t
198	8	Neuroscience	59	t
199	8	Audiology/Audiologist	58	t
200	8	History	58	t
201	9	Accounting and Finance	4241	t
202	9	Economics	3381	t
203	9	Accounting	3045	t
204	9	Finance	2254	t
205	9	Mathematics	1702	t
206	9	Law	1094	t
207	9	Business	1048	t
208	9	Business Studies	761	t
209	9	 Business Administration and Management	744	t
210	9	Computer Science	737	t
211	9	Business Management	607	t
212	9	History	503	t
213	9	Management	464	t
214	9	International Business	454	t
215	9	Accounting and Business/Management	438	t
216	9	Marketing	416	t
217	9	Psychology	405	t
218	9	Business Administration	398	t
219	9	Geography	381	t
220	9	Physics	345	t
221	9	Information Technology	285	t
222	9	 Banking	284	t
223	9	Business and Finance	279	t
224	9	Chemistry	268	t
225	9	Banking and Finance	259	t
226	9	Economics and Finance	255	t
227	9	Finance and Investment	228	t
228	9	English	214	t
229	9	Financial Mathematics	213	t
230	9	Human Resource Management	209	t
231	9	Finance and Financial Management Services	205	t
232	9	Business Economics	197	t
233	9	Politics	191	t
234	9	ACCA	188	t
235	9	Mechanical Engineering	170	t
236	9	Financial Services	170	t
237	9	Actuarial Science	168	t
238	9	Computing	167	t
239	9	English Literature	167	t
240	9	Engineering	164	t
241	9	Financial Economics	163	t
242	9	Philosophy	160	t
243	9	Project Management	158	t
245	9	Management Accounting	155	t
246	9	Mathematics and Statistics	154	t
247	9	Accounting and Financial Management	142	t
248	9	Chartered Accountant	137	t
249	9	Finance and Economics	133	t
244	9	English Language and Literature	157	t
250	9	International Finance	128	t
251	10	Biotechnology	163	t
252	10	Biochemistry	145	t
253	10	Biomedical Sciences	109	t
254	10	Biology	106	t
255	10	Chemistry	61	t
256	10	Molecular Biology	59	t
257	10	Microbiology	46	t
258	10	Biochemical Engineering	42	t
259	10	Physics	38	t
260	10	Genetics	30	t
261	10	Biological Sciences	27	t
262	10	Immunology	27	t
263	10	Biochemistry and Molecular Biology	27	t
264	10	Biomedical/Medical Engineering	26	t
265	10	Nanotechnology	24	t
266	10	Bioinformatics	22	t
267	10	Cell/Cellular and Molecular Biology	21	t
268	10	Pharmacology	18	t
269	10	Bioengineering and Biomedical Engineering	18	t
270	10	Forensic Science	18	t
271	10	Materials Science	17	t
272	10	Biological and Biomedical Sciences	16	t
273	10	Electrical and Electronics Engineering	15	t
274	10	Chemical Engineering	15	t
275	10	Neuroscience	15	t
276	10	Business	14	t
277	10	Mechanical Engineering	14	t
278	10	Molecular Medicine	13	t
279	10	Biomedical Engineering	13	t
280	10	Engineering	11	t
281	10	Biosciences	11	t
282	10	Computer Science	10	t
283	10	Virology	10	t
284	10	Structural Biology	10	t
285	10	Applied Biology	9	t
286	10	Microbiology and Immunology	9	t
287	10	Business Studies	9	t
288	10	Life Sciences	9	t
289	10	Forensic Biology	9	t
290	10	Analytical Chemistry	9	t
291	10	 Business Administration and Management	9	t
292	10	 PhD	9	t
293	10	Oncology and Cancer Biology	8	t
294	10	Molecular Genetics	8	t
295	10	Mathematics	8	t
296	10	Marketing	8	t
297	10	Medical Biotechnology	8	t
298	10	Cell Biology	8	t
299	10	Accounting	7	t
300	10	Law	7	t
301	11	Mechanical Engineering	2150	t
302	11	Engineering	319	t
303	11	Electrical and Electronics Engineering	196	t
304	11	Business	94	t
305	11	 Business Administration and Management	89	t
306	11	Manufacturing Engineering	78	t
307	11	Business Administration	58	t
308	11	Business Studies	57	t
309	11	Marketing	52	t
310	11	Mathematics	48	t
311	11	Building Services Engineering	46	t
312	11	Chemical Engineering	46	t
313	11	Mechanical & Production Engineering	45	t
314	11	 Mechatronics	43	t
315	11	Mechanical	43	t
316	11	Business Management	43	t
317	11	Electrical Engineering	42	t
318	11	Accounting	41	t
319	11	Management	38	t
320	11	Project Management	37	t
321	11	Engineering Design	37	t
322	11	Mechanical and Manufacturing Engineering	36	t
323	11	Physics	35	t
324	11	Computer Science	33	t
325	11	Economics	32	t
326	11	Industrial Engineering	30	t
327	11	Accounting and Finance	30	t
328	11	 Aerospace	30	t
329	11	Product Design Engineering	29	t
330	11	Materials Engineering	27	t
331	11	Chemistry	26	t
332	11	Information Technology	25	t
333	11	English	24	t
334	11	Aerospace Engineering	24	t
335	11	Engineering Management	24	t
336	11	Motorsport Engineering	23	t
337	11	Building Services	23	t
338	11	International Business	23	t
339	11	Advanced Mechanical Engineering	22	t
340	11	Human Resource Management	22	t
341	11	Agricultural Engineering	21	t
342	11	Materials Science	21	t
343	11	Industrial and Product Design	21	t
344	11	Marine Engineering	20	t
345	11	Automotive Engineering	19	t
346	11	Electronic Engineering	19	t
347	11	Production Engineering	18	t
348	11	 Heating	18	t
349	11	Civil Engineering	18	t
350	11	Product Design	18	t
351	12	Electrical and Electronics Engineering	892	t
352	12	Electronic Engineering	156	t
353	12	Electrical Engineering	115	t
354	12	Electronics	104	t
355	12	Mechanical Engineering	100	t
356	12	Business	96	t
357	12	Engineering	92	t
358	12	Physics	84	t
359	12	Business Studies	71	t
360	12	Computer Science	68	t
361	12	 Business Administration and Management	57	t
362	12	Electronic and Electrical Engineering	53	t
363	12	Marketing	51	t
364	12	Business Administration	49	t
365	12	Mathematics	48	t
366	12	Business Management	44	t
367	12	Information Technology	39	t
368	12	Economics	35	t
369	12	 Mechatronics	35	t
370	12	International Business	32	t
371	12	Accounting	31	t
372	12	Electrician	28	t
373	12	Law	27	t
374	12	Electronics and Communications Engineering	27	t
375	12	Electrical Installation	27	t
376	12	Computing	25	t
377	12	Psychology	24	t
378	12	Accounting and Finance	24	t
379	12	English	22	t
380	12	Electrical Engineering Technologies/Technicians	20	t
381	12	Business and Finance	20	t
382	12	Management	19	t
383	12	English Language and Literature	18	t
384	12	Human Resource Management	18	t
385	12	Engineering Management	17	t
386	12	History	17	t
387	12	Chemistry	17	t
388	12	Industrial and Product Design	16	t
389	12	Microelectronics	16	t
390	12	Computer Engineering	14	t
391	12	Graphic Design	14	t
392	12	Electronics and Communication	13	t
393	12	Project Management	13	t
394	12	Electrical and Electronics	12	t
395	12	Robotics	12	t
396	12	Sociology	11	t
397	12	Electrical and Mechanical Engineering	11	t
398	12	Electrical Power Engineering	11	t
399	12	Power Electronics	11	t
400	12	Control Systems	11	t
\.


--
-- Name: sector_subject_id_seq; Type: SEQUENCE SET; Schema: public; Owner: geektalent
--

SELECT pg_catalog.setval('sector_subject_id_seq', 400, true);


--
-- Name: career_company_career_id_company_name_key; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY career_company
    ADD CONSTRAINT career_company_career_id_company_name_key UNIQUE (career_id, company_name);


--
-- Name: career_company_pkey; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY career_company
    ADD CONSTRAINT career_company_pkey PRIMARY KEY (id);


--
-- Name: career_institute_career_id_institute_name_key; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY career_institute
    ADD CONSTRAINT career_institute_career_id_institute_name_key UNIQUE (career_id, institute_name);


--
-- Name: career_institute_pkey; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY career_institute
    ADD CONSTRAINT career_institute_pkey PRIMARY KEY (id);


--
-- Name: career_pkey; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY career
    ADD CONSTRAINT career_pkey PRIMARY KEY (id);


--
-- Name: career_sector_id_title_key; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY career
    ADD CONSTRAINT career_sector_id_title_key UNIQUE (sector_id, title);


--
-- Name: career_skill_career_id_skill_name_key; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY career_skill
    ADD CONSTRAINT career_skill_career_id_skill_name_key UNIQUE (career_id, skill_name);


--
-- Name: career_skill_pkey; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY career_skill
    ADD CONSTRAINT career_skill_pkey PRIMARY KEY (id);


--
-- Name: career_subject_career_id_subject_name_key; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY career_subject
    ADD CONSTRAINT career_subject_career_id_subject_name_key UNIQUE (career_id, subject_name);


--
-- Name: career_subject_pkey; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY career_subject
    ADD CONSTRAINT career_subject_pkey PRIMARY KEY (id);


--
-- Name: entity_description_entity_type_linkedin_sector_entity_name_key; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY entity_description
    ADD CONSTRAINT entity_description_entity_type_linkedin_sector_entity_name_key UNIQUE (entity_type, linkedin_sector, entity_name);


--
-- Name: entity_description_pkey; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY entity_description
    ADD CONSTRAINT entity_description_pkey PRIMARY KEY (id);


--
-- Name: next_title_career_id_next_title_key; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY next_title
    ADD CONSTRAINT next_title_career_id_next_title_key UNIQUE (career_id, next_title);


--
-- Name: next_title_pkey; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY next_title
    ADD CONSTRAINT next_title_pkey PRIMARY KEY (id);


--
-- Name: previous_title_career_id_previous_title_key; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY previous_title
    ADD CONSTRAINT previous_title_career_id_previous_title_key UNIQUE (career_id, previous_title);


--
-- Name: previous_title_pkey; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY previous_title
    ADD CONSTRAINT previous_title_pkey PRIMARY KEY (id);


--
-- Name: salary_bin_pkey; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY salary_bin
    ADD CONSTRAINT salary_bin_pkey PRIMARY KEY (id);


--
-- Name: salary_history_point_pkey; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY salary_history_point
    ADD CONSTRAINT salary_history_point_pkey PRIMARY KEY (id);


--
-- Name: sector_company_pkey; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY sector_company
    ADD CONSTRAINT sector_company_pkey PRIMARY KEY (id);


--
-- Name: sector_company_sector_id_company_name_key; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY sector_company
    ADD CONSTRAINT sector_company_sector_id_company_name_key UNIQUE (sector_id, company_name);


--
-- Name: sector_institute_pkey; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY sector_institute
    ADD CONSTRAINT sector_institute_pkey PRIMARY KEY (id);


--
-- Name: sector_institute_sector_id_institute_name_key; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY sector_institute
    ADD CONSTRAINT sector_institute_sector_id_institute_name_key UNIQUE (sector_id, institute_name);


--
-- Name: sector_name_key; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY sector
    ADD CONSTRAINT sector_name_key UNIQUE (name);


--
-- Name: sector_pkey; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY sector
    ADD CONSTRAINT sector_pkey PRIMARY KEY (id);


--
-- Name: sector_skill_pkey; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY sector_skill
    ADD CONSTRAINT sector_skill_pkey PRIMARY KEY (id);


--
-- Name: sector_skill_sector_id_skill_name_key; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY sector_skill
    ADD CONSTRAINT sector_skill_sector_id_skill_name_key UNIQUE (sector_id, skill_name);


--
-- Name: sector_subject_pkey; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY sector_subject
    ADD CONSTRAINT sector_subject_pkey PRIMARY KEY (id);


--
-- Name: sector_subject_sector_id_subject_name_key; Type: CONSTRAINT; Schema: public; Owner: geektalent; Tablespace: 
--

ALTER TABLE ONLY sector_subject
    ADD CONSTRAINT sector_subject_sector_id_subject_name_key UNIQUE (sector_id, subject_name);


--
-- Name: ix_career_company_career_id; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_career_company_career_id ON career_company USING btree (career_id);


--
-- Name: ix_career_company_company_name; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_career_company_company_name ON career_company USING btree (company_name);


--
-- Name: ix_career_institute_career_id; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_career_institute_career_id ON career_institute USING btree (career_id);


--
-- Name: ix_career_institute_institute_name; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_career_institute_institute_name ON career_institute USING btree (institute_name);


--
-- Name: ix_career_sector_id; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_career_sector_id ON career USING btree (sector_id);


--
-- Name: ix_career_skill_career_id; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_career_skill_career_id ON career_skill USING btree (career_id);


--
-- Name: ix_career_skill_skill_name; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_career_skill_skill_name ON career_skill USING btree (skill_name);


--
-- Name: ix_career_subject_career_id; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_career_subject_career_id ON career_subject USING btree (career_id);


--
-- Name: ix_career_subject_subject_name; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_career_subject_subject_name ON career_subject USING btree (subject_name);


--
-- Name: ix_career_title; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_career_title ON career USING btree (title);


--
-- Name: ix_entity_description_entity_name; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_entity_description_entity_name ON entity_description USING btree (entity_name);


--
-- Name: ix_entity_description_entity_type; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_entity_description_entity_type ON entity_description USING btree (entity_type);


--
-- Name: ix_entity_description_linkedin_sector; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_entity_description_linkedin_sector ON entity_description USING btree (linkedin_sector);


--
-- Name: ix_next_title_career_id; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_next_title_career_id ON next_title USING btree (career_id);


--
-- Name: ix_next_title_next_title; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_next_title_next_title ON next_title USING btree (next_title);


--
-- Name: ix_previous_title_career_id; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_previous_title_career_id ON previous_title USING btree (career_id);


--
-- Name: ix_previous_title_previous_title; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_previous_title_previous_title ON previous_title USING btree (previous_title);


--
-- Name: ix_salary_bin_career_id; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_salary_bin_career_id ON salary_bin USING btree (career_id);


--
-- Name: ix_salary_history_point_career_id; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_salary_history_point_career_id ON salary_history_point USING btree (career_id);


--
-- Name: ix_sector_company_company_name; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_sector_company_company_name ON sector_company USING btree (company_name);


--
-- Name: ix_sector_company_sector_id; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_sector_company_sector_id ON sector_company USING btree (sector_id);


--
-- Name: ix_sector_institute_institute_name; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_sector_institute_institute_name ON sector_institute USING btree (institute_name);


--
-- Name: ix_sector_institute_sector_id; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_sector_institute_sector_id ON sector_institute USING btree (sector_id);


--
-- Name: ix_sector_name; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_sector_name ON sector USING btree (name);


--
-- Name: ix_sector_skill_sector_id; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_sector_skill_sector_id ON sector_skill USING btree (sector_id);


--
-- Name: ix_sector_skill_skill_name; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_sector_skill_skill_name ON sector_skill USING btree (skill_name);


--
-- Name: ix_sector_subject_sector_id; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_sector_subject_sector_id ON sector_subject USING btree (sector_id);


--
-- Name: ix_sector_subject_subject_name; Type: INDEX; Schema: public; Owner: geektalent; Tablespace: 
--

CREATE INDEX ix_sector_subject_subject_name ON sector_subject USING btree (subject_name);


--
-- Name: career_company_career_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY career_company
    ADD CONSTRAINT career_company_career_id_fkey FOREIGN KEY (career_id) REFERENCES career(id);


--
-- Name: career_institute_career_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY career_institute
    ADD CONSTRAINT career_institute_career_id_fkey FOREIGN KEY (career_id) REFERENCES career(id);


--
-- Name: career_sector_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY career
    ADD CONSTRAINT career_sector_id_fkey FOREIGN KEY (sector_id) REFERENCES sector(id);


--
-- Name: career_skill_career_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY career_skill
    ADD CONSTRAINT career_skill_career_id_fkey FOREIGN KEY (career_id) REFERENCES career(id);


--
-- Name: career_subject_career_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY career_subject
    ADD CONSTRAINT career_subject_career_id_fkey FOREIGN KEY (career_id) REFERENCES career(id);


--
-- Name: next_title_career_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY next_title
    ADD CONSTRAINT next_title_career_id_fkey FOREIGN KEY (career_id) REFERENCES career(id);


--
-- Name: previous_title_career_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY previous_title
    ADD CONSTRAINT previous_title_career_id_fkey FOREIGN KEY (career_id) REFERENCES career(id);


--
-- Name: salary_bin_career_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY salary_bin
    ADD CONSTRAINT salary_bin_career_id_fkey FOREIGN KEY (career_id) REFERENCES career(id);


--
-- Name: salary_history_point_career_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY salary_history_point
    ADD CONSTRAINT salary_history_point_career_id_fkey FOREIGN KEY (career_id) REFERENCES career(id);


--
-- Name: sector_company_sector_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY sector_company
    ADD CONSTRAINT sector_company_sector_id_fkey FOREIGN KEY (sector_id) REFERENCES sector(id);


--
-- Name: sector_institute_sector_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY sector_institute
    ADD CONSTRAINT sector_institute_sector_id_fkey FOREIGN KEY (sector_id) REFERENCES sector(id);


--
-- Name: sector_skill_sector_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY sector_skill
    ADD CONSTRAINT sector_skill_sector_id_fkey FOREIGN KEY (sector_id) REFERENCES sector(id);


--
-- Name: sector_subject_sector_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: geektalent
--

ALTER TABLE ONLY sector_subject
    ADD CONSTRAINT sector_subject_sector_id_fkey FOREIGN KEY (sector_id) REFERENCES sector(id);


--
-- PostgreSQL database dump complete
--

